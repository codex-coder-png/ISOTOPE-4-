/* ISOTOPE V50 — FINALE OVERHAUL
 * Built on the original isotope-fixed.zip codebase.
 * This layer is intentionally additive: older game systems remain available,
 * while V50 supplies the final compound catalogue, card rebalance, nicotine
 * safety/abilities, relic synchronization, mastery refresh, and UI/update-log fixes.
 */
'use strict';
(function(){
  if(window.__ISO_V50_FINALE__) return;
  window.__ISO_V50_FINALE__ = true;

  const CORE = window.ISO_V23_CORE || {};
  const DATA = window.DATA || {};
  const SAVE = window.SAVE || {};
  const CARD_MUL = {common:1, uncommon:1.25, rare:1.5, epic:1.9, legendary:2.4, mythic:3.2};
  const clamp = (v,a,b)=>v<a?a:v>b?b:v;
  const TAU = Math.PI*2;
  const now = ()=>performance.now();
  const run = ()=>window.RUN || null;
  const alive = e=>e && !e.dead && !e._v29Converted && e.team!=='player' && Number(e.hp)>0;
  const dist2 = (a,b,x,y)=>{const dx=a-x,dy=b-y;return dx*dx+dy*dy;};
  const hash = s=>{let h=2166136261>>>0;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return h>>>0;};
  const slug = s=>String(s||'compound').toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_+|_+$/g,'').slice(0,54)||'compound';
  const formulaKey = f=>{
    const a=[]; String(f||'').replace(/([A-Z][a-z]?)(\d*)/g,(_,e,n)=>a.push([e,Math.max(1,Number(n||1))]));
    a.sort((x,y)=>x[0].localeCompare(y[0])); return a.map(x=>x[0]+(x[1]>1?x[1]:'' )).join('+');
  };
  const parseFormula = f=>{const out={};String(f||'').replace(/([A-Z][a-z]?)(\d*)/g,(_,e,n)=>out[e]=(out[e]||0)+Math.max(1,Number(n||1)));return out;};
  const massOfFormula = f=>{const aw={H:1.008,C:12.011,N:14.007,O:15.999,F:18.998,Na:22.990,Mg:24.305,Al:26.982,Si:28.085,P:30.974,S:32.06,Cl:35.45,K:39.098,Ca:40.078,Ti:47.867,Cr:51.996,Mn:54.938,Fe:55.845,Co:58.933,Ni:58.693,Cu:63.546,Zn:65.38,Br:79.904,Ag:107.868,I:126.904,Ba:137.327,Pt:195.084,Au:196.967,Hg:200.592,Pb:207.2, Bi:208.98, U:238.029};const p=parseFormula(f);return Object.keys(p).reduce((s,e)=>s+(aw[e]||70)*p[e],0);};
  const chemClass = (m)=>{
    const n=String(m.name||'').toLowerCase(), f=String(m.f||'').toUpperCase();
    if(/nicotine|cotinine/.test(n))return'neuro';
    if(/creatine|glucose|fructose|sucrose|lactose|maltose|ribose|deoxyribose|adenosine|guanosine|cytidine|uridine|thymidine|inosine|glutathione|taurine|vitamin|retinol|tocopherol|riboflavin|thiamine|pyridoxine|biotin|folic|pantothenic|carnitine|choline/.test(n))return'bio';
    if(/aspirin|ibuprofen|acetaminophen|paracetamol|naproxen|salbutamol|lidocaine|tetracaine|metformin|caffeine|theobromine|xanthine/.test(n))return'medicine';
    if(/acid$|acid |anhydride|peroxide|permanganate|chlorate|perchlorate|nitrate|nitrite|chromate|dichromate|hypochlorite/.test(n))return'oxidizer';
    if(/alkali|hydroxide|bicarbonate|carbonate|chloride|bromide|iodide|sulfate|sulfite|phosphate|fluoride|cyanide|thiocyanate|oxide|sulfide/.test(n))return'ionic';
    if(/[A-Z]?[0-9]*[A-Z].*[A-Z]/.test(f) && /Na|K|Ca|Mg|Fe|Cu|Zn|Ag|Ba|Sr|Li/.test(f))return'ionic';
    if(/benz|phenyl|naph|anthrac|biphenyl|tolu|ethylbenz|styrene/.test(n))return'aromatic';
    if(/methane|ethane|propane|butane|pentane|hexane|heptane|octane|alkene|alkyne|acetylene|ethylene|propylene|benzene|toluene/.test(n))return'fuel';
    if(/ammonia|chlorine|fluorine|hydrogen sulfide|carbon monoxide|carbon dioxide|nitric oxide|nitrous oxide|sulfur dioxide/.test(n))return'gas';
    return 'general';
  };
  const baseCombat = m=>{try{return DATA.baseCombat?DATA.baseCombat(m):{dmg:1.05,rate:1,ps:410,hp:100};}catch(_){return{dmg:1.05,rate:1,ps:410,hp:100};}};
  const isHostish = r=>!!r && (!r.isOnline || (window.NET && NET.isHost));
  const playerHue = p=>Number.isFinite(+p?.elem?.hue)?+p.elem.hue:Number(run()?.hue||190);
  const enemyList = ()=>{const r=run();return r&&Array.isArray(r.enemies)?r.enemies.filter(alive):[];};
  const players = ()=>{const r=run();return r&&Array.isArray(r.players)?r.players:[];};
  const fxBurst=(x,y,hue,n=12)=>{try{if(window.fxBurst)window.fxBurst(x,y,hue,n);else if(run()&&run().parts)for(let i=0;i<n;i++)run().parts.push({x,y,vx:(Math.random()-.5)*180,vy:(Math.random()-.5)*180,t:.35,life:.35,hue,r:2});}catch(_){}};
  const fxRing=(x,y,hue,r=80,w=7,life=.35)=>{try{if(window.fxRing)window.fxRing(x,y,hue,r,w,life);else if(window.ringFx)window.ringFx(x,y,hue,r,w);}catch(_){}};
  const pushText=(x,y,t,hue)=>{const r=run();if(r&&r.texts)r.texts.push({x,y,s:t,t:.9,life:.9,hue});};
  const withPlayerContext=(p,fn)=>{
    const r=run(); if(!r||!p||!p.elem||p.elem===r.el)return fn();
    const oldEl=r.el,oldStyle=r.style,oldHue=r.hue;
    try{r.el=p.elem;r.style=(DATA.baseCombat&&DATA.baseCombat(p.elem)||{}).style||oldStyle;r.hue=p.elem.hue;CORE.getComputeStats&&CORE.getComputeStats()();return fn();}
    finally{r.el=oldEl;r.style=oldStyle;r.hue=oldHue;try{CORE.getComputeStats&&CORE.getComputeStats()();}catch(_){}}
  };
  const damage=(e,v,opts)=>{try{if(window.dmgEnemy)window.dmgEnemy(e,v,opts||{});else{e.hp-=v;if(e.hp<=0)e.dead=true;}}catch(_){}};
  const aoe=(x,y,radius,amount,hue)=>{try{if(window.aoe)window.aoe(x,y,radius,amount,hue);else enemyList().forEach(e=>{if(dist2(e.x,e.y,x,y)<radius*radius)damage(e,amount);});}catch(_){}};
  const status=(e,k,power)=>{try{if(k==='burn'&&window.addBurn)window.addBurn(e,power*.3,3.2);if(k==='freeze'&&window.addFreeze)window.addFreeze(e,1.35);if(k==='corrode'&&window.addCorrode)window.addCorrode(e,4,.34);if(k==='rust'&&window.addRust)window.addRust(e,3.6,.72);if(k==='shock'&&((window.addShock)||CORE.addShock))(window.addShock||CORE.addShock)(e,1.4);if(k==='brittle'&&window.addBrittle)window.addBrittle(e,3.5);if(k==='drenched'&&((window.addDrenched)||CORE.addDrenched))(window.addDrenched||CORE.addDrenched)(e,2.8);}catch(_){}}
  const fireBeam=(p,m,extra={})=>{
    const r=run();if(!r)return;
    const hue=playerHue(p), a=Number.isFinite(+p.angle)?+p.angle:Math.atan2((window.mouse?.y||p.y)-p.y,(window.mouse?.x||p.x)-p.x);
    const mass=massOfFormula(m.f), hetero=Object.keys(parseFormula(m.f)).filter(e=>e!=='C'&&e!=='H').length;
    const bc=baseCombat(m); const realPower=clamp(.82+(Number(bc.dmg)||1)*.33+mass/520+hetero*.05+(extra.power||0),.8,3.4);
    const width=7+realPower*7+(extra.width||0), len=170+realPower*145, x2=clamp(p.x+Math.cos(a)*len,20,window.W-20), y2=clamp(p.y+Math.sin(a)*len,20,window.H-20);
    const dmgAmt=(Number(window.ST?.dmg)||18)*(1.05+realPower*.72)*(extra.damageMul||1);
    const beam={x:p.x,y:p.y,x2,y2,width,life:.28,max:.28,hue,realPower,compound:m.name}; r._isoV50Beams=r._isoV50Beams||[];r._isoV50Beams.push(beam);
    enemyList().forEach(e=>{
      const vx=x2-p.x,vy=y2-p.y,wx=e.x-p.x,wy=e.y-p.y,den=vx*vx+vy*vy||1,t=clamp((wx*vx+wy*vy)/den,0,1),px=p.x+vx*t,py=p.y+vy*t;
      if(dist2(e.x,e.y,px,py)<(width+e.r)*(width+e.r)){damage(e,dmgAmt,{quiet:true,pierce:true});if(extra.status)status(e,extra.status,realPower);if(extra.cripple)e.slowT=Math.max(e.slowT||0,extra.cripple);}
    });
    fxRing(p.x,p.y,hue,45,4,.2);fxBurst(x2,y2,hue,8);
    return realPower;
  };
  const burstAt=(p,m,extra={})=>{
    const r=run();if(!r)return;
    const x=clamp(Number(window.mouse?.x)||p.x,20,window.W-20),y=clamp(Number(window.mouse?.y)||p.y,20,window.H-20);
    const mass=massOfFormula(m.f), power=clamp(.9+(mass/300)+(Number(baseCombat(m).dmg)||1)*.25+(extra.power||0),.9,3.5),radius=75+power*45;
    aoe(x,y,radius,(Number(window.ST?.dmg)||18)*(1.15+power*.8)*(extra.damageMul||1),playerHue(p));
    enemyList().forEach(e=>{if(dist2(e.x,e.y,x,y)<radius*radius){if(extra.status)status(e,extra.status,power);if(extra.pull){const a=Math.atan2(y-e.y,x-e.x);e.x+=Math.cos(a)*36*power;e.y+=Math.sin(a)*36*power;}if(extra.slow)e.slowT=Math.max(e.slowT||0,extra.slow);}});
    r._isoV50Bursts=r._isoV50Bursts||[];r._isoV50Bursts.push({x,y,r:radius,t:.45,life:.45,hue:playerHue(p),power});
    fxBurst(x,y,playerHue(p),Math.round(18+power*7));fxRing(x,y,playerHue(p),radius,7,.5);
  };
  const later=(r,ms,fn)=>setTimeout(()=>{if(window.RUN===r)try{fn();}catch(e){console.error('V50 delayed action',e);}},ms);

  // ---- 1) Famous-compound expansion: add only genuinely missing formula keys. ----
  const FAMOUS = [
{name:'Acetic Anhydride',formula:'C4H6O3'},
{name:'Acetyl Chloride',formula:'C2H3ClO'},
{name:'Methyl Acetate',formula:'C3H6O2'},
{name:'Propyl Acetate',formula:'C5H10O2'},
{name:'Amyl Acetate',formula:'C7H14O2'},
{name:'Methyl Benzoate',formula:'C8H8O2'},
{name:'Ethyl Benzoate',formula:'C9H10O2'},
{name:'Benzyl Alcohol',formula:'C7H8O'},
{name:'Benzaldehyde',formula:'C7H6O'},
{name:'Acetophenone',formula:'C8H8O'},
{name:'Benzophenone',formula:'C13H10O'},
{name:'Naphthalene',formula:'C10H8'},
{name:'Anthracene',formula:'C14H10'},
{name:'Biphenyl',formula:'C12H10'},
{name:'Ethylbenzene',formula:'C8H10'},
{name:'Phenylacetylene',formula:'C8H6'},
{name:'Styrene Oxide',formula:'C8H8O'},
{name:'Resorcinol',formula:'C6H6O2'},
{name:'Phthalic Acid',formula:'C8H6O4'},
{name:'Maleic Acid',formula:'C4H4O4'},
{name:'Glutaric Acid',formula:'C5H8O4'},
{name:'Adipic Acid',formula:'C6H10O4'},
{name:'Butyric Acid',formula:'C4H8O2'},
{name:'Propionic Acid',formula:'C3H6O2'},
{name:'Valeric Acid',formula:'C5H10O2'},
{name:'Caproic Acid',formula:'C6H12O2'},
{name:'Palmitic Acid',formula:'C16H32O2'},
{name:'Stearic Acid',formula:'C18H36O2'},
{name:'Oleic Acid',formula:'C18H34O2'},
{name:'Linoleic Acid',formula:'C18H32O2'},
{name:'Pyruvic Acid',formula:'C3H4O3'},
{name:'Acetoacetic Acid',formula:'C4H6O3'},
{name:'Gluconic Acid',formula:'C6H12O7'},
{name:'Ascorbic Acid',formula:'C6H8O6'},
{name:'Dehydroascorbic Acid',formula:'C6H6O6'},
{name:'Glyceraldehyde',formula:'C3H6O3'},
{name:'Triacetin',formula:'C9H14O6'},
{name:'Ethylene Glycol Dinitrate',formula:'C2H4N2O6'},
{name:'Caffeine',formula:'C8H10N4O2'},
{name:'Cotinine',formula:'C10H12N2O'},
{name:'Quinine',formula:'C20H24N2O2'},
{name:'Warfarin',formula:'C19H16O4'},
{name:'Lidocaine',formula:'C14H22N2O'},
{name:'Benzocaine',formula:'C9H11NO2'},
{name:'Procaine',formula:'C13H20N2O2'},
{name:'Tetracaine',formula:'C15H24N2O2'},
{name:'Allopurinol',formula:'C5H4N4O'},
{name:'Barbituric Acid',formula:'C4H4N2O3'},
{name:'Histamine',formula:'C5H9N3'},
{name:'Choline',formula:'C5H14NO'},
{name:'Betaine',formula:'C5H11NO2'},
{name:'Carnitine',formula:'C7H15NO3'},
{name:'Purine',formula:'C5H4N4'},
{name:'Adenine',formula:'C5H5N5'},
{name:'Guanine',formula:'C5H5N5O'},
{name:'Cytosine',formula:'C4H5N3O'},
{name:'Thymine',formula:'C5H6N2O2'},
{name:'Uracil',formula:'C4H4N2O2'},
{name:'Creatinine',formula:'C4H7N3O'},
{name:'Uric Acid',formula:'C5H4N4O3'},
{name:'Nicotinamide',formula:'C6H6N2O'},
{name:'Nicotinic Acid',formula:'C6H5NO2'},
{name:'Pyridine',formula:'C5H5N'},
{name:'Pyrrole',formula:'C4H5N'},
{name:'Piperidine',formula:'C5H11N'},
{name:'Pyrrolidine',formula:'C4H9N'},
{name:'Morpholine',formula:'C4H9NO'},
{name:'Imidazole',formula:'C3H4N2'},
{name:'Pyrazine',formula:'C4H4N2'},
{name:'Dimethylformamide',formula:'C3H7NO'},
{name:'Dimethylacetamide',formula:'C4H9NO'},
{name:'Menthol',formula:'C10H20O'},
{name:'Thymol',formula:'C10H14O'},
{name:'Vanillin',formula:'C8H8O3'},
{name:'Cinnamaldehyde',formula:'C9H8O'},
{name:'Limonene',formula:'C10H16'},
{name:'Camphor',formula:'C10H16O'},
{name:'Borneol',formula:'C10H18O'},
{name:'Geraniol',formula:'C10H18O'},
{name:'Citronellol',formula:'C10H20O'},
{name:'Eugenol',formula:'C10H12O2'},
{name:'Isoeugenol',formula:'C10H12O2'},
{name:'Aniline',formula:'C6H7N'},
{name:'Nitrobenzene',formula:'C6H5NO2'},
{name:'Phenol',formula:'C6H6O'},
{name:'Anisole',formula:'C7H8O'},
{name:'Acetanilide',formula:'C8H9NO'},
{name:'Paracetamol',formula:'C8H9NO2'},
{name:'Naproxen',formula:'C14H14O3'},
{name:'Salbutamol',formula:'C13H21NO3'},
{name:'Metformin',formula:'C4H11N5'},
{name:'Melatonin',formula:'C13H16N2O2'},
{name:'Serotonin',formula:'C10H12N2O'},
{name:'Sodium Acetate',formula:'C2H3NaO2'},
{name:'Potassium Acetate',formula:'C2H3KO2'},
{name:'Lithium Acetate',formula:'C2H3LiO2'},
{name:'Sodium Benzoate',formula:'C7H5NaO2'},
{name:'Potassium Benzoate',formula:'C7H5KO2'},
{name:'Sodium Salicylate',formula:'C7H5NaO3'},
{name:'Potassium Salicylate',formula:'C7H5KO3'},
{name:'Sodium Citrate',formula:'Na3C6H5O7'},
{name:'Potassium Citrate',formula:'K3C6H5O7'},
{name:'Calcium Citrate',formula:'Ca3C12H10O14'},
{name:'Magnesium Citrate',formula:'Mg3C12H10O14'},
{name:'Sodium Oxalate',formula:'Na2C2O4'},
{name:'Potassium Oxalate',formula:'K2C2O4'},
{name:'Calcium Oxalate',formula:'CaC2O4'},
{name:'Magnesium Oxalate',formula:'MgC2O4'},
{name:'Sodium Tartrate',formula:'Na2C4H4O6'},
{name:'Potassium Tartrate',formula:'K2C4H4O6'},
{name:'Calcium Tartrate',formula:'CaC4H4O6'},
{name:'Sodium Malate',formula:'Na2C4H4O5'},
{name:'Potassium Malate',formula:'K2C4H4O5'},
{name:'Calcium Malate',formula:'CaC4H4O5'},
{name:'Sodium Succinate',formula:'Na2C4H4O4'},
{name:'Potassium Succinate',formula:'K2C4H4O4'},
{name:'Calcium Succinate',formula:'CaC4H4O4'},
{name:'Potassium Bicarbonate',formula:'KHCO3'},
{name:'Potassium Sulfate',formula:'K2SO4'},
{name:'Calcium Sulfate',formula:'CaSO4'},
{name:'Strontium Sulfate',formula:'SrSO4'},
{name:'Barium Sulfate',formula:'BaSO4'},
{name:'Barium Carbonate',formula:'BaCO3'},
{name:'Potassium Chromate',formula:'K2CrO4'},
{name:'Sodium Chromate',formula:'Na2CrO4'},
{name:'Potassium Dichromate',formula:'K2Cr2O7'},
{name:'Ammonium Perchlorate',formula:'NH4ClO4'},
{name:'Sodium Perchlorate',formula:'NaClO4'},
{name:'Lithium Fluoride',formula:'LiF'},
{name:'Sodium Bromate',formula:'NaBrO3'},
{name:'Potassium Bromate',formula:'KBrO3'},
{name:'Sodium Iodate',formula:'NaIO3'},
{name:'Potassium Iodate',formula:'KIO3'},
{name:'Sodium Thiosulfate',formula:'Na2S2O3'},
{name:'Potassium Thiocyanate',formula:'KSCN'},
{name:'Sodium Thiocyanate',formula:'NaSCN'},
{name:'Silver Nitrate',formula:'AgNO3'},
{name:'Copper Sulfate',formula:'CuSO4'},
{name:'Iron Sulfate',formula:'FeSO4'},
{name:'Zinc Sulfate',formula:'ZnSO4'},
{name:'Zinc Oxide',formula:'ZnO'},
{name:'Copper Oxide',formula:'CuO'},
{name:'Copper Sulfide',formula:'CuS'},
{name:'Iron Sulfide',formula:'FeS'},
{name:'Iron(II) Oxide',formula:'FeO'},
{name:'Iron(III) Oxide',formula:'Fe2O3'},
{name:'Manganese Dioxide',formula:'MnO2'},
{name:'Chromium(III) Oxide',formula:'Cr2O3'},
{name:'Titanium Dioxide',formula:'TiO2'},
{name:'Silicon Carbide',formula:'SiC'},
{name:'Silicon Tetrachloride',formula:'SiCl4'},
{name:'Boron Trifluoride',formula:'BF3'},
{name:'Sulfur Hexafluoride',formula:'SF6'},
{name:'Carbonyl Sulfide',formula:'COS'},
{name:'Thionyl Chloride',formula:'SOCl2'},
{name:'Phosphorus Pentachloride',formula:'PCl5'},
{name:'Phosphorus Trichloride',formula:'PCl3'},
{name:'Phosphoryl Chloride',formula:'POCl3'},
{name:'Sodium Azide',formula:'NaN3'},
{name:'Silver Azide',formula:'AgN3'},
{name:'Phosgene',formula:'COCl2'},
{name:'Cyanogen Chloride',formula:'CNCl'},
{name:'Ammonium Perchlorate',formula:'NH4ClO4'},
{name:'Dimethyl Sulfide',formula:'C2H6S'},
{name:'Dimethyl Sulfoxide',formula:'C2H6OS'},
{name:'Dimethyl Sulfone',formula:'C2H6O2S'},
{name:'Carbon Disulfide',formula:'CS2'},
{name:'Tetramethylsilane',formula:'C4H12Si'},
{name:'Trimethylsilanol',formula:'C3H10OSi'},
{name:'Triethylamine',formula:'C6H15N'},
{name:'Acetamide',formula:'C2H5NO'},
{name:'Formamide',formula:'CH3NO'},
{name:'Acetonitrile',formula:'C2H3N'},
{name:'Propionitrile',formula:'C3H5N'},
{name:'Benzonitrile',formula:'C7H5N'},
{name:'Urea Peroxide',formula:'CH6N2O3'},
{name:'Ammonium Bicarbonate',formula:'NH4HCO3'},
{name:'Malonic Acid',formula:'C3H4O4'},
{name:'Oxaloacetic Acid',formula:'C4H4O5'},
{name:'Tartaric Acid',formula:'C4H6O6'},
{name:'Salicylaldehyde',formula:'C7H6O2'},
{name:'Hydroxybenzoic Acid',formula:'C7H6O3'},
{name:'Trifluoroacetic Acid',formula:'C2HF3O2'},
{name:'Monochloroacetic Acid',formula:'C2H3ClO2'},
{name:'Dichloroacetic Acid',formula:'C2H2Cl2O2'},
{name:'Trichloroacetic Acid',formula:'C2HCl3O2'},
{name:'Chloral Hydrate',formula:'C2H3Cl3O2'},
{name:'Oxalyl Chloride',formula:'C2Cl2O2'},
{name:'Sulfuryl Chloride',formula:'Cl2O2S'},
{name:'Sulfuryl Fluoride',formula:'F2O2S'},
{name:'Chlorosulfuric Acid',formula:'HClO3S'},
{name:'Trichloromethyl Chloroformate',formula:'C2HCl3O2'},
{name:'Xanthine',formula:'C5H4N4O2'},
{name:'Hypoxanthine',formula:'C5H4N4O'},
{name:'Theobromine',formula:'C7H8N4O2'},
{name:'Guanosine',formula:'C10H13N5O5'},
{name:'Adenosine',formula:'C10H13N5O4'},
{name:'Cytidine',formula:'C9H14N3O5'},
{name:'Uridine',formula:'C9H12N2O6'},
{name:'Thymidine',formula:'C10H14N2O5'},
{name:'Inosine',formula:'C10H12N4O5'},
{name:'Deoxyadenosine',formula:'C10H13N5O3'},
{name:'Riboflavin',formula:'C17H20N4O6'},
{name:'Thiamine',formula:'C12H17N4OS'},
{name:'Pyridoxine',formula:'C8H11NO3'},
{name:'Biotin',formula:'C10H16N2O3S'},
{name:'Folic Acid',formula:'C19H19N7O6'},
{name:'Pantothenic Acid',formula:'C9H17NO5'},
{name:'Retinol',formula:'C20H30O'},
{name:'Beta-Carotene',formula:'C40H56'},
{name:'Tocopherol',formula:'C29H50O2'},
{name:'Coenzyme Q10',formula:'C59H90O4'},
{name:'Glutathione',formula:'C10H17N3O6S'},
{name:'Taurine',formula:'C2H7NO3S'},
{name:'Uric Acid',formula:'C5H4N4O3'},
{name:'Creatinine',formula:'C4H7N3O'},
{name:'Cotinine',formula:'C10H12N2O'},
{name:'Nicotinamide',formula:'C6H6N2O'},
{name:'Norepinephrine',formula:'C8H11NO3'},
{name:'Ammonium Sulfate',formula:'N2H8SO4'},
{name:'Ammonium Phosphate',formula:'H12N3PO4'},
{name:'Sodium Sulfite',formula:'Na2SO3'},
{name:'Potassium Sulfite',formula:'K2SO3'},
{name:'Sodium Metabisulfite',formula:'Na2S2O5'},
{name:'Potassium Metabisulfite',formula:'K2S2O5'},
{name:'Sodium Bisulfate',formula:'NaHSO4'},
{name:'Potassium Bisulfate',formula:'KHSO4'},
{name:'Sodium Silicate',formula:'Na2SiO3'},
{name:'Potassium Silicate',formula:'K2SiO3'},
{name:'Calcium Silicate',formula:'CaSiO3'},
{name:'Magnesium Silicate',formula:'MgSiO3'},
{name:'Sodium Aluminate',formula:'NaAlO2'},
{name:'Potassium Aluminate',formula:'KAlO2'},
{name:'Sodium Ferrate',formula:'Na2FeO4'},
{name:'Potassium Ferrate',formula:'K2FeO4'},
{name:'Potassium Cyanide',formula:'KCN'},
{name:'Calcium Cyanamide',formula:'CaCN2'},
{name:'Sodium Carbide',formula:'Na2C2'},
{name:'Magnesium Carbide',formula:'Mg2C3'},
{name:'Aluminum Nitride',formula:'AlN'},
{name:'Boron Nitride',formula:'BN'},
{name:'Silicon Nitride',formula:'Si3N4'},
{name:'Titanium Carbide',formula:'TiC'},
{name:'Tungsten Carbide',formula:'WC'},
{name:'Zirconium Carbide',formula:'ZrC'},
{name:'Tungsten Trioxide',formula:'WO3'},
{name:'Tungsten Hexachloride',formula:'WCl6'},
{name:'Vanadium Pentoxide',formula:'V2O5'},
{name:'Molybdenum Trioxide',formula:'MoO3'},
{name:'Potassium Chlorate',formula:'KClO3'},
{name:'Ammonium Chlorate',formula:'NH4ClO3'},
{name:'Chloramine',formula:'NH2Cl'},
{name:'Chloroform',formula:'CHCl3'},
{name:'Carbon Tetrachloride',formula:'CCl4'},
{name:'Dichloromethane',formula:'CH2Cl2'},
{name:'Trichloroethylene',formula:'C2HCl3'},
{name:'Tetrachloroethylene',formula:'C2Cl4'},
{name:'Hexafluorobenzene',formula:'C6F6'},
{name:'Sulfur Tetrafluoride',formula:'SF4'},
{name:'Sulfur Dichloride',formula:'SCl2'},
{name:'Disulfur Dichloride',formula:'S2Cl2'},
{name:'Chlorine Dioxide',formula:'ClO2'},
{name:'Nitrogen Trichloride',formula:'NCl3'},
{name:'Nitrogen Trifluoride',formula:'NF3'},
{name:'Bromine Pentafluoride',formula:'BrF5'},
{name:'Iodine Pentafluoride',formula:'IF5'},
{name:'Iodine Heptafluoride',formula:'IF7'},
{name:'Chlorine Trifluoride',formula:'ClF3'},
{name:'Boron Trichloride',formula:'BCl3'},
{name:'Phosphorus Pentafluoride',formula:'PF5'},
{name:'Phosphorus Oxyfluoride',formula:'POF3'},
{name:'Arsenic Trioxide',formula:'As2O3'},
{name:'Arsenic Pentoxide',formula:'As2O5'},
{name:'Antimony Trioxide',formula:'Sb2O3'},
{name:'Bismuth Oxide',formula:'Bi2O3'},
{name:'Lead Dioxide',formula:'PbO2'},
{name:'Lead Acetate',formula:'C4H6O4Pb'},
{name:'Heptane',formula:'C7H16'},
{name:'Octane',formula:'C8H18'},
{name:'Nonane',formula:'C9H20'},
{name:'Decane',formula:'C10H22'},
{name:'Undecane',formula:'C11H24'},
{name:'Dodecane',formula:'C12H26'},
{name:'Cyclopentane',formula:'C5H10'},
{name:'Cyclohexane',formula:'C6H12'},
{name:'Methylcyclohexane',formula:'C7H14'},
{name:'Ethylcyclohexane',formula:'C8H16'},
{name:'1-Butene',formula:'C4H8'},
{name:'1-Pentene',formula:'C5H10'},
{name:'1-Hexene',formula:'C6H12'},
{name:'1-Heptene',formula:'C7H14'},
{name:'1-Octene',formula:'C8H16'},
{name:'1-Nonene',formula:'C9H18'},
{name:'1-Decene',formula:'C10H20'},
{name:'1-Butyne',formula:'C4H6'},
{name:'1-Pentyne',formula:'C5H8'},
{name:'1-Hexyne',formula:'C6H10'},
{name:'1-Heptyne',formula:'C7H12'},
{name:'1-Octyne',formula:'C8H14'},
{name:'1-Nonyn',formula:'C9H16'},
{name:'1-Decyne',formula:'C10H18'},
{name:'Diethyl Ether',formula:'C4H10O'},
{name:'Diethyl Sulfate',formula:'C4H10O4S'},
{name:'Ethyl Methyl Ether',formula:'C3H8O'},
{name:'Propylene Oxide',formula:'C3H6O'},
{name:'Epichlorohydrin',formula:'C3H5ClO'},
{name:'Acrolein',formula:'C3H4O'},
{name:'Crotonaldehyde',formula:'C4H6O'},
{name:'Cyclohexanone',formula:'C6H10O'},
{name:'Cyclohexanol',formula:'C6H12O'},
{name:'Methyl Ethyl Ketone',formula:'C4H8O'},
{name:'Methyl Isobutyl Ketone',formula:'C6H12O'},
{name:'Acetaldehyde',formula:'C2H4O'},
{name:'Propionaldehyde',formula:'C3H6O'},
{name:'Butyraldehyde',formula:'C4H8O'},
{name:'Isobutyraldehyde',formula:'C4H8O'},
{name:'Formic Anhydride',formula:'C2H2O3'},
{name:'Propionic Anhydride',formula:'C6H10O3'},
{name:'Benzoic Anhydride',formula:'C14H10O3'},
{name:'Benzylamine',formula:'C7H9N'},
{name:'Phenethylamine',formula:'C8H11N'},
{name:'Ethylenediamine',formula:'C2H8N2'},
{name:'Propylenediamine',formula:'C3H10N2'},
{name:'Hydrazine',formula:'N2H4'},
{name:'Methylhydrazine',formula:'CH6N2'},
{name:'Hydroxylamine',formula:'H3NO'},
{name:'N,N-Diethyl-m-toluamide',formula:'C12H17NO'},
{name:'Acetohydroxamic Acid',formula:'C2H5NO2'},
{name:'Methylparaben',formula:'C8H8O3'},
{name:'Propylparaben',formula:'C10H12O3'},
{name:'Butylparaben',formula:'C11H14O3'},
{name:'Benzophenone Oxime',formula:'C13H11NO'},
{name:'Azobenzene',formula:'C12H10N2'},
{name:'Diphenylamine',formula:'C12H11N'},
{name:'Triphenylamine',formula:'C18H15N'},
{name:'Carbazole',formula:'C12H9N'},
{name:'Indole',formula:'C8H7N'},
{name:'Quinoline',formula:'C9H7N'},
{name:'Isoquinoline',formula:'C9H7N'},
{name:'Acridine',formula:'C13H9N'},
{name:'Phenazine',formula:'C12H8N2'},
{name:'Phenothiazine',formula:'C12H9NS'},
{name:'Ferrocene',formula:'FeC10H10'},
{name:'Nickelocene',formula:'NiC10H10'},
{name:'Cobaltocene',formula:'CoC10H10'},
{name:'Manganese Carbonyl',formula:'Mn2C10O10'},
{name:'Iron Pentacarbonyl',formula:'FeC5O5'},
{name:'Nickel Tetracarbonyl',formula:'NiC4O4'},
{name:'Cobalt Carbonyl',formula:'Co2C8O8'},
{name:'Calcium Phosphate',formula:'Ca3PO4'},
{name:'Magnesium Phosphate',formula:'Mg3PO4'},
{name:'Sodium Phosphate',formula:'Na3PO4'},
{name:'Potassium Phosphate',formula:'K3PO4'},
{name:'Disodium Hydrogen Phosphate',formula:'Na2HPO4'},
{name:'Monosodium Dihydrogen Phosphate',formula:'NaH2PO4'},
{name:'Potassium Dihydrogen Phosphate',formula:'KH2PO4'},
{name:'Calcium Hydrogen Phosphate',formula:'CaHPO4'},
{name:'Calcium Oxide',formula:'CaO'},
{name:'Magnesium Oxide',formula:'MgO'},
{name:'Sodium Oxide',formula:'Na2O'},
{name:'Potassium Oxide',formula:'K2O'},
{name:'Lithium Oxide',formula:'Li2O'},
{name:'Aluminum Oxide',formula:'Al2O3'},
{name:'Chromium Trioxide',formula:'CrO3'},
{name:'Manganese Heptoxide',formula:'Mn2O7'},
{name:'Osmium Tetroxide',formula:'OsO4'},
{name:'Ruthenium Tetroxide',formula:'RuO4'},
{name:'Palladium Oxide',formula:'PdO'},
{name:'Platinum Oxide',formula:'PtO2'},
{name:'Silver Oxide',formula:'Ag2O'},
{name:'Gold Oxide',formula:'Au2O3'},
{name:'Mercury Oxide',formula:'HgO'},
  ];

  function injectFamousCompounds(){
    if(!DATA.MOLDEF||!DATA.RECIPES)return 0;
    const before=Object.keys(DATA.MOLDEF).filter(k=>DATA.MOLDEF[k]?.mol).length,seen=new Set(Object.keys(DATA.MOLDEF));
    const added=[];
    FAMOUS.forEach((item,i)=>{
      const key=formulaKey(item.formula); if(!key||seen.has(key))return;
      const p=parseFormula(item.formula), mass=massOfFormula(item.formula), h=hash(item.name+'|'+item.formula), cc=chemClass(item);
      const atoms=Object.values(p).reduce((a,b)=>a+b,0);
      const elPower=clamp(1.0+mass/310+atoms/90+(cc==='oxidizer'?.14:0)+(cc==='medicine'?.06:0),1,2.35);
      const id='f50_'+slug(item.name)+'_'+h.toString(16);
      const mods={dmg:1.0+clamp((elPower-1)*.11,.02,.22),rate:clamp(1-(mass/2100),.72,1.08),hp:1.0+clamp(mass/6200,.01,.32),ps:1+clamp(mass/850,.02,.45)};
      DATA.MOLDEF[key]={id,token:key,f:item.formula,name:item.name,hue:90+(h%250),mods,cat:cc,mol:true,rx:'Real compound',cost:Math.round(120+mass*1.35),desc:'Famous real compound. V50 custom abilities are tuned from its molecular composition and documented chemical role.'};
      DATA.RECIPES[key]=key;seen.add(key);added.push(DATA.MOLDEF[key]);
    });
    DATA.realCompoundCount=Object.keys(DATA.MOLDEF).filter(k=>DATA.MOLDEF[k]?.mol&&DATA.MOLDEF[k]?.rx==='Real compound').length;
    DATA.compoundCatalogNames=Object.values(DATA.MOLDEF).filter(m=>m?.mol&&m.rx==='Real compound').map(m=>m.name);
    return DATA.realCompoundCount-before;
  }

  // ---- 2) Every compound gets three independent ability bodies. ----
  function compoundAbilitySet(m,index){
    const klass=chemClass(m), h=hash(m.name+'|'+m.f), pwr=clamp(1+h%7*.08,1,1.48), name=m.name, id=m.id||('mol_'+slug(name));
    const choices=[];
    const c0=function(p){
      if(!p||p.downed)return; const r=run(), hue=playerHue(p);
      if(klass==='medicine'||klass==='bio'){
        p.puDamage=Math.max(p.puDamage||1,1.22+pwr*.08);p.puRate=Math.max(p.puRate||1,1.12+pwr*.05);p.puTimer=Math.max(p.puTimer||0,5.2);
        p.hp=Math.min(Number(window.ST?.hp)||p.hp,p.hp+(Number(window.ST?.hp)||100)*.07);fxRing(p.x,p.y,hue,95,5,.45);pushText(p.x,p.y,'BIOACTIVE SURGE',hue);
      }else if(klass==='neuro'){
        const a=p.angle||0, count=3+(h%3); for(let i=0;i<count;i++){const aa=a+(i-(count-1)/2)*.11;r._isoV50NeedleShots=r._isoV50NeedleShots||[];r._isoV50NeedleShots.push({x:p.x+Math.cos(aa)*14,y:p.y+Math.sin(aa)*14,vx:Math.cos(aa)*390,vy:Math.sin(aa)*390,r:4,life:1.15,owner:p.id,hue});}
        fxBurst(p.x+Math.cos(a)*55,p.y+Math.sin(a)*55,hue,14);
      }else if(klass==='oxidizer') fireBeam(p,m,{status:'burn',damageMul:1.08,width:3,power:.12});
      else if(klass==='ionic') fireBeam(p,m,{status:(h%2?'shock':'corrode'),damageMul:1.02,power:.08});
      else if(klass==='fuel') fireBeam(p,m,{damageMul:1.3,power:.25});
      else if(klass==='aromatic'){
        const len=140+(h%100);fireBeam(p,m,{status:'brittle',damageMul:1.2,power:.18,width:4});r._isoV50Scents=r._isoV50Scents||[];r._isoV50Scents.push({x:p.x+Math.cos(p.angle)*len,y:p.y+Math.sin(p.angle)*len,r:58,t:2.4,life:2.4,hue});
      }else fireBeam(p,m,{status:(h%3===0?'freeze':h%3===1?'corrode':'rust'),damageMul:1.12+(h%5)*.04,power:.1});
      p.activeCd=Number(window.ST?.activeCd)||2;
    };
    const c1=function(p){
      if(!p||p.downed)return; const r=run(),hue=playerHue(p),x=clamp(Number(window.mouse?.x)||p.x,20,window.W-20),y=clamp(Number(window.mouse?.y)||p.y,20,window.H-20);
      if(klass==='bio'||klass==='medicine'){
        const affected=players().filter(q=>!q.downed&&dist2(q.x,q.y,x,y)<185*185);affected.forEach(q=>{q.puDamage=Math.max(q.puDamage||1,1.25);q.puRate=Math.max(q.puRate||1,1.18);q.puTimer=Math.max(q.puTimer||0,6.5);q.sh=Math.min(Number(window.ST?.shieldMax)||100,(q.sh||0)+(Number(window.ST?.shieldMax)||100)*.08);});
        r._isoV50Fields=r._isoV50Fields||[];r._isoV50Fields.push({x,y,r:118,t:3.2,life:3.2,mode:'support',hue});fxRing(x,y,hue,118,5,.6);
      }else if(klass==='neuro'){
        r._isoV50NicoMists=r._isoV50NicoMists||[];r._isoV50NicoMists.push({x,y,r:150,t:3.6,ownerId:p.id,hue,used:new Set(),cool:0,max:4});fxRing(x,y,hue,150,8,.7);fxBurst(x,y,hue,24);
      }else if(klass==='oxidizer'){
        r._isoV50Fields=r._isoV50Fields||[];r._isoV50Fields.push({x,y,r:105,t:4.2,life:4.2,mode:'burn',hue,interval:.38,acc:0});fxRing(x,y,hue,105,7,.55);
      }else if(klass==='ionic'){
        r._isoV50Fields=r._isoV50Fields||[];r._isoV50Fields.push({x,y,r:125,t:3.3,life:3.3,mode:'ionic',hue,interval:.52,acc:0});fxRing(x,y,hue,125,7,.55);
      }else if(klass==='fuel'){
        p.puSpeed=Math.max(p.puSpeed||1,1.38);p.puDamage=Math.max(p.puDamage||1,1.18);p.puTimer=Math.max(p.puTimer||0,6.5);r._isoV50Trails=r._isoV50Trails||[];r._isoV50Trails.push({x:p.x,y:p.y,t:4,life:4,owner:p.id,hue});fxBurst(p.x,p.y,hue,18);
      }else{
        r._isoV50Fields=r._isoV50Fields||[];r._isoV50Fields.push({x,y,r:95+(h%50),t:3.8,life:3.8,mode:'debuff',hue,interval:.45,acc:0});fxRing(x,y,hue,110,7,.55);
      }
      p.activeCd=Number(window.ST?.activeCd)||2;
    };
    const c2=function(p){
      if(!p||p.downed)return; const hue=playerHue(p),r=run(),x=clamp(Number(window.mouse?.x)||p.x,25,window.W-25),y=clamp(Number(window.mouse?.y)||p.y,25,window.H-25);
      if(klass==='medicine'||klass==='bio'){
        const allies=players().filter(q=>!q.downed).sort((a,b)=>dist2(a.x,a.y,x,y)-dist2(b.x,b.y,x,y)).slice(0,4);
        allies.forEach((q,i)=>{q.iframes=Math.max(q.iframes||0,.55);q.hp=Math.min(Number(window.ST?.hp)||q.hp,q.hp+(Number(window.ST?.hp)||100)*(.1-i*.012));q.puDamage=Math.max(q.puDamage||1,1.3);q.puTimer=Math.max(q.puTimer||0,5);});
        fxBurst(x,y,hue,30);fxRing(x,y,hue,145,9,.8);
      }else if(klass==='ionic'){
        const list=enemyList().sort((a,b)=>dist2(a.x,a.y,x,y)-dist2(b.x,b.y,x,y)).slice(0,Math.min(7,3+h%5));list.forEach((e,i)=>{damage(e,(Number(window.ST?.dmg)||18)*(1.25-i*.08));status(e,i%2?'shock':'corrode',pwr);});
        r._isoV50Arcs=r._isoV50Arcs||[];list.forEach(e=>r._isoV50Arcs.push({x,y,x2:e.x,y2:e.y,t:.35,life:.35,hue}));fxBurst(x,y,hue,18);
      }else if(klass==='oxidizer'){
        burstAt(p,m,{status:'burn',damageMul:1.55,power:.35});
        later(r,420,()=>burstAt(p,m,{status:'burn',damageMul:1.0,power:.08}));
      }else if(klass==='fuel'){
        p.iframes=Math.max(p.iframes||0,.8);p.x=clamp(p.x+Math.cos(p.angle||0)*135,25,window.W-25);p.y=clamp(p.y+Math.sin(p.angle||0)*135,25,window.H-25);burstAt(p,m,{damageMul:1.2,power:.18});
      }else if(klass==='aromatic'){
        const es=enemyList().sort((a,b)=>dist2(a.x,a.y,x,y)-dist2(b.x,b.y,x,y)).slice(0,5);es.forEach((e,i)=>{e.slowT=Math.max(e.slowT||0,1.8+.2*i);damage(e,(Number(window.ST?.dmg)||18)*(1.05+.1*(4-i)));status(e,'brittle',pwr);});fxBurst(x,y,hue,28);
      }else if(klass==='neuro'){
        const es=enemyList().filter(e=>dist2(e.x,e.y,x,y)<240*240).sort((a,b)=>dist2(a.x,a.y,x,y)-dist2(b.x,b.y,x,y)).slice(0,4);es.forEach(e=>V50_NICO.befriend(e,p.id,'neuro-pulse'));fxRing(x,y,hue,235,11,.7);fxBurst(x,y,hue,24);
      }else{
        burstAt(p,m,{status:(h%2?'freeze':'rust'),damageMul:1.42,power:.25,slow:1.5,pull:h%3===0});
      }
      p.activeCd=Number(window.ST?.activeCd)||2;
    };
    const shapes=[
      {name:name+' · Molecular Edge',desc:'Project a compound-scaled reaction beam. Width and impact reach are derived from molecular mass and combat power.',fn:c0},
      {name:name+' · Reactive Field',desc:'Deploy a custom reaction field tuned to this compound’s chemical family and tactical role.',fn:c1},
      {name:name+' · Signature Cascade',desc:'Trigger a separate tertiary reaction that chains, bursts, supports, or repositions according to this compound.',fn:c2}
    ];
    shapes.forEach((s,slot)=>choices.push({id:id+'_v50_a'+slot+'_'+hash(name+'|'+m.f+'|'+slot),key:'v50compound_'+slug(name)+'_'+hash(m.f+slot).toString(16),slot,ic:['⚛','✦','◈'][slot],name:s.name,desc:s.desc,main:slot===0,power:pwr+.05*slot,exec:s.fn,profile:klass,formula:m.f}));
    return choices;
  }

  function overhaulCompounds(){
    const mol=DATA.MOLDEF;if(!mol)return;
    const all=Object.values(mol).filter(m=>m&&m.mol&&m.rx==='Real compound');
    const audit=[];
    all.forEach((m,i)=>{
      const c=compoundAbilitySet(m,i);m.choices=c;m.signatures=c;m.act=c[0];m.v50Profile=chemClass(m);audit.push({name:m.name,formula:m.f,count:3,ids:c.map(x=>x.key),unique:new Set(c.map(x=>x.key)).size===3});
    });
    DATA.compoundSemanticProfiles=audit;DATA.compoundSemanticCount=audit.length;DATA.compoundSemanticUnique=audit.filter(x=>x.unique).length;DATA.compoundAbilityManifest=audit.flatMap(a=>a.ids.map((id,i)=>({compound:a.name,formula:a.formula,slot:i+1,key:id})));
    DATA.compoundAbilityAudit=()=>audit.slice();
  }

  // ---- 3) Fix the nicotine crash and give all three slots a safe, distinct path. ----
  const V50_NICO={
    state(r){r._v50Nico=r._v50Nico||{}} ,
    is(p){const n=String(p?.elem?.name||p?.elem?.token||'').toLowerCase();return n==='nicotine'||n.includes('nicotine');},
    befriend(e,ownerId,reason){
      const r=run();if(!r||!e||!alive(e)||e.boss||e._v29Converted)return false;
      if(!r._v29Allies)r._v29Allies=[];if(!r._v29CharmUsed)r._v29CharmUsed=Object.create(null);if(!r._v29CharmReserved)r._v29CharmReserved=Object.create(null);
      const key=String(e.eid!=null?e.eid:('enemy_'+Math.round(e.x)+'_'+Math.round(e.y)+'_'+Math.round(e.maxhp||0)));
      if(r._v29CharmUsed[key]||e._v29Converted||e.team==='player')return false;
      r._v29CharmUsed[key]=true;e._v29CharmLocked=true;e._v29Converted=true;e._befriended=true;e.team='player';e.dead=true;
      const owner=players().find(q=>q.id===ownerId)||players()[0], hue=playerHue(owner);const maxhp=Math.max(1,Number(e.maxhp)||Number(e.hp)||20);
      r._v29Allies.push({eid:e.eid,sourceEid:e.eid,sourceType:e.type||'mote',type:e.type||'mote',name:e.name||e.type||'Nicotine Ally',x:e.x,y:e.y,r:Math.max(7,e.r||10),hp:Math.max(1,Math.min(maxhp,e.hp||maxhp*.72)),maxhp,spd:Math.max(55,e.spd||100),dmg:Math.max(1,e.dmg||10),hue,playerHue:hue,ownerId:owner?owner.id:ownerId,team:'player',befriended:true,permanent:true,nicotineAlly:true,incomingMul:.5,shootT:.7,specialT:1.4,healT:1.8,orb:0,charge:0,chargeT:2.5,targetEid:0,special:e.special||null,pat:e.pat||null,fast:!!e.fast,canCharge:!!e.canCharge,shape:e.shape||'dot',seed:e.seed||0,elite:!!e.elite,aiRole:e.aiRole||'melee',_v29:true});
      for(let i=r.enemies.length-1;i>=0;i--)if(r.enemies[i]===e||r.enemies[i]?._v29Converted)r.enemies.splice(i,1);
      fxRing(e.x,e.y,hue,115,7,.45);fxBurst(e.x,e.y,hue,18);pushText(e.x,e.y,'BEFRIENDED',hue);return true;
    }
  };
  window.ISO_V50_NICO=V50_NICO;

  function nicotineUse(p,slot){
    const r=run(); if(!r||!p||p.downed||(p.activeCd||0)>0)return false;
    const hue=playerHue(p), a=Number(p.angle)||0, cd=Number(window.ST?.activeCd)||2;
    V50_NICO.state(r);
    if(slot===0){
      // Small receptor darts — no giant charm projectile and no generic bullet queue.
      r._v29CharmShots=r._v29CharmShots||[];const fan=5;
      for(let i=0;i<fan;i++){const ang=a+(i-2)*.12;r._v29CharmShots.push({x:p.x+Math.cos(ang)*18,y:p.y+Math.sin(ang)*18,vx:Math.cos(ang)*430,vy:Math.sin(ang)*430,r:4,life:1.35,owner:p.id,consumed:false});}
      fxBurst(p.x+Math.cos(a)*40,p.y+Math.sin(a)*40,hue,12);fxRing(p.x,p.y,hue,52,5,.28);
    }else if(slot===1){
      const x=clamp(Number(window.mouse?.x)||p.x,20,window.W-20),y=clamp(Number(window.mouse?.y)||p.y,20,window.H-20);
      r._isoV50NicoMists=r._isoV50NicoMists||[];r._isoV50NicoMists.push({x,y,r:155,t:3.8,ownerId:p.id,hue,used:new Set(),cool:0,max:5});fxRing(x,y,hue,155,9,.8);fxBurst(x,y,hue,26);
    }else{
      const x=clamp(Number(window.mouse?.x)||p.x,20,window.W-20),y=clamp(Number(window.mouse?.y)||p.y,20,window.H-20);
      const targets=enemyList().sort((u,v)=>dist2(u.x,u.y,x,y)-dist2(v.x,v.y,x,y)).slice(0,5);
      targets.forEach((e,i)=>later(r,i*95,()=>V50_NICO.befriend(e,p.id,'synaptic-chain')));
      r._isoV50Beams=r._isoV50Beams||[];r._isoV50Beams.push({x:p.x,y:p.y,x2:x,y2:y,width:9,life:.5,max:.5,hue,realPower:1.8,compound:'Nicotine Synaptic Cascade'});fxBurst(x,y,hue,30);
    }
    p.activeCd=cd;try{window.SFX&&SFX.active&&SFX.active();}catch(_){};return true;
  }

  // The original nicotine module references clamp/TAU globally. Give that older module safe helpers too.
  try{if(!('clamp' in window))window.clamp=clamp;}catch(_){ }
  try{if(!('TAU' in window))window.TAU=TAU;}catch(_){ }

  const prevUse=window.useActive;
  window.useActive=function(p){
    if(V50_NICO.is(p) && p && !p.downed && (p.activeCd||0)<=0){
      const slot=clamp(Number(p.signatureSlot)||0,0,2);
      if(nicotineUse(p,slot)){cooperativeShieldPulse(p.id);return;}
    }
    const before=(p&&Number(p.activeCd)||0);
    const ret=typeof prevUse==='function'?prevUse(p):undefined;
    if(p&&before<=0&&Number(p.activeCd||0)>0)cooperativeShieldPulse(p.id);
    return ret;
  };

  // ---- 4) Cards: rebuild stat ladder and remove known duplicate mechanics. ----
  function cardOwned(id){const r=run();return !!(r&&r.ab&&r.ab[id]);}
  const CARD_LADDER=[
    ['dmg','Projectile Damage','Projectiles deal +{v}% damage.', [6,14,24,35,55,70]],
    ['rate','Fire Rate','Fire rate is +{v}%.',[5,13,22,34,52,70]],
    ['spd','Movement Speed','Movement speed is +{v}%.',[5,14,23,34,54,70]],
    ['crit','Critical Chance','Critical chance is +{v}%.',[3,12,21,32,52,70]],
    ['hp','Maximum HP','Maximum HP is +{v}.',[6,14,24,34,52,70]],
    ['shield','Maximum Shield','Maximum shield is +{v}.',[6,14,24,34,52,70]],
    ['magnet','Pickup Range','Pickup range is +{v}%.',[4,13,22,33,52,70]],
    ['coin','Coin Gain','Coin gain is +{v}%.',[5,14,23,34,52,70]],
    ['pierce','Piercing','Gain +{v} pierce.', [1,2,3,4,5,6], ['uncommon','rare','epic','legendary','mythic']],
    ['aoe','Reaction Area','Ability and reaction radius is +{v}%.',[5,13,22,34,52,70]],
    ['homing','Homing','Homing strength is +{v}%.',[4,12,22,33,52,70]],
    ['luck','Luck','Luck is +{v}%.',[4,12,22,34,52,70]],
    ['projs','Projectile Count','Fire +{v} additional projectile.', [0,0,1,2,3,4], ['rare','epic','legendary','mythic']]
  ];
  const RARITIES=['common','uncommon','rare','epic','legendary','mythic'];
  const keepNonStat=c=>c && !c.extraStat;
  function installCards(){
    const cards=window.ALL_CARDS;if(!Array.isArray(cards))return;
    // Remove generated/stack/stat duplicates from all previous revisions while retaining bespoke ability modules.
    for(let i=cards.length-1;i>=0;i--){const c=cards[i];if(!c)continue; if(c.extraStat || /^xcard_/i.test(c.id||'') || /\bstack \+/i.test(String(c.d||'')) && /\bfor hit effects?\b/i.test(String(c.d||''))){cards.splice(i,1);}}
    const usedDesc=new Set();
    for(let i=cards.length-1;i>=0;i--){const c=cards[i],k=String(c.n||'')+'|'+String(c.d||'').replace(/\s+/g,' ').trim().toLowerCase();if(usedDesc.has(k))cards.splice(i,1);else usedDesc.add(k);}
    const added=[];
    CARD_LADDER.forEach(([stat,label,templ,vals,allowed])=>{
      vals.forEach((target,ri)=>{
        const rarity=RARITIES[ri];if(allowed&&!allowed.includes(rarity))return;
        const targetReal=target;
        const raw = (stat==='crit'||stat==='dmg'||stat==='rate'||stat==='spd'||stat==='magnet'||stat==='coin'||stat==='aoe'||stat==='homing'||stat==='luck') ? (targetReal/100)/(CARD_MUL[rarity]||1) : Math.max(.01,(targetReal+.01)/(CARD_MUL[rarity]||1));
        const id='v50_stat_'+stat+'_'+rarity;
        if(cards.some(c=>c.id===id))return;
        const card={id,ic:['◌','◇','✦','◆','⬢','☼'][ri],n:'V50 '+label+' '+rarity.toUpperCase(),d:templ.replace('{v}',String(targetReal)),max:1,rarity,extraStat:stat,extraValue:raw,finalTarget:targetReal,unique:true,v50Unique:true};
        cards.push(card);added.push(card);
      });
    });
    // Explicit single +1 projectile is RARE. Higher tiers increase the amount.
    const statusCards=[['freeze','❄','Cryogenic Contact','Hits inflict Freeze.'],['corrode','🜁','Corrosive Contact','Hits inflict Corrosion.'],['rust','⚙','Oxidized Contact','Hits inflict Rust.'],['burn','☀','Thermal Contact','Hits inflict Burn.'],['shock','ϟ','Voltaic Contact','Hits inflict Shock.'],['brittle','◇','Fracture Contact','Hits inflict Brittle.'],['drenched','≈','Drenched Contact','Hits inflict Drenched.']];
    statusCards.forEach(([effect,ic,name,desc])=>{
      const id='v50_onhit_'+effect;if(!cards.some(c=>c.id===id))cards.push({id,ic,n:'Legendary '+name,d:desc,max:1,rarity:'legendary',extraSpecial:'onhit',onHitEffect:effect,unique:true,v50Unique:true});
    });
    const specials=[
      {id:'v50_cooldown_mythic',ic:'⟳',n:'Temporal Accelerator',d:'Ability cooldowns are 25% shorter.',rarity:'mythic',extraSpecial:'cooldown',extraValue:.25,max:1},
      {id:'v50_beam_mythic',ic:'╋',n:'Singular Beam Reactor',d:'Compound beams gain a much larger width and damage envelope.',rarity:'mythic',extraSpecial:'beamPower',extraValue:.7,max:1},
      {id:'v50_charge_rare',ic:'⇢',n:'Charge Converter',d:'Every tenth primary hit refunds 8% of your active cooldown.',rarity:'rare',extraSpecial:'charge',extraValue:.08,max:1},
      {id:'v50_team_epic',ic:'✚',n:'Cooperative Resonator',d:'Ability casts grant nearby teammates a 3% shield pulse.',rarity:'epic',extraSpecial:'teamShield',extraValue:.03,max:1}
    ];
    specials.forEach(c=>{if(!cards.some(x=>x.id===c.id))cards.push(c);});
    // Final exact-description de-duplication, leaving every rarity target as its own mechanic.
    const seen=new Set();for(let i=cards.length-1;i>=0;i--){const c=cards[i];const key=String(c.n||'').toLowerCase().replace(/\s+/g,' ')+'|'+String(c.d||'').toLowerCase().replace(/\s+/g,' ');if(seen.has(key)&&c.v50Unique!==true){cards.splice(i,1);}else seen.add(key);}
    DATA.cardRarityLadder={common:'single digits',uncommon:'10s',rare:'20s',epic:'30s',legendary:'50s',mythic:'70s'};
    DATA.cardRarityAudit=()=>cards.map(c=>({id:c.id,rarity:c.rarity,name:c.n,desc:c.d}));
  }

  // Keep original compute pipeline but give V50 cards precise values and new stats/effects.
  let rawCompute=CORE.getComputeStats?CORE.getComputeStats():null;
  // V55: make the compute wrapper re-entry safe. Some older additive compute
  // layers can form a cycle through CORE.setComputeStats; never recurse into
  // the wrapper itself (or another wrapper that loops back into it).
  if(typeof rawCompute==='function'&&!rawCompute.__isoV50Cooldown){
    let computingV50=false;
    const f=function(){
      if(computingV50)return window.ST;
      computingV50=true;
      try{
        if(rawCompute&&rawCompute!==f)rawCompute();
        const r=run(),s=window.ST;if(!r||!s)return s;
        /* V61: cooldown scaling is an assignment from the current base cooldown,
           never a multiplication of the already-scaled live value. This keeps
           the requested 1.8x increase stable even when stats are recomputed
           repeatedly while a signature is recharging. */
        const elem=r.el||window.RUN?.el||{};
        const cat=(window.CATS&&window.CATS[elem.cat])||{};
        const baseCd=Number((elem.act&&elem.act.cd)||((cat.act||{}).cd)||s.activeCd||7);
        const battery=(Array.isArray(r.relics)&&r.relics.indexOf('battery')>=0)?0.7:1;
        s.activeCd=Math.max(0.1,baseCd*battery);
        s.__isoCooldownScale=1;
        s.luck=0; s.beamPower=0;
      const cards=window.ALL_CARDS||[];cards.forEach(c=>{const lv=(r.ab&&r.ab[c.id])||0;if(!lv)return;if(c.extraSpecial==='luck'||c.extraStat==='luck')s.luck+=(c.finalTarget||c.extraValue*100||0)*lv;if(c.extraSpecial==='cooldown')s.activeCd*=Math.max(.15,1-(c.extraValue||.25)*lv);if(c.extraSpecial==='beamPower')s.beamPower+=(c.extraValue||0)*lv;if(c.extraSpecial==='teamShield')s.teamShieldPulse=(s.teamShieldPulse||0)+(c.extraValue||0)*lv;});
      const luckMult=1+(s.luck/100)*.35;s.coinMult*=luckMult;
      return s;
      }finally{computingV50=false;}
    };
    f.__isoV50Cooldown=true;CORE.setComputeStats&&CORE.setComputeStats(f);rawCompute=f;
  }
  // Some original ability cards use extraStat before the V50 pool is installed. Re-run stats after installation.

  function findPlayerById(id){return players().find(p=>p&&p.id===id)||null;}
  function cooperativeShieldPulse(ownerId){
    const r=run(), owner=findPlayerById(ownerId);
    if(!r||!owner)return;
    const cards=window.ALL_CARDS||[];
    const card=cards.find(c=>c&&c.extraSpecial==='teamShield'&&r.ab&&r.ab[c.id]);
    if(!card)return;
    const amount=Math.max(1,(Number(window.ST?.shieldMax)||Number(window.ST?.shield)||30)*(Number(card.extraValue)||.03));
    players().forEach(tm=>{
      if(!tm||tm===owner||tm.downed)return;
      if(dist2(tm.x,tm.y,owner.x,owner.y)<=230*230){
        tm.sh=Math.min(Number(window.ST?.shieldMax)||9999,(Number(tm.sh)||0)+amount);
        tm._isoV50ShieldPulse=.45;
        fxRing(tm.x,tm.y,playerHue(owner),22,3,.28);
      }
    });
  }

  function installHitStatusWrapper(){
    const old=CORE.getApplyElemHit&&CORE.getApplyElemHit();
    if(typeof old!=='function'||old.__isoV50Hit)return;
    const f=function(b,e){
      old(b,e);
      try{
        const r=run(),cards=window.ALL_CARDS||[], owner=b&&findPlayerById(b.owner);
        // Legendary contact cards: the wording and the implementation now match exactly.
        for(const c of cards){
          if(!c||c.extraSpecial!=='onhit'||!r||!(r.ab&&r.ab[c.id]))continue;
          status(e,c.onHitEffect,1);
        }
        // Charge Converter: only primary/player-fired hits count; split/fragment bullets
        // do not recursively farm cooldown refunds.
        const chargeCard=cards.find(c=>c&&c.extraSpecial==='charge'&&r&&r.ab&&r.ab[c.id]);
        if(chargeCard&&b&&b.main&&owner){
          owner._isoV50PrimaryHits=(owner._isoV50PrimaryHits||0)+1;
          if(owner._isoV50PrimaryHits%10===0){
            const remain=Math.max(0,Number(owner.activeCd)||0), refund=remain*(Number(chargeCard.extraValue)||.08);
            owner.activeCd=Math.max(0,remain-refund);
            pushText(owner.x,owner.y,'+8% COOLDOWN',playerHue(owner));
            fxRing(owner.x,owner.y,playerHue(owner),34,4,.25);
          }
        }
      }catch(_){}
    };
    f.__isoV50Hit=true;
    CORE.setApplyElemHit&&CORE.setApplyElemHit(f);
  }


  // ---- 5) Relics: host-authoritative per-player claims + scrollable panel + deploy refresh. ----
  let relaySeq=0;
  function ensureRelicIds(r){
    if(!r||!Array.isArray(r.pickups))return;
    r._isoRelicSeq=r._isoRelicSeq||0;r.pickups.forEach(k=>{if(k&&k.t==='relic'&&!k._isoId)k._isoId='r'+(++r._isoRelicSeq)+'_'+Math.floor(Math.random()*1e6).toString(36);});
    r.isoRelicsByPlayer=r.isoRelicsByPlayer||{};
  }
  function claimRelicHost(r,pid,pickupId){
    if(!r||!isHostish(r))return false;ensureRelicIds(r);const p=players().find(q=>q.id===pid);if(!p)return false;
    const k=r.pickups.find(q=>q&&q.t==='relic'&&q._isoId===pickupId&&!q.got);if(!k||dist2(k.x,k.y,p.x,p.y)>42*42)return false;
    k.got=true;r.isoRelicsByPlayer[String(pid)]=r.isoRelicsByPlayer[String(pid)]||[];if(!r.isoRelicsByPlayer[String(pid)].includes(k.v))r.isoRelicsByPlayer[String(pid)].push(k.v);
    r.relics=r.relics||[];if(!r.relics.includes(k.v))r.relics.push(k.v);
    try{CORE.getComputeStats&&CORE.getComputeStats()();}catch(_){ }
    if(pid===r.localNetId || !r.isOnline){SAVE.raw&&(SAVE.raw.relicsFound=SAVE.raw.relicsFound||[],!SAVE.raw.relicsFound.includes(k.v)&&SAVE.raw.relicsFound.push(k.v));try{SAVE.save&&SAVE.save();}catch(_){} }
    pushText(p.x,p.y,'RELIC ACQUIRED',playerHue(p));fxRing(p.x,p.y,playerHue(p),80,7,.5);return true;
  }
  function hostAutoClaim(r){ensureRelicIds(r);if(!isHostish(r))return;players().forEach(p=>r.pickups.filter(k=>k&&k.t==='relic'&&!k.got&&dist2(k.x,k.y,p.x,p.y)<42*42).forEach(k=>claimRelicHost(r,p.id,k._isoId)));}

  if(window.NET){
    const oldClient=NET.onClientAction;NET.onClientAction=function(playerId,action){try{if(NET.isHost&&action&&String(action).startsWith('isoRelic:')){const r=run();claimRelicHost(r,Number(playerId)||0,String(action).slice(9));return;}}catch(_){ }if(typeof oldClient==='function')return oldClient.apply(this,arguments);};
    const oldBroadcast=NET.broadcastSnapshot;NET.broadcastSnapshot=function(s){try{const r=run();ensureRelicIds(r);if(r&&s){s.isoRelicsByPlayer=r.isoRelicsByPlayer||{};if(Array.isArray(s.pickups))s.pickups.forEach((k,i)=>{const live=r.pickups&&r.pickups[i];if(live&&live._isoId)k._isoId=live._isoId;});s.isoV50Beams=(r._isoV50Beams||[]).slice(-18);}}catch(_){ }if(typeof oldBroadcast==='function')return oldBroadcast.apply(this,arguments);};
    const oldState=NET.onStateSnapshot;NET.onStateSnapshot=function(s){const out=typeof oldState==='function'?oldState.apply(this,arguments):undefined;try{const r=run();if(r&&s){r.isoRelicsByPlayer=s.isoRelicsByPlayer||{};if(Array.isArray(s.pickups))s.pickups.forEach((k,i)=>{if(k&&k._isoId&&r.pickups[i])r.pickups[i]._isoId=k._isoId;});const own=(s.isoRelicsByPlayer&&s.isoRelicsByPlayer[String(r.localNetId)])||[];if(SAVE.raw){SAVE.raw.relicsFound=Array.isArray(SAVE.raw.relicsFound)?SAVE.raw.relicsFound:[];own.forEach(id=>{if(!SAVE.raw.relicsFound.includes(id))SAVE.raw.relicsFound.push(id);});SAVE.save&&SAVE.save();}setTimeout(refreshRelicPanel,0);}}catch(_){ }return out;};
  }

  let relicRefreshLock=false;
  function refreshRelicPanel(){
    try{
      if(typeof window.ISO_REFRESH_RELIC_PANEL==='function') window.ISO_REFRESH_RELIC_PANEL();
      const holder=document.getElementById('v14-relic-panel')||document.getElementById('vd-relics')||document.getElementById('v14-relic-grid')||document.getElementById('relic-list');
      if(holder){holder.style.maxHeight='68vh';holder.style.overflowY='auto';holder.style.overflowX='hidden';holder.dataset.loaded=String(Date.now());}
    }catch(_){ }
  }
  function installRelicUI(){
    let st=document.getElementById('v50-relic-style');if(!st){st=document.createElement('style');st.id='v50-relic-style';st.textContent=`#v14-relic-panel,#vd-relics,#v14-relic-grid,#relic-list{max-height:68vh!important;overflow-y:auto!important;overflow-x:hidden!important;scrollbar-gutter:stable!important}.v50-relic-card{min-height:72px}.v50-relic-card span{display:block}.v50-relic-card b,.v50-relic-card span{overflow-wrap:anywhere}`;document.head.appendChild(st);}
    refreshRelicPanel();
    if(!document.__v50RelicDeployListener){document.__v50RelicDeployListener=true;document.addEventListener('click',e=>{const b=e.target.closest('#btn-deploy,[data-deploy]');if(!b)return;setTimeout(refreshRelicPanel,0);setTimeout(refreshRelicPanel,120);setTimeout(refreshRelicPanel,700);});}
  }

  // Update loop handles short-lived V50 visual zones and reliable relic claiming/requests.
  const oldUpdate=window.update;
  if(typeof oldUpdate==='function'&&!oldUpdate.__isoV50Update){
    const f=function(dt){
      const r=run();
      if(r){
        ensureRelicIds(r);r.isoRelicsByPlayer=r.isoRelicsByPlayer||{};
        // Ask host to claim the exact pickup this client is touching; do not mutate client inventory locally.
        if(r.isOnline&&!isHostish(r)&&NET?.sendClientAction){const me=players().find(p=>p.id===r.localNetId);if(me){for(const k of r.pickups||[]){if(k?.t==='relic'&&!k.got&&k._isoId&&dist2(k.x,k.y,me.x,me.y)<42*42){const key='isoRelic:'+k._isoId;if(!r._isoRelicRequests)r._isoRelicRequests=new Set();if(!r._isoRelicRequests.has(k._isoId)){r._isoRelicRequests.add(k._isoId);NET.sendClientAction(key);}}}}}
        if(isHostish(r))hostAutoClaim(r);
        // Nicotine mist converts one hostile at a time and expires cleanly.
        if(isHostish(r)&&Array.isArray(r._isoV50NicoMists)){for(let i=r._isoV50NicoMists.length-1;i>=0;i--){const m=r._isoV50NicoMists[i];m.t-=dt;m.cool=Math.max(0,(m.cool||0)-dt);if(m.cool<=0){m.cool=.28;const e=enemyList().find(e=>dist2(e.x,e.y,m.x,m.y)<m.r*m.r&&!m.used.has(e.eid));if(e){m.used.add(e.eid);V50_NICO.befriend(e,m.ownerId,'nicotine-mist');}}if(m.t<=0)r._isoV50NicoMists.splice(i,1);}}
        // General V50 fields.
        if(Array.isArray(r._isoV50Fields)&&isHostish(r))for(let i=r._isoV50Fields.length-1;i>=0;i--){const f0=r._isoV50Fields[i];f0.t-=dt;f0.acc=(f0.acc||0)+dt;if(f0.acc>=Number(f0.interval)||!f0.interval){f0.acc=0;enemyList().forEach(e=>{if(dist2(e.x,e.y,f0.x,f0.y)<f0.r*f0.r){if(f0.mode==='support'){}else{damage(e,(Number(window.ST?.dmg)||18)*.18,{quiet:true});if(f0.mode==='burn')status(e,'burn',1);else if(f0.mode==='ionic')status(e,'shock',1);else status(e,f0.mode==='debuff'?'corrode':'rust',1);if(f0.mode!=='burn')e.slowT=Math.max(e.slowT||0,.35);}}});}if(f0.t<=0)r._isoV50Fields.splice(i,1);}
        if(Array.isArray(r._isoV50Beams))r._isoV50Beams=r._isoV50Beams.filter(b=>(b.life-=dt)>0);
        if(Array.isArray(r._isoV50Bursts))r._isoV50Bursts=r._isoV50Bursts.filter(b=>(b.t-=dt)>0);
        if(Array.isArray(r._isoV50Arcs))r._isoV50Arcs=r._isoV50Arcs.filter(b=>(b.life-=dt)>0);
      }
      const out=oldUpdate(dt);
      return out;
    };f.__isoV50Update=true;window.update=f;if(CORE.setUpdate)CORE.setUpdate(f);
  }

  // Safe small nicotine darts are handled separately from generic RUN.bullets.
  function stepNicotineDarts(r,dt){
    if(!r||!Array.isArray(r._v29CharmShots))return;
    for(let i=r._v29CharmShots.length-1;i>=0;i--){const b=r._v29CharmShots[i];if(!b){r._v29CharmShots.splice(i,1);continue;}b.life-=dt;b.x+=b.vx*dt;b.y+=b.vy*dt;if(b.life<=0){r._v29CharmShots.splice(i,1);continue;}const e=enemyList().find(e=>dist2(e.x,e.y,b.x,b.y)<(b.r+e.r)*(b.r+e.r));if(e){V50_NICO.befriend(e,b.owner,'receptor-dart');r._v29CharmShots.splice(i,1);}}}
  const oldUpdate2=window.update;
  if(typeof oldUpdate2==='function'&&!oldUpdate2.__isoV50DartWrap){
    const f=function(dt){const r=run();if(r&&isHostish(r))stepNicotineDarts(r,dt);return oldUpdate2(dt);};f.__isoV50DartWrap=true;window.update=f;if(CORE.setUpdate)CORE.setUpdate(f);
  }

  // ---- 6) Mastery: rebuild left-hand owned-element list every time it opens or changes. ----
  function refreshMastery(){
    const box=document.getElementById('m-elems');if(!box)return;const owned=Object.values(DATA.ELEMS||{}).filter(e=>e&&SAVE.raw?.unlocked?.includes(e.id));owned.sort((a,b)=>(a.n||0)-(b.n||0));const selected=SAVE.sel;
    box.innerHTML='';owned.forEach(e=>{const d=document.createElement('div');d.className='mchip'+(selected===e.id?' sel':'');d.dataset.id=e.id;d.innerHTML=`<span class="mchip-num">${e.n||''}</span><b>${e.name||e.id}</b>`;d.onclick=()=>{SAVE.sel=e.id;SAVE.save&&SAVE.save();refreshMastery();try{window.renderMastery&&window.renderMastery();}catch(_){} };box.appendChild(d);});
    box.scrollTop=Math.max(0,[...box.children].findIndex(x=>x.dataset.id===selected)*34-100);const badge=document.getElementById('mxp-badge');if(badge&&SAVE.mxp)badge.textContent='◆ '+SAVE.mxp(selected).xp;
  }
  if(window.UI&&typeof UI.show==='function'){
    const oldShow=UI.show;UI.show=function(id){const out=oldShow.apply(this,arguments);if(id==='scr-mastery'||id==='scr-vault'||id==='scr-deploy')setTimeout(refreshMastery,0);return out;};
  }
  if(SAVE.unlockElement){const oldUnlock=SAVE.unlockElement;SAVE.unlockElement=function(){const out=oldUnlock.apply(this,arguments);setTimeout(refreshMastery,0);return out;};}

  // ---- 7) Final render layer: beams, fields, bursts, arcs, trails. ----
  const oldRender=window.render;
  if(typeof oldRender==='function'&&!oldRender.__isoV50Render){
    const f=function(){const out=oldRender();try{const r=run(),cx=CORE.ctx&&CORE.ctx();if(!r||!cx)return out;cx.save();
      (r._isoV50Beams||[]).forEach(b=>{const alpha=clamp(b.life/(b.max||.28),0,1),p=b.realPower||1;cx.save();cx.lineCap='round';cx.shadowBlur=18+p*10;cx.shadowColor=`hsla(${b.hue},95%,65%,${.75*alpha})`;cx.strokeStyle=`hsla(${b.hue},100%,72%,${.82*alpha})`;cx.lineWidth=b.width*1.9;cx.beginPath();cx.moveTo(b.x,b.y);cx.lineTo(b.x2,b.y2);cx.stroke();cx.shadowBlur=0;cx.strokeStyle=`hsla(${(b.hue+35)%360},100%,88%,${.95*alpha})`;cx.lineWidth=Math.max(2,b.width*.38);cx.beginPath();cx.moveTo(b.x,b.y);cx.lineTo(b.x2,b.y2);cx.stroke();cx.restore();});
      (r._isoV50Fields||[]).forEach(z=>{const a=clamp(z.t/(z.life||1),0,1);cx.save();cx.strokeStyle=`hsla(${z.hue},90%,65%,${.18+.28*a})`;cx.fillStyle=`hsla(${z.hue},90%,55%,${.035+.03*a})`;cx.lineWidth=2;cx.beginPath();cx.arc(z.x,z.y,z.r,0,TAU);cx.fill();cx.stroke();cx.restore();});
      (r._isoV50NicoMists||[]).forEach(z=>{const a=clamp(z.t/3.8,0,1);cx.save();cx.globalAlpha=.22+.16*a;cx.strokeStyle=`hsla(${z.hue},95%,65%,1)`;cx.setLineDash([8,9]);cx.lineWidth=3;cx.beginPath();cx.arc(z.x,z.y,z.r,0,TAU);cx.stroke();cx.setLineDash([]);cx.restore();});
      (r._isoV50Bursts||[]).forEach(z=>{const a=clamp(z.t/(z.life||.45),0,1);cx.save();cx.globalAlpha=.55*a;cx.strokeStyle=`hsla(${z.hue},100%,72%,1)`;cx.lineWidth=5;cx.beginPath();cx.arc(z.x,z.y,z.r*(1-a*.35),0,TAU);cx.stroke();cx.restore();});
      (r._isoV50Arcs||[]).forEach(a=>{const al=clamp(a.life/.35,0,1);cx.save();cx.globalAlpha=al;cx.strokeStyle=`hsla(${a.hue},100%,75%,1)`;cx.shadowBlur=14;cx.shadowColor=`hsla(${a.hue},100%,65%,.6)`;cx.lineWidth=3;cx.beginPath();cx.moveTo(a.x,a.y);const mx=(a.x+a.x2)/2+(Math.random()-.5)*24,my=(a.y+a.y2)/2+(Math.random()-.5)*24;cx.lineTo(mx,my);cx.lineTo(a.x2,a.y2);cx.stroke();cx.restore();});
      cx.restore();
    }catch(_){ }return out;};f.__isoV50Render=true;window.render=f;if(CORE.setRender)CORE.setRender(f);
  }

  // ---- 8) Patch merge and update log. ----
  function updateLog(){
    const versionNodes=document.querySelectorAll('.menu-update,#menufoot span:last-child');versionNodes.forEach(n=>{if(/V3\d|V4\d|V42/i.test(n.textContent||''))n.textContent='V53 · NICOTINE + ONE-TIME FRESH RESTART';});
    const host=document.querySelector('#mega-update-panel .mega-update-scroll')||document.querySelector('#mega-update-panel')||document.querySelector('#update-log');if(!host)return;
    const counter=document.getElementById('mega-content-counter');if(counter)counter.textContent='BUILD COUNTS: '+Object.keys(DATA.ELEMS||{}).length+' ELEMENTS · '+Object.keys(DATA.MOLDEF||{}).filter(k=>DATA.MOLDEF[k]?.mol).length+' COMPOUNDS · '+(window.ALL_CARDS?.length||0)+' CARDS · '+Object.keys(DATA.ETYPES||{}).length+' ENEMY ARCHETYPES · '+(DATA.BOSSDEFS?.length||0)+' BOSSES';
    const rows=[
      ['V33 · RUNTIME HARDENING','Closed the missing global A/clamp failure path in the late ability modules. Nicotine now has an independently bound clamp helper, and the game core exports its ability table safely before later modules run.'],
      ['V50 · PATCH MERGE','Preserved the full original isotope-fixed.zip codebase. The separate (1).zip was treated as an additive patch source; its unique ability-cast feedback layer is included without replacing newer original files.'],
      ['V50 · COMPOUNDS','Expanded the real-compound catalogue with a large set of famous compounds while preserving existing entries; every real compound is assigned three separate V50 ability functions.'],
      ['V50 · NICOTINE','Nicotine Ability 1 uses a dedicated projectile conversion path; Ability 2 uses a charm mist; Ability 3 uses a targeted synaptic chain. All three feed the same safe permanent ally conversion result through different code paths.'],
      ['V50 · CARDS','Rebuilt the stat-card ladder around the requested rarity bands: common single digits, uncommon 10s, rare 20s, epic 30s, legendary 50s, mythic 70s. +1 projectile moved to rare and hit-effect cards now say “Hits inflict …” and are legendary.'],
      ['V50 · CARDS · SPECIALS','Added Luck progression, a mythic 25% ability-cooldown card, beam-power progression, cooperative shielding, and other base-stat/reaction modules while removing known generated/stat duplicates.'],
      ['V50 · COOLDOWNS','Active-ability cooldowns use each Signature’s fixed base cooldown plus legitimate relic/card/mastery modifiers; no round-based 1.8× multiplier.'],
      ['V50 · BEAMS','Compound beam width, reach, and hitbox are calculated from molecular mass, heteroatom count, and the compound’s base combat power, with layered glow and core visuals.'],
      ['V50 · MASTERY','The Element Mastery left-hand list is rebuilt from the live saved unlock list every time the screen opens and whenever a new element is bought.'],
      ['V50 · RELICS','Relic claims are now host-authoritative per player, tracked with stable pickup IDs, synchronized to co-op clients, and reloaded on every Deploy. The relic display is scrollable so more than four can be collected.'],
      ['V52 · RUNTIME HARDENING','Removed the remaining bare A/clamp dependency from late-loaded ability code. The game exports its ability table safely, Nicotine has a self-contained safeClamp, and the loaded script names are cache-busted to prevent an older broken module from being reused.'],
      ['V53 · NICOTINE + RESET','Added the dedicated large receptor projectile and moved the one-time fresh progression restart into Settings with a two-press confirmation and one-relic starter selection.'],
      ['V55 · RUNTIME STABILITY','Made the V50 stat-compute wrapper re-entry safe, guarded null enemy/player targets before speed access, and resumed suspended audio after the first user gesture.']
    ];
    if(host.dataset.v50logged==='1')return;host.dataset.v50logged='1';rows.forEach(([v,t])=>{const d=document.createElement('div');d.className='urow';d.innerHTML=`<div class="uver">${v}</div><div class="utxt">${t}</div>`;host.appendChild(d);});host.scrollTop=host.scrollHeight;
  }

  // ---- boot sequence ----
  try{injectFamousCompounds();}catch(e){console.error('V50 compound injection',e);}
  try{overhaulCompounds();}catch(e){console.error('V50 compound ability overhaul',e);}
  try{installCards();}catch(e){console.error('V50 card overhaul',e);}
  try{CORE.getComputeStats&&CORE.getComputeStats()();}catch(_){ }
  try{installHitStatusWrapper();}catch(e){console.error('V50 hit statuses',e);}
  try{installRelicUI();}catch(e){console.error('V50 relic UI',e);}
  try{refreshMastery();}catch(_){ }
  try{updateLog();}catch(_){ }
  setTimeout(()=>{try{installRelicUI();refreshMastery();updateLog();}catch(_){ }},250);
  setTimeout(()=>{try{refreshRelicPanel();refreshMastery();updateLog();}catch(_){ }},1000);
  console.log('ISOTOPE V50 FINALE active:',Object.keys(DATA.MOLDEF||{}).filter(k=>DATA.MOLDEF[k]?.mol).length,'compounds /',window.ALL_CARDS?.length||0,'cards');
})();
