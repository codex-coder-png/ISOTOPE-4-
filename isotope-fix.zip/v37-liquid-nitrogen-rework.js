/* ISOTOPE V37 — LIQUID NITROGEN ABILITY SWAP + TRUE SHATTER/FREEZE
 *
 * Liquid Nitrogen
 *  1. Former ability 3 becomes ability 1: large-radius freeze/slow pulse.
 *  2. Fires three cryogenic bullets outward. They do NOT explode; on enemy contact
 *     the projectile is consumed and breaks into exactly four outward shards.
 *  3. Former ability 1 becomes ability 3: one cryogenic bullet that shatters into
 *     four outward shards on contact.
 *
 * Every Liquid Nitrogen round and shard freezes/slows non-boss enemies on hit.
 * Bosses are explicitly excluded from the freeze status.
 * Liquid Nitrogen has deliberately low direct damage and Combust 0.
 */
(function(){
  'use strict';
  if(!window.DATA || !window.ISO_V23_CORE) return;

  var DATA=window.DATA, CORE=window.ISO_V23_CORE;
  var LN_HUE=195;
  var LN_DAMAGE_MULT=.62;
  var LN_FREEZE_TIME=2.0;
  var LN_SLOW_TIME=3.0;
  var LN_BIG_RADIUS=300;

  function findLiquidNitrogen(){
    var vals=Object.values(DATA.MOLDEF||{});
    for(var i=0;i<vals.length;i++){
      var m=vals[i];
      if(m && /liquid nitrogen/i.test(String(m.name||''))) return m;
    }
    return null;
  }
  var ln=findLiquidNitrogen();
  if(!ln) return;

  ln.f='N₂';
  ln.name='Liquid Nitrogen';
  ln.hue=LN_HUE;
  ln.mol=true;
  ln.combustLv=0;
  ln.trait='chill';
  ln.desc='Low-damage cryogenic rounds freeze and slow enemies; each round shatters into four shards on contact.';
  ln.mods=Object.assign({},ln.mods||{}, { dmg:LN_DAMAGE_MULT, rate:1.08, ps:1.12, hp:.92, spd:1.03 });
  DATA.MOLDEF['N+N']=ln;
  DATA.RECIPES['N+N']='N+N';
  DATA.RECIPES['N2']='N+N';
  DATA.RECIPES['N₂']='N+N';

  function st(){
    try{return window.ST||{};}catch(e){return {};}
  }
  function playerEl(p){return p&&p.elem ? p.elem : (window.RUN&&RUN.el ? RUN.el : null);}
  function isLN(p){
    var e=playerEl(p);
    return !!(e && /^Liquid Nitrogen$/i.test(String(e.name||'')));
  }
  function cooldown(p,s){
    if(!p) return;
    p.activeCd=Number(st().activeCd)||s;
    try{if(window.AUDIO&&AUDIO.SFX&&AUDIO.SFX.active)AUDIO.SFX.active();}catch(e){}
    if(window.RUN)RUN.shake=Math.max(RUN.shake||0,7);
  }
  function freezeLargeRadius(p){
    if(!window.RUN||!Array.isArray(RUN.enemies))return;
    RUN.enemies.forEach(function(e){
      if(!e||e.dead||e.boss)return;
      var rr=LN_BIG_RADIUS+(e.r||0);
      if((e.x-p.x)*(e.x-p.x)+(e.y-p.y)*(e.y-p.y)<=rr*rr){
        try{CORE.addFreeze(e,LN_FREEZE_TIME);}catch(err){e.freeze=Math.max(e.freeze||0,LN_FREEZE_TIME);}
        e.slowT=Math.max(e.slowT||0,LN_SLOW_TIME);
      }
    });
    try{
      CORE.ctx().save();
      CORE.ctx().strokeStyle='rgba(80,180,255,.9)';
      CORE.ctx().lineWidth=3;
      CORE.ctx().beginPath();
      CORE.ctx().arc(p.x,p.y,LN_BIG_RADIUS,0,Math.PI*2);
      CORE.ctx().stroke();
      CORE.ctx().restore();
    }catch(e){}
    try{if(window.RUN&&window.ringFx)window.ringFx(p.x,p.y,LN_HUE,LN_BIG_RADIUS,10);}catch(e){}
  }
  function makeRound(p,a){
    var S=st(),speed=Number(S.ps)||380,dmg=(Number(S.dmg)||14)*LN_DAMAGE_MULT;
    return {
      x:p.x,y:p.y,
      vx:Math.cos(a)*speed*1.38,
      vy:Math.sin(a)*speed*1.38,
      dmg:dmg,
      r:7,pierce:0,hit:[],life:1.75,owner:p.id,
      freeze:false,
      _isoV37LNShatter:true,
      semanticType:'liquid-nitrogen-round',hue:LN_HUE
    };
  }
  function spawnFourShards(b){
    if(!window.RUN)return;
    var S=st(),speed=Number(S.ps)||380,base=Math.atan2(b.vy||0,b.vx||1);
    for(var i=0;i<4;i++){
      var a=base+i*Math.PI/2;
      RUN.bullets.push({
        x:b.x,y:b.y,
        vx:Math.cos(a)*speed*1.18,
        vy:Math.sin(a)*speed*1.18,
        dmg:Math.max(1,(Number(b.dmg)||Number(S.dmg)||14)*.30),
        r:4,pierce:0,hit:[],life:.72,owner:b.owner,
        freeze:false,_isoV37LNShard:true,
        semanticType:'liquid-nitrogen-shard',hue:LN_HUE
      });
    }
    // Tiny cryogenic particle burst: visual shatter, not an explosion/AOE.
    try{
      for(var k=0;k<8;k++){
        var aa=Math.random()*Math.PI*2;
        RUN.parts.push({x:b.x,y:b.y,vx:Math.cos(aa)*90,vy:Math.sin(aa)*90,t:.18,life:.18,hue:LN_HUE,r:1.6});
      }
    }catch(e){}
  }

  /* Exact ability order requested. */
  ln.choices=[
    {
      name:'Liquid Nitrogen — Cryogenic Field',ic:'❄',slot:0,main:true,cd:6,
      desc:'Freezes and slows non-boss enemies in a large radius around you.',
      exec:function(p){if(!window.RUN)return;cooldown(p,6);freezeLargeRadius(p);}
    },
    {
      name:'Liquid Nitrogen — Shatter Volley',ic:'❄️',slot:1,cd:7,
      desc:'Fires three cryogenic bullets outward. Each breaks into four shards on enemy contact; the shards freeze and slow enemies they hit.',
      exec:function(p){
        if(!window.RUN)return;
        cooldown(p,7);
        var a=p.angle||0;
        for(var i=-1;i<=1;i++) RUN.bullets.push(makeRound(p,a+i*.25));
      }
    },
    {
      name:'Liquid Nitrogen — Cryogenic Shatter',ic:'🧊',slot:2,cd:5.5,
      desc:'Fires a low-damage cryogenic bullet that shatters into four outward shards on enemy contact; the shards freeze and slow enemies they hit.',
      exec:function(p){if(!window.RUN)return;cooldown(p,5.5);RUN.bullets.push(makeRound(p,p.angle||0));}
    }
  ];
  ln.signatures=ln.choices;
  ln.act=ln.choices[0];

  /* Replace V36's Liquid Nitrogen hit flags after every fire path. */
  if(!window.__ISO_V37_LN_FIRE__){
    window.__ISO_V37_LN_FIRE__=true;
    var oldFire=CORE.getFire();
    CORE.setFire(function(p){
      var before=window.RUN&&RUN.bullets?RUN.bullets.length:0;
      if(typeof oldFire==='function') oldFire(p);
      if(!window.RUN||!isLN(p))return;
      for(var i=before;i<RUN.bullets.length;i++){
        var b=RUN.bullets[i];
        if(!b||b.owner!==p.id||!b.main)continue;
        b.expl=false;
        b.burn=false;
        b._isoLNShatter=false;
        b._isoLNCryoBurst=false;
        b._isoV37LNShatter=true;
        b.freeze=false;
        b.hue=LN_HUE;
        b.dmg=(Number(st().dmg)||14)*LN_DAMAGE_MULT;
      }
    });
  }

  /* Custom hit handler: no LN explosion/AOE. The projectile is consumed and
     exactly four shards replace it. */
  if(!window.__ISO_V37_LN_HIT__){
    window.__ISO_V37_LN_HIT__=true;
    var oldHit=CORE.getApplyElemHit();
    CORE.setApplyElemHit(function(b,e){
      if(!b||!e)return;
      var special=!!b._isoV37LNShatter, shard=!!b._isoV37LNShard;
      if(special||shard){
        /* We still want the normal damage/death/drop pipeline first, but do not
           allow inherited V36 LN freeze/AOE behavior to run for this projectile. */
        var prevShatter=b._isoLNShatter, prevBurst=b._isoLNCryoBurst, prevFreeze=b.freeze;
        b._isoLNShatter=false;
        b._isoLNCryoBurst=false;
        b.freeze=false;
        if(typeof oldHit==='function'){
          try{oldHit(b,e);}catch(err){console.error('V37 LN hit base chain',err);}
        }
        b._isoLNShatter=prevShatter;
        b._isoLNCryoBurst=prevBurst;
        b.freeze=prevFreeze;
        if(!e.dead && !e.boss){
          try{CORE.addFreeze(e,LN_FREEZE_TIME);}catch(err){e.freeze=Math.max(e.freeze||0,LN_FREEZE_TIME);}
          e.slowT=Math.max(e.slowT||0,LN_SLOW_TIME);
        }
        if(special && !b._isoV37Consumed){
          b._isoV37Consumed=true;
          b.life=0;
          b.pierce=0;
          spawnFourShards(b);
        }
        return;
      }
      if(typeof oldHit==='function')return oldHit(b,e);
    });
  }

  /* Make sure shots created by other late fire layers also use the V37 shatter
     semantics, including normal M1 shots. */
  var oldChoices=ln.choices;
  ln.choices=oldChoices;
  ln.signatures=ln.choices;
  ln.act=ln.choices[0];

  /* Re-map the selected player's active to the current Liquid Nitrogen choices
     without introducing any new popup/banner UI. */
  if(!window.__ISO_V37_LN_USEACTIVE__){
    window.__ISO_V37_LN_USEACTIVE__=true;
    var oldActive=CORE.getUseActive();
    CORE.setUseActive(function(p){
      if(!isLN(p))return oldActive(p);
      if(!p||p.downed||(p.activeCd||0)>0)return;
      var slot=Math.max(0,Math.min(2,Number(p.signatureSlot)||0));
      var choice=ln.choices[slot];
      if(!choice||typeof choice.exec!=='function')return;
      choice.exec(p);
    });
  }

  console.log('ISOTOPE V37: Liquid Nitrogen ability order swapped; ability 1 is large freeze field, ability 2 is 3-shot shatter volley, ability 3 is single shatter round; LN uses 4-shard contact shatter with no explosion/AOE.');
})();
