/* ISOTOPE V31 — NITROGLYCERIN RECIPE FIX
   Fixes the synthesis lookup for C3H5N3O9. The Synthesis Lab canonicalizes
   ingredient tokens alphabetically, so this registers the exact canonical key
   plus a formula-based fallback. */
(function(){
  'use strict';
  if(!window.DATA || !DATA.MOLDEF || !DATA.RECIPES) return;

  var KEY='C+C+C+H+H+H+H+H+N+N+N+O+O+O+O+O+O+O+O+O';

  function findNitro(){
    var vals=Object.values(DATA.MOLDEF||{});
    for(var i=0;i<vals.length;i++){
      var m=vals[i];
      if(m && /nitroglycerin/i.test(String(m.name||''))) return m;
    }
    return null;
  }

  var nit=findNitro();

  /* If an older layer created it under a different key, normalize it. */
  if(nit){
    DATA.MOLDEF[KEY]=nit;
  }else{
    nit={
      token:'Nitroglycerin',
      f:'C₃H₅N₃O₉',
      name:'Nitroglycerin',
      hue:12,
      mods:{dmg:.78,rate:1.04},
      trait:'combust',
      desc:'Low direct damage, but catches enemies on fire and builds toward volatile combustion.',
      rx:'3C+5H+3N+9O',
      recipe:'3C+5H+3N+9O',
      mol:true,
      cost:320,
      combustLv:4
    };
    DATA.MOLDEF[KEY]=nit;
  }

  /* The UI uses this exact key after sorting the selected ingredient tokens. */
  DATA.RECIPES[KEY]=KEY;

  /* Also register the equivalent compact formula as metadata for other
     synthesis systems that resolve by formula instead of token key. */
  DATA.RECIPES['C3H5N3O9']=KEY;
  DATA.RECIPES['C₃H₅N₃O₉']=KEY;

  /* Make sure the compound is treated as a real catalogued compound. */
  nit.mol=true;
  nit.f=nit.f||'C₃H₅N₃O₉';
  nit.rx='3C+5H+3N+9O';
  nit.recipe='3C+5H+3N+9O';

  console.log('ISOTOPE V31: Nitroglycerin synthesis recipe registered:',KEY);

  window.ISOTOPE_NITRO_FIX_V31={
    key:KEY,
    formula:'C3H5N3O9',
    registered:DATA.RECIPES[KEY]===KEY,
    compound:DATA.MOLDEF[KEY]
  };
})();
