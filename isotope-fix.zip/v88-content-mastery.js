/* ISOTOPE V88 — COMPOUND EXPANSION + PER-ABILITY SIGNATURE MASTERY
 * Built on the current isotope-fix-nicotine-playable version.
 * Adds a duplicate-safe real-compound expansion, three working custom moves for
 * every newly added compound, a Minecraft-style science splash, per-ability
 * signature upgrade paths, and removal of element/compound-exclusive cards.
 */
(function(){
  'use strict';
  if(window.__ISO_V88_CONTENT_MASTERY__)return;
  window.__ISO_V88_CONTENT_MASTERY__=true;

  var D=window.DATA||{}, S=window.SAVE||{}, TAU=Math.PI*2;
  var PATHS={
    damage:{label:'DAMAGE',desc:'+12% SIGNATURE DAMAGE / RANK',icon:'⚔',mult:1.12},
    range:{label:'RANGE',desc:'+18% SIGNATURE RANGE / RANK',icon:'⌁',mult:1.18},
    cooldown:{label:'COOLDOWN',desc:'-10% SIGNATURE COOLDOWN / RANK',icon:'⟳',mult:.90}
  };
  var COSTS=[100,180,300];
  var pending={};

  function run(){return window.RUN||null}
  function clamp(v,a,b){return v<a?a:v>b?b:v}
  function d2(a,b,x,y){var dx=a-x,dy=b-y;return dx*dx+dy*dy}
  function players(){var r=run();return r&&Array.isArray(r.players)?r.players:[]}
  function enemies(){var r=run();return r&&Array.isArray(r.enemies)?r.enemies.filter(function(e){return e&&!e.dead&&!e._v29Converted&&e.team!=='player'&&Number(e.hp)>0}):[]}
  function pHue(p,m){return Number(m&&m.hue)!=null?Number(m.hue):Number(p&&p.elem&&p.elem.hue)||190}
  function dmg(e,v){try{if(window.dmgEnemy)window.dmgEnemy(e,v,{quiet:true,pierce:true});else{e.hp-=v;if(e.hp<=0)e.dead=true}}catch(_){}}
  function burst(x,y,hue,n){try{if(window.fxBurst)window.fxBurst(x,y,hue,n||16)}catch(_){} }
  function ring(x,y,hue,r,w,l){try{if(window.fxRing)window.fxRing(x,y,hue,r||80,w||6,l||.45);else if(window.ringFx)window.ringFx(x,y,hue,r||80,w||6)}catch(_){} }
  function status(e,k){try{
    if(k==='burn'&&window.addBurn)window.addBurn(e,1.25,3.2);
    else if(k==='freeze'&&window.addFreeze)window.addFreeze(e,1.25);
    else if(k==='corrode'&&window.addCorrode)window.addCorrode(e,4,.36);
    else if(k==='rust'&&window.addRust)window.addRust(e,3.8,.72);
  }catch(_){} }
  function fireBeam(p,m,opt){
    var r=run();if(!r||!p)return;
    opt=opt||{};var hue=pHue(p,m),a=Number.isFinite(Number(p.angle))?Number(p.angle):0;
    var len=Number(opt.len)||260,width=Number(opt.width)||8;
    var x2=clamp(p.x+Math.cos(a)*len,20,(window.innerWidth||W||1200)-20),y2=clamp(p.y+Math.sin(a)*len,20,(window.innerHeight||H||800)-20);
    var power=Number(opt.power)||1,amount=(Number(window.ST&&ST.dmg)||18)*power*(opt.damageMul||1);
    r._isoV50Beams=r._isoV50Beams||[];
    r._isoV50Beams.push({x:p.x,y:p.y,x2:x2,y2:y2,width:width,life:Number(opt.life)||.34,max:Number(opt.life)||.34,hue:hue,realPower:power,compound:m.name});
    var vx=x2-p.x,vy=y2-p.y,den=vx*vx+vy*vy||1;
    enemies().forEach(function(e){
      var wx=e.x-p.x,wy=e.y-p.y,t=clamp((wx*vx+wy*vy)/den,0,1),px=p.x+vx*t,py=p.y+vy*t;
      if(d2(e.x,e.y,px,py)<Math.pow(width+(e.r||10),2)){dmg(e,amount);if(opt.status)status(e,opt.status);if(opt.slow)e.slowT=Math.max(e.slowT||0,opt.slow)}
    });
    ring(p.x,p.y,hue,42,4,.22);burst(x2,y2,hue,8);
  }
  function bullet(p,m,ang,speed,damage,r,pierce,life,extra){
    var R=run();if(!R||!Array.isArray(R.bullets))return;
    var hue=pHue(p,m);R.bullets.push(Object.assign({x:p.x+Math.cos(ang)*18,y:p.y+Math.sin(ang)*18,vx:Math.cos(ang)*speed,vy:Math.sin(ang)*speed,dmg:damage,r:r||5,pierce:pierce||1,hit:[],life:life||1.4,owner:p.id,hue:hue},extra||{}));
  }
  function burstAt(p,m,rad,mul,statusKey){
    var R=run();if(!R)return;var x=clamp(Number(window.mouse&&mouse.x)||p.x,20,(window.innerWidth||W||1200)-20),y=clamp(Number(window.mouse&&mouse.y)||p.y,20,(window.innerHeight||H||800)-20),hue=pHue(p,m),amt=(Number(window.ST&&ST.dmg)||18)*(mul||1.5);
    enemies().forEach(function(e){if(d2(e.x,e.y,x,y)<rad*rad){dmg(e,amt);if(statusKey)status(e,statusKey)}});
    R._isoV50Bursts=R._isoV50Bursts||[];R._isoV50Bursts.push({x:x,y:y,r:rad,t:.42,life:.42,hue:hue,power:Math.min(3,(mul||1.5)+.5)});ring(x,y,hue,rad,7,.5);burst(x,y,hue,24);
  }
  function field(p,m,rad,mode,duration,interval){
    var R=run();if(!R)return;var x=clamp(Number(window.mouse&&mouse.x)||p.x,20,(window.innerWidth||W||1200)-20),y=clamp(Number(window.mouse&&mouse.y)||p.y,20,(window.innerHeight||H||800)-20),hue=pHue(p,m);
    R._isoV50Fields=R._isoV50Fields||[];R._isoV50Fields.push({x:x,y:y,r:rad,t:duration||3.4,life:duration||3.4,mode:mode||'debuff',hue:hue,interval:interval||.35,acc:0});ring(x,y,hue,rad,7,.55);burst(x,y,hue,18);
  }
  function dash(p,m,dist,rad,mul,statusKey){
    var R=run();if(!R)return;var a=Number(p.angle)||0,hue=pHue(p,m);p.iframes=Math.max(Number(p.iframes)||0,.42);p.x=clamp(p.x+Math.cos(a)*dist,24,(window.innerWidth||W||1200)-24);p.y=clamp(p.y+Math.sin(a)*dist,24,(window.innerHeight||H||800)-24);burstAt({x:p.x,y:p.y,id:p.id},m,rad,mul,statusKey);ring(p.x,p.y,hue,rad,5,.34);
  }
  function chain(p,m,count,mul,statusKey){
    var R=run();if(!R)return;var hue=pHue(p,m),x=clamp(Number(window.mouse&&mouse.x)||p.x,20,(window.innerWidth||W||1200)-20),y=clamp(Number(window.mouse&&mouse.y)||p.y,20,(window.innerHeight||H||800)-20);
    var list=enemies().sort(function(a,b){return d2(a.x,a.y,x,y)-d2(b.x,b.y,x,y)}).slice(0,count||5),last={x:x,y:y};
    list.forEach(function(e,i){dmg(e,(Number(window.ST&&ST.dmg)||18)*(mul||1));if(statusKey)status(e,statusKey);R._isoV50Arcs=R._isoV50Arcs||[];R._isoV50Arcs.push({x:last.x,y:last.y,x2:e.x,y2:e.y,t:.3,life:.3,hue:hue});last=e;});burst(x,y,hue,16);
  }
  function buff(p,m,type){
    var hue=pHue(p,m),R=run();if(!p)return;
    if(type==='speed'){p.puSpeed=Math.max(p.puSpeed||1,1.42);p.puTimer=Math.max(p.puTimer||0,6.5)}
    else if(type==='fire'){p.puRate=Math.max(p.puRate||1,1.38);p.puDamage=Math.max(p.puDamage||1,1.18);p.puTimer=Math.max(p.puTimer||0,6.5)}
    else if(type==='shield')p.sh=Math.min(Number(window.ST&&ST.shieldMax)||100,(p.sh||0)+(Number(window.ST&&ST.shieldMax)||100)*.28);
    else {p.hp=Math.min(Number(window.ST&&ST.hp)||p.hp,p.hp+(Number(window.ST&&ST.hp)||100)*.18);p.iframes=Math.max(p.iframes||0,.35)}
    ring(p.x,p.y,hue,90,6,.5);burst(p.x,p.y,hue,20);if(R)R.texts&&R.texts.push({x:p.x,y:p.y,s:type.toUpperCase()+' SURGE',t:.8,life:.8,hue:hue});
  }
  function markBurst(p,m){
    var hue=pHue(p,m),R=run(),target=null,md=Infinity;
    enemies().forEach(function(e){var dd=d2(e.x,e.y,p.x,p.y);if(dd<md){md=dd;target=e}});
    if(!target)return;target._isoV88Marked=(target._isoV88Marked||0)+1;dmg(target,(Number(window.ST&&ST.dmg)||18)*1.55);status(target,'corrode');ring(target.x,target.y,hue,(target.r||10)+16,4,.35);burst(target.x,target.y,hue,14);
    if(R){R._isoV50Arcs=R._isoV50Arcs||[];R._isoV50Arcs.push({x:p.x,y:p.y,x2:target.x,y2:target.y,t:.35,life:.35,hue:hue})}
  }
  function delayed(p,m,delay,rad,mul,statusKey){
    var R=run();if(!R)return;var x=clamp(Number(window.mouse&&mouse.x)||p.x,20,(window.innerWidth||W||1200)-20),y=clamp(Number(window.mouse&&mouse.y)||p.y,20,(window.innerHeight||H||800)-20),hue=pHue(p,m);ring(x,y,hue,rad,4,.25);burst(x,y,hue,10);
    setTimeout(function(){if(window.RUN!==R)return;burstAt({x:x,y:y,id:p.id},m,rad,mul,statusKey)},delay||850);
  }
  function orbital(p,m){
    var R=run();if(!R)return;var hue=pHue(p,m),a=Number(p.angle)||0;
    for(var i=0;i<5;i++){var aa=a+TAU*i/5;bullet(p,m,aa,330+i*28,(Number(window.ST&&ST.dmg)||18)*(.72+i*.08),5,2,1.25,{orbitShot:true})}
    ring(p.x,p.y,hue,70,5,.4);
  }

  /* ---------- NEW REAL COMPOUND CATALOG ---------- */
  var NEW=[
    {n:'Methamphetamine',f:'C10H15N',cat:'stimulant',h:18,mods:{dmg:1.12,rate:1.16,spd:1.08},moves:[['Adrenal Surge','Rapidly amplifies movement and fire rate for a short burst.','buffFire'],['Rush Volley','Fires a tight fan of hyper-fast rounds.','rushVolley'],['Crashwave','A violent recoil pulse around the target that slows survivors.','crashwave']]},
    {n:'Fentanyl',f:'C22H28N2O',cat:'opioid',h:338,mods:{dmg:1.2,hp:1.18,rate:.9},moves:[['Opioid Beam','A focused beam heavily slows enemies it touches.','beamSlow'],['Respiratory Field','Deploys a dense field that drains and slows hostile movement.','slowField'],['Sedation Chain','Jumps between several enemies, briefly freezing each target.','chainFreeze']]},
    {n:'Morphine',f:'C17H19NO3',cat:'opioid',h:345,mods:{dmg:1.06,hp:1.2},moves:[['Analgesic Ray','A narrow ray that cuts through a line of enemies.','beamCorrode'],['Calm Zone','Creates a field that steadily weakens hostile defenses.','debuffField'],['Mend Through Pain','Heals you and nearby allies while granting brief invulnerability.','healPulse']]},
    {n:'Heroin (Diacetylmorphine)',f:'C21H23NO5',cat:'opioid',h:350,mods:{dmg:1.16,hp:1.1,rate:.94},moves:[['Dark Needle','Fires three heavy penetrating needles.','tripleNeedle'],['Narcotic Haze','Creates a wide slowing haze around the target point.','slowFieldWide'],['Blackout Wave','A delayed pulse freezes the nearest wave of enemies.','delayedFreeze']]},
    {n:'Cocaine',f:'C17H21NO4',cat:'stimulant',h:52,mods:{rate:1.2,spd:1.12,dmg:1.04},moves:[['Nerve Spark','Marks the nearest foe with a high-voltage hit.','markShock'],['Rapid Fire','Fires a burst of seven accelerating rounds.','rushVolley'],['Overclock Dash','Dashes forward in a protected burst and detonates on arrival.','dashBurst']]},
    {n:'MDMA',f:'C11H15NO2',cat:'empathogen',h:306,mods:{rate:1.1,hp:1.06},moves:[['Pulse of Empathy','Boosts damage and fire rate for the whole team.','teamFire'],['Serotonin Halo','A bright radial pulse heals allies and damages nearby enemies.','supportBlast'],['Connected Cascade','Chains between enemies and allies, alternating damage and healing.','allyChain']]},
    {n:'LSD',f:'C20H25N3O',cat:'psychedelic',h:278,mods:{rate:1.08,crit:12,spd:1.05},moves:[['Prismatic Ray','A long multicolor-looking precision beam.','prismBeam'],['Distortion Field','Enemies in the field are slowed and corroded.','debuffField'],['Reality Fold','Pulls nearby enemies toward a point before a burst.','gravityBurst']]},
    {n:'Psilocybin',f:'C12H17N2O4P',cat:'psychedelic',h:262,mods:{dmg:1.08,rate:1.04,spd:1.06},moves:[['Spore Lance','A straight projectile stream that pierces multiple enemies.','pierceVolley'],['Fractal Garden','Creates a circular field of repeating corrosive pulses.','corrodeField'],['Ego Dissolution','Temporarily collapses enemy spacing into a single gravity burst.','gravityBurst']]},
    {n:'Delta-9-Tetrahydrocannabinol (THC)',f:'C21H30O2',cat:'cannabinoid',h:118,mods:{hp:1.14,spd:1.05},moves:[['Cannabinoid Beam','A soft-looking beam that heavily reduces enemy speed.','beamSlow'],['Sticky Canopy','A wide field that slows and rusts enemies.','rustField'],['Mellow Drift','A protected forward dash that leaves a slowing trail.','dashTrail']]},
    {n:'Ketamine',f:'C13H16ClNO',cat:'anesthetic',h:205,mods:{hp:1.08,spd:1.08},moves:[['Dissociation Beam','A thin beam that phases through targets while freezing them.','beamFreeze'],['Blank Space','Drops a field that suppresses enemy movement.','freezeField'],['Out-of-Body Dash','Briefly becomes intangible, then bursts from the dash endpoint.','dashBurstWide']]},
    {n:'Propofol',f:'C12H18O',cat:'anesthetic',h:42,mods:{hp:1.16,rate:.92,dmg:1.08},moves:[['Induction Needle','Three heavy shots seek the nearest enemies.','homingVolley'],['Anesthetic Pool','Creates a quiet field that slows enemies almost to a stop.','slowFieldWide'],['Sleep Cycle','After a short delay, a large circle freezes everything inside.','delayedFreeze']]},
    {n:'Melatonin',f:'C13H16N2O2',cat:'bioactive',h:235,mods:{hp:1.18,spd:1.03},moves:[['Night Beam','A dark-spectrum beam that slows and rusts targets.','beamRust'],['Circadian Field','A timed field that weakens enemy attacks.','debuffField'],['Sleep Reset','Restores health and shield while granting a short defensive window.','healShield']]},
    {n:'Diazepam',f:'C16H13ClN2O',cat:'anesthetic',h:222,mods:{hp:1.12,dmg:1.06},moves:[['Quiet Ray','A calming ray that freezes the first enemies in its path.','beamFreeze'],['Tranquility Zone','A field that repeatedly slows hostile movement.','slowField'],['Emergency Sedation','A delayed radial freeze centered on the nearest enemy.','targetedFreeze']]},
    {n:'Chloroquine',f:'C18H26ClN3',cat:'medicine',h:174,mods:{dmg:1.1,rate:1.04,hp:1.06},moves:[['Antimalarial Beam','A precise energy beam that corrodes armored targets.','beamCorrode'],['Quinine-Like Field','A defensive field that pulses damage around you.','personalField'],['Parasite Breaker','Chains a hard strike through several marked enemies.','chainCorrode']]},
    {n:'Amoxicillin',f:'C16H19N3O5S',cat:'medicine',h:48,mods:{dmg:1.08,hp:1.12},moves:[['Beta-Lactam Lance','A heavy lance of projectiles that pierces lines.','pierceVolley'],['Cell-Wall Collapse','Corrosive area attack that rapidly weakens enemies.','corrodeField'],['Dose Burst','Heals allies and detonates a medicinal pulse around each one.','teamMendBlast']]},
    {n:'Penicillin G',f:'C16H18N2O4S',cat:'medicine',h:66,mods:{dmg:1.06,hp:1.1,rate:1.04},moves:[['Penicillin Ray','A straight corrosive beam with strong armor stripping.','beamCorrodeWide'],['Culture Flood','Creates a persistent reaction field.','corrodeField'],['Antibiotic Relay','Targets up to six enemies with linked strikes.','chainCorrode']]},
    {n:'Penicillin V',f:'C16H18N2O5S',cat:'medicine',h:82,mods:{dmg:1.05,hp:1.1,spd:1.04},moves:[['Violet Lance','Fires a narrow purple-coded projectile stream.','pierceVolley'],['Oral Dose Field','A field that weakens enemies while restoring your shield.','shieldField'],['Broad-Spectrum Burst','A large delayed detonation that corrodes survivors.','delayedCorrode']]},
    {n:'Erythromycin',f:'C37H67NO13',cat:'medicine',h:98,mods:{hp:1.2,dmg:1.1,rate:.9},moves:[['Macrolide Beam','A broad line attack with a long reach.','beamCorrodeWide'],['Ribosome Lock','Enemies inside the zone are slowed and steadily damaged.','debuffFieldWide'],['Recovery Cycle','Heals the team and releases a protective pulse.','teamHealPulse']]},
    {n:'Epinephrine',f:'C9H13NO3',cat:'hormone',h:6,mods:{rate:1.18,spd:1.16},moves:[['Fight-or-Flight','Major temporary speed and fire-rate boost.','buffSpeedFire'],['Adrenal Bolt','Fires five fast shots with increasing damage.','rushVolley'],['Emergency Response','A protected dash that explodes and immediately restores a chunk of shield.','dashShieldBurst']]},
    {n:'Dopamine',f:'C8H11NO2',cat:'neurotransmitter',h:44,mods:{rate:1.1,crit:10},moves:[['Reward Beam','Precision beam whose final hit bursts outward.','beamBurst'],['Motivation Field','A field that improves player damage and fire rate while active.','playerField'],['Feedback Loop','Chains through enemies and restores a little health per target hit.','chainHeal']]},
    {n:'Serotonin',f:'C10H12N2O',cat:'neurotransmitter',h:295,mods:{hp:1.14,rate:1.05},moves:[['Mood Ray','A wide ray that slows everything in its path.','beamSlowWide'],['Harmony Pulse','A radial heal/shield pulse that also staggers enemies.','supportBlast'],['Balanced Cascade','Alternates between damaging and healing targets in range.','allyChain']]},
    {n:'Melamine',f:'C3H6N6',cat:'industrial',h:188,mods:{hp:1.16,crit:8},moves:[['Nitrogen Spike','Launches a triangular volley of piercing rounds.','pierceVolleyWide'],['Resin Net','Places a dense rust field that pins enemy movement.','rustFieldWide'],['Trimeric Burst','Three timed pulses erupt around the target point.','tripleDelayed']]},
    {n:'Cyanuric Acid',f:'C3H3N3O3',cat:'industrial',h:154,mods:{dmg:1.16,hp:1.06},moves:[['Ring Acid Beam','A wide chemical beam that corrodes enemies.','beamCorrodeWide'],['Stabilizer Field','A reaction field with repeated rust pulses.','rustField'],['Cyanuric Collapse','Pulls foes inward and detonates once compressed.','gravityBurstBig']]},
    {n:'Indigo',f:'C16H10N2O2',cat:'dye',h:250,mods:{crit:14,rate:1.05},moves:[['Indigo Laser','Long precision beam in the compound hue.','beamPrecision'],['Dye Splash','Marks the target area with a wide colored burst.','burstMark'],['Vat Echo','Creates three orbiting shots that fire outward in sequence.','orbital']]},
    {n:'Vanillin',f:'C8H8O3',cat:'aromatic',h:30,mods:{rate:1.08,spd:1.08},moves:[['Vanilla Ray','A sweet-looking precision beam that applies brittle.','beamBrittle'],['Aroma Cloud','A wide field that slows and rusts enemies.','rustFieldWide'],['Aromatic Bloom','A radial burst followed by a five-shot fan.','bloomFan']]},
    {n:'Menthol',f:'C10H20O',cat:'cooling',h:165,mods:{spd:1.14,rate:1.08},moves:[['Cooling Beam','A cold beam that freezes its path.','beamFreezeWide'],['Mint Field','A large field that slows every hostile in it.','freezeField'],['Crystal Dash','Dash through enemies with brief invulnerability and leave a cold burst behind.','dashBurstWideFreeze']]},
    {n:'Capsaicin',f:'C18H27NO3',cat:'irritant',h:8,mods:{dmg:1.16,rate:1.06},moves:[['Heat Sting','A piercing red beam that burns targets.','beamBurn'],['Spice Cloud','Creates a burning area that ticks rapidly.','burnFieldWide'],['Pepper Flash','A point-blank burst that burns and knocks enemies outward.','burnKnockback']]},
    {n:'DDT',f:'C14H9Cl5',cat:'pesticide',h:195,mods:{dmg:1.18,hp:1.08},moves:[['Persistent Ray','A long beam that rusts anything it touches.','beamRust'],['Residual Film','Leaves a lingering field that keeps damaging enemies.','rustFieldWide'],['Contact Cascade','A chain reaction jumps through nearby hostiles.','chainRust']]},
    {n:'TNT',f:'C7H5N3O6',cat:'explosive',h:16,mods:{dmg:1.3,rate:.86,spd:.9},moves:[['Trinitro Beam','A short heavy beam that primes targets.','beamPrime'],['Detonation Charge','Places a delayed high-damage charge at the target point.','delayedBig'],['Three-Nitro Chain','Three sequential blasts leap across the nearest enemies.','tripleBurstChain']]},
    {n:'Picric Acid',f:'C6H3N3O7',cat:'explosive-acid',h:58,mods:{dmg:1.22,rate:.92},moves:[['Picrate Ray','A focused yellow beam that burns and corrodes.','beamBurnCorrode'],['Picric Crater','Creates a large corrosive crater.','corrodeFieldWide'],['Shock Decomposition','A delayed blast followed by a smaller aftershock.','doubleDelayed']]},
    {n:'Carbon Disulfide',f:'CS2',cat:'solvent',h:28,mods:{rate:1.12,spd:1.12,dmg:1.08},moves:[['Disulfide Beam','A hot-looking beam with high projectile speed.','beamBurn'],['Solvent Wake','A moving field follows your current position briefly.','playerTrailBurn'],['Flash Solvent','A fast dash that ends in a compact burn explosion.','dashBurst']]},
    {n:'Silane',f:'SiH4',cat:'volatile',h:205,mods:{rate:1.2,spd:1.1},moves:[['Silicon Hydride Ray','A fast, narrow beam.','beamPrecision'],['Spontaneous Wake','Leaves a short-lived reactive field behind movement.','playerTrailRust'],['Pyrophoric Burst','A protected dash ignites the endpoint.','dashBurn']]},
    {n:'Nitrogen Pentoxide',f:'N2O5',cat:'oxidizer',h:282,mods:{dmg:1.2,rate:.96},moves:[['Pentoxide Beam','A strong oxidizing beam that burns targets.','beamBurnWide'],['Nitrating Zone','Places a persistent burn field.','burnFieldWide'],['Five-Oxygen Collapse','A delayed large blast with a hot aftershock.','doubleDelayed']]},
    {n:'Sulfur Hexafluoride',f:'SF6',cat:'heavy-gas',h:198,mods:{hp:1.22,spd:.9,dmg:1.1},moves:[['Heavy Gas Ray','A dense beam with strong range but reduced spread.','beamPrecisionWide'],['Hexafluoride Sink','Creates a field that drags enemies inward.','gravityField'],['Suppression Pulse','A radial burst that slows the entire nearby pack.','slowBurst']]},
    {n:'Buckminsterfullerene',f:'C60',cat:'nanocarbon',h:262,mods:{crit:18,dmg:1.14,spd:1.06},moves:[['Buckyball Lance','Fires compact spherical projectiles with high pierce.','pierceVolley'],['Molecular Orbit','Five projectiles orbit you before shooting outward.','orbital'],['Fullerene Collapse','A gravity-like implosion followed by a sharp pulse.','gravityBurstBig']]},
    {n:'Tetrodotoxin',f:'C11H17N3O8',cat:'toxin',h:115,mods:{dmg:1.2,rate:1.05},moves:[['Sodium Block','A beam that drastically slows enemy movement.','beamSlowWide'],['Neurotoxin Field','A persistent hostile-debuff field.','debuffFieldWide'],['Channel Shutdown','Freezes several nearby enemies in a chained strike.','chainFreeze']]}
  ];

  function formulaKey(f){
    var a=[];String(f||'').replace(/([A-Z][a-z]?)(\d*)/g,function(_,e,n){a.push([e,Math.max(1,Number(n||1))])});
    a.sort(function(x,y){return x[0].localeCompare(y[0])});return a.map(function(x){return x[0]+(x[1]>1?x[1]:'')}).join('+');
  }
  function mass(f){var aw={H:1,C:12,N:14,O:16,F:19,Na:23,Mg:24,Al:27,Si:28,P:31,S:32,Cl:35.5,K:39,Ca:40,Fe:56,Co:59,Ni:59,Cu:64,Zn:65,Br:80,Ag:108,I:127,Ba:137,Pt:195,Au:197,Hg:201,Pb:207,Bi:209};var n=0;String(f).replace(/([A-Z][a-z]?)(\d*)/g,function(_,e,c){n+=(aw[e]||70)*Math.max(1,Number(c||1))});return n}
  function hueFrom(name){var h=0;for(var i=0;i<name.length;i++)h=(h*33+name.charCodeAt(i))%360;return 25+h}
  function addCompound(x){
    if(!D.MOLDEF||!D.RECIPES)return null;
    var fk=formulaKey(x.f), lname=x.n.toLowerCase();
    var existingKey=Object.keys(D.MOLDEF).find(function(k){var m=D.MOLDEF[k];return m&&m.mol&&(String(m.name||'').toLowerCase()===lname||k===fk||String(m.f||'').toLowerCase()===x.f.toLowerCase())});
    if(existingKey)return D.MOLDEF[existingKey];
    var m={id:'v88_'+fk,token:x.f,f:x.f,name:x.n,hue:x.h!=null?x.h:hueFrom(x.n),mods:Object.assign({dmg:1,rate:1,ps:1,hp:1,spd:1,crit:0},x.mods||{}),cat:x.cat||'general',mol:true,rx:'Real compound',cost:Math.round(160+mass(x.f)*1.15),desc:'Famous real compound added in V88. Three dedicated gameplay moves use this compound as the theme.'};
    D.MOLDEF[fk]=m;D.RECIPES[fk]=fk; m.v88Added=true;m.v88Kit=x.moves||[];return m;
  }

  var added=[];
  NEW.forEach(function(x){var m=addCompound(x);if(m&&m.v88Added)added.push(m)});
  D.V88_NEW_COMPOUNDS=added.map(function(m){return {key:Object.keys(D.MOLDEF).find(function(k){return D.MOLDEF[k]===m}),name:m.name,formula:m.f}});

  /* ---------- three custom abilities for every V88 compound ---------- */
  function execMove(kind,p,m){
    switch(kind){
      case 'buffFire':buff(p,m,'fire');break;
      case 'buffSpeedFire':buff(p,m,'fire');buff(p,m,'speed');break;
      case 'buffSpeed':buff(p,m,'speed');break;
      case 'beamSlow':fireBeam(p,m,{len:330,width:10,power:1.6,damageMul:1.0,status:null,slow:3.2});break;
      case 'beamSlowWide':fireBeam(p,m,{len:285,width:16,power:1.45,damageMul:1.08,slow:4});break;
      case 'beamCorrode':fireBeam(p,m,{len:300,width:8,power:1.58,status:'corrode'});break;
      case 'beamCorrodeWide':fireBeam(p,m,{len:285,width:15,power:1.5,damageMul:1.1,status:'corrode'});break;
      case 'beamFreeze':fireBeam(p,m,{len:300,width:8,power:1.45,status:'freeze',slow:2});break;
      case 'beamFreezeWide':fireBeam(p,m,{len:280,width:16,power:1.35,status:'freeze',slow:2.4});break;
      case 'beamRust':fireBeam(p,m,{len:315,width:9,power:1.5,status:'rust',slow:1.8});break;
      case 'beamPrecision':fireBeam(p,m,{len:390,width:4,power:2.0,damageMul:1.18});break;
      case 'beamBrittle':fireBeam(p,m,{len:300,width:8,power:1.45,status:null,slow:1});break;
      case 'beamBurst':fireBeam(p,m,{len:260,width:7,power:1.5,damageMul:1.15});burstAt(p,m,72,1.0,null);break;
      case 'beamBurn':fireBeam(p,m,{len:290,width:8,power:1.5,status:'burn'});break;
      case 'beamBurnWide':fireBeam(p,m,{len:285,width:14,power:1.52,status:'burn'});break;
      case 'beamBurnCorrode':fireBeam(p,m,{len:290,width:10,power:1.48,status:'burn'});enemies().forEach(function(e){if(d2(e.x,e.y,p.x,p.y)<300*300)status(e,'corrode')});break;
      case 'beamPrime':fireBeam(p,m,{len:260,width:12,power:1.7,status:'burn'});enemies().slice(0,8).forEach(function(e){e._isoV88Prime=(e._isoV88Prime||0)+1});break;
      case 'beamPrecisionWide':fireBeam(p,m,{len:360,width:11,power:1.75,damageMul:1.12});break;
      case 'rushVolley':for(var i=0;i<7;i++)bullet(p,m,(Number(p.angle)||0)+(i-3)*.07,480+i*24,(Number(window.ST&&ST.dmg)||18)*(.66+i*.11),4,1,1.0,{v88Rush:true});break;
      case 'tripleNeedle':for(var j=0;j<3;j++)bullet(p,m,(Number(p.angle)||0)+(j-1)*.1,360,(Number(window.ST&&ST.dmg)||18)*1.3,6,3,1.6,{v88Needle:true});break;
      case 'pierceVolley':for(var k=0;k<5;k++)bullet(p,m,(Number(p.angle)||0)+(k-2)*.055,430,(Number(window.ST&&ST.dmg)||18)*1.05,5,4,1.45,{v88Pierce:true});break;
      case 'pierceVolleyWide':for(var l=0;l<7;l++)bullet(p,m,(Number(p.angle)||0)+(l-3)*.105,410,(Number(window.ST&&ST.dmg)||18)*.9,5,3,1.45,{v88Pierce:true});break;
      case 'homingVolley':for(var q=0;q<3;q++)bullet(p,m,(Number(p.angle)||0)+(q-1)*.12,360,(Number(window.ST&&ST.dmg)||18)*1.35,6,2,1.7,{v88Homing:true,homing:1});break;
      case 'fieldSlow':field(p,m,155,'debuff',3.8,.28);break;
      case 'slowField':field(p,m,145,'debuff',3.8,.28);break;
      case 'slowFieldWide':field(p,m,190,'debuff',4.0,.26);break;
      case 'debuffField':field(p,m,135,'debuff',4.0,.4);break;
      case 'debuffFieldWide':field(p,m,180,'debuff',4.2,.32);break;
      case 'rustField':field(p,m,145,'rust',3.8,.32);break;
      case 'rustFieldWide':field(p,m,185,'rust',4.1,.28);break;
      case 'corrodeField':field(p,m,145,'ionic',3.8,.34);break;
      case 'corrodeFieldWide':field(p,m,185,'ionic',4.2,.3);break;
      case 'burnField':field(p,m,135,'burn',3.6,.3);break;
      case 'burnFieldWide':field(p,m,180,'burn',4.0,.26);break;
      case 'freezeField':field(p,m,150,'debuff',3.5,.25);enemies().forEach(function(e){if(d2(e.x,e.y,Number(window.mouse&&mouse.x)||p.x,Number(window.mouse&&mouse.y)||p.y)<150*150)status(e,'freeze')});break;
      case 'shieldField':field(p,m,135,'support',3.8,.35);p.sh=Math.min(Number(window.ST&&ST.shieldMax)||100,(p.sh||0)+(Number(window.ST&&ST.shieldMax)||100)*.12);break;
      case 'personalField':field(p,m,135,'ionic',3.4,.28);ring(p.x,p.y,pHue(p,m),135,5,.4);break;
      case 'playerField':field(p,m,125,'support',3.5,.25);p.puDamage=Math.max(p.puDamage||1,1.25);p.puRate=Math.max(p.puRate||1,1.18);p.puTimer=Math.max(p.puTimer||0,4.5);break;
      case 'gravityBurst':burstAt(p,m,115,1.4,'rust');enemies().forEach(function(e){if(d2(e.x,e.y,Number(window.mouse&&mouse.x)||p.x,Number(window.mouse&&mouse.y)||p.y)<125*125){var x=Number(window.mouse&&mouse.x)||p.x,y=Number(window.mouse&&mouse.y)||p.y,a=Math.atan2(y-e.y,x-e.x);e.x+=Math.cos(a)*34;e.y+=Math.sin(a)*34}});break;
      case 'gravityBurstBig':burstAt(p,m,165,1.75,'rust');enemies().forEach(function(e){var x=Number(window.mouse&&mouse.x)||p.x,y=Number(window.mouse&&mouse.y)||p.y,dd=d2(e.x,e.y,x,y);if(dd<190*190){var a=Math.atan2(y-e.y,x-e.x),pull=(1-Math.sqrt(dd)/190)*54;e.x+=Math.cos(a)*pull;e.y+=Math.sin(a)*pull}});break;
      case 'gravityField':var gx=Number(window.mouse&&mouse.x)||p.x,gy=Number(window.mouse&&mouse.y)||p.y;field(p,m,145,'debuff',3.5,.32);enemies().forEach(function(e){if(d2(e.x,e.y,gx,gy)<165*165){var a=Math.atan2(gy-e.y,gx-e.x);e.x+=Math.cos(a)*42;e.y+=Math.sin(a)*42}});break;
      case 'dashBurst':dash(p,m,145,90,1.7,'burn');break;
      case 'dashBurstWide':dash(p,m,155,135,1.6,'rust');break;
      case 'dashBurstWideFreeze':dash(p,m,150,125,1.55,'freeze');break;
      case 'dashShieldBurst':dash(p,m,145,95,1.55,'burn');p.sh=Math.min(Number(window.ST&&ST.shieldMax)||100,(p.sh||0)+(Number(window.ST&&ST.shieldMax)||100)*.25);break;
      case 'dashBurn':dash(p,m,135,82,1.75,'burn');break;
      case 'dashTrail':dash(p,m,135,75,1.35,'rust');field(p,m,95,'debuff',2.0,.25);break;
      case 'dashBurstWideFreeze':dash(p,m,155,135,1.6,'freeze');break;
      case 'healPulse':buff(p,m,'heal');players().forEach(function(q){if(q!==p&&!q.downed&&d2(q.x,q.y,p.x,p.y)<150*150){q.hp=Math.min(Number(window.ST&&ST.hp)||q.hp,q.hp+(Number(window.ST&&ST.hp)||100)*.12);q.iframes=Math.max(q.iframes||0,.3)}});break;
      case 'healShield':buff(p,m,'heal');buff(p,m,'shield');break;
      case 'teamFire':players().forEach(function(q){q.puDamage=Math.max(q.puDamage||1,1.24);q.puRate=Math.max(q.puRate||1,1.18);q.puTimer=Math.max(q.puTimer||0,6)});ring(p.x,p.y,pHue(p,m),150,7,.5);break;
      case 'supportBlast':burstAt(p,m,145,.75,null);players().forEach(function(q){if(!q.downed&&d2(q.x,q.y,p.x,p.y)<155*155){q.hp=Math.min(Number(window.ST&&ST.hp)||q.hp,q.hp+(Number(window.ST&&ST.hp)||100)*.1);q.sh=Math.min(Number(window.ST&&ST.shieldMax)||100,(q.sh||0)+12)}});break;
      case 'allyChain':chain(p,m,5,1.0,'corrode');players().forEach(function(q){if(!q.downed&&d2(q.x,q.y,p.x,p.y)<170*170)q.hp=Math.min(Number(window.ST&&ST.hp)||q.hp,q.hp+8)});break;
      case 'chainFreeze':chain(p,m,6,.92,'freeze');break;
      case 'chainCorrode':chain(p,m,6,1.1,'corrode');break;
      case 'chainRust':chain(p,m,6,1.05,'rust');break;
      case 'chainHeal':chain(p,m,5,1.0,'corrode');p.hp=Math.min(Number(window.ST&&ST.hp)||p.hp,p.hp+6);break;
      case 'targetedFreeze':var t=enemies().sort(function(a,b){return d2(a.x,a.y,p.x,p.y)-d2(b.x,b.y,p.x,p.y)})[0];if(t){var fake={x:t.x,y:t.y,id:p.id};setTimeout(function(){if(window.RUN===run()){enemies().forEach(function(e){if(d2(e.x,e.y,t.x,t.y)<90*90)status(e,'freeze')});ring(t.x,t.y,pHue(p,m),90,6,.45)}},400)}break;
      case 'delayedFreeze':delayed(p,m,800,145,1.55,'freeze');break;
      case 'delayedCorrode':delayed(p,m,700,155,1.65,'corrode');break;
      case 'delayedBig':delayed(p,m,1050,170,2.25,'burn');break;
      case 'doubleDelayed':delayed(p,m,700,145,1.65,'burn');setTimeout(function(){if(window.RUN===run())delayed(p,m,480,95,1.0,'corrode')},720);break;
      case 'tripleDelayed':for(var z=0;z<3;z++)setTimeout(function(){if(window.RUN===run())burstAt(p,m,82,1.05,'rust')},z*300);break;
      case 'tripleBurstChain':for(var y=0;y<3;y++)setTimeout(function(){if(window.RUN===run())chain(p,m,3,1.05,'burn')},y*260);break;
      case 'markShock':markBurst(p,m);enemies().slice(0,1).forEach(function(e){if(window.addShock)addShock(e,1.3)});break;
      case 'burstMark':markBurst(p,m);burstAt(p,m,95,1.25,'rust');break;
      case 'bloomFan':burstAt(p,m,105,1.2,'rust');for(var b=0;b<5;b++)bullet(p,m,(Number(p.angle)||0)+(b-2)*.11,390,(Number(window.ST&&ST.dmg)||18)*.88,5,2,1.4,{v88Bloom:true});break;
      case 'orbital':orbital(p,m);break;
      case 'teamMendBlast':players().forEach(function(q){if(!q.downed){q.hp=Math.min(Number(window.ST&&ST.hp)||q.hp,q.hp+(Number(window.ST&&ST.hp)||100)*.16);q.sh=Math.min(Number(window.ST&&ST.shieldMax)||100,(q.sh||0)+18);burst(q.x,q.y,pHue(p,m),10)}});burstAt(p,m,130,.9,'corrode');break;
      case 'teamHealPulse':players().forEach(function(q){if(!q.downed){q.hp=Math.min(Number(window.ST&&ST.hp)||q.hp,q.hp+(Number(window.ST&&ST.hp)||100)*.2);q.sh=Math.min(Number(window.ST&&ST.shieldMax)||100,(q.sh||0)+14)}});ring(p.x,p.y,pHue(p,m),160,8,.65);burst(p.x,p.y,pHue(p,m),26);break;
      case 'shieldField':field(p,m,135,'support',3.5,.35);p.sh=Math.min(Number(window.ST&&ST.shieldMax)||100,(p.sh||0)+18);break;
      case 'playerTrailBurn':field(p,m,90,'burn',2.0,.22);break;
      case 'playerTrailRust':field(p,m,90,'rust',2.0,.22);break;
      case 'burnKnockback':burstAt(p,m,105,1.5,'burn');var bx=Number(window.mouse&&mouse.x)||p.x,by=Number(window.mouse&&mouse.y)||p.y;enemies().forEach(function(e){if(d2(e.x,e.y,bx,by)<115*115){var a=Math.atan2(e.y-by,e.x-bx);e.x+=Math.cos(a)*65;e.y+=Math.sin(a)*65}});break;
      case 'slowBurst':burstAt(p,m,145,1.1,null);enemies().forEach(function(e){if(d2(e.x,e.y,p.x,p.y)<150*150)e.slowT=Math.max(e.slowT||0,4)});break;
      case 'crashwave':burstAt(p,m,120,1.75,'rust');enemies().forEach(function(e){if(d2(e.x,e.y,p.x,p.y)<125*125)e.slowT=Math.max(e.slowT||0,2.5)});break;
      case 'chainHeal':chain(p,m,6,1.0,'corrode');p.hp=Math.min(Number(window.ST&&ST.hp)||p.hp,p.hp+10);break;
      default:burstAt(p,m,110,1.25,'corrode');break;
    }
  }
  function kitFor(m){
    var found=NEW.find(function(x){return x.n===m.name});
    if(!found)return null;
    var slots=[];found.moves.forEach(function(v,i){var slot=i,fn=function(p){execMove(v[2],p,m);p.activeCd=Number(window.ST&&ST.activeCd)||Number(m.choices&&m.choices[slot]&&m.choices[slot].cd)||2;};slots.push({id:'v88_'+m.id+'_a'+slot,key:'v88_'+m.name.toLowerCase().replace(/[^a-z0-9]+/g,'_')+'_a'+slot+'_'+i,slot:slot,ic:['⚛','✦','◈'][slot],name:v[0],desc:v[1],cd:[5.5,7,8.5][slot],main:slot===0,exec:fn,profile:m.cat,formula:m.f,implemented:true,v88Custom:true})});return slots;
  }
  added.forEach(function(m){var c=kitFor(m);if(c){m.choices=c;m.signatures=c;m.act=c[0]}});

  /* ---------- duplicate-name compound cleanup ----------
     The older catalog contains reaction-preview aliases beside the actual
     real-compound entry. Keep one visible compound per normalized name while
     redirecting synthesis aliases to the surviving canonical entry. ---------- */
  (function dedupeCompounds(){
    if(!D.MOLDEF)return;
    var groups=Object.create(null),entries=[];
    Object.keys(D.MOLDEF).forEach(function(k){var m=D.MOLDEF[k];if(m&&m.mol)entries.push({k:k,m:m})});
    entries.forEach(function(x){var n=String(x.m.name||x.m.token||x.k).trim().toLowerCase();(groups[n]||(groups[n]=[])).push(x)});
    var removed=0,aliases=0;
    Object.keys(groups).forEach(function(n){
      var g=groups[n];if(g.length<2)return;
      var keep=g[0];
      // Prefer the actual real-compound record over a reaction-preview alias.
      for(var i=1;i<g.length;i++){
        var cand=g[i];
        if(String(keep.m.rx||'')!=='Real compound'&&String(cand.m.rx||'')==='Real compound')keep=cand;
      }
      g.forEach(function(x){
        if(x===keep)return;
        if(D.RECIPES&&D.RECIPES[x.k]!=null){D.RECIPES[x.k]=keep.k;aliases++}
        delete D.MOLDEF[x.k];removed++;
      });
    });
    D.v88DuplicateCleanup={removed:removed,aliasesRedirected:aliases,visibleCompounds:Object.keys(D.MOLDEF).filter(function(k){return D.MOLDEF[k]&&D.MOLDEF[k].mol}).length};
  })();

  /* ---------- exclusive-card cleanup ---------- */
  (function removeExclusiveCards(){
    var cards=window.ALL_CARDS;if(!Array.isArray(cards))return;
    var fields=['elementOnly','compoundOnly','requiredElement','requiredCompound','requiresElement','requiresCompound','onlyForElement','onlyForCompound','elementId','compoundId','molId','onlyFor','element','compound','requires','require'];
    var names=Object.values(D.MOLDEF||{}).filter(function(m){return m&&m.mol&&m.name}).map(function(m){return String(m.name)});
    for(var i=cards.length-1;i>=0;i--){
      var c=cards[i];if(!c)continue;var exclusive=false;
      fields.some(function(k){if(c[k]!=null&&String(c[k]).trim()!==''){exclusive=true;return true}return false});
      var text=String(c.n||'')+' '+String(c.d||'');
      if(/(usable|available|works|equipped|requires)\s+(only\s+)?with\s+[A-Za-z0-9][A-Za-z0-9'()\- .]+/i.test(text)||/only\s+for\s+(this|the)\s+(element|compound)/i.test(text))exclusive=true;
      if(!exclusive){
        for(var ni=0;ni<names.length&&!exclusive;ni++){var nn=names[ni].replace(/[.*+?^${}()|[\]\\]/g,'\\$&');if(new RegExp('(?:only|exclusive|exclusively|requires|specifically|equipped with)[^\n]{0,42}\\b'+nn+'\\b','i').test(text)||new RegExp('\\b'+nn+'\\b[^\n]{0,42}(?:only|exclusive|exclusively|requires|specifically)','i').test(text))exclusive=true;}
      }
      if(exclusive)cards.splice(i,1);
    }
    D.exclusiveCardsRemovedV88=true;
  })();

  /* ---------- per-ability Signature Mastery storage ---------- */
  function idKey(id){try{return D.canonicalId?D.canonicalId(id):id}catch(_){return id}}
  function inferSlot(id){
    try{
      var r=run(),p=r&&r.players&&((r.players[r.localNetId||0]||r.players[0])||null);
      if(p&&p.elem&&idKey(p.elem.id)===idKey(id))return clamp(Number(p.signatureSlot)||0,0,2);
      return S.getSignature?clamp(Number(S.getSignature(id))||0,0,2):0;
    }catch(_){return 0}
  }
  var oldGet=S.getSignatureUpgrade,oldChoose=S.chooseSignatureUpgradePath,oldCost=S.signatureUpgradeCost,oldBuy=S.buySignatureUpgrade,oldStats=S.getSignatureUpgradeStats;
  function ensure(id,slot){
    id=idKey(id);slot=slot==null?inferSlot(id):clamp(Number(slot)||0,0,2);
    var raw=S.raw&&S.raw.signatureUpgrades?S.raw.signatureUpgrades:(S.raw?S.raw.signatureUpgrades:null);
    if(!raw)raw={};
    var cur=raw[id];
    if(cur&&typeof cur==='object'&&('path' in cur||'rank' in cur)){ // legacy one-path format -> slot 0
      raw[id]={0:{path:cur.path||null,rank:Number(cur.rank)||0}};cur=raw[id];
    }
    if(!cur||typeof cur!=='object')cur={};
    if(cur[String(slot)]==null)cur[String(slot)]={path:null,rank:0};
    raw[id]=cur;
    return {id:id,slot:slot,store:cur,state:cur[String(slot)]};
  }
  function normState(id,slot){var x=ensure(id,slot),u=x.state||{};return {path:Object.prototype.hasOwnProperty.call(PATHS,String(u.path))?String(u.path):null,rank:Math.max(0,Math.min(3,Math.floor(Number(u.rank)||0)))};}
  S.getSignatureUpgrade=function(id,slot){return normState(id,slot)};
  S.chooseSignatureUpgradePath=function(id,path,slot){var x=ensure(id,slot);if(!PATHS[path]||x.state.path)return false;x.store[String(x.slot)]={path:String(path),rank:0};try{S.save&&S.save()}catch(_){}return true};
  S.signatureUpgradeCost=function(id,slot){var u=normState(id,slot);return u.path&&u.rank<3?COSTS[u.rank]:0};
  S.buySignatureUpgrade=function(id,slot){var x=ensure(id,slot),u=normState(id,x.slot);if(!u.path||u.rank>=3)return false;var m=S.mxp?S.mxp(id):{xp:0,nodes:{}};var c=COSTS[u.rank];if(Number(m.xp||0)<c)return false;m.xp-=c;m.nodes=m.nodes||{};if(S.raw&&S.raw.mastery)S.raw.mastery[id]=m;x.store[String(x.slot)]={path:u.path,rank:u.rank+1};try{S.save&&S.save()}catch(_){}return true};
  S.getSignatureUpgradeStats=function(id,slot){var u=normState(id,slot),r=u.rank;return {path:u.path,rank:r,damageMult:u.path==='damage'?1+.12*r:1,rangeMult:u.path==='range'?Math.pow(1.18,r):1,cooldownMult:u.path==='cooldown'?Math.pow(.9,r):1,cost:u.path&&r<3?COSTS[r]:0,slot:(slot==null?inferSlot(id):Number(slot)||0)};};

  /* ---------- authoritative per-ability mastery UI ---------- */
  var esc=function(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})};
  function css(){
    if(document.getElementById('v88-mastery-style'))return;
    var s=document.createElement('style');s.id='v88-mastery-style';s.textContent=''
      +'#scr-mastery #m-detail{min-width:0}.v88-mastery-wrap{margin-top:12px;padding:14px;border:1px solid #28445e;background:rgba(7,15,26,.82)}'
      +'.v88-ability{border:1px solid #2a4762;background:rgba(9,19,32,.88);padding:13px;margin-top:11px}'
      +'.v88-ability-head{display:flex;align-items:flex-start;justify-content:space-between;gap:10px}.v88-ability-title{font-family:var(--disp,Arial);font-size:18px;letter-spacing:.07em}.v88-ability-sub{font-size:11px;color:#96abc0;line-height:1.35;margin-top:4px}.v88-ability-state{font-size:10px;color:#72f2a0;white-space:nowrap}'
      +'.v88-path-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin-top:10px}.v88-path{min-height:112px;padding:10px;text-align:left;border:1px solid #28445e;background:#0a1422;color:#d8e7f5;cursor:pointer}.v88-path:hover{border-color:#66ecff}.v88-path.chosen{border-color:#66f0a0;box-shadow:0 0 0 1px rgba(102,240,160,.15) inset}.v88-path.disabled{opacity:.35;cursor:not-allowed}.v88-path .ico{font-size:20px}.v88-path b{display:block;letter-spacing:.08em}.v88-path small{display:block;color:#91a7bd;line-height:1.25;margin-top:4px}.v88-pips{display:flex;gap:4px;margin-top:8px}.v88-pips i{display:block;width:24px;height:5px;border:1px solid #28445e}.v88-pips i.on{background:#66f0a0}.v88-action{margin-top:7px;font-size:9px;color:#b8cbe0;letter-spacing:.08em}.v88-up{display:flex;justify-content:space-between;gap:10px;align-items:center;margin-top:10px;padding-top:9px;border-top:1px solid #28445e}.v88-locked{font-size:10px;color:#8296ab}.v88-comp-tag{font-size:10px;color:#78cfff;letter-spacing:.12em;text-transform:uppercase}'
      +'@media(max-width:850px){.v88-path-grid{grid-template-columns:1fr}.v88-ability-head{display:block}.v88-ability-state{margin-top:5px}}';document.head.appendChild(s);
  }
  function currentEl(id){try{return D&&D.EL?D.EL(id):null}catch(_){return null}}
  function owned(id){try{return !!(D&&D.isOwned&&D.isOwned(id))}catch(_){return false}}
  function saveMxp(id){try{return S.mxp?S.mxp(id):{xp:0,nodes:{}}}catch(_){return {xp:0,nodes:{}}}}
  function renderMastery(id){
    var scr=document.getElementById('scr-mastery');if(!scr||scr.classList.contains('hidden'))return;var el=currentEl(id||S.sel);if(!el)return;css();
    var detail=document.getElementById('m-detail');if(!detail)return;var col='hsl('+(Number(el.hue)||190)+' 80% 68%)',list=el.choices||el.signatures||[],mx=saveMxp(el.id);
    detail.innerHTML='';var head=document.createElement('div');head.id='m-head';head.innerHTML='<div style="font-family:var(--disp,Arial);font-size:24px;color:'+col+'">'+esc(el.name||el.sym||el.id).toUpperCase()+'</div><div class="sub">Mastery XP available: <b style="color:var(--gr,#66f0a0)">◆ '+String(mx.xp||0)+'</b> · each Signature ability now has its own permanent upgrade path.</div>';detail.appendChild(head);
    var wrap=document.createElement('div');wrap.className='v88-mastery-wrap';wrap.innerHTML='<div class="v88-comp-tag">✦ INDIVIDUAL SIGNATURE MASTERY</div><div class="sub" style="margin-top:5px">Choose a path separately for Signature 1, Signature 2, and Signature 3. Upgrades are stored independently for this '+(el.mol?'compound':'element')+'.</div>';detail.appendChild(wrap);
    for(var slotIndex=0;slotIndex<3;slotIndex++){
      (function(slot){
      var sig=list[slot]||{name:'SIGNATURE '+(slot+1),desc:'Ability not installed.',ic:['⚛','✦','◈'][slot]};
      var ownedSlot=slot===0||!S.abilOwned||S.abilOwned(el.id,slot),u=normState(el.id,slot),box=document.createElement('div');box.className='v88-ability';
      var stateText=ownedSlot?(u.path?('PATH: '+PATHS[u.path].label+' · '+u.rank+'/3'):'NO PATH CHOSEN'):'LOCKED — PURCHASE ABILITY '+(slot+1);
      box.innerHTML='<div class="v88-ability-head"><div><div class="v88-ability-title" style="color:'+col+'">SIGNATURE '+(slot+1)+' · '+esc(sig.ic||['⚛','✦','◈'][slot])+' '+esc(sig.name||('ABILITY '+(slot+1)))+'</div><div class="v88-ability-sub">'+esc(sig.desc||'')+'</div></div><div class="v88-ability-state">'+esc(stateText)+'</div></div>';
      var grid=document.createElement('div');grid.className='v88-path-grid';
      Object.keys(PATHS).forEach(function(k){var P=PATHS[k],chosen=u.path===k,pkey=el.id+'|'+slot+'|'+k,isPending=pending[pkey];var b=document.createElement('button');b.type='button';b.className='v88-path'+(chosen?' chosen':'')+((u.path&&!chosen)||!ownedSlot?' disabled':'');b.disabled=(u.path&&!chosen)||!ownedSlot;var pip='';for(var pi=0;pi<3;pi++)pip+='<i class="'+(chosen&&pi<u.rank?'on':'')+'"></i>';b.innerHTML='<span class="ico">'+P.icon+'</span><span><b>'+P.label+'</b><small>'+P.desc+'</small><span class="v88-pips">'+pip+'</span><span class="v88-action">'+(chosen?'PATH LOCKED':isPending?'ARE YOU SURE? CLICK AGAIN':'CHOOSE '+P.label)+'</span></span>';b.onclick=function(){
        if(!ownedSlot||u.path)return;
        if(!pending[pkey]){pending[pkey]=true;renderMastery(el.id);return}
        if(S.chooseSignatureUpgradePath&&S.chooseSignatureUpgradePath(el.id,k,slot)){delete pending[pkey];renderMastery(el.id);try{SFX.unlock()}catch(_){ }if(window.toast)toast(P.label+' PATH LOCKED FOR SIGNATURE '+(slot+1),'good')}
      };grid.appendChild(b)});box.appendChild(grid);
      if(u.path){var up=document.createElement('div');up.className='v88-up';var cost=u.rank<3?COSTS[u.rank]:0,ok=u.rank<3&&Number(mx.xp||0)>=cost;var info=document.createElement('div');info.innerHTML='<b>'+PATHS[u.path].label+' PATH · '+u.rank+'/3</b><div class="sub">'+(u.rank>=3?'MAXED — this ability cannot switch paths.':'Next rank costs ◆ '+cost+' mastery XP.')+'</div>';up.appendChild(info);var btn=document.createElement('button');btn.className='btn primary';btn.type='button';btn.textContent=u.rank>=3?'MAX':'UPGRADE · ◆ '+cost;btn.disabled=!ok;btn.onclick=function(){if(S.buySignatureUpgrade&&S.buySignatureUpgrade(el.id,slot)){renderMastery(el.id);try{SFX.unlock()}catch(_){ }}};up.appendChild(btn);box.appendChild(up)}
      wrap.appendChild(box);
      })(slotIndex);
    }
    var note=document.createElement('div');note.className='sub';note.style.marginTop='12px';note.textContent='Your equipped Signature is still controlled by the normal Signature selector; mastery upgrades remain attached to the individual ability slot.';wrap.appendChild(note);
  }

  /* Replace the late V86 render hook so the screen always shows three independent trees. */
  if(window.UI&&typeof UI.show==='function'&&!UI.show.__v88Mastery){
    var oldShow=UI.show;UI.show=function(id){var out=oldShow.apply(this,arguments);if(id==='scr-mastery'){var chosen=null;try{chosen=S.sel}catch(_){}requestAnimationFrame(function(){renderMastery(chosen)});setTimeout(function(){renderMastery(chosen)},70)}return out};UI.show.__v88Mastery=true;
  }
  window.ISO_V88_RENDER_MASTERY=renderMastery;

  /* ---------- science Minecraft-style menu splash ---------- */
  var SPLASHES=['E = MC²','CHECK YOUR VALENCE','ENTROPY HAS ENTERED THE CHAT','AVOGADRO IS WATCHING','SCIENCE! PROBABLY.','MIND THE ACTIVATION ENERGY','PROTONS HAVE ENTERED THE CHAT','IT’S ALWAYS EXOTHERMIC SOMEWHERE','THE PERIODIC TABLE KNOWS YOUR LOCATION*','99.9% PURE CHAOS*','REACTIONS > RUMORS','DO NOT SHAKE THE BEAKER','THE ORBITALS ARE VIBING','ONE MOLE = A LOT OF FRIENDS','PRESS Q. BLAME CHEMISTRY.','SCIENCE HAS PATCH NOTES','PLEASE LABEL YOUR SAMPLES','KEEP CALM AND COUNT ELECTRONS','THE LAB IS RUNNING','NEUTRONS DO SIDE QUESTS','CHEMISTRY, BUT LOUDER','WARNING: UNSTABLE ORBITALS'];
  function menuSplash(){
    var brand=document.querySelector('#scr-menu #menuleft .brand');if(!brand)return;var s=document.getElementById('iso-v88-splash');
    if(!s){s=document.createElement('div');s.id='iso-v88-splash';s.className='iso-v88-splash';brand.insertAdjacentElement('afterend',s)}
    s.textContent=SPLASHES[Math.floor(Math.random()*SPLASHES.length)];
  }
  (function menuStyle(){var s=document.getElementById('iso-v88-menu-style');if(s)return;s=document.createElement('style');s.id='iso-v88-menu-style';s.textContent='#scr-menu #menuleft{position:relative}.iso-v88-splash{display:inline-block;position:relative;margin-left:46%;margin-top:-18px;margin-bottom:8px;max-width:52%;font-family:var(--disp,Arial);font-weight:900;font-size:clamp(16px,1.8vw,25px);letter-spacing:.03em;color:var(--yl,#ffe866);text-shadow:0 0 12px rgba(255,232,102,.18);transform-origin:50% 50%;animation:isoV88SplashTilt 1.7s ease-in-out infinite;white-space:nowrap}@keyframes isoV88SplashTilt{0%,100%{transform:rotate(-7deg) scale(1)}50%{transform:rotate(7deg) scale(1.035)}}#scr-menu #menuleft .brand{font-size:clamp(96px,10vw,136px);text-shadow:0 0 26px rgba(102,236,255,.12),4px 4px 0 rgba(0,0,0,.24)}';document.head.appendChild(s)})();
  document.addEventListener('click',function(ev){var btn=ev.target&&ev.target.closest?ev.target.closest('[data-go="scr-menu"]'):null;if(btn)requestAnimationFrame(menuSplash)});
  document.addEventListener('DOMContentLoaded',function(){menuSplash();setInterval(function(){var m=document.getElementById('scr-menu');if(m&&!m.classList.contains('hidden'))menuSplash()},12000)});

  /* Refresh catalogue counters once new compounds exist. */
  D.realCompoundCount=Object.keys(D.MOLDEF||{}).filter(function(k){return D.MOLDEF[k]&&D.MOLDEF[k].mol}).length;
  D.compoundCatalogNames=Object.values(D.MOLDEF||{}).filter(function(m){return m&&m.mol}).map(function(m){return m.name});
  D.v88CompoundAudit={added:added.map(function(m){return {name:m.name,formula:m.f,key:Object.keys(D.MOLDEF).find(function(k){return D.MOLDEF[k]===m}),abilities:(m.choices||[]).map(function(c){return {slot:c.slot+1,name:c.name,exec:typeof c.exec==='function'}})}}),duplicateNames:[],duplicateFormulas:[]};
  console.log('ISOTOPE V88 ACTIVE:',added.length,'new compounds; per-ability mastery; exclusive-card cleanup; science splash.');
})();
