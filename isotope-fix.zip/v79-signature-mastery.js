/* ISOTOPE V79/V83 — Signature Mastery: one permanent path per element, 3 ranks max. */
(function(){
  'use strict';
  if(window.__ISO_V79_SIGNATURE_MASTERY_V83__)return;
  window.__ISO_V79_SIGNATURE_MASTERY_V83__=true;

  var SFX=(window.AUDIO&&AUDIO.SFX)||{};
  var PATHS={
    damage:{label:'DAMAGE',desc:'+12% SIGNATURE DAMAGE / RANK',icon:'⚔'},
    range:{label:'RANGE',desc:'+18% SIGNATURE RANGE / RANK',icon:'⌁'},
    cooldown:{label:'COOLDOWN',desc:'-10% SIGNATURE COOLDOWN / RANK',icon:'⟳'}
  };
  var COSTS=[100,180,300], pending=null, viewId=null;

  function canonical(id){try{return DATA&&DATA.canonicalId?DATA.canonicalId(id):id;}catch(e){return id;}}
  function owned(id){try{return DATA&&DATA.isOwned?DATA.isOwned(id):false;}catch(e){return false;}}
  function getElement(id){try{return DATA&&DATA.EL?DATA.EL(canonical(id)):null;}catch(e){return null;}}
  function currentSignature(el){
    var slot=SAVE.getSignature?SAVE.getSignature(el.id):0, choices=el.choices||el.signatures||[];
    return {slot:slot,choice:choices[slot]||choices[0]||{name:'SIGNATURE '+(slot+1),desc:''}};
  }
  function state(el){return SAVE.getSignatureUpgrade?SAVE.getSignatureUpgrade(el.id):{path:null,rank:0};}
  function selectedElement(){
    var forced=window.__ISO_MASTERY_FORCED_ID;
    var id=canonical(forced||viewId||SAVE.sel), el=getElement(id);
    return el&&owned(id)?el:getElement(SAVE.sel);
  }
  function cleanLegacy(){
    ['ability-mastery','mega-codex'].forEach(function(id){var n=document.getElementById(id);if(n)n.remove();});
    var codex=document.querySelector('[id*="codex"]');if(codex&&/ABILITY LOADOUT/i.test(codex.textContent||''))codex.remove();
  }
  function panelHTML(el){
    var st=state(el),sig=currentSignature(el),chosen=st.path,rank=st.rank;
    var cards=Object.keys(PATHS).map(function(k){
      var p=PATHS[k], chosenHere=chosen===k, isPending=pending&&pending.id===el.id&&pending.path===k;
      var disabled=!!chosen&&!chosenHere;
      var label=chosenHere?'PATH LOCKED':isPending?'ARE YOU SURE? CLICK AGAIN':'CHOOSE '+p.label;
      var pip=Array.from({length:3},function(_,i){return '<i class="'+(i<rank&&chosenHere?'on':'')+'"></i>';}).join('');
      return '<button type="button" class="v79-sig-path '+(chosenHere?'chosen ':'')+(disabled?'disabled ':'')+(isPending?'pending ':'')+'" data-v79-path="'+k+'" '+(disabled?'disabled':'')+'><span class="v79-sig-icon">'+p.icon+'</span><span class="v79-sig-main"><b>'+p.label+'</b><small>'+p.desc+'</small><span class="v79-sig-pips">'+pip+'</span></span><em>'+label+'</em></button>';
    }).join('');
    var cost=chosen&&rank<3?COSTS[rank]:0;
    var up=chosen?'<div class="v79-sig-upgrade-row"><span><b>'+PATHS[chosen].label+' PATH · '+rank+'/3</b><small>'+(rank>=3?'MAXED':'Next rank: '+PATHS[chosen].desc+' · costs ◆ '+cost+' MASTERY XP')+'</small></span><button type="button" class="btn primary" id="v79-sig-buy" '+(rank>=3||SAVE.mxp(el.id).xp<cost?'disabled':'')+'>'+(rank>=3?'MAX':'UPGRADE · ◆ '+cost)+'</button></div>':'';
    return '<div id="v79-signature-mastery" class="panel2"><div class="v79-sig-title">✦ SIGNATURE MASTERY</div><div class="v79-sig-sub">Choose ONE upgrade path for '+(el.name||'this element')+' Signature '+(sig.slot+1)+'. The path is permanent for this element and can be upgraded only 3 times.</div><div class="v79-sig-equipped">EQUIPPED: <b>'+esc(sig.choice.name||('SIGNATURE '+(sig.slot+1)))+'</b></div><div class="v79-sig-path-grid">'+cards+'</div>'+up+'</div>';
  }
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]);});}
  function render(id){
    var scr=document.getElementById('scr-mastery');if(!scr||scr.classList.contains('hidden'))return;
    if(id) viewId=canonical(id);
    var el=selectedElement(),detail=document.getElementById('m-detail'),tree=document.getElementById('m-tree');
    if(!el||!detail||!tree)return;
    cleanLegacy();
    var badge=document.getElementById('mxp-badge');if(badge)badge.textContent='◆ '+SAVE.mxp(el.id).xp;
    var chips=document.querySelectorAll('#m-elems .mchip');chips.forEach(function(ch){ch.classList.toggle('sel',canonical(ch.dataset.id)===canonical(el.id));});
    var old=document.getElementById('v79-signature-mastery');if(old)old.remove();
    var node=document.createElement('div');node.innerHTML=panelHTML(el);
    var panel=node.firstElementChild;
    tree.parentNode.insertBefore(panel,tree);
    bind(panel,el);
    /* Rebuild the live Mastery index after ui.js renders so owned compounds
       remain visible without triggering another detail-panel refresh. */
    if(window.ISO_REFRESH_MASTERY)window.ISO_REFRESH_MASTERY();
    if(window.__ISO_MASTERY_VIEW_ID!==el.id)window.__ISO_MASTERY_VIEW_ID=el.id;
  }
  function bind(panel,el){
    panel.querySelectorAll('[data-v79-path]').forEach(function(btn){
      btn.onclick=function(){
        var path=btn.dataset.v79Path,st=state(el);
        if(st.path)return;
        if(!(pending&&pending.id===el.id&&pending.path===path)){
          pending={id:el.id,path:path}; if(SFX.click)SFX.click(); render(el.id); return;
        }
        if(SAVE.chooseSignatureUpgradePath&&SAVE.chooseSignatureUpgradePath(el.id,path)){
          pending=null;if(SFX.unlock)SFX.unlock();render(el.id);toast('SIGNATURE '+PATHS[path].label+' PATH LOCKED IN','good');
        }else if(SFX.error)SFX.error();
      };
    });
    var buy=panel.querySelector('#v79-sig-buy');
    if(buy)buy.onclick=function(){
      var st=state(el);if(!st.path||st.rank>=3)return;
      var cost=COSTS[st.rank];
      if(SAVE.buySignatureUpgrade&&SAVE.buySignatureUpgrade(el.id)){
        pending=null;if(SFX.unlock)SFX.unlock();render(el.id);
        toast(PATHS[st.path].label+' SIGNATURE UPGRADE '+(st.rank+1)+'/3 PURCHASED · ◆ '+cost,'good');
      }else{if(SFX.error)SFX.error();toast('NOT ENOUGH MASTERY XP · NEED ◆ '+cost,'bad');}
    };
  }
  function toast(msg,cls){
    try{var host=document.getElementById('toasts');if(!host)return;var t=document.createElement('div');t.className='toast '+(cls||'');t.textContent=msg;host.appendChild(t);setTimeout(function(){t.style.opacity='0';t.style.transition='opacity .35s';setTimeout(function(){t.remove()},400)},2200);}catch(e){}
  }
  function openMastery(){
    viewId=canonical(SAVE.sel);window.__ISO_MASTERY_FORCED_ID=viewId;
    window.__isoMasteryLiveSelected=viewId;
    window.__ISO_MASTERY_VIEW_ID=viewId;
  }
  function hookUI(){
    if(!window.UI||typeof UI.show!=='function'||UI.show.__v83Mastery)return;
    var base=UI.show;
    UI.show=function(id){
      if(id==='scr-mastery')openMastery();
      var out=base.apply(this,arguments);
      if(id==='scr-mastery'){ window.__isoMasteryLiveSelected=viewId; if(window.ISO_REFRESH_MASTERY)window.ISO_REFRESH_MASTERY(); render(viewId); }
      return out;
    };
    UI.show.__v83Mastery=true;
    document.addEventListener('click',function(e){
      var chip=e.target.closest&&e.target.closest('#m-elems .mchip[data-id]');
      if(!chip)return;
      var id=canonical(chip.dataset.id);if(!id||!owned(id))return;
      e.preventDefault();e.stopImmediatePropagation();
      viewId=id;window.__ISO_MASTERY_FORCED_ID=id;window.__isoMasteryLiveSelected=id;window.__ISO_MASTERY_VIEW_ID=id;
      if(SFX.click)SFX.click();
      render(id);
    },true);
  }
  window.ISO_V79_RENDER_MASTERY=function(id){viewId=canonical(id||window.__ISO_MASTERY_FORCED_ID||SAVE.sel);window.__ISO_MASTERY_FORCED_ID=viewId;render(viewId);};
  window.ISO_V79_SET_MASTERY_ELEMENT=function(id){viewId=canonical(id||SAVE.sel);window.__ISO_MASTERY_FORCED_ID=viewId;};

  function hookGame(){
    var helper=window.ISO_V79_WITH_SIGNATURE_UPGRADE_CONTEXT;
    var old=window.useActive;
    if(typeof helper!=='function'||typeof old!=='function'||old.__v83SigWrap)return;
    var f=function(p){return helper(p,function(){return old(p);});};
    f.__v83SigWrap=true;
    window.useActive=f;
    try{if(window.ISO_V23_CORE&&ISO_V23_CORE.setUseActive)ISO_V23_CORE.setUseActive(f);}catch(e){}
  }
  function boot(){}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
  boot();
})();
