/* ISOTOPE — INPUT-LOCK WATCHDOG
   v38-full-qol.js and v40-fresh-start-update.js each install a one-time
   startup modal plus a page-wide, capture-phase click/keydown blocker that
   stays active for as long as that modal exists in the DOM. If the modal
   ever renders somewhere unreachable for any reason, the blocker never
   gets released and silently eats every click and keypress everywhere -
   this guarantees that can never happen permanently. */
'use strict';
(function(){
  if(window.__ISO_INPUT_WATCHDOG__)return;
  window.__ISO_INPUT_WATCHDOG__=true;

  var WATCH=[
    {id:'v38-start-prompt', acceptedKey:'v38RestartAccepted'},
    {id:'v40-start-prompt', acceptedKey:'v40RestartAccepted'}
  ];

  function forceClear(entry){
    try{
      var el=document.getElementById(entry.id);
      if(!el) return false;
      try{ if(window.SAVE && window.SAVE.raw){ window.SAVE.raw[entry.acceptedKey]=true; window.SAVE.save&&window.SAVE.save(); } }catch(_e){}
      el.remove();
      console.warn('ISO_INPUT_WATCHDOG: force-cleared a stuck #'+entry.id+' overlay that was blocking all input.');
      return true;
    }catch(_e){ return false; }
  }

  var firstSeenAt={};
  function tick(){
    WATCH.forEach(function(entry){
      var present=!!document.getElementById(entry.id);
      if(present){
        if(!firstSeenAt[entry.id]) firstSeenAt[entry.id]=Date.now();
        else if(Date.now()-firstSeenAt[entry.id] > 20000) forceClear(entry);
      } else {
        firstSeenAt[entry.id]=0;
      }
    });
  }
  setInterval(tick, 1000);

  var mo=new MutationObserver(function(){
    WATCH.forEach(function(entry){
      if(document.getElementById(entry.id)) forceClear(entry);
    });
  });
  try{
    ['scr-menu','scr-vault','scr-mastery','scr-lab','scr-aug','scr-arch','scr-set','scr-game'].forEach(function(id){
      var el=document.getElementById(id);
      if(el) mo.observe(el,{attributes:true,attributeFilter:['class']});
    });
  }catch(_e){}

  console.log('ISO_INPUT_WATCHDOG active: guarantees startup prompts can never permanently block clicks/keys.');
})();
