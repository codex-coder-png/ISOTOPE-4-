/* ISOTOPE V34 — NITROGLYCERIN STATS + ABILITY DISPLAY FIX
   Keeps Nitroglycerin's real-world identity while making the game sheet use
   the intended low-HP / high-combust gameplay profile and showing all three
   exact ability names + descriptions. */
(function(){
  'use strict';
  if(!window.DATA) return;
  var DATA=window.DATA;

  function findNitro(){
    var vals=Object.values(DATA.MOLDEF||{});
    for(var i=0;i<vals.length;i++) if(vals[i] && /nitroglycerin/i.test(String(vals[i].name||''))) return vals[i];
    return null;
  }
  var n=findNitro();
  if(!n) return;

  /* Nitroglycerin is intentionally fragile in-game: its HP is below the
     lowest base-element HP (100.5), while Combust remains 4. */
  n.mods=Object.assign({},n.mods||{}, { hp:.68, dmg:.78, rate:1.04 });
  n.combustLv=4;
  n.trait='combust';
  n.desc='Low direct damage, but catches enemies on fire and builds toward volatile combustion.';

  /* Exact descriptions are written to match the actual three actions. */
  var choices=[
    {
      name:'Nitroglycerin — Gentle Detonation', ic:'💥', slot:0, main:true, cd:5.5,
      desc:'Fires a low-damage explosive round that burns enemies on hit.'
    },
    {
      name:'Nitroglycerin — Combustion Chain', ic:'🔥', slot:1, cd:7,
      desc:'Fires three small combustion charges that burn and explode one after another.'
    },
    {
      name:'Nitroglycerin — Four-Step Combustion', ic:'♨', slot:2, cd:8,
      desc:'Primes four combustion levels; your next four hits build toward a larger burning explosion.'
    }
  ];

  /* Preserve the existing executable functions when available. */
  var old=n.choices||n.signatures||[];
  for(var i=0;i<3;i++){
    if(old[i] && typeof old[i].exec==='function') choices[i].exec=old[i].exec;
    else if(i===0 && n.act && typeof n.act.exec==='function') choices[i].exec=n.act.exec;
  }
  n.choices=choices;
  n.signatures=choices;
  n.act=choices[0];

  /* Make every alias resolve to the same corrected compound object. */
  Object.keys(DATA.MOLDEF).forEach(function(k){
    var m=DATA.MOLDEF[k];
    if(m && /nitroglycerin/i.test(String(m.name||''))) DATA.MOLDEF[k]=n;
  });

  /* Add the missing real stat to the existing FULL STATS panel. */
  function patchStats(){
    try{
      var box=document.getElementById('vd-extra');
      if(!box || !document.getElementById('vd-name')) return;
      if(!/NITROGLYCERIN/i.test(document.getElementById('vd-name').textContent||'')) return;
      var rows=box.querySelectorAll('div');
      var has=false;
      rows.forEach(function(r){ if(/\bCOMBUST\b/i.test(r.textContent||'')) has=true; });
      if(!has){
        var d=document.createElement('div');
        d.style.cssText='display:flex;justify-content:space-between;gap:8px';
        d.innerHTML='<span>COMBUST</span><b style="color:var(--mg)">4</b>';
        box.appendChild(d);
      }
      /* Force the corrected HP to be visible even if an older stats helper
         cached the previous compound values. */
      box.querySelectorAll('div').forEach(function(r){
        if(/\bMAX HP\b/i.test(r.textContent||'')){
          var b=r.querySelector('b'); if(b) b.textContent='78';
        }
      });
    }catch(e){}
  }

  /* Refresh the vault after this last data layer is installed. */
  var oldSelect=window.selectVault;
  if(typeof oldSelect==='function' && !window.__ISO_V34_SELECT_PATCH__){
    window.selectVault=function(id){
      var r=oldSelect.apply(this,arguments);
      setTimeout(patchStats,0);
      return r;
    };
    window.__ISO_V34_SELECT_PATCH__=true;
  }
  document.addEventListener('click',function(e){
    if(e.target.closest('#vd-more') || e.target.closest('#ptable .pt') || e.target.closest('#vd-btn')) setTimeout(patchStats,30);
  },true);

  console.log('ISOTOPE V34: Nitroglycerin stats + exact ability display fixed.');
})();
