/* ISOTOPE V71 — Periodic Vault sorting, categories, stat filters, and persistent compound-name reveal */
(function(){
  'use strict';
  if(window.__ISO_V71_VAULT__) return;
  window.__ISO_V71_VAULT__=true;
  const $=s=>document.querySelector(s), $$=s=>Array.from(document.querySelectorAll(s));
  const E=()=>Object.values(DATA.ELEMS||{}), M=()=>Object.keys(DATA.MOLDEF||{}).map(k=>DATA.MOLDEF[k]).filter(m=>m&&m.mol);
  const id=x=>String(x&&x.id||'');
  const name=x=>String(x&&x.name||x&&x.f||x&&x.sym||x&&x.id||'');
  function stats(x){
    try { const s=DATA.baseCombat(x); return {dmg:+s.dmg||0,rate:+s.rate||0,vel:+s.ps||0,hp:+s.hp||0,spd:+s.spd||0,crit:+s.crit||0,pierce:+s.pierce||0,react:x.mol?0:(DATA.CATS[x.cat]||{}).react||0,toxic:x.mol?0:(DATA.CATS[x.cat]||{}).tox||0}; } catch(e){ return {dmg:0,rate:0,vel:0,hp:0,spd:0,crit:0,pierce:0,react:0,toxic:0}; }
  }
  function category(x){
    if(x.mol){
      const s=(name(x)+' '+String(x.f||'')+' '+String(x.desc||'')).toLowerCase();
      const out=[];
      if(/acid|hydrogen chloride|nitric acid|sulfuric acid|acetic acid|carbonic acid|hydrofluoric/.test(s)) out.push('Acids');
      if(/base|hydroxide|ammonia|amine/.test(s)) out.push('Bases');
      if(/salt|chloride|bromide|iodide|fluoride|nitrate|sulfate|phosphate|carbonate|permanganate|chromate/.test(s)) out.push('Salts');
      if(/drug|alkaloid|nicotine|caffeine|ibuprofen|aspirin|morphine|codeine|dopamine|serotonin/.test(s)) out.push('Drugs / Alkaloids');
      if(/organic|carbon|methane|ethanol|glucose|glycine|benzene|acetone|urea|lipid|amino/.test(s)) out.push('Organic Compounds');
      if(/explosive|nitroglycerin|peroxide|trinitrotoluene|tnt|azide/.test(s)) out.push('Explosive / Reactive');
      if(/bio|protein|peptide|amino|dna|rna|glucose|glycine|serotonin/.test(s)) out.push('Biochemical');
      if(!out.length) out.push(/carbon|hydrogen|oxygen|nitrogen|silicon|phosph|sulfur|chlor|brom|iod|fluor/.test(s)?'Organic / Molecular':'Inorganic Compounds');
      return out;
    }
    const c=(DATA.CATS[x.cat]||{}).n||'';
    const n=String(x.name||'').toLowerCase(); const out=[];
    const synthetic=(x.n>=95 || ['Technetium','Promethium','Astatine','Polonium','Francium'].includes(x.name));
    const radioactive=(x.n>=84 || x.n===43 || x.n===61);
    if(synthetic) out.push('Synthetic');
    if(radioactive) out.push('Radioactive');
    if(/halogen/i.test(c)) out.push('Halogens');
    else if(/noble gas/i.test(c)) out.push('Noble Gases');
    else if(/metal/i.test(c)) out.push('Metals');
    else if(/metalloid/i.test(c)) out.push('Metalloids');
    else out.push('Nonmetals');
    if(!out.length) out.push(c||'Elements');
    return out;
  }
  function rarity(x){
    const s=stats(x), power=s.dmg*2+s.rate*8+s.vel/70+s.hp/8+s.spd/20+s.crit*2+s.pierce*5+s.react*3+s.toxic*3;
    return power;
  }
  function owned(x){try{return DATA.isOwned(x.id)}catch(e){return false}}
  function fav(x){try{return !!(SAVE.isFav?SAVE.isFav(x.id):(SAVE.raw.favs||[]).includes(x.id))}catch(e){return false}}
  function value(x,key){
    const s=stats(x);
    if(key==='name') return name(x).toLowerCase();
    if(key==='z') return Number(x.n)||0;
    if(key==='dmg') return s.dmg;
    if(key==='rate') return s.rate;
    if(key==='vel') return s.vel;
    if(key==='hp') return s.hp;
    if(key==='spd') return s.spd;
    if(key==='crit') return s.crit;
    if(key==='pierce') return s.pierce;
    if(key==='react') return s.react;
    if(key==='toxic') return s.toxic;
    if(key==='power') return rarity(x);
    if(key==='owned') return owned(x)?1:0;
    if(key==='fav') return fav(x)?1:0;
    if(key==='rarity') return Number(x.cost)||0;
    return 0;
  }
  function inject(){
    const main=$('#vault-main'), search=$('#vault-element-search');
    if(!main||!search) return;
    let controls=$('#vault-v71-controls');
    if(!controls){
      controls=document.createElement('div'); controls.id='vault-v71-controls';
      controls.innerHTML=`<label>TYPE <select id="vault-v71-type"><option value="">ALL TYPES</option></select></label><label>SORT <select id="vault-v71-sort"><option value="name:asc">A → Z</option><option value="name:desc">Z → A</option><option value="power:asc">WEAKEST → STRONGEST</option><option value="power:desc">STRONGEST → WEAKEST</option><option value="dmg:asc">LOWEST DAMAGE → HIGHEST</option><option value="dmg:desc">HIGHEST DAMAGE → LOWEST</option><option value="crit:asc">LOWEST CRIT → HIGHEST</option><option value="crit:desc">HIGHEST CRIT → LOWEST</option><option value="rate:asc">LOWEST FIRE RATE → HIGHEST</option><option value="rate:desc">HIGHEST FIRE RATE → LOWEST</option><option value="hp:asc">LOWEST HEALTH → HIGHEST</option><option value="hp:desc">HIGHEST HEALTH → LOWEST</option><option value="spd:asc">LOWEST SPEED → HIGHEST</option><option value="spd:desc">HIGHEST SPEED → LOWEST</option><option value="vel:asc">LOWEST PROJECTILE SPEED → HIGHEST</option><option value="vel:desc">HIGHEST PROJECTILE SPEED → LOWEST</option><option value="pierce:asc">LOWEST PIERCE → HIGHEST</option><option value="pierce:desc">HIGHEST PIERCE → LOWEST</option><option value="toxic:asc">LOWEST TOXIC → HIGHEST</option><option value="toxic:desc">HIGHEST TOXIC → LOWEST</option><option value="react:asc">LOWEST REACTIVITY → HIGHEST</option><option value="react:desc">HIGHEST REACTIVITY → LOWEST</option><option value="owned:desc">OWNED → LOCKED</option><option value="owned:asc">LOCKED → OWNED</option><option value="fav:desc">FAVORITES → OTHER</option><option value="fav:asc">OTHER → FAVORITES</option><option value="z:asc">ATOMIC NUMBER ↑</option><option value="z:desc">ATOMIC NUMBER ↓</option></select></label>`;
      main.insertBefore(controls, search.nextSibling);
      const t=$('#vault-v71-type'); const types=[...new Set(E().concat(M()).flatMap(category))].sort();
      types.forEach(v=>{const o=document.createElement('option');o.value=v;o.textContent=v.toUpperCase();t.appendChild(o)});
      $('#vault-v71-type').addEventListener('change',apply); $('#vault-v71-sort').addEventListener('change',apply);
      search.querySelector('input').addEventListener('input',apply);
    }
    let cat=$('#vault-v71-catalog');
    if(!cat){cat=document.createElement('div');cat.id='vault-v71-catalog';main.insertBefore(cat,$('#molstrip'));}
    renderCatalog();
  }
  function renderCatalog(){
    const cat=$('#vault-v71-catalog'); if(!cat) return;
    const input=$('#vault-element-search-input'); const term=(input?.value||'').trim().toLowerCase();
    const type=$('#vault-v71-type')?.value||''; const [key,dir]=($('#vault-v71-sort')?.value||'name:asc').split(':');
    let items=E().concat(M());
    items=items.filter(x=>{const hay=(name(x)+' '+String(x.sym||'')+' '+String(x.f||'')+' '+String(x.id||'')+' '+String(x.n||'')+' '+category(x).join(' ')).toLowerCase(); return (!term||hay.includes(term))&&(!type||category(x).includes(type));});
    items.sort((a,b)=>{const av=value(a,key),bv=value(b,key); if(typeof av==='string'||typeof bv==='string') return dir==='asc'?String(av).localeCompare(String(bv)):String(bv).localeCompare(String(av)); return dir==='asc'?av-bv:bv-av;});
    cat.innerHTML='';
    const groups={};
    items.forEach(x=>{const primary=category(x)[0]||'Other';(groups[primary]||(groups[primary]=[])).push(x)});
    const order=Object.keys(groups).sort((a,b)=>a.localeCompare(b));
    if(!items.length){cat.innerHTML='<div class="vault-v71-empty">NO MATCHES FOR THIS SEARCH / FILTER.</div>';return;}
    order.forEach(g=>{const sec=document.createElement('section');sec.className='vault-v71-group';sec.innerHTML='<div class="vault-v71-sep">'+g.toUpperCase()+' <span>· '+groups[g].length+'</span></div><div class="vault-v71-grid"></div>';const grid=sec.querySelector('.vault-v71-grid');groups[g].forEach(x=>grid.appendChild(card(x)));cat.appendChild(sec)});
  }
  function card(x){
    const d=document.createElement('button'); d.type='button'; d.className='vault-v71-card'+(owned(x)?' owned':' locked')+(fav(x)?' favorite':'');
    const c=x.hue==null?'190':x.hue; const s=stats(x); const cats=category(x).join(' · ');
    d.style.setProperty('--vcol',`hsl(${c} 72% 62%)`);
    d.innerHTML=`<span class="v71-top"><b>${x.mol?'⚗':(x.sym||'')}</b><i>${fav(x)?'★':'☆'}</i></span><strong>${name(x)}</strong><small>${x.mol?(x.f||'COMPOUND'):'Z = '+(x.n||'?')} · ${cats}</small><span class="v71-stats">DMG ${s.dmg.toFixed(1)} · CRIT ${s.crit.toFixed(1)} · RATE ${s.rate.toFixed(2)} · HP ${Math.round(s.hp)}</span>`;
    d.addEventListener('click',()=>{try{SFX.click()}catch(e){};try{if(typeof window.__ISO_SELECT_VAULT==='function')window.__ISO_SELECT_VAULT(x.id);else if(typeof selectVault==='function')selectVault(x.id)}catch(e){}});
    return d;
  }
  function apply(){
    const input=$('#vault-element-search-input'); const term=(input?.value||'').trim().toLowerCase();
    $$('#ptable .pt[data-id]').forEach(t=>{let e=DATA.EL(t.dataset.id);let hay=e?(name(e)+' '+e.sym+' '+e.id+' '+(e.n||'')+' '+category(e).join(' ')).toLowerCase():'';t.style.display=(!term||hay.includes(term))?'':'none'});
    renderCatalog();
  }
  function bind(){
    inject();
    setTimeout(apply,0);
  }
  const oldShow=window.UI&&UI.show;
  if(oldShow&&!UI.__v71Show){UI.show=function(id){const r=oldShow.apply(this,arguments);if(id==='scr-vault')setTimeout(bind,0);return r};UI.__v71Show=true}
  const css=document.createElement('style');css.textContent=`
#vault-v71-controls{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0 12px}
#vault-v71-controls label{display:flex;align-items:center;gap:5px;font:9px var(--mono);color:var(--tx3);letter-spacing:.08em}
#vault-v71-controls select{background:#0b1320;color:var(--tx);border:1px solid var(--line);padding:7px 8px;font:10px var(--mono);outline:none;max-width:250px}
#vault-v71-catalog{margin-top:12px;padding:10px;background:rgba(8,12,20,.38);border:1px solid var(--line);max-height:48vh;overflow:auto}
.vault-v71-group{margin-bottom:15px}.vault-v71-sep{font:11px var(--mono);letter-spacing:.18em;color:var(--cy);padding:6px 4px;border-bottom:1px solid var(--line);margin-bottom:7px}.vault-v71-sep span{color:var(--tx3);letter-spacing:0}
.vault-v71-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(175px,1fr));gap:7px}
.vault-v71-card{position:relative;text-align:left;background:#0c1320;border:1px solid color-mix(in srgb,var(--vcol),transparent 45%);color:var(--tx);padding:8px;cursor:pointer;min-height:91px;font-family:var(--mono)}
.vault-v71-card:hover{border-color:var(--vcol);transform:translateY(-1px)}.vault-v71-card.locked{opacity:.45}.vault-v71-card.owned{box-shadow:inset 0 0 0 1px color-mix(in srgb,var(--vcol),transparent 72%)}
.v71-top{display:flex;justify-content:space-between;color:var(--vcol);font-size:16px}.v71-top i{font-style:normal;color:var(--am)}
.vault-v71-card strong{display:block;color:var(--vcol);font-size:12px;margin-top:4px}.vault-v71-card small{display:block;color:var(--tx3);font-size:8px;line-height:1.3;margin-top:3px}.v71-stats{display:block;color:var(--tx2);font-size:8px;line-height:1.35;margin-top:5px}.vault-v71-empty{padding:18px;text-align:center;color:var(--tx3);font:10px var(--mono)}
@media(max-width:700px){#vault-v71-controls{display:grid;grid-template-columns:1fr 1fr}.vault-v71-grid{grid-template-columns:1fr 1fr}}
`;
  document.head.appendChild(css);
  setTimeout(bind,0);
  console.log('ISOTOPE V71 VAULT SORT/FILTER active');
})();
