/* ISOTOPE V64 — EFFECT DAMAGE SCALING
   DoT and explicitly tagged effect/radius damage scale from the player's
   current Damage stat. Base effect damage is 75% of current Damage, with
   each move's existing coefficient preserved. Normal direct projectiles are
   untouched. The factor is applied once per damage event. */
(function(){
  'use strict';
  if(window.__ISO_V64_EFFECT_DAMAGE_SCALING__) return;
  window.__ISO_V64_EFFECT_DAMAGE_SCALING__=true;
  console.log('ISOTOPE V64 EFFECT DAMAGE SCALING active.');
})();
