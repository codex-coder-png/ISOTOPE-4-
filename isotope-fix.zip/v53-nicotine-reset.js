/* ISOTOPE V53 — NICOTINE RECEPTOR ROUND + ONE-TIME SETTINGS FRESH RESTART
   - Ability 1: one fast, large receptor projectile that converts the first hostile
     it hits into a permanent nicotine ally through the existing safe conversion API.
   - Keeps this projectile in its own queue so legacy V29/V50 charm queues cannot
     double-step or double-collide with it.
   - Main Settings screen gains one free, permanently consumable fresh-start reset.
   - First click arms reset confirmation; second click opens the V40-style relic
     picker. Picking one relic commits the reset and consumes the one free use.
*/
(function(){
  'use strict';
  if(window.__ISO_V53_PATCH__) return;
  window.__ISO_V53_PATCH__=true;

  function R(){return window.RUN||null;}
  function C(v,a,b){v=Number(v);if(!Number.isFinite(v))v=a;return Math.max(a,Math.min(b,v));}
  function d2(ax,ay,bx,by){var dx=ax-bx,dy=ay-by;return dx*dx+dy*dy;}
  function esc(v){return String(v==null?'':v).replace(/[&<>\"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
  function relList(){
    var D=window.DATA||{};
    var a=Array.isArray(D.RELICS)?D.RELICS.filter(Boolean):[];
    var seen=Object.create(null);
    return a.filter(function(r){if(!r||!r.id||seen[r.id])return false;seen[r.id]=1;return true;});
  }
  function playerHue(p){return Number(p&&p.elem&&p.elem.hue)||145;}

  /* ---------------- Nicotine Ability 1 ---------------- */
  function fireReceptorRound(p){
    var r=R();
    if(!r||!p||p.downed)return false;
    r._isoV53NicoRounds=Array.isArray(r._isoV53NicoRounds)?r._isoV53NicoRounds:[];
    if(r._isoV53NicoRounds.length>=3)return false;
    var a=Number(p.angle)||0;
    var hue=playerHue(p);
    var speed=C(Number(p && window.__ISO_ST && window.__ISO_ST.ps)||Number(window.ST&&ST.ps)||390,300,900);
    speed=Math.max(680,speed*1.55);
    var r0=15;
    r._isoV53NicoRounds.push({
      x:p.x+Math.cos(a)*24,
      y:p.y+Math.sin(a)*24,
      px:p.x+Math.cos(a)*10,
      py:p.y+Math.sin(a)*10,
      vx:Math.cos(a)*speed,
      vy:Math.sin(a)*speed,
      r:r0,
      life:1.65,
      owner:p.id,
      hue:hue,
      pulse:0,
      hit:false
    });
    try{window.SFX&&SFX.active&&SFX.active();}catch(_){ }
    try{window.fxBurst&&fxBurst(p.x+Math.cos(a)*38,p.y+Math.sin(a)*38,hue,22);}catch(_){ }
    try{window.fxRing&&fxRing(p.x,p.y,hue,68,6,.32);}catch(_){ }
    return true;
  }

  var oldUse=window.useActive;
  window.useActive=function(p){
    try{
      var n=String(p&&p.elem&&(p.elem.name||p.elem.token)||'').toLowerCase();
      if(n==='nicotine' && p && !p.downed && (p.activeCd||0)<=0){
        var slot=C(Number(p.signatureSlot)||0,0,2);
        if(slot===0){
          var r=R();
          if(!r)return;
          var st=window.ST||{};
          var cd=Number(st.activeCd);
          if(!Number.isFinite(cd)||cd<=0)cd=7;
          if(fireReceptorRound(p)){p.activeCd=cd;return;}
        }
      }
    }catch(e){console.warn('V53 nicotine Ability 1',e);}
    return typeof oldUse==='function'?oldUse.apply(this,arguments):undefined;
  };

  function liveEnemies(r){
    var a=Array.isArray(r&&r.enemies)?r.enemies:[];
    return a.filter(function(e){return e&&!e.dead&&!e.boss&&!e._v29Converted&&e.team!=='player'&&!e._v29CharmLocked;});
  }
  function stepReceptorRounds(dt){
    var r=R();if(!r||!Array.isArray(r._isoV53NicoRounds))return;
    var hostCheck=!(r.isOnline&&window.NET&&NET.isHost===false);
    if(!hostCheck)return;
    var arr=r._isoV53NicoRounds;
    for(var i=arr.length-1;i>=0;i--){
      var b=arr[i];
      if(!b){arr.splice(i,1);continue;}
      b.life-=dt;b.px=b.x;b.py=b.y;b.x+=b.vx*dt;b.y+=b.vy*dt;b.pulse+=dt;
      var hit=null,es=liveEnemies(r);
      for(var j=0;j<es.length;j++){
        var e=es[j];
        if(d2(b.x,b.y,e.x,e.y)<(b.r+Math.max(7,e.r||10))*(b.r+Math.max(7,e.r||10))){hit=e;break;}
      }
      if(hit){
        var ok=false;
        try{if(window.ISO_V50_NICO&&typeof window.ISO_V50_NICO.befriend==='function')ok=window.ISO_V50_NICO.befriend(hit,b.owner,'nicotine-receptor-round');}catch(e){console.warn('V53 nicotine conversion',e);}
        if(ok){
          try{window.fxRing&&fxRing(hit.x,hit.y,b.hue,126,9,.55);}catch(_){ }
          try{window.fxBurst&&fxBurst(hit.x,hit.y,b.hue,28);}catch(_){ }
        }
        arr.splice(i,1);continue;
      }
      if(b.life<=0||b.x<-90||b.x>window.W+90||b.y<-90||b.y>window.H+90)arr.splice(i,1);
    }
  }
  var prevUpdate=window.update;
  if(typeof prevUpdate==='function'&&!prevUpdate.__isoV53Update){
    var wrappedUpdate=function(dt){
      var out=prevUpdate.call(this,dt);
      try{stepReceptorRounds(dt);}catch(e){console.warn('V53 nicotine projectile loop',e);}
      return out;
    };
    wrappedUpdate.__isoV53Update=true;window.update=wrappedUpdate;
    try{window.CORE&&CORE.setUpdate&&CORE.setUpdate(wrappedUpdate);}catch(_){ }
  }

  var prevRender=window.render;
  if(typeof prevRender==='function'&&!prevRender.__isoV53Render){
    var wrappedRender=function(){
      var out=prevRender.apply(this,arguments);
      try{
        var r=R(),cx=window.CORE&&CORE.ctx&&CORE.ctx();
        if(!r||!cx)return out;
        (r._isoV53NicoRounds||[]).forEach(function(b){
          var alpha=C(b.life/1.65,.08,1),ang=Math.atan2(b.vy,b.vx),backX=b.x-Math.cos(ang)*28,backY=b.y-Math.sin(ang)*28;
          cx.save();
          cx.lineCap='round';
          cx.shadowBlur=24;
          cx.shadowColor='hsla('+b.hue+',100%,70%,'+(.72*alpha)+')';
          cx.strokeStyle='hsla('+b.hue+',95%,65%,'+(.92*alpha)+')';
          cx.lineWidth=b.r*1.9;
          cx.beginPath();cx.moveTo(backX,backY);cx.lineTo(b.x,b.y);cx.stroke();
          cx.shadowBlur=12;
          cx.strokeStyle='rgba(235,255,245,'+(.98*alpha)+')';
          cx.lineWidth=Math.max(4,b.r*.7);
          cx.beginPath();cx.moveTo(backX+Math.cos(ang)*6,backY+Math.sin(ang)*6);cx.lineTo(b.x,b.y);cx.stroke();
          cx.fillStyle='hsla('+((b.hue+28)%360)+',100%,86%,'+(.96*alpha)+')';
          cx.beginPath();cx.arc(b.x,b.y,b.r*.72*(1+.08*Math.sin(b.pulse*22)),0,Math.PI*2);cx.fill();
          cx.strokeStyle='hsla('+b.hue+',100%,78%,'+(.42*alpha)+')';cx.lineWidth=2;
          cx.beginPath();cx.arc(b.x,b.y,b.r+5+2*Math.sin(b.pulse*11),0,Math.PI*2);cx.stroke();
          cx.restore();
        });
      }catch(e){ }
      return out;
    };
    wrappedRender.__isoV53Render=true;window.render=wrappedRender;
    try{window.CORE&&CORE.setRender&&CORE.setRender(wrappedRender);}catch(_){ }
  }

  /* ---------------- One-time settings fresh restart ---------------- */
  var USED='__isoV53SettingsRestartUsed';
  var ARM='__isoV53SettingsRestartArmed';
  function S(){return window.SAVE&&SAVE.raw?SAVE.raw:null;}
  function markUsed(){var s=S();return !!(s&&s[USED]===true);}
  function save(){try{window.SAVE&&SAVE.save&&SAVE.save();}catch(_){ }}

  function wipeAndCommit(chosen){
    var s=S();if(!s)return false;
    var valid=relList().some(function(r){return r.id===chosen;});
    if(!valid)return false;
    /* Preserve user settings; clear essentially all progression. */
    s.coins=200;
    s.unlocked=['e1','e6','e8']; /* H, C, O */
    s.sel='e6';s.sel2='e8';
    s.mols=[];s.favs=[];s.abil={};s.signatures={};s.mastery={};s.abilityMastery={};s.meta={};
    s.relicsFound=[chosen];s.relicLoadout=[chosen];
    s.plays={};s.achievements={};s.stats={runs:0,kills:0,bestWave:0,earned:0,mxp:0};
    s.synthesisLabUnlocked=false;
    delete s.__isoMxp15;delete s.__megaSig;delete s.__megaUnlock;delete s.v39FullWipeApplied;
    s[USED]=true;s[ARM]=false;
    /* Disable the old startup V40 prompt now that this reset was deliberately
       performed from Settings. */
    s.v40RestartAccepted=true;s.v38RestartAccepted=true;
    save();
    try{SAVE.refreshCoins&&SAVE.refreshCoins();}catch(_){ }
    return true;
  }

  function showRelicPicker(){
    if(document.getElementById('v53-relic-picker'))return;
    var ov=document.createElement('div');ov.id='v53-relic-picker';
    ov.style.cssText='position:fixed;inset:0;z-index:100500;background:rgba(2,6,12,.98);display:flex;align-items:center;justify-content:center;padding:18px;font-family:var(--mono,monospace);';
    var modal=document.createElement('div');
    modal.style.cssText='width:min(920px,96vw);max-height:92vh;overflow:auto;border:1px solid #4c84b9;background:linear-gradient(155deg,#0c1522,#080d15);box-shadow:0 0 45px rgba(20,110,210,.2);padding:26px;text-align:center;';
    var h=document.createElement('div');h.style.cssText='font-family:var(--disp,sans-serif);font-size:clamp(24px,3vw,36px);letter-spacing:.08em;color:#d9efff;margin-bottom:9px;';h.textContent='CHOOSE 1 STARTING RELIC';
    var sub=document.createElement('div');sub.style.cssText='font-size:12px;line-height:1.7;color:#9dacbe;max-width:760px;margin:0 auto 18px;';sub.innerHTML='This consumes your <b style="color:#ffd86b">one free Settings restart</b>. The reset will leave <b style="color:#7ef0a6">200 coins</b>, only <b style="color:#8fdcff">Hydrogen + Carbon + Oxygen</b> unlocked, and exactly this relic.';
    var grid=document.createElement('div');grid.style.cssText='display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:9px;text-align:left;';
    relList().forEach(function(r){
      var b=document.createElement('button');b.type='button';b.className='btn';b.style.cssText='padding:12px;border:1px solid #31455c;background:#0d1724;color:#e9f5ff;text-align:left;cursor:pointer;min-height:82px;';
      b.innerHTML='<div style="font-weight:800;font-size:14px">'+esc(r.ic||'✦')+' '+esc(r.n||r.id)+'</div><div style="font-size:11px;color:#9dacbe;line-height:1.4;margin-top:5px">'+esc(r.d||'')+'</div>';
      b.onclick=function(){
        if(markUsed())return;
        if(wipeAndCommit(r.id)){ov.remove();location.reload();}
      };
      grid.appendChild(b);
    });
    var cancel=document.createElement('button');cancel.type='button';cancel.className='btn';cancel.style.cssText='margin-top:14px;padding:9px 18px;';cancel.textContent='CANCEL';
    cancel.onclick=function(){ov.remove();};
    modal.appendChild(h);modal.appendChild(sub);modal.appendChild(grid);modal.appendChild(cancel);ov.appendChild(modal);document.body.appendChild(ov);
  }

  function installSettingsReset(){
    var scr=document.getElementById('scr-set')||document.getElementById('scr-settings');
    if(!scr||scr.dataset.isoV53Installed==='1')return;
    scr.dataset.isoV53Installed='1';
    var rows=document.getElementById('set-rows');
    var box=document.createElement('div');box.id='v53-settings-reset';box.className='setrow panel';
    box.style.cssText='border-color:#705b35;background:linear-gradient(145deg,rgba(52,38,16,.33),rgba(10,15,22,.92));';
    box.innerHTML='<div><label style="color:#ffd86b">ONE-TIME FRESH RESTART</label><small id="v53-reset-hint" style="display:block;color:var(--tx2);margin-top:4px;line-height:1.5">Reset progression once. You will choose exactly 1 starting relic.</small></div><button class="btn warn" id="v53-reset-btn">RESTART FROM 0</button>';
    (rows||scr).appendChild(box);
    var btn=box.querySelector('#v53-reset-btn'),hint=box.querySelector('#v53-reset-hint');
    function paint(){
      var used=markUsed(),armed=!!(S()&&S()[ARM]===true);
      if(used){box.remove();return true;}
      btn.textContent=armed?'CONFIRM RESTART':'RESTART FROM 0';
      btn.dataset.armed=armed?'1':'0';
      hint.innerHTML=armed?'This is your <b style="color:#ffcb72">final confirmation</b>. Press the button again to choose your starting relic.':'You get exactly <b style="color:#7ef0a6">one</b> use. Your progression stays untouched until you confirm.';
      return false;
    }
    btn.onclick=function(){
      if(markUsed())return;
      var st=S();
      if(!st[ARM]){
        st[ARM]=true;save();paint();try{SFX.click();}catch(_){ }return;
      }
      try{SFX.click();}catch(_){ }
      showRelicPicker();
    };
    paint();
    /* Repaint whenever settings is opened and after save-driven UI changes. */
    var tick=function(){if(!document.body.contains(box))return;paint();};
    setInterval(tick,700);
  }
  setTimeout(installSettingsReset,80);
  setTimeout(installSettingsReset,300);
  setTimeout(installSettingsReset,900);

  /* Suppress the legacy startup V40 prompt: this V53 feature replaces it with
     the one-free-use reset in Settings, without changing progression. */
  try{
    var s=S();
    if(s){s.v40RestartAccepted=true;s.v38RestartAccepted=true;save();}
    setTimeout(function(){var old=document.getElementById('v40-start-prompt');if(old)old.remove();},320);
  }catch(_){ }

  function log(){
    var host=document.querySelector('#mega-update-panel .mega-update-scroll')||document.querySelector('#mega-update-panel')||document.querySelector('#update-log');
    if(!host||host.dataset.v53logged==='1')return;
    host.dataset.v53logged='1';
    var rows=[
      ['V53 · NICOTINE RECEPTOR ROUND','Ability 1 now fires one fast, large receptor projectile with a dedicated hitbox/trail. On contact it converts the struck hostile into a permanent green-outlined ally through the safe nicotine befriending system.'],
      ['V53 · SETTINGS FRESH RESTART','Settings now grants exactly one free progression restart. The first button press arms confirmation; the second opens the starting-relic picker. After a relic is chosen, the use is permanently consumed and the button disappears on every future Settings open. The fresh save starts with 200 coins and only Hydrogen, Carbon, and Oxygen unlocked.'],
      ['V53 · SAVE SAFETY','The deliberate Settings reset preserves audio/UI preferences but clears progression, mastery, compounds, favorites, achievements, run history, ability ownership, augment progression, and prior relics before restoring the one selected starter relic.']
    ];
    rows.forEach(function(x){var d=document.createElement('div');d.className='urow';d.innerHTML='<div class="uver">'+esc(x[0])+'</div><div class="utxt">'+esc(x[1])+'</div>';host.appendChild(d);});
    try{host.scrollTop=host.scrollHeight;}catch(_){ }
    document.querySelectorAll('.menu-update,#menufoot span:last-child').forEach(function(n){n.textContent=n.id==='menu-update'?'BUILD V53 · NICOTINE RECEPTOR ROUND + ONE-TIME FRESH RESTART':'BUILD V53 · LOCAL CO-OP';});
  }
  setTimeout(log,500);setTimeout(log,1400);setTimeout(log,2500);
  console.log('ISOTOPE V53 active: big nicotine receptor projectile + one-time Settings fresh restart');
})();
