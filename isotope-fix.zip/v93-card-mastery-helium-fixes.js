/* ISOTOPE V93 — authoritative cards + per-ability mastery + helium fix
 * Final compatibility layer loaded after V92. It does not replace the current
 * build; it normalizes the active level-up pool and fixes the remaining runtime
 * ownership/slot/rendering issues in-place.
 */
(function(){
  'use strict';
  if(window.__ISO_V93_CARD_MASTERY_HELIUM_FIXES__)return;
  window.__ISO_V93_CARD_MASTERY_HELIUM_FIXES__=true;

  var DATA0=window.DATA||{}, SAVE0=window.SAVE||{};
  var PATHS={
    damage:{label:'DAMAGE',desc:'+12% SIGNATURE DAMAGE / RANK',icon:'⚔'},
    range:{label:'RANGE',desc:'+18% SIGNATURE RANGE / RANK',icon:'⌁'},
    cooldown:{label:'COOLDOWN',desc:'-10% SIGNATURE COOLDOWN / RANK',icon:'⟳'}
  };
  var COSTS=[100,180,300];

  function canonical(id){try{return DATA0.canonicalId?DATA0.canonicalId(id):String(id)}catch(_){return String(id)}}
  function getEl(id){try{return DATA0.EL?DATA0.EL(canonical(id)):null}catch(_){return null}}
  function owned(id){try{return !!(DATA0.isOwned&&DATA0.isOwned(canonical(id)))}catch(_){return false}}
  function activePlayer(){try{var r=window.RUN;if(!r||!Array.isArray(r.players))return null;return r.players[r.localNetId||0]||r.players[0]||null}catch(_){return null}}
  function playerSlot(p){p=p||activePlayer();return Math.max(0,Math.min(2,Number(p&&p.signatureSlot)||0))}

  /* ---------------------------------------------------------------
     CARD POOL — exactly one direct card per direct stat.
     Old raw stat cards and generated progress cards are removed from the
     selectable pool. Bespoke mechanics (turret, ricochet, etc.) stay intact.
     --------------------------------------------------------------- */
  (function installCards(){
    var cards=[];
    try{cards=window.ALL_CARDS||[]}catch(_){cards=[]}
    if(!Array.isArray(cards))return;
    var removeId={
      pow:1, rate:1, multi:1, pierce:1, crit:1, magnet:1, homing:1, plating:1,
      scavenger:1
    };
    var seen={};
    var keep=[];
    for(var i=0;i<cards.length;i++){
      var c=cards[i];if(!c)continue;
      var id=String(c.id||''), text=(String(c.n||'')+' '+String(c.d||''));
      var kill=false;
      if(c.extraStat)kill=true;
      if(/^xcard_|^content_card_|^v50_stat_|^v84_direct_/i.test(id))kill=true;
      if(removeId[id])kill=true;
      if(/^(?:v93_stat_)/i.test(id))kill=true;
      /* Remove older duplicate projectile-count cards, but do not touch genuine
         attack descriptions that merely happen to fire several projectiles. */
      if(/(?:^|\b)(?:gain\s+)?\+1\s+(?:additional\s+)?projectile(?:\b|s)|projectile\s+(?:count|output)/i.test(text))kill=true;
      if(!kill){
        var mech=null;
        if(id==='orbit')mech='orbit';
        if(id==='turret')mech='turret';
        if(id==='nova')mech='nova';
        if(mech){if(seen['id:'+id])kill=true;else seen['id:'+id]=1;}
      }
      if(!kill)keep.push(c);
    }

    /* One canonical direct-stat card for each stat. Values are pre-divided by
       the game's rarity multiplier so the resulting live stat is exact. */
    var defs=[
      ['dmg','⚔','Focused Damage','Projectiles deal +10% damage.','common',0.10],
      ['rate','↯','Rapid Fire','Fire rate is +8%.','uncommon',0.08/1.25],
      ['hp','♥','Reinforced Hull','Maximum HP is +12.','common',12],
      ['spd','➤','Thruster Boost','Movement speed is +8%.','common',0.08],
      ['crit','✧','Critical Mass','Critical chance is +8%.','rare',0.08/1.5],
      ['shield','◈','Shield Reserve','Maximum shield is +15.','uncommon',15/1.25],
      ['magnet','◎','Pickup Field','Pickup range is +10%.','uncommon',0.10/1.25],
      ['coin','◈','Coin Matrix','Coin gain is +10%.','rare',0.10/1.5],
      ['pierce','➤','Penetrator','Gain +1 pierce.','uncommon',1/1.25],
      ['aoe','✹','Reaction Radius','Ability and reaction radius is +10%.','uncommon',0.10/1.25],
      ['homing','⌖','Guidance Core','Homing strength is +10%.','uncommon',0.10/1.25],
      ['projs','⋔','Particle Split','Gain +1 projectile.','rare',1/1.5]
    ];
    var rarityMul={common:1,uncommon:1.25,rare:1.5,epic:1.9,legendary:2.4,mythic:3.2};
    defs.forEach(function(d){
      keep.push({id:'v93_stat_'+d[0],ic:d[1],n:d[2],d:d[3],rarity:d[4],max:1,extraStat:d[0],extraValue:d[5],finalTarget:(Number(d[5])*(rarityMul[d[4]]||1)),unique:true,v93Direct:true});
    });
    cards.length=0;
    Array.prototype.push.apply(cards,keep);
    window.ISO_V93_CARD_AUDIT={count:cards.length,projectileCards:cards.filter(function(c){return c&&c.extraStat==='projs'}).map(function(c){return c.id}),directStats:defs.map(function(d){return d[0]})};

    /* Legacy saved cards remain valid in existing runs, but the new pool can
       never roll the old duplicates again. */
    try{if(typeof EXTRA_CARDS!=='undefined'&&Array.isArray(EXTRA_CARDS))EXTRA_CARDS.length=0}catch(_){ }
  })();

  /* ---------------------------------------------------------------
     CHOOSE CARD — one and only one meaning per selected card.
     --------------------------------------------------------------- */
  (function installChooseCard(){
    var hasBound=false;
    function authoritativeChooseCard(pid,key){
      var R=window.RUN;if(!R||R.state!=='level'||!R.pools||!R.pools[pid]||R.levelDone&&R.levelDone[pid])return;
      var pool=R.pools[pid], card=pool.find(function(c){return c&&c.key===key});
      if(!card)return;
      R.ab=R.ab||{};
      if(String(key).indexOf('filler:')===0){
        if(key==='filler:hp'){
          R.players.forEach(function(p){if(!p||p.downed)return;var cap=Number(window.ST&&ST.hp)||Number(p.hp)||100;p.hp=Math.min(cap,p.hp+30)});
        }else{
          R.coins=(Number(R.coins)||0)+40;
          try{if(SAVE0.addCoins)SAVE0.addCoins(40)}catch(_){ }
        }
        try{if(window.SFX&&SFX.coin)SFX.coin()}catch(_){ }
      }else{
        R.ab[key]=(Number(R.ab[key])||0)+1;
        try{if(window.SFX&&SFX.unlock)SFX.unlock()}catch(_){ }
      }
      if(!R.levelDone)R.levelDone={};R.levelDone[pid]=true;
      try{if(typeof computeStats==='function')computeStats()}catch(_){ }
      try{if(typeof buildChips==='function')buildChips()}catch(_){ }
      var ids=(typeof pickerIds==='function')?pickerIds():[pid];
      var done=ids.every(function(id){return R.levelDone[id]});
      if(done){
        R.pending=Math.max(0,(Number(R.pending)||0)-1);
        R.levelDone={};
        if(R.pending>0){if(typeof openLevel==='function')openLevel();return;}
        R.pools=null;
        var lm=document.getElementById('m-level');if(lm){lm.classList.remove('prism-level');var li=lm.querySelector('.modal');if(li)li.classList.remove('prism-level-modal');lm.classList.add('hidden')}
        R.state=(R.enemies&&R.enemies.length)||R.spawnLeft>0?'play':'inter';
      }else if(pid===R.localNetId){
        var box=document.getElementById('cards');if(box)box.innerHTML='<div class="panel" style="padding:20px;font-family:var(--mono);color:var(--tx2)">MODULE LOCKED IN — WAITING FOR TEAM…</div>';
      }
      try{if(R.isOnline&&window.NET&&NET.isHost&&typeof broadcastGameState==='function')broadcastGameState(true)}catch(_){ }
    }
    try{window.chooseCard=authoritativeChooseCard;hasBound=true}catch(_){ }
    try{chooseCard=authoritativeChooseCard}catch(_){ }
    try{if(window.ISO_V23_CORE&&ISO_V23_CORE.getUseActive){} }catch(_){ }
    window.ISO_V93_AUTHORITATIVE_CHOOSE_CARD=hasBound;
  })();

  /* ---------------------------------------------------------------
     PER-ABILITY SIGNATURE MASTERY storage + runtime slot context.
     --------------------------------------------------------------- */
  (function installMasteryStorage(){
    if(!SAVE0||!SAVE0.raw)return;
    function ensureRaw(id,slot){
      id=canonical(id);slot=slot==null?playerSlot():Math.max(0,Math.min(2,Number(slot)||0));
      var raw=SAVE0.raw.signatureUpgrades||(SAVE0.raw.signatureUpgrades={});
      var cur=raw[id];
      if(cur&&typeof cur==='object'&&Object.prototype.hasOwnProperty.call(cur,'path')){
        cur={0:{path:cur.path||null,rank:Number(cur.rank)||0}};raw[id]=cur;
      }
      if(!cur||typeof cur!=='object')cur={};
      if(!cur[String(slot)])cur[String(slot)]={path:null,rank:0};
      raw[id]=cur;
      return {id:id,slot:slot,raw:raw,state:cur[String(slot)]};
    }
    function norm(id,slot){var x=ensureRaw(id,slot),u=x.state||{};var path=PATHS[u.path]?u.path:null;var rank=Math.max(0,Math.min(3,Math.floor(Number(u.rank)||0)));return {id:x.id,slot:x.slot,path:path,rank:rank,store:x.raw,state:x.state};}
    SAVE0.getSignatureUpgrade=function(id,slot){return {path:norm(id,slot).path,rank:norm(id,slot).rank};};
    SAVE0.chooseSignatureUpgradePath=function(id,path,slot){var x=norm(id,slot);if(!PATHS[path]||x.path)return false;x.store[x.id][String(x.slot)]={path:String(path),rank:0};try{SAVE0.save&&SAVE0.save()}catch(_){ }return true;};
    SAVE0.signatureUpgradeCost=function(id,slot){var x=norm(id,slot);return x.path&&x.rank<3?COSTS[x.rank]:0;};
    SAVE0.buySignatureUpgrade=function(id,slot){var x=norm(id,slot);if(!x.path||x.rank>=3)return false;var m=SAVE0.mxp?SAVE0.mxp(x.id):{xp:0,nodes:{}};var cost=COSTS[x.rank];if(Number(m.xp||0)<cost)return false;m.xp-=cost; m.nodes=m.nodes||{};if(SAVE0.raw.mastery)SAVE0.raw.mastery[x.id]=m;x.store[x.id][String(x.slot)]={path:x.path,rank:x.rank+1};try{SAVE0.save&&SAVE0.save()}catch(_){ }return true;};
    SAVE0.getSignatureUpgradeStats=function(id,slot){
      if(slot==null&&SAVE0.__activeSignatureId===canonical(id)&&SAVE0.__activeSignatureSlot!=null)slot=SAVE0.__activeSignatureSlot;
      var x=norm(id,slot),r=x.rank;
      return {path:x.path,rank:r,damageMult:x.path==='damage'?1+.12*r:1,rangeMult:x.path==='range'?Math.pow(1.18,r):1,cooldownMult:x.path==='cooldown'?Math.pow(.90,r):1,cost:x.path&&r<3?COSTS[r]:0,slot:x.slot};
    };

    /* Put the exact player slot into a tiny temporary context while an ability
       executes. Existing V79/V86 wrappers call getSignatureUpgradeStats(id)
       without the slot argument, so this bridges that call to the actual
       ability the player pressed without double-applying any upgrade. */
    try{
      var core=window.ISO_V23_CORE||{}, raw=core.getUseActive&&core.getUseActive();
      if(typeof raw==='function'&&!raw.__isoV93SlotContext){
        var wrap=function(p){
          var prevId=SAVE0.__activeSignatureId,prevSlot=SAVE0.__activeSignatureSlot;
          SAVE0.__activeSignatureId=canonical((p&&p.elementId)||((p&&p.elem)||{}).id||((window.RUN||{}).el||{}).id);
          SAVE0.__activeSignatureSlot=playerSlot(p);
          try{return raw.apply(this,arguments)}finally{SAVE0.__activeSignatureId=prevId;SAVE0.__activeSignatureSlot=prevSlot;}
        };
        wrap.__isoV93SlotContext=true;
        if(core.setUseActive)core.setUseActive(wrap);
        window.useActive=wrap;try{useActive=wrap}catch(_){ }
      }
    }catch(_){ }
  })();

  /* ---------------------------------------------------------------
     AUTHORITATIVE MASTERY SCREEN: always render all 3 signature abilities,
     each with its own independent DAMAGE/RANGE/COOLDOWN tree.
     --------------------------------------------------------------- */
  (function installMasteryUI(){
    var pending={};
    function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])})}
    function state(id,slot){return SAVE0.getSignatureUpgrade?SAVE0.getSignatureUpgrade(id,slot):{path:null,rank:0}}
    function css(){
      if(document.getElementById('v93-mastery-style'))return;
      var s=document.createElement('style');s.id='v93-mastery-style';s.textContent=''
      +'#scr-mastery .v93-mastery{margin-top:12px;padding:14px;border:1px solid #28445e;background:rgba(7,15,26,.84)}'
      +'.v93-mastery-intro{font-size:11px;color:#91a9c4;line-height:1.45;margin:5px 0 12px}'
      +'.v93-sig{border:1px solid #2a4762;background:rgba(9,19,32,.9);padding:12px;margin-top:10px}'
      +'.v93-sighead{display:flex;align-items:flex-start;justify-content:space-between;gap:10px}'
      +'.v93-sigtitle{font-family:var(--disp,Arial);font-size:17px;letter-spacing:.07em}'
      +'.v93-sigdesc{font-size:11px;color:#96abc0;line-height:1.35;margin-top:4px}'
      +'.v93-state{font-size:10px;color:#72f2a0;white-space:nowrap}'
      +'.v93-tabs{display:flex;gap:6px;flex-wrap:wrap;margin:12px 0 4px}'
      +'.v93-tab{padding:7px 11px;border:1px solid #28445e;background:#0a1422;color:#a9bfd5;cursor:pointer}'
      +'.v93-tab.on{border-color:#66ecff;color:#66ecff;box-shadow:0 0 12px rgba(102,236,255,.1) inset}'
      +'.v93-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin-top:9px}'
      +'.v93-path{min-height:104px;padding:10px;text-align:left;border:1px solid #28445e;background:#0a1422;color:#d8e7f5;cursor:pointer}'
      +'.v93-path:hover{border-color:#66ecff}.v93-path.chosen{border-color:#66f0a0;box-shadow:0 0 0 1px rgba(102,240,160,.13) inset}.v93-path.disabled{opacity:.36;cursor:not-allowed}'
      +'.v93-path b{display:block;letter-spacing:.08em}.v93-path small{display:block;color:#91a7bd;line-height:1.3;margin-top:4px}.v93-pips{display:flex;gap:4px;margin-top:8px}.v93-pips i{display:block;width:24px;height:5px;border:1px solid #28445e}.v93-pips i.on{background:#66f0a0}'
      +'.v93-action{font-size:9px;color:#b8cbe0;margin-top:7px;letter-spacing:.08em}.v93-up{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-top:9px;padding-top:9px;border-top:1px solid #28445e}'
      +'@media(max-width:900px){.v93-grid{grid-template-columns:1fr}.v93-sighead{display:block}.v93-state{margin-top:4px}}';
      document.head.appendChild(s);
    }
    function render(id){
      var scr=document.getElementById('scr-mastery');if(!scr||scr.classList.contains('hidden'))return;
      var el=getEl(id||SAVE0.sel);if(!el)return;css();
      var detail=document.getElementById('m-detail');if(!detail)return;
      var list=el.choices||el.signatures||[];
      var mx=SAVE0.mxp?SAVE0.mxp(el.id):{xp:0};
      var col='hsl('+(Number(el.hue)||190)+' 80% 68%)';
      detail.innerHTML='<div style="font-family:var(--disp,Arial);font-size:24px;color:'+col+'">'+esc(el.name||el.sym||el.id).toUpperCase()+'</div>'
        +'<div class="sub">Mastery XP available: <b style="color:var(--gr,#66f0a0)">◆ '+String(mx.xp||0)+'</b></div>';
      var wrap=document.createElement('div');wrap.className='v93-mastery';
      wrap.innerHTML='<div style="font-family:var(--disp,Arial);font-size:18px;letter-spacing:.08em;color:#66ecff">✦ SIGNATURE MASTERY — PER ABILITY</div>'
        +'<div class="v93-mastery-intro">Each Signature ability has a completely separate upgrade path. Choosing DAMAGE, RANGE, or COOLDOWN for Signature 1 does not choose or alter the path for Signature 2 or Signature 3.</div>';
      /* Render all three signature abilities at once so every independent path is
         immediately visible; each section still stores its own slot state. */
      var body=document.createElement('div');
      body.className='v93-mastery-body';
      for(var slot=0;slot<3;slot++){
        (function(slt){
          var holder=document.createElement('div');
          body.appendChild(holder);
          var sig=list[slt]||{name:'SIGNATURE '+(slt+1),desc:'Ability not installed.',ic:['⚛','✦','◈'][slt]};
          var own=slt===0||!SAVE0.abilOwned||SAVE0.abilOwned(el.id,slt),u=state(el.id,slt),box=document.createElement('div');box.className='v93-sig';
          var st=own?(u.path?'PATH: '+PATHS[u.path].label+' · '+u.rank+'/3':'NO PATH CHOSEN'):'LOCKED — PURCHASE ABILITY '+(slt+1);
          box.innerHTML='<div class="v93-sighead"><div><div class="v93-sigtitle" style="color:'+col+'">SIGNATURE '+(slt+1)+' · '+esc(sig.ic||['⚛','✦','◈'][slt])+' '+esc(sig.name||('ABILITY '+(slt+1)))+'</div><div class="v93-sigdesc">'+esc(sig.desc||'')+'</div></div><div class="v93-state">'+esc(st)+'</div></div>';
          var grid=document.createElement('div');grid.className='v93-grid';
          Object.keys(PATHS).forEach(function(k){
            var P=PATHS[k],chosen=u.path===k,pk=el.id+'|'+slt+'|'+k,pnd=!!pending[pk];
            var b=document.createElement('button');b.type='button';b.className='v93-path'+(chosen?' chosen':'')+((u.path&&!chosen)||!own?' disabled':'');b.disabled=!!((u.path&&!chosen)||!own);
            var pip='';for(var j=0;j<3;j++)pip+='<i class="'+(chosen&&j<u.rank?'on':'')+'"></i>';
            b.innerHTML='<span style="font-size:20px">'+P.icon+'</span><span><b>'+P.label+'</b><small>'+P.desc+'</small><span class="v93-pips">'+pip+'</span><span class="v93-action">'+(chosen?'PATH LOCKED':pnd?'CLICK AGAIN TO CONFIRM':'CHOOSE '+P.label)+'</span></span>';
            b.onclick=function(){
              if(!own||u.path)return;
              if(!pending[pk]){pending[pk]=1;render(el.id);return;}
              if(SAVE0.chooseSignatureUpgradePath&&SAVE0.chooseSignatureUpgradePath(el.id,k,slt)){
                delete pending[pk];try{if(window.SFX&&SFX.unlock)SFX.unlock()}catch(_){ }render(el.id);
              }
            };
            grid.appendChild(b);
          });
          box.appendChild(grid);
          if(u.path){
            var up=document.createElement('div');up.className='v93-up';var cost=u.rank<3?COSTS[u.rank]:0;
            up.innerHTML='<div><b>'+PATHS[u.path].label+' PATH · '+u.rank+'/3</b><div class="sub">'+(u.rank>=3?'MAXED':'Next rank costs ◆ '+cost+' mastery XP.')+'</div></div>';
            var buy=document.createElement('button');buy.type='button';buy.className='btn primary';buy.textContent=u.rank>=3?'MAX':'UPGRADE · ◆ '+cost;buy.disabled=u.rank>=3||Number(mx.xp||0)<cost;
            buy.onclick=function(){if(SAVE0.buySignatureUpgrade&&SAVE0.buySignatureUpgrade(el.id,slt)){try{if(window.SFX&&SFX.unlock)SFX.unlock()}catch(_){ }render(el.id)}};
            up.appendChild(buy);box.appendChild(up);
          }
          holder.appendChild(box);
        })(slot);
      }
      wrap.appendChild(body);detail.appendChild(wrap);
    }

    /* Keep the normal chip/navigation system; only replace the detail area. */
    function hook(){
      if(window.UI&&typeof UI.show==='function'&&!UI.show.__v93Mastery){
        var base=UI.show;
        UI.show=function(id){var out=base.apply(this,arguments);if(id==='scr-mastery'){requestAnimationFrame(function(){render(SAVE0.sel)});setTimeout(function(){render(SAVE0.sel)},80)}return out};
        UI.show.__v93Mastery=true;
      }
      document.addEventListener('click',function(e){
        var chip=e.target&&e.target.closest?e.target.closest('#m-elems .mchip[data-id]'):null;
        if(!chip)return;var id=canonical(chip.dataset.id);if(!owned(id))return;setTimeout(function(){render(id)},0);
      },true);
    }
    hook();
    window.ISO_V93_RENDER_MASTERY=render;
    setTimeout(function(){if(document.getElementById('scr-mastery')&&!document.getElementById('scr-mastery').classList.contains('hidden'))render(SAVE0.sel)},120);
  })();

  /* ---------------------------------------------------------------
     CENTERED SCIENCE SPLASH — preserve Minecraft-style rocking.
     --------------------------------------------------------------- */
  (function centerSplash(){
    function apply(){
      var s=document.getElementById('v93-splash-center-style');
      if(!s){s=document.createElement('style');s.id='v93-splash-center-style';document.head.appendChild(s)}
      s.textContent='#scr-menu #menuleft{align-items:center!important;text-align:center!important}.iso-v88-splash{margin-left:0!important;margin-right:0!important;left:auto!important;right:auto!important;align-self:center!important;display:block!important;text-align:center!important;max-width:92%!important;white-space:normal!important;}';
    }
    apply();
    document.addEventListener('DOMContentLoaded',apply,{once:false});
  })();

  console.log('ISOTOPE V93 ACTIVE: authoritative stat cards, per-ability mastery, centered splash, and helium iframe fix.');
})();
