/* ISOTOPE V36 — EXACT NITROGLYCERIN/LiQUID NITROGEN + SYNTHESIS LAB GATE
 *
 * Nitroglycerin
 *  - Ability 2: exactly three outward charges; each detonates on enemy contact,
 *    damages in a large radius, and burns nearby enemies.
 *  - Ability 3: after activation, exactly the next three normal player shots
 *    become large-radius burning explosive shots.
 *
 * Liquid Nitrogen
 *  - Formula N₂, Combust 0.
 *  - Normal shots shatter on enemy contact into exactly four cryogenic shards;
 *    the original projectile is consumed.
 *  - Ability 1: one cryogenic shattering round.
 *  - Ability 2: three cryogenic outward charges with contact shatter + freeze/slow
 *    burst.
 *  - Ability 3: primes exactly the next three normal player shots for a large
 *    freeze/slow burst plus four outward shards on contact.
 *
 * Synthesis Lab
 *  - Costs 200 ◈ points to unlock the first time.
 *  - Unlock state is stored in the normal SAVE object/exported save JSON.
 */
(function(){
  'use strict';
  if(!window.DATA || !window.SAVE) return;
  var DATA=window.DATA, SAVE=window.SAVE, CORE=window.ISO_V23_CORE;
  if(!CORE) return;

  var NITRO_RX='C+C+C+H+H+H+H+H+N+N+N+O+O+O+O+O+O+O';
  var LN_RX='N+N';
  var NITRO_HUE=12;
  var LN_HUE=195;

  function findByName(name){
    var target=String(name).toLowerCase();
    var vals=Object.values(DATA.MOLDEF||{});
    for(var i=0;i<vals.length;i++){
      var m=vals[i];
      if(m && String(m.name||'').toLowerCase()===target) return m;
    }
    return null;
  }
  function playerElement(p){ return p&&p.elem ? p.elem : (window.RUN&&RUN.el ? RUN.el : null); }
  function currentStats(){
    try{return window.ST||{};}catch(e){return {};} 
  }
  function isName(p,name){
    var el=playerElement(p); return !!(el && new RegExp('^'+name+'$','i').test(String(el.name||'')));
  }
  function setCooldown(p,seconds){
    try{p.activeCd=currentStats().activeCd||seconds||0;}catch(e){p.activeCd=seconds||0;}
    try{if(window.AUDIO&&AUDIO.SFX&&AUDIO.SFX.active)AUDIO.SFX.active();}catch(e){}
    if(window.RUN) RUN.shake=Math.max(RUN.shake||0,8);
  }
  function burnNear(x,y,r,dmg){
    if(!window.RUN||!Array.isArray(RUN.enemies))return;
    RUN.enemies.forEach(function(e){
      if(!e||e.dead)return;
      if(d2(e.x,e.y,x,y)<=Math.pow(r+(e.r||0),2)){
        try{CORE.addBurn(e,Math.max(1,dmg),3.5,NITRO_HUE);}catch(err){}
      }
    });
  }
  function freezeSlowNear(x,y,r,dmg){
    if(!window.RUN||!Array.isArray(RUN.enemies))return;
    RUN.enemies.forEach(function(e){
      if(!e||e.dead)return;
      if(d2(e.x,e.y,x,y)<=Math.pow(r+(e.r||0),2)){
        try{CORE.addFreeze(e,1.35);}catch(err){}
        e.slowT=Math.max(e.slowT||0,2.7);
      }
    });
  }
  function nitroBlast(b,radius,extraBurnRadius){
    if(!window.RUN)return;
    try{CORE.aoe(b.x,b.y,radius,Math.max(1,(b.dmg||1)*.9),NITRO_HUE);}catch(e){}
    burnNear(b.x,b.y,extraBurnRadius||radius*1.18,Math.max(1,(b.dmg||1)*.22));
  }
  function cryoBlast(b,radius){
    if(!window.RUN)return;
    try{CORE.aoe(b.x,b.y,radius,Math.max(1,(b.dmg||1)*.72),LN_HUE);}catch(e){}
    freezeSlowNear(b.x,b.y,radius*1.15,Math.max(1,(b.dmg||1)*.1));
  }
  function spawnCryoShards(b){
    if(!window.RUN)return;
    var st=currentStats(),speed=Number(st.ps)||380;
    var base=Math.atan2(b.vy||0,b.vx||1);
    for(var i=0;i<4;i++){
      var a=base+i*Math.PI/2;
      RUN.bullets.push({
        x:b.x,y:b.y,
        vx:Math.cos(a)*speed*1.15,
        vy:Math.sin(a)*speed*1.15,
        dmg:Math.max(1,(b.dmg||Number(st.dmg)||14)*.34),
        r:4,pierce:0,hit:[],life:.82,owner:b.owner,
        freeze:true,_isoLNShard:true,semanticType:'liquid-nitrogen-shard',hue:LN_HUE
      });
    }
    try{CORE.addFreeze(RUN.enemies.find(function(e){return e&&!e.dead&&d2(e.x,e.y,b.x,b.y)<(e.r+8)*(e.r+8);}),.01);}catch(e){}
  }

  /* ---------- Liquid Nitrogen catalog entry ---------- */
  var ln=findByName('Liquid Nitrogen');
  if(!ln){
    ln={
      token:'LiquidNitrogen',f:'N₂',name:'Liquid Nitrogen',hue:LN_HUE,
      mods:{dmg:.82,rate:1.08,ps:1.12,hp:.92,spd:1.03},
      trait:'chill',desc:'Cryogenic nitrogen that freezes and slows enemies; shots shatter into four shards on contact.',
      rx:'2N → N₂ (liquid)',mol:true,cost:0,combustLv:0
    };
    DATA.MOLDEF[LN_RX]=ln;
    DATA.RECIPES[LN_RX]=LN_RX;
    DATA.realCompoundCount=(DATA.realCompoundCount||0)+1;
  }else{
    ln.f='N₂'; ln.hue=LN_HUE; ln.mol=true; ln.combustLv=0;
    ln.mods=Object.assign({},ln.mods||{},{dmg:.82,rate:1.08,ps:1.12,hp:.92,spd:1.03});
    DATA.MOLDEF[LN_RX]=ln; DATA.RECIPES[LN_RX]=LN_RX;
  }

  function lnBullet(p,a,largeBurst){
    var st=currentStats();
    return {
      x:p.x,y:p.y,
      vx:Math.cos(a)*(Number(st.ps)||380)*1.38,
      vy:Math.sin(a)*(Number(st.ps)||380)*1.38,
      dmg:(Number(st.dmg)||14)*.82,
      r:7,pierce:0,life:1.75,owner:p.id,hit:[],
      freeze:true,_isoLNShatter:true,
      _isoLNCryoBurst:!!largeBurst,
      _isoLNBurstRadius:largeBurst?168:108,
      semanticType:'liquid-nitrogen-round',hue:LN_HUE
    };
  }

  ln.choices=[
    {
      name:'Liquid Nitrogen — Cryogenic Shatter',ic:'❄',slot:0,main:true,cd:5.5,
      desc:'Fires a cryogenic bullet that freezes and slows on impact, then shatters into four shards that shoot outward.' ,
      exec:function(p){if(!window.RUN)return;setCooldown(p,5.5);RUN.bullets.push(lnBullet(p,p.angle||0,false));}
    },
    {
      name:'Liquid Nitrogen — Shatter Chain',ic:'❄️',slot:1,cd:7,
      desc:'Fires three cryogenic bullets outward; each shatters on enemy contact and freezes and slows nearby enemies.',
      exec:function(p){if(!window.RUN)return;setCooldown(p,7);for(var i=-1;i<=1;i++)RUN.bullets.push(lnBullet(p,(p.angle||0)+i*.25,true));}
    },
    {
      name:'Liquid Nitrogen — Three-Step Cryogenic Burst',ic:'🧊',slot:2,cd:8,
      desc:'Primes your next three bullets; each one shatters on contact and creates a large burst that freezes and slows nearby enemies.',
      exec:function(p){setCooldown(p,8);p._v36LNNext=3;try{CORE.ctx().save();CORE.ctx().strokeStyle='hsla('+LN_HUE+',100%,78%,.9)';CORE.ctx().lineWidth=3;CORE.ctx().beginPath();CORE.ctx().arc(p.x,p.y,18,0,Math.PI*2);CORE.ctx().stroke();CORE.ctx().restore();}catch(e){}}
    }
  ];
  ln.signatures=ln.choices; ln.act=ln.choices[0];

  /* ---------- Nitroglycerin exact ability 2 + 3 ---------- */
  var nit=findByName('Nitroglycerin');
  if(nit){
    nit.combustLv=4;
    nit.mods=Object.assign({},nit.mods||{},{hp:.68,dmg:.78,rate:1.04});
    nit.trait='combust';
    nit.desc='Low direct damage, but catches enemies on fire and builds toward volatile combustion.';

    var nit1=nit.choices&&nit.choices[0] ? nit.choices[0] : (nit.act||{});
    nit.choices=[
      Object.assign({},nit1,{
        name:'Nitroglycerin — Gentle Detonation',ic:'💥',slot:0,main:true,cd:5.5,
        desc:'Fires a low-damage explosive round that burns enemies on hit.'
      }),
      {
        name:'Nitroglycerin — Combustion Chain',ic:'🔥',slot:1,cd:7,
        desc:'Fires three combustion bullets outward; each explodes on enemy contact and burns other nearby enemies in a larger radius.',
        exec:function(p){
          if(!window.RUN)return;setCooldown(p,7);
          for(var i=-1;i<=1;i++){
            var b={
              x:p.x,y:p.y,vx:Math.cos((p.angle||0)+i*.25)*(Number(currentStats().ps)||380)*1.32,
              vy:Math.sin((p.angle||0)+i*.25)*(Number(currentStats().ps)||380)*1.32,
              dmg:(Number(currentStats().dmg)||14)*.72,r:7,pierce:0,hit:[],life:1.75,owner:p.id,
              burn:true,_isoNitroExplodeOnHit:true,_isoNitroBlastRadius:148,_isoNitroBurnRadius:182,
              semanticType:'nitroglycerin-combustion-charge',hue:NITRO_HUE
            };
            RUN.bullets.push(b);
          }
        }
      },
      {
        name:'Nitroglycerin — Three-Step Combustion',ic:'♨',slot:2,cd:8,
        desc:'Primes your next three bullets; each one explodes in a large radius and burns nearby enemies on impact.',
        exec:function(p){setCooldown(p,8);p._v36NitroNext=3;}
      }
    ];
    nit.signatures=nit.choices;nit.act=nit.choices[0];
  }

  /* ---------- Exact on-contact explosion/shatter pipeline ---------- */
  var prevApply=CORE.getApplyElemHit();
  if(!window.__ISO_V36_SPECIAL_HIT__){
    window.__ISO_V36_SPECIAL_HIT__=true;
    CORE.setApplyElemHit(function(b,e){
      if(typeof prevApply==='function'){
        try{prevApply(b,e);}catch(err){console.error('V36 previous hit handler',err);}
      }
      if(!b||!e||e.dead)return;

      if(b._isoNitroExplodeOnHit && !b._isoV36Triggered){
        b._isoV36Triggered=true;b.life=0;b.pierce=0;
        nitroBlast(b,Number(b._isoNitroBlastRadius)||148,Number(b._isoNitroBurnRadius)||182);
        return;
      }

      if(b._isoLNShatter && !b._isoV36Triggered){
        b._isoV36Triggered=true;b.life=0;b.pierce=0;
        /* The first enemy receives the cryogenic status from the projectile
           itself; the burst affects nearby enemies as well. */
        try{CORE.addFreeze(e,1.4);}catch(err){}
        e.slowT=Math.max(e.slowT||0,2.7);
        if(b._isoLNCryoBurst)cryoBlast(b,Number(b._isoLNBurstRadius)||168);
        spawnCryoShards(b);
      }
    });
  }

  /* ---------- Next-three normal bullets after Ability 3 ---------- */
  var prevFire=CORE.getFire();
  if(!window.__ISO_V36_FIRE__){
    window.__ISO_V36_FIRE__=true;
    CORE.setFire(function(p){
      var before=window.RUN&&Array.isArray(RUN.bullets)?RUN.bullets.length:0;
      if(typeof prevFire==='function')prevFire(p);
      if(!window.RUN||!Array.isArray(RUN.bullets))return;
      var el=playerElement(p),name=String(el&&el.name||'');
      var isNit=/^Nitroglycerin$/i.test(name),isLN=/^Liquid Nitrogen$/i.test(name);
      for(var i=before;i<RUN.bullets.length;i++){
        var b=RUN.bullets[i];if(!b||!b.main||b.owner!==p.id)continue;
        if(isNit){
          if((p._v36NitroNext||0)>0){
            b._isoNitroExplodeOnHit=true;b._isoNitroBlastRadius=172;b._isoNitroBurnRadius=198;
            b.burn=true;b.hue=NITRO_HUE;b.pierce=0;p._v36NitroNext--;
          }
        }else if(isLN){
          /* Every normal Liquid Nitrogen shot shatters on contact. */
          b._isoLNShatter=true;b.freeze=true;b.hue=LN_HUE;
          if((p._v36LNNext||0)>0){
            b._isoLNCryoBurst=true;b._isoLNBurstRadius=172;b._isoLNCryoBurst=true;
            p._v36LNNext--;
          }
        }
      }
    });
  }

  /* ---------- Exact special stat values in the FULL STATS panel ---------- */
  if(typeof window.ISO_NS==='function' && !window.__ISO_V36_NS__){
    window.__ISO_V36_NS__=true;
    var oldNS=window.ISO_NS;
    window.ISO_NS=function(el){
      var o=oldNS(el)||{};
      var name=String(el&&el.name||'');
      if(/^Nitroglycerin$/i.test(name))o.combust=4;
      if(/^Liquid Nitrogen$/i.test(name))o.combust=0;
      return o;
    };
  }

  /* Also force the live combat stat so the value is not just cosmetic. */
  if(!window.__ISO_V36_COMPUTE__){
    window.__ISO_V36_COMPUTE__=true;
    var prevCompute=CORE.getComputeStats();
    CORE.setComputeStats(function(){
      if(typeof prevCompute==='function')prevCompute();
      if(!window.RUN||!window.ST)return;
      var name=String(RUN.el&&RUN.el.name||'');
      if(/^Nitroglycerin$/i.test(name))ST.combust=4;
      if(/^Liquid Nitrogen$/i.test(name))ST.combust=0;
    });
  }

  /* ---------- Synthesis Lab: 200-point first unlock, saved persistently ---------- */
  if(SAVE.raw.synthesisLabUnlocked===undefined){
    SAVE.raw.synthesisLabUnlocked=false;
    SAVE.save();
  }
  var LAB_COST=200;
  function labUnlocked(){return SAVE.raw.synthesisLabUnlocked===true;}
  function refreshLabButton(){
    var b=document.querySelector('[data-go="scr-lab"]');
    if(!b)return;
    b.innerHTML=labUnlocked()
      ? 'SYNTHESIS LAB<small>real chemistry · unlocked</small>'
      : 'SYNTHESIS LAB<small>🔒 '+LAB_COST+' POINTS TO UNLOCK</small>';
  }
  function labToast(msg,cls){try{if(window.UI&&UI.toast)UI.toast(msg,cls||'');}catch(e){}}
  function unlockLab(){
    if(labUnlocked())return true;
    if(Number(SAVE.coins||0)<LAB_COST){
      try{if(window.AUDIO&&AUDIO.SFX&&AUDIO.SFX.error)AUDIO.SFX.error();}catch(e){}
      labToast('SYNTHESIS LAB LOCKED · NEED '+LAB_COST+' POINTS','bad');
      return false;
    }
    if(!SAVE.spend(LAB_COST))return false;
    SAVE.raw.synthesisLabUnlocked=true;
    SAVE.save();
    try{if(window.AUDIO&&AUDIO.SFX&&AUDIO.SFX.unlock)AUDIO.SFX.unlock();}catch(e){}
    labToast('SYNTHESIS LAB UNLOCKED · -'+LAB_COST+' POINTS','good');
    refreshLabButton();
    return true;
  }
  SAVE.unlockSynthesisLab=function(){return unlockLab();};
  SAVE.isSynthesisLabUnlocked=function(){return labUnlocked();};

  /* The UI's internal `show()` is private, so guard its menu button during the
     capture phase. This prevents the lab from opening unless purchased. */
  document.addEventListener('click',function(ev){
    var b=ev.target&&ev.target.closest?ev.target.closest('[data-go="scr-lab"]'):null;
    if(!b)return;
    if(labUnlocked())return;
    ev.preventDefault();ev.stopImmediatePropagation();
    if(unlockLab() && window.UI&&UI.show)UI.show('scr-lab');
  },true);

  var oldShow=window.UI&&UI.show;
  if(typeof oldShow==='function'&&!window.__ISO_V36_LAB_SHOW__){
    window.__ISO_V36_LAB_SHOW__=true;
    UI.show=function(id){
      if(id==='scr-lab'&&!labUnlocked()){
        if(unlockLab())return oldShow.call(this,'scr-lab');
        return;
      }
      return oldShow.apply(this,arguments);
    };
  }

  /* Keep direct DOM/programmatic attempts from exposing the screen while locked. */
  var lab=document.getElementById('scr-lab');
  if(lab){
    var obs=new MutationObserver(function(){
      if(!labUnlocked()&&!lab.classList.contains('hidden')){
        lab.classList.add('hidden');
        labToast('SYNTHESIS LAB LOCKED · BUY IT FOR '+LAB_COST+' POINTS','bad');
      }
    });
    obs.observe(lab,{attributes:true,attributeFilter:['class']});
  }

  refreshLabButton();
  setTimeout(refreshLabButton,200);
  setTimeout(refreshLabButton,800);

  console.log('ISOTOPE V36: exact Nitro 2/3, Liquid Nitrogen N2 shatter/freeze kit, and 200-point persistent Synthesis Lab unlock active.');
})();
