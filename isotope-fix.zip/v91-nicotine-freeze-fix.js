/* ISOTOPE V91 — NICOTINE FREEZE FIX
 * Final nicotine runtime for the current build.
 *
 * Root cause addressed:
 *   Earlier versions had several independent Nicotine implementations active at
 *   once (V20/V26/V28/V52/V60/V84). Different versions used RUN.allies,
 *   RUN._v29Allies, RUN.bullets, and several charm queues. A single cast could
 *   therefore enter more than one conversion/collision path, and Ability 3 could
 *   synchronously convert many enemies while firing one audio cue per enemy.
 *
 * V91 keeps the current gameplay, but makes ONE canonical nicotine path:
 *   - Ability 1 uses a tiny isolated projectile queue.
 *   - Ability 2 converts one nearby non-boss enemy into the dedicated V52 ally list.
 *   - Ability 3 queues nearby conversions and commits at most 4 per simulation frame.
 *   - Converted allies live in RUN._v29Allies, so the newer RUN.allies AI layers
 *     cannot process the same ally a second time.
 *   - Legacy nicotine queues are drained before/after the real update.
 *   - Only one activation sound is played per cast, never once per enemy.
 */
(function(){
  'use strict';
  if(window.__ISO_V91_NICOTINE_FREEZE_FIX__)return;
  window.__ISO_V91_NICOTINE_FREEZE_FIX__=true;

  var CORE=window.ISO_V23_CORE||{};
  var MAX_ALLIES=40;
  var A3_PER_FRAME=4;

  function run(){return window.RUN||null;}
  function d2(ax,ay,bx,by){var dx=ax-bx,dy=ay-by;return dx*dx+dy*dy;}
  function isNicoPlayer(p){
    var e=p&&p.elem,n=String(e&&e.name||e&&e.token||'').toLowerCase();
    return !!(e&&e.mol&&(n==='nicotine'||n.indexOf('nicotine')>=0));
  }
  function owner(id){
    var r=run();
    if(!r||!Array.isArray(r.players))return null;
    return r.players.find(function(p){return p&&p.id===id;})||r.players[0]||null;
  }
  function hueFor(id){var p=owner(id),e=p&&p.elem;return e&&Number.isFinite(+e.hue)?+e.hue:145;}
  function hostiles(r){
    return (r&&Array.isArray(r.enemies)?r.enemies:[]).filter(function(e){
      return e&&!e.dead&&!e.boss&&!e.befriended&&e.team!=='player';
    });
  }
  function safeSfx(){try{if(window.SFX&&SFX.active)SFX.active();}catch(_){} }
  function safeRing(x,y,h,r){try{if(window.ringFx)ringFx(x,y,h,r);}catch(_){} }
  function safeBurst(x,y,h){try{if(window.fxBurst)fxBurst(x,y,h,18);else if(window.burst)burst(x,y,h);}catch(_){} }

  function ensure(r){
    r._v29Allies=Array.isArray(r._v29Allies)?r._v29Allies:[];
    r._isoV91NicoA1=Array.isArray(r._isoV91NicoA1)?r._isoV91NicoA1:[];
    r._isoV91NicoQueue=Array.isArray(r._isoV91NicoQueue)?r._isoV91NicoQueue:[];
    r._isoV91NicoQueued= r._isoV91NicoQueued || Object.create(null);
  }

  function migrateLegacyRunAllies(r){
    if(!r||r._isoV91MigratedAllies)return;
    ensure(r);
    var legacy=Array.isArray(r.allies)?r.allies:[];
    var keep=[];
    for(var i=0;i<legacy.length;i++){
      var a=legacy[i];
      if(a&&a.befriended&&a.team==='player'&&a.nicotineAlly){
        if(r._v29Allies.length<MAX_ALLIES){
          a.playerHue=Number.isFinite(+a.playerHue)?+a.playerHue:hueFor(a.ownerId);
          a.hue=a.playerHue;a.permanent=true;a.decay=Infinity;a.decayT=Infinity;
          r._v29Allies.push(a);
        }
      }else keep.push(a);
    }
    if(Array.isArray(r.allies))r.allies=keep;
    r._isoV91MigratedAllies=true;
  }

  function convert(e,ownerId){
    var r=run();
    if(!r||!e||e.dead||e.boss||e.befriended||e.team==='player')return null;
    ensure(r);
    if(r._v29Allies.length>=MAX_ALLIES)return null;
    var key=String(e.eid!=null?e.eid:('enemy_'+Math.round(e.x)+'_'+Math.round(e.y)+'_'+Math.round(e.maxhp||0)));
    if(r._isoV91NicoQueued[key]||e._isoV91Converted)return null;

    var p=owner(ownerId),ph=hueFor(ownerId),maxhp=Math.max(1,Number(e.maxhp)||Number(e.hp)||20);
    var a={
      eid:e.eid,sourceEid:e.eid,sourceType:e.type||'mote',type:e.type||'mote',
      name:e.name||((window.DATA&&DATA.ETYPES&&DATA.ETYPES[e.type]&&DATA.ETYPES[e.type].name)||e.type||'ALLY'),
      x:Number(e.x)||0,y:Number(e.y)||0,r:Math.max(7,Number(e.r)||10),
      hp:Math.max(1,Math.min(maxhp,Number(e.hp)||maxhp*.72)),maxhp:maxhp,
      spd:Math.max(55,Number(e.spd)||100),dmg:Math.max(1,Number(e.dmg)||10),
      hue:ph,playerHue:ph,ownerId:p?p.id:ownerId,team:'player',befriended:true,
      permanent:true,nicotineAlly:true,incomingMul:.5,
      shootT:Math.max(.15,Number(e.shootT)||.7),specialT:Math.max(.4,Number(e.specialT)||1.4),
      healT:Math.max(.5,Number(e.healT)||1.8),orb:Number(e.orb)||Math.random()*Math.PI*2,
      charge:0,chargeT:Math.max(.5,Number(e.chgT)||2.5),targetEid:0,pickupT:0,hurtT:0,
      special:e.special||null,pat:e.pat||null,fast:!!e.fast,canCharge:!!e.canCharge,
      shape:e.shape||'dot',seed:e.seed||0,elite:!!e.elite,aiRole:e.aiRole||'melee',
      decay:Infinity,decayT:Infinity,_v91:true
    };

    /* Mark and remove the hostile BEFORE adding any visual or other side effects. */
    e._isoV91Converted=true;e._befriended=true;e.befriended=true;e.team='player';e.dead=true;
    e._removedFromEnemyTeam=true;
    e._nicotineFriend=false;e._nicotineFriendT=0;e._nicotineOwner=null;e._nicotineDebuff=false;
    r._v29Allies.push(a);
    delete r._isoV91NicoQueued[key];
    return a;
  }

  function enqueue(r,e,ownerId){
    if(!r||!e||e.dead||e.boss||e.befriended||e.team==='player')return false;
    ensure(r);
    var key=String(e.eid!=null?e.eid:('enemy_'+Math.round(e.x)+'_'+Math.round(e.y)+'_'+Math.round(e.maxhp||0)));
    if(r._isoV91NicoQueued[key])return false;
    if(r._v29Allies.length+r._isoV91NicoQueue.length>=MAX_ALLIES)return false;
    r._isoV91NicoQueued[key]=ownerId;
    r._isoV91NicoQueue.push({e:e,owner:ownerId,key:key});
    return true;
  }

  function processQueue(r){
    if(!r||!r._isoV91NicoQueue)return;
    var done=0;
    while(done<A3_PER_FRAME&&r._isoV91NicoQueue.length){
      var q=r._isoV91NicoQueue.shift();
      if(!q){done++;continue;}
      var e=q.e;
      if(e&&!e.dead&&!e.boss&&!e.befriended&&e.team!=='player')convert(e,q.owner);
      else delete r._isoV91NicoQueued[q.key];
      done++;
    }
  }

  function stepA1(dt){
    var r=run();if(!r||!Array.isArray(r._isoV91NicoA1))return;
    if(r.isOnline&&window.NET&&NET.isHost===false)return;
    var arr=r._isoV91NicoA1;
    var hs=hostiles(r);
    for(var i=arr.length-1;i>=0;i--){
      var b=arr[i];
      if(!b){arr.splice(i,1);continue;}
      b.life-=dt;
      var px=b.x,py=b.y;
      b.x+=b.vx*dt;b.y+=b.vy*dt;
      if(b.life<=0||b.x<-120||b.x>(Number(window.W)||1280)+120||b.y<-120||b.y>(Number(window.H)||720)+120){arr.splice(i,1);continue;}
      var hit=null;
      for(var j=0;j<hs.length;j++){
        var e=hs[j];if(!e||e.dead||e.boss||e.befriended||e.team==='player')continue;
        var rr=(b.r+Math.max(8,Number(e.r)||10));
        var vx=b.x-px,vy=b.y-py,ww=e.x-px,wy=e.y-py,vv=vx*vx+vy*vy,t=vv?Math.max(0,Math.min(1,(ww*vx+wy*vy)/vv)):0;
        var qx=px+vx*t,qy=py+vy*t,dx=e.x-qx,dy=e.y-qy;
        if(dx*dx+dy*dy<=rr*rr){hit=e;break;}
      }
      if(hit){
        arr.splice(i,1);
        var a=convert(hit,b.owner);
        if(a){safeRing(a.x,a.y,b.hue,120);safeBurst(a.x,a.y,b.hue);}
      }
    }
  }

  function useNico(p,slot){
    var r=run();if(!r||!p||p.downed)return false;
    ensure(r);migrateLegacyRunAllies(r);
    if((p.activeCd||0)>0)return false;
    var el=p.elem||r.el,h=Number(el&&el.hue)||145,st=window.ST||{};
    p.activeCd=Math.max(.1,Number(st.activeCd)||7);
    safeSfx();

    if(slot===0){
      if(r._isoV91NicoA1.length>=1)return false;
      var ang=Number(p.angle)||0,spd=Math.max(900,(Number(st.ps)||380)*2.35),x=p.x+Math.cos(ang)*28,y=p.y+Math.sin(ang)*28;
      r._isoV91NicoA1.push({x:x,y:y,vx:Math.cos(ang)*spd,vy:Math.sin(ang)*spd,r:18,life:1.15,owner:p.id,hue:h});
      safeRing(p.x,p.y,h,64);return true;
    }

    var hs=hostiles(r);
    if(slot===1){
      var best=null,bd=Infinity;
      for(var i=0;i<hs.length;i++){var dd=d2(p.x,p.y,hs[i].x,hs[i].y);if(dd<bd){bd=dd;best=hs[i];}}
      if(best)convert(best,p.id);
      return true;
    }

    var radius=Math.min(Number(window.W)||1280,Number(window.H)||720)*.25,r2=radius*radius,count=0;
    for(var j=0;j<hs.length;j++)if(d2(p.x,p.y,hs[j].x,hs[j].y)<=r2)if(enqueue(r,hs[j],p.id))count++;
    r._isoV91NicoAura={x:p.x,y:p.y,r:radius,t:.34};
    safeRing(p.x,p.y,h,radius);
    if(r.texts&&count)r.texts.push({x:p.x,y:p.y-30,t:.7,life:.7,s:count+' RECEPTORS',big:false,col:'#7ef0a6'});
    return true;
  }

  function cleanup(r){
    if(!r)return;
    ensure(r);migrateLegacyRunAllies(r);
    /* Historical routes must stay empty so an old wrapper cannot process a new cast. */
    if(Array.isArray(r._v29CharmShots))r._v29CharmShots.length=0;
    if(Array.isArray(r._v28CharmShots))r._v28CharmShots.length=0;
    if(Array.isArray(r._v84CharmShots))r._v84CharmShots.length=0;
    if(Array.isArray(r._isoV60NicoA1))r._isoV60NicoA1.length=0;
    if(Array.isArray(r._isoV53NicoRounds))r._isoV53NicoRounds.length=0;
    r.bullets=(r.bullets||[]).filter(function(b){
      return !(b&&((b._v26NicoCharm)||(b._v27NicoCharm)||(b._v28Charm)||b.semanticType==='nicotine-recruiting-dart'));
    });
    /* Never leave queued targets around after a run ends. */
    if(r.state==='over'){r._isoV91NicoQueue.length=0;r._isoV91NicoQueued=Object.create(null);r._isoV91NicoA1.length=0;}
  }

  /* Final ability dispatcher: all Nicotine slots now share this bounded path. */
  var getUse=CORE.getUseActive,setUse=CORE.setUseActive;
  var baseUse=(typeof getUse==='function'?getUse():window.useActive);
  if(typeof baseUse==='function'){
    var wrappedUse=function(p){
      if(isNicoPlayer(p)){
        var slot=Math.max(0,Math.min(2,Number(p.signatureSlot)||0));
        return useNico(p,slot);
      }
      return baseUse.apply(this,arguments);
    };
    wrappedUse.__isoV91NicotineUse=true;
    if(typeof setUse==='function')setUse(wrappedUse);
    window.useActive=wrappedUse;
    try{useActive=wrappedUse;}catch(_){ }
  }
  window.ISO_NICOTINE_USE=function(p,slot){if(isNicoPlayer(p))return useNico(p,Math.max(0,Math.min(2,Number(slot)||0)));return false;};

  /* One authoritative update wrapper. Nicotine conversion work is bounded and
     the legacy queues are emptied before the old layers have a chance to see them. */
  var getUpdate=CORE.getUpdate;
  var baseUpdate=typeof getUpdate==='function'?getUpdate():window.update;
  if(typeof baseUpdate==='function'){
    var wrappedUpdate=function(dt){
      var r=run();
      cleanup(r);
      processQueue(r);
      var out;
      try{out=baseUpdate.apply(this,arguments);}finally{
        r=run();
        stepA1(Number(dt)||0);
        var af=r&&r._isoV91NicoAura;
        if(r&&af){af.t-=Number(dt)||0;if(af.t<=0)delete r._isoV91NicoAura;}
        cleanup(r);
      }
      return out;
    };
    wrappedUpdate.__isoV91NicotineUpdate=true;
    if(typeof CORE.setUpdate==='function')CORE.setUpdate(wrappedUpdate);
    window.update=wrappedUpdate;
    try{update=wrappedUpdate;}catch(_){ }
  }

  /* Keep the new isolated A1 visual lightweight and draw it outside the generic bullet renderer. */
  var getRender=CORE.getRender;
  var baseRender=typeof getRender==='function'?getRender():window.render;
  if(typeof baseRender==='function'){
    var wrappedRender=function(){
      var out=baseRender.apply(this,arguments),r=run();
      if(!r)return out;
      if(Array.isArray(r._isoV91NicoA1))r._isoV91NicoA1.forEach(function(b){
        try{
          var c=window.cx|| (window.CORE&&CORE.ctx&&CORE.ctx());if(!c)return;
          var ang=Math.atan2(b.vy,b.vx),al=Math.max(.1,Math.min(1,b.life/1.15));
          c.save();c.lineCap='round';c.shadowBlur=18;c.shadowColor='hsla('+b.hue+',100%,70%,'+(0.6*al)+')';c.strokeStyle='hsla('+b.hue+',100%,66%,'+(0.92*al)+')';c.lineWidth=12;
          c.beginPath();c.moveTo(b.x-Math.cos(ang)*42,b.y-Math.sin(ang)*42);c.lineTo(b.x,b.y);c.stroke();c.restore();
        }catch(_){ }
      });
      var af=r._isoV91NicoAura;
      if(af)try{var c2=window.cx|| (window.CORE&&CORE.ctx&&CORE.ctx());if(c2){c2.save();c2.strokeStyle='rgba(126,240,166,'+Math.max(0,af.t/.34)+')';c2.lineWidth=3;c2.beginPath();c2.arc(af.x,af.y,af.r*(1-(af.t/.34)*.08),0,Math.PI*2);c2.stroke();c2.restore();}}catch(_){ }
      return out;
    };
    wrappedRender.__isoV91NicotineRender=true;
    if(typeof CORE.setRender==='function')CORE.setRender(wrappedRender);
    window.render=wrappedRender;
    try{render=wrappedRender;}catch(_){ }
  }

  console.log('ISOTOPE V91 NICOTINE FREEZE FIX active: canonical bounded conversion queue, dedicated ally container, legacy queue isolation, one SFX per cast, and non-reentrant update path.');
})();
