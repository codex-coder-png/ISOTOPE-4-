/* ============================================================================
 * ISOTOPE V24 - ELEMENT SLOT 2 DESCRIPTION CONTRACTS
 *
 * This file owns ONLY the SECOND ability (slot index 1 / "Ability 2") for the
 * 118 base elements.  Slot 1 and slot 3 are deliberately untouched here.
 * Every entry keeps its existing name + description, but receives its own
 * parameter set so the runtime behavior follows that description instead of
 * falling back to a copied category move.
 * ========================================================================== */
'use strict';
(function(){
  if(window.__ISO_ELEMENT_SECOND_V24__) return;
  window.__ISO_ELEMENT_SECOND_V24__=true;

  var TAU2=Math.PI*2;
  function R(){return window.RUN||null;}
  function S(){return window.ST||{};}
  function live(){var r=R();return r&&Array.isArray(r.enemies)?r.enemies.filter(function(e){return e&&!e.dead;}):[];}
  function d2(x1,y1,x2,y2){var dx=x1-x2,dy=y1-y2;return dx*dx+dy*dy;}
  function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
  function hue(n){
    try{var e=DATA&&DATA.ELEMS&&DATA.ELEMS['e'+n]; if(e&&Number.isFinite(+e.hue))return +e.hue;}
    catch(_e){}
    return (n*29)%360;
  }
  function mult(p,m){return (S().dmg||14)*m*(p&&p.puDamage||1);}
  function nearest(p){
    var es=live(),best=null,bd=Infinity;
    for(var i=0;i<es.length;i++){var q=d2(es[i].x,es[i].y,p.x,p.y);if(q<bd){bd=q;best=es[i];}}
    return best;
  }
  function atAim(p,dist){
    var W0=window.W||1200,H0=window.H||800,a=p.angle||0;
    return {x:clamp(p.x+Math.cos(a)*dist,24,W0-24),y:clamp(p.y+Math.sin(a)*dist,24,H0-24)};
  }
  function flash(x,y,h,r){
    var r0=R();if(!r0)return;
    if(typeof ringFx==='function')ringFx(x,y,h,r||100,8);
    if(Array.isArray(r0.parts)){
      for(var i=0;i<Math.min(22,8+((r||100)/18));i++){
        var a=Math.random()*TAU2,sp=70+Math.random()*240;
        r0.parts.push({x:x,y:y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,t:.32,life:.32,hue:h,r:1.5+Math.random()*3.2});
      }
    }
  }
  function dmg(e,d){if(!e||e.dead)return;if(typeof dmgEnemy==='function')dmgEnemy(e,d,{quiet:true});}
  function status(e,kind,dur,amount){
    if(!e||e.dead)return;
    if(kind==='burn'&&typeof addBurn==='function')addBurn(e,amount||mult({puDamage:1},.35)*.25,dur||4);
    else if(kind==='poison'&&typeof addPoison==='function')addPoison(e,amount||mult({puDamage:1},.35)*.3,dur||4);
    else if(kind==='corrode'&&typeof addCorrode==='function')addCorrode(e,dur||4,.55);
    else if(kind==='rust'&&typeof addRust==='function')addRust(e,dur||4,.86);
    else if(kind==='freeze'&&typeof addFreeze==='function')addFreeze(e,dur||1.2);
    else if(kind==='shock'&&typeof addShock==='function')addShock(e,dur||1.5);
    else if(kind==='brittle'&&typeof addBrittle==='function')addBrittle(e,dur||4);
    else if(kind==='drenched'&&typeof addDrenched==='function')addDrenched(e,dur||4);
    else if(kind==='slow')e.slowT=Math.max(e.slowT||0,dur||3);
    else if(kind==='stun')e.stun=Math.max(e.stun||0,dur||1);
    else if(kind==='confuse')e.conf=Math.max(e.conf||0,dur||2);
    else if(kind==='mark')e.mark=Math.max(e.mark||0,dur||6);
    else if(kind==='weaken')e.v24WeakenT=Math.max(e.v24WeakenT||0,dur||4);
    else if(kind==='root')e.v24RootT=Math.max(e.v24RootT||0,dur||2.5);
  }
  function hitNear(x,y,r,d,st,h,opts){
    var es=live(),rr=r*r;
    for(var i=0;i<es.length;i++){
      var e=es[i]; if(d2(x,y,e.x,e.y)>(r+e.r)*(r+e.r))continue;
      if(d>0)dmg(e,d);
      if(st)status(e,st,opts&&opts.statusTime,opts&&opts.statusAmount);
      if(opts&&opts.extra)opts.extra(e);
    }
    flash(x,y,h,r);
  }
  function line(p,len,w,d,st,h){
    if(typeof hitLine==='function')hitLine(p.x,p.y,p.angle||0,len,w,d,h,st==='confuse'?'conf':st);
    else hitNear(p.x+Math.cos(p.angle||0)*len*.5,p.y+Math.sin(p.angle||0)*len*.5,w,d,st,h);
  }
  function fire(p,opts){
    if(typeof bullet==='function')return bullet(p,opts);
    if(typeof shootBullet==='function'){
      var o=Object.assign({},opts,{d:opts.d==null?mult(p,1):opts.d});
      return shootBullet(p,o);
    }
    var r=R();if(!r||!r.bullets)return null;
    var a=opts.a==null?(p.angle||0):opts.a,sp=opts.sp||S().ps||360;
    var b={x:p.x,y:p.y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,dmg:opts.d||mult(p,1),r:opts.r||5,pierce:opts.pierce||0,hit:[],life:opts.life||1.5,owner:p.id};
    Object.keys(opts).forEach(function(k){if(k!=='a'&&k!=='sp'&&k!=='d'&&k!=='r'&&k!=='pierce'&&k!=='life')b[k]=opts[k];});
    r.bullets.push(b);return b;
  }
  function fan(p,n,spread,opts){for(var i=0;i<n;i++)fire(p,Object.assign({},opts,{a:(p.angle||0)+(n===1?0:(i/(n-1)-.5)*spread)}));}
  function shield(p,amt,ifr){
    p.sh=Math.min((S().shieldMax||90)+amt,(p.sh||0)+amt);
    if(ifr)p.iframes=Math.max(p.iframes||0,ifr);
    flash(p.x,p.y,hue(p.elem&&p.elem.n||0),95);
  }
  function buff(p,kind,value,time){
    if(kind==='damage')p.puDamage=Math.max(p.puDamage||1,value);
    if(kind==='rate')p.puRate=Math.max(p.puRate||1,value);
    if(kind==='speed')p.adrenT=Math.max(p.adrenT||0,time||4);
    if(kind==='armor')p.puArmor=Math.max(p.puArmor||0,value);
    if(kind==='crit')p.puCrit=1;
    p.puTimer=Math.max(p.puTimer||0,time||5);
    flash(p.x,p.y,hue(p.elem&&p.elem.n||0),88);
  }
  function zone(spec,p){
    var r=R();if(!r)return;
    r.v24SecondZones=r.v24SecondZones||[];
    var q=spec.anchor==='player'?{x:p.x,y:p.y}:atAim(p,spec.distance||180);
    r.v24SecondZones.push({x:q.x,y:q.y,r:spec.r||140,t:spec.t||4.5,dt:.18,dmg:mult(p,spec.dmgMult||.25),status:spec.status||null,status2:spec.status2||null,owner:p.id,h:hue(p.elem&&p.elem.n||0),pull:spec.pull||0,slowProjectiles:!!spec.slowProjectiles,healPlayer:!!spec.healPlayer,shield:spec.shield||0,beam:!!spec.beam});
    flash(q.x,q.y,hue(p.elem&&p.elem.n||0),spec.r||140);
  }
  function explosion(p,x,y,delay,radius,mul,statusKind){
    var r=R(),h=hue(p.elem&&p.elem.n||0);if(!r)return;
    r.v24SecondFuses.push({x:x,y:y,t:delay,life:delay,r:radius,dmg:mult(p,mul||2.2),status:statusKind||null,h:h});
    flash(x,y,h,radius*.35);
  }
  function clearEnemyShots(p,radius){
    var r=R();if(!r||!Array.isArray(r.ebullets))return 0;var cut=radius*radius,count=0;
    r.ebullets=r.ebullets.filter(function(b){if(d2(b.x,b.y,p.x,p.y)<=cut){count++;return false;}return true;});
    return count;
  }
  function revealAll(duration){
    var es=live();for(var i=0;i<es.length;i++){es[i].v24RevealT=Math.max(es[i].v24RevealT||0,duration||5);if(es[i].type==='ghost')es[i].invuln=false;}
  }

  /* Each descriptor below corresponds to the currently displayed Ability 2.
     The runner supports distinct mechanics; parameters are intentionally
     different for every element. */
  var SPEC={
    1:{k:'beam',len:560,w:20,m:2.7,st:'burn',flash:130},
    2:{k:'lift',count:4,dist:150,r:170,st:'stun',root:2.6},
    3:{k:'buff',damage:1.4,rate:1.75,speed:4,shield:20},
    4:{k:'reflect',r:190,damage:1.35,crit:1.25},
    5:{k:'absorb',r:190,shieldPer:10,root:0},
    6:{k:'web',r:155,t:5.2,slow:5.2,root:2.2,st:'bleed'},
    7:{k:'cascade',bursts:3,r:145,m:1.75,st:'burn'},
    8:{k:'arcPulse',pulses:4,r:175,m:1.5,st:'shock'},
    9:{k:'beamTrail',len:500,w:17,m:2.35,st:'corrode',trail:4},
    10:{k:'flash',r:340,st:'stun',clear:9999},
    11:{k:'pool',r:185,t:5.5,m:.45,st:'corrode',st2:'slow'},
    12:{k:'ribbon',count:7,spread:.65,m:2.15,st:'burn'},
    13:{k:'plating',shield:36,speed:1.45,armor:.25,time:6},
    14:{k:'chain',m:2.05,jumps:7,range:190,st:'shock'},
    15:{k:'smoke',r:210,t:5,st:'confuse',revealOwner:false},
    16:{k:'geyser',r:130,m:2.1,fan:9,st:'burn'},
    17:{k:'bleach',r:250,m:.9,st:'poison',strip:true,corrode:true},
    18:{k:'purge',shield:34,healStatus:true,r:185,st:'none'},
    19:{k:'surge',speed:5,rate:1.55,dash:1.4,reload:1},
    20:{k:'carapace',ifr:2.2,thorns:1.8,shield:18,time:4.5},
    21:{k:'spear',m:3.8,pierce:20,sp:900,r:5},
    22:{k:'radialShards',count:24,m:1.15,pierce:8,st:'corrode'},
    23:{k:'redox',shield:42,st:'shock',r:190,m:1.45},
    24:{k:'mirrorBeam',len:520,w:15,m:2.2,st:'mark',reflect:2},
    25:{k:'oxidizer',r:230,m:1.1,corrode:6,accelerate:true},
    26:{k:'shrapnelCannon',m:4.0,pierce:12,sp:430,split:5,st:'rust'},
    27:{k:'radiationPulse',r:250,m:.85,radDps:.32,t:6},
    28:{k:'shapeMemory',heal:.28,dodge:4.5,time:6},
    29:{k:'whip',len:330,w:80,m:2.4,st:'shock'},
    30:{k:'mantle',r:105,st:'shock',retaliate:2.2,time:7},
    31:{k:'galliumDart',m:3.4,sp:980,pierce:30,r:5,st:'mark'},
    32:{k:'infrared',len:440,w:42,m:2.0,st:'mark',burn:true},
    33:{k:'toxicHaze',r:220,t:5.5,st:'poison',slow:4,rateSlow:.45},
    34:{k:'seekMarked',count:6,m:1.8,sp:760,hom:true,st:'burn'},
    35:{k:'acidSplash',r:240,m:1.1,st:'corrode',st2:'rust'},
    36:{k:'kryptonPulse',r:245,m:.8,st:'slow',slow:.7,stripShield:true},
    37:{k:'ignition',bursts:7,r:100,m:1.05,st:'burn'},
    38:{k:'rocketBarrage',count:8,m:1.55,hom:true,st:'burn'},
    39:{k:'yag',len:650,w:10,m:4.4,pierce:99,st:'corrode'},
    40:{k:'zirconia',shield:45,armor:.75,knockRes:true,time:5},
    41:{k:'pin',r:260,t:3.2,st:'root'},
    42:{k:'crucible',r:210,t:5.5,m:.42,st:'burn',deleteEnemyShots:true},
    43:{k:'tracer',r:520,st:'mark',critD:1.6,reveal:7},
    44:{k:'needleRain',count:14,m:1.9,pierce:18,st:'rust',sp:740},
    45:{k:'luster',shield:32,clearStatus:true,antiDebuff:6},
    46:{k:'purge',shield:38,healStatus:false,r:200,convertToxic:true},
    47:{k:'cleanse',shield:0,clearStatus:true,r:240,m:1.8,st:'shock'},
    48:{k:'controlRods',r:230,t:5.2,deleteEnemyShots:true,st:'slow',rateSlow:.5},
    49:{k:'conductiveScreen',shield:26,reflect:2,vel:1.7,time:6},
    50:{k:'tinPest',r:260,st:'rust',m:.75,armorShred:0.8},
    51:{k:'stibnite',count:12,m:1.65,pierce:10,st:'brittle',sp:720},
    52:{k:'cooler',r:230,t:4.5,st:'freeze',clearEnemyShots:true},
    53:{k:'iodineCloud',r:250,t:4.8,m:.32,st:'poison'},
    54:{k:'thruster',dash:330,m:2.0,cone:130,st:'burn'},
    55:{k:'atomicClock',crit:true,bulletSpeed:1600,time:5.5},
    56:{k:'bariumFlame',r:190,t:5,m:.55,st:'burn',corrode:.4},
    57:{k:'sparkShower',count:22,m:.72,st:'burn',chain:true},
    58:{k:'ceriaGrind',count:18,m:.65,pierce:8,st:'corrode'},
    59:{k:'eyeFilter',immuneBlind:true,reveal:7},
    60:{k:'gaussBolt',m:4.1,sp:1100,pierce:22,pull:120},
    61:{k:'radiantAura',r:220,t:6,m:.24,radDps:.24,reveal:999},
    62:{k:'magnetron',r:260,m:1.15,st:'stun',disarm:4,pull:55},
    63:{k:'uvFlash',r:300,st:'confuse',clearEnemyShots:true},
    64:{k:'magnoFreeze',r:260,m:.8,st:'freeze'},
    65:{k:'soundwave',r:280,m:1.3,st:'brittle',shieldBreak:true},
    66:{k:'laserRod',len:560,w:15,m:3.3,pierce:40,st:'corrode'},
    67:{k:'scalpel',len:700,w:6,m:5.0,pierce:99,st:'bleed'},
    68:{k:'opticalAmplifier',damage:1.5,vel:1.5,time:6,allPlayers:true},
    69:{k:'xray',len:820,w:9,m:2.8,pierce:99,st:'radiation',reveal:10},
    70:{k:'atomicLaser',rate:2.1,time:6,beam:true},
    71:{k:'scintillator',r:260,shieldPer:9,deleteEnemyShots:true},
    72:{k:'neutronShield',shield:50,armor:.65,damage:1.45,time:6,antiBlast:true},
    73:{k:'capacitor',len:420,w:55,m:2.5,st:'shock'},
    74:{k:'penetrator',m:5.2,pierce:99,sp:620,r:9,kb:4.5},
    75:{k:'turbine',r:145,t:5.5,m:.78,st:'burn',speed:1.2},
    76:{k:'fumes',r:250,t:5,m:.26,st:'poison',st2:'confuse'},
    77:{k:'meteor',distance:260,delay:.85,r:240,m:4.2,st:'stun'},
    78:{k:'cisplatin',r:220,m:.65,st:'poison',mark:true},
    79:{k:'goldLeaf',shield:28,armor:.35,clearShots:true,time:6},
    80:{k:'mercuryPool',r:185,t:5.5,m:.32,st:'poison',slow:5},
    81:{k:'cellToxin',m:3.1,sp:820,pierce:99,st:'poison',ignoreShield:true},
    82:{k:'leadSlug',m:4.7,sp:480,pierce:15,kb:7.0,r:11},
    83:{k:'levitation',hover:true,immuneGround:true,time:6,speed:1.2},
    84:{k:'alphaCloud',r:260,t:5,m:.55,st:'radiation'},
    85:{k:'halogenRadiance',r:235,t:5,m:.75,st:'burn',st2:'radiation'},
    86:{k:'radonSeep',global:true,t:5.5,m:.22,st:'radiation'},
    87:{k:'franciumBlast',count:5,m:1.2,r:125,st:'burn'},
    88:{k:'radiumGlow',r:360,t:6,st:'weaken',reveal:999},
    89:{k:'alphaCascade',count:8,m:1.75,pierce:22,st:'radiation',chain:true},
    90:{k:'moltenSalt',damage:1.45,rate:1.55,shieldRegen:true,time:7},
    91:{k:'transmute',r:360,t:6,stripRes:true,st:'brittle'},
    92:{k:'uraniumSabot',m:5.0,sp:620,pierce:80,st:'radiation'},
    93:{k:'decayDart',m:2.7,sp:880,pierce:15,st:'radiation',linger:5},
    94:{k:'plutoniumImplosion',distance:260,delay:1.0,r:280,m:4.8,st:'radiation'},
    95:{k:'ionChamber',r:240,t:6,m:.3,st:'shock'},
    96:{k:'curiumGlow',r:330,m:.75,st:'confuse',st2:'radiation'},
    97:{k:'precursor',m:3.0,sp:900,pierce:12,secondBurst:7,st:'radiation'},
    98:{k:'fissionEmitter',count:30,m:.65,pierce:99,sp:900,st:'radiation',t:5},
    99:{k:'distortion',r:420,t:5,projectileSlow:.1},
    100:{k:'fissure',distance:260,r:115,t:5.5,m:.4,st:'radiation'},
    101:{k:'vulnerability',r:520,t:7,allStatus:true},
    102:{k:'nobel',count:6,m:1.55,st:'burn',expl:true},
    103:{k:'cyclotron',bulletSpeed:1500,damage:1.7,time:5.5},
    104:{k:'goldScatter',m:3.0,sp:950,pierce:10,backscatter:6,st:'radiation'},
    105:{k:'isomer',m:3.0,sp:820,pierce:12,fragment:6,st:'radiation'},
    106:{k:'heavyBeam',len:800,w:18,m:4.4,pierce:99,st:'radiation'},
    107:{k:'orbitLeap',dash:280,r:110,m:2.6,st:'shock'},
    108:{k:'heavyStrike',distance:210,r:140,m:3.3,st:'stun',kb:8.0},
    109:{k:'fissionBeam',len:740,w:14,m:3.9,pierce:99,st:'radiation',stripShield:true},
    110:{k:'fusionSlug',m:5.8,sp:520,pierce:30,r:10,st:'burn'},
    111:{k:'xrayLaser',len:900,w:10,m:3.7,pierce:99,st:'radiation',reveal:12},
    112:{k:'orbitSpheres',count:6,r:68,t:8,deleteShots:true,m:.55},
    113:{k:'sunFlare',r:300,m:2.0,st:'stun',shield:28},
    114:{k:'stabilityShield',shield:45,ifr:4,immuneStatus:true,time:4},
    115:{k:'alphaSacrifice',hpCost:10,r:300,m:3.8,st:'radiation'},
    116:{k:'chalcogenPool',r:190,t:5.5,m:.38,st:'corrode',st2:'slow'},
    117:{k:'halogenLance',m:4.0,sp:900,pierce:30,st:'poison',st2:'corrode'},
    118:{k:'electronCloud',r:170,t:7,deleteShots:true,m:.28,orbit:true}
  };

  function runSpec(p,n,sp){
    if(!R()||!p)return;
    var h=hue(n),d;
    switch(sp.k){
      case 'beam':
        line(p,sp.len,sp.w,mult(p,sp.m),sp.st,h);flash(atAim(p,sp.len*.9).x,atAim(p,sp.len*.9).y,h,sp.flash);break;
      case 'beamTrail':
        line(p,sp.len,sp.w,mult(p,sp.m),sp.st,h);
        zone({anchor:'aim',distance:sp.len*.55,r:sp.w*2.5,t:sp.trail,dmgMult:.18,status:sp.st},p);break;
      case 'heavyBeam': case 'fissionBeam': case 'xrayLaser': case 'laserRod': case 'scalpel': case 'yag': case 'mirrorBeam':
        line(p,sp.len,sp.w,mult(p,sp.m),sp.st,h);break;
      case 'xray':
        line(p,sp.len,sp.w,mult(p,sp.m),sp.st==='radiation'?'mark':sp.st,h);revealAll(sp.reveal||10);break;
      case 'lift':
        for(var i=0;i<sp.count;i++)fire(p,{a:(p.angle||0)+(i-sp.count/2)*.18,sp:(S().ps||360)*1.25,d:mult(p,1.25),pierce:3,hom:true,r:6,life:1.5,v24Lift:true});
        hitNear(atAim(p,sp.dist).x,atAim(p,sp.dist).y,sp.r,0,sp.st,h,{statusTime:sp.root});
        live().forEach(function(e){if(d2(e.x,e.y,p.x,p.y)<sp.r*sp.r){e.v24LiftT=sp.root;e.v24LiftY=e.y;e.v24RootT=sp.root;e.v24DisarmT=sp.root;}});
        break;
      case 'buff':
        if(sp.damage)buff(p,'damage',sp.damage,sp.shield?6:5);
        if(sp.rate)buff(p,'rate',sp.rate,6);
        if(sp.speed)buff(p,'speed',1,sp.speed);
        if(sp.shield)shield(p,sp.shield,.35);
        break;
      case 'reflect':
        shield(p,sp.r*.08,1.0);p.v24ReflectT=5;p.v24ReflectDamage=sp.damage||1.3;p.v24CritBoost=sp.crit||1.2;clearEnemyShots(p,sp.r);break;
      case 'absorb':{
        var got=clearEnemyShots(p,sp.r);shield(p,Math.max(8,got*(sp.shieldPer||10)),.4);hitNear(p.x,p.y,sp.r,0,null,h);break;}
      case 'web':
        zone({anchor:'aim',distance:150,r:sp.r,t:sp.t,dmgMult:.22,status:'slow'},p);
        live().forEach(function(e){if(d2(e.x,e.y,p.x+Math.cos(p.angle)*150,p.y+Math.sin(p.angle)*150)<sp.r*sp.r){e.v24RootT=Math.max(e.v24RootT||0,sp.root);if(sp.st==='bleed'){e.v24BleedT=Math.max(e.v24BleedT||0,sp.t);e.v24BleedDps=mult(p,.2);}}});
        break;
      case 'cascade':
        var q=atAim(p,220);for(var c=0;c<sp.bursts;c++)explosion(p,q.x+(c-1)*35,q.y+(c%2?25:-25),.55+c*.32,sp.r,sp.m,sp.st);break;
      case 'arcPulse':
        for(var a0=0;a0<sp.pulses;a0++){
          (function(step){setTimeout(function(){if(!R())return;hitNear(p.x,p.y,sp.r,mult(p,sp.m*(1-step*.12)),sp.st,h,{statusTime:1.5});if(typeof arcChain==='function'){var t=nearest(p);if(t)arcChain(t,mult(p,.7),4,h);}},step*260);})(a0);
        }break;
      case 'flash':
        flash(p.x,p.y,h,sp.r);hitNear(p.x,p.y,sp.r,mult(p,1.0),sp.st,h);clearEnemyShots(p,sp.clear);break;
      case 'pool': case 'smoke': case 'toxicHaze': case 'iodineCloud': case 'fumes': case 'mercuryPool': case 'chalcogenPool': case 'alphaCloud': case 'radiantAura': case 'ionChamber': case 'fissure':
        zone({anchor:sp.global?'player':'aim',distance:170,r:sp.r,t:sp.t,dmgMult:sp.m,status:sp.st,status2:sp.st2,slowProjectiles:!!sp.slowProjectiles,healPlayer:!!sp.healPlayer},p);
        if(sp.global){live().forEach(function(e){status(e,sp.st,sp.t,mult(p,.3));});}
        break;
      case 'ribbon':
        for(var rr=0;rr<sp.count;rr++){var aa=(p.angle||0)+(rr/(sp.count-1)-.5)*sp.spread;fire(p,{a:aa,sp:(S().ps||360)*1.9,d:mult(p,sp.m),r:5,pierce:3,burn:sp.st==='burn',life:1.6});}
        break;
      case 'plating':
        shield(p,sp.shield,0);p.puArmor=Math.max(p.puArmor||0,sp.armor);p.adrenT=Math.max(p.adrenT||0,sp.time);p.puTimer=Math.max(p.puTimer||0,sp.time);p.v24SpeedPlate=1;break;
      case 'chain':
        var t=nearest(p);if(t&&typeof arcChain==='function')arcChain(t,mult(p,sp.m),sp.jumps, h);else if(t)status(t,sp.st,2,mult(p,.35));break;
      case 'geyser':
        q=atAim(p,230);hitNear(q.x,q.y,sp.r,mult(p,sp.m),sp.st,h);fan(p,sp.fan,.9,{d:mult(p,.65),sp:(S().ps||360)*1.5,pierce:3,burn:true,r:5,life:1.4});break;
      case 'bleach':
        hitNear(p.x,p.y,sp.r,mult(p,sp.m),sp.st,h,{statusTime:4});live().forEach(function(e){if(d2(e.x,e.y,p.x,p.y)<sp.r*sp.r){e.puTimer=0;e.v24WeakenT=4;if(sp.strip)e.mark=0;if(sp.corrode)status(e,'corrode',6);}});break;
      case 'purge':
        p.hp=Math.min(S().hp||100,(p.hp||0)+8);if(sp.shield)shield(p,sp.shield,.35);p.burn=null;p.poison=null;p.corrode=0;p.rust=0;p.freeze=0;p.stun=0;p.conf=0;if(sp.convertToxic){clearEnemyShots(p,200);hitNear(p.x,p.y,200,mult(p,.75),'shock',h);}break;
      case 'surge':
        p.adrenT=Math.max(p.adrenT||0,sp.speed);p.puRate=Math.max(p.puRate||1,sp.rate);p.puTimer=Math.max(p.puTimer||0,5);p.v24DashBoost=sp.dash;break;
      case 'carapace':
        p.iframes=Math.max(p.iframes||0,sp.ifr);p.puTimer=Math.max(p.puTimer||0,sp.time);p.puArmor=Math.max(p.puArmor||0,.85);p.v24Thorns={t:sp.time,d:mult(p,sp.thorns)};shield(p,sp.shield,.4);break;
      case 'spear': case 'galliumDart': case 'cellToxin': case 'leadSlug': case 'penetrator': case 'uraniumSabot': case 'decayDart': case 'fusionSlug': case 'halogenLance': case 'gaussBolt':
        d=mult(p,sp.m);var opt={d:d,sp:sp.sp||900,r:sp.r||6,pierce:sp.pierce||0,life:1.6,hom:!!sp.hom,kb:sp.kb||0};if(sp.st==='radiation')opt.poison=true;if(sp.st==='poison')opt.poison=true;if(sp.st==='burn')opt.burn=true;if(sp.st==='corrode')opt.corrode=true;if(sp.st==='rust')opt.rust=true;if(sp.st==='mark')opt.mark=true;if(sp.pull)opt.pull=true;fire(p,opt);break;
      case 'radialShards': fan(p,sp.count,TAU2,{d:mult(p,sp.m),sp:(S().ps||360)*1.6,r:4,pierce:sp.pierce,corrode:sp.st==='corrode',rust:sp.st==='rust',brittle:sp.st==='brittle',life:1.3});break;
      case 'redox': shield(p,sp.shield,.45);hitNear(p.x,p.y,sp.r,mult(p,sp.m),sp.st,h,{statusTime:2});break;
      case 'mirrorBeam': line(p,sp.len,sp.w,mult(p,sp.m),sp.st,h);p.v24ReflectT=4;p.v24ReflectDamage=sp.reflect||2;break;
      case 'oxidizer': hitNear(p.x,p.y,sp.r,mult(p,sp.m),null,h);live().forEach(function(e){if(d2(e.x,e.y,p.x,p.y)<sp.r*sp.r){status(e,'corrode',sp.corrode);if(e.burn)e.burn.dps*=1.6;if(e.poison)e.poison.dps*=1.6;}});break;
      case 'shrapnelCannon':
        fire(p,{d:mult(p,sp.m),sp:sp.sp,r:10,pierce:sp.pierce,life:2,kb:sp.kb||0});fan(p,sp.split,.5,{d:mult(p,.6),sp:sp.sp*1.25,r:4,pierce:4,rust:true,life:1.1});break;
      case 'radiationPulse':
        hitNear(p.x,p.y,sp.r,mult(p,sp.m),null,h);zone({anchor:'player',r:sp.r,t:sp.t,dmgMult:.12,status:'radiation'},p);break;
      case 'shapeMemory':
        p.hp=Math.min(S().hp||100,(p.hp||0)+(S().hp||100)*sp.heal);p.v24DodgeT=sp.dodge;p.puTimer=Math.max(p.puTimer||0,sp.time);flash(p.x,p.y,h,140);break;
      case 'whip': line(p,sp.len,sp.w,mult(p,sp.m),sp.st,h);break;
      case 'mantle': p.v24RetaliateT=sp.time;p.v24RetaliateDamage=mult(p,sp.retaliate);p.puArmor=Math.max(p.puArmor||0,.25);zone({anchor:'player',r:sp.r,t:sp.time,dmgMult:.15,status:sp.st},p);break;
      case 'infrared': line(p,sp.len,sp.w,mult(p,sp.m),'mark',h);live().forEach(function(e){if(d2(e.x,e.y,p.x,p.y)<sp.len*sp.len)e.v24InfraMarkT=5;if(e.mark>0)addBurn(e,mult(p,.28),4);});break;
      case 'seekMarked':
        for(var sm=0;sm<sp.count;sm++){
          var tgt=live().filter(function(e){return e.mark>0;})[sm%Math.max(1,live().filter(function(e){return e.mark>0;}).length)]||nearest(p);
          var ang=tgt?Math.atan2(tgt.y-p.y,tgt.x-p.x):(p.angle||0)+((sm-sp.count/2)*.12);
          fire(p,{a:ang,d:mult(p,sp.m),sp:sp.sp,r:5,pierce:2,hom:true,burn:true,life:1.7});
        }break;
      case 'acidSplash': q=atAim(p,190);hitNear(q.x,q.y,sp.r,mult(p,sp.m),sp.st,h,{statusTime:6});hitNear(q.x,q.y,sp.r*.58,0,sp.st2,h,{statusTime:5});break;
      case 'kryptonPulse': hitNear(p.x,p.y,sp.r,mult(p,sp.m),sp.st,h,{statusTime:sp.slow||3});live().forEach(function(e){if(d2(e.x,e.y,p.x,p.y)<sp.r*sp.r){e.sh=0;e.v24SlowMul=sp.slow;}});break;
      case 'ignition': for(var ig=0;ig<sp.bursts;ig++){var angI=Math.random()*TAU2,rrI=50+Math.random()*sp.r;setTimeout((function(x,y){return function(){if(R())hitNear(x,y,sp.r,mult(p,sp.m),sp.st,h);};})(p.x+Math.cos(angI)*rrI,p.y+Math.sin(angI)*rrI),ig*120);}break;
      case 'rocketBarrage': fan(p,sp.count,.95,{d:mult(p,sp.m),sp:620,r:6,pierce:1,hom:true,burn:true,life:2});break;
      case 'zirconia': shield(p,sp.shield,0);p.puArmor=sp.armor;p.puTimer=sp.time;p.v24KnockRes=1;clearEnemyShots(p,180);break;
      case 'pin': hitNear(p.x,p.y,sp.r,mult(p,.45),sp.st,h,{statusTime:sp.t});live().forEach(function(e){if(d2(e.x,e.y,p.x,p.y)<sp.r*sp.r)e.v24RootT=Math.max(e.v24RootT||0,sp.t);});break;
      case 'crucible': zone({anchor:'player',r:sp.r,t:sp.t,dmgMult:sp.m,status:sp.st,slowProjectiles:sp.deleteEnemyShots},p);if(sp.deleteEnemyShots)clearEnemyShots(p,sp.r);break;
      case 'tracer': hitNear(p.x,p.y,sp.r,mult(p,.65),sp.st,h,{statusTime:sp.reveal});live().forEach(function(e){if(d2(e.x,e.y,p.x,p.y)<sp.r*sp.r){e.mark=Math.max(e.mark,sp.reveal||7);e.v24CritVulnT=sp.reveal||7;}});p.v24CritDamageBoost=sp.critD;break;
      case 'needleRain': fan(p,sp.count,1.05,{d:mult(p,sp.m),sp:sp.sp,r:3,pierce:sp.pierce,life:1.9,rust:true});break;
      case 'luster': shield(p,sp.shield,.4);p.v24DebuffImmuneT=sp.antiDebuff;var es=live();for(var ii=0;ii<es.length;ii++){};break;
      case 'cleanse':
        p.burn=null;p.poison=null;p.corrode=0;p.rust=0;p.freeze=0;p.stun=0;p.conf=0;
        hitNear(p.x,p.y,sp.r,mult(p,sp.m),sp.st,h);break;
      case 'controlRods': zone({anchor:'player',r:sp.r,t:sp.t,dmgMult:.16,status:sp.st},p);clearEnemyShots(p,sp.r);live().forEach(function(e){if(d2(e.x,e.y,p.x,p.y)<sp.r*sp.r){e.v24DisarmT=sp.t;e.shootT=Math.max(e.shootT||0,sp.t);e.specialT=Math.max(e.specialT||0,sp.t);e.v24SlowAttack=sp.rateSlow;}});break;
      case 'conductiveScreen': shield(p,sp.shield,.3);p.v24ReflectT=sp.time;p.v24ReflectDamage=sp.reflect;p.puSpeed=sp.vel;p.puTimer=sp.time;break;
      case 'tinPest':
        live().forEach(function(e){var metal=/brute|tank|crusher|basalt|sentinel|reactor|boulder|mole|shielder|glasslancer/i.test(String(e.type||''));if(metal&&d2(e.x,e.y,p.x,p.y)<sp.r*sp.r){status(e,'rust',6);e.v24ArmorBreakT=6;e.v24ArmorBreakAmp=sp.armorShred;dmg(e,mult(p,sp.m));}});flash(p.x,p.y,h,sp.r);break;
      case 'stibnite': fan(p,sp.count,.7,{d:mult(p,sp.m),sp:sp.sp,r:4,pierce:sp.pierce,brittle:true,life:1.6});break;
      case 'cooler': zone({anchor:'player',r:sp.r,t:sp.t,dmgMult:.22,status:sp.st},p);if(sp.clearEnemyShots)clearEnemyShots(p,sp.r);break;
      case 'thruster': var ox=p.x,oy=p.y;if(typeof dashMove==='function')dashMove(p,sp.dash,.7);hitNear(p.x,p.y,sp.cone,mult(p,sp.m),'burn',h);flash(ox,oy,h,90);break;
      case 'atomicClock': p.puCrit=sp.crit?1:0;p.puTimer=sp.time;p.v24InstantShots=true;for(var ac=0;ac<8;ac++)fire(p,{a:(p.angle||0)+(ac-3.5)*.035,d:mult(p,1.3),sp:sp.bulletSpeed,r:3,pierce:5,life:.55,crit:true});break;
      case 'bariumFlame': zone({anchor:'aim',distance:160,r:sp.r,t:sp.t,dmgMult:sp.m,status:sp.st},p);live().forEach(function(e){if(d2(e.x,e.y,p.x,p.y)<sp.r*sp.r){e.v24ArmorBreakT=sp.t;e.v24ArmorBreakAmp=sp.corrode||.4;}});break;
      case 'sparkShower':
        for(var ss=0;ss<sp.count;ss++){var as=Math.random()*TAU2;fire(p,{a:as,d:mult(p,sp.m),sp:500+Math.random()*500,r:3,pierce:1,burn:true,life:1.2,crit:ss%4===0});}hitNear(p.x,p.y,110,mult(p,.25),'burn',h);break;
      case 'ceriaGrind': fan(p,sp.count,1.4,{d:mult(p,sp.m),sp:900,r:2.5,pierce:sp.pierce,corrode:true,life:.9});break;
      case 'eyeFilter': p.v24BlindImmuneT=sp.reveal||7;revealAll(sp.reveal||7);flash(p.x,p.y,h,170);break;
      case 'radiantAura': zone({anchor:'player',r:sp.r,t:sp.t,dmgMult:sp.m,status:null},p);revealAll(sp.reveal||999);break;
      case 'magnetron': hitNear(p.x,p.y,sp.r,mult(p,sp.m),sp.st,h,{statusTime:1.6});live().forEach(function(e){if(d2(e.x,e.y,p.x,p.y)<sp.r*sp.r){e.v24DisarmT=sp.disarm;e.shootT=Math.max(e.shootT||0,sp.disarm);var a=Math.atan2(p.y-e.y,p.x-e.x);e.x+=Math.cos(a)*sp.pull;e.y+=Math.sin(a)*sp.pull;}});break;
      case 'uvFlash': hitNear(p.x,p.y,sp.r,mult(p,.85),sp.st,h,{statusTime:3});clearEnemyShots(p,9999);break;
      case 'magnoFreeze': hitNear(p.x,p.y,sp.r,mult(p,sp.m),sp.st,h,{statusTime:2.1});break;
      case 'soundwave': hitNear(p.x,p.y,sp.r,mult(p,sp.m),sp.st,h,{statusTime:4});live().forEach(function(e){if(d2(e.x,e.y,p.x,p.y)<sp.r*sp.r){if(sp.shieldBreak)e.sh=0;e.v24BarrierBreakT=4;}});break;
      case 'opticalAmplifier':
        (sp.allPlayers?R().players:[p]).forEach(function(qp){qp.puDamage=Math.max(qp.puDamage||1,sp.damage);qp.puSpeed=sp.vel;qp.puTimer=sp.time;});flash(p.x,p.y,h,160);break;
      case 'atomicLaser': p.puRate=Math.max(p.puRate||1,sp.rate);p.puTimer=sp.time;p.v24LaserPulseT=sp.time;line(p,600,7,mult(p,1.6),null,h);break;
      case 'scintillator': var absorbed=clearEnemyShots(p,sp.r);shield(p,absorbed*(sp.shieldPer||9),.2);break;
      case 'neutronShield': shield(p,sp.shield,0);p.puArmor=sp.armor;p.puDamage=Math.max(p.puDamage||1,sp.damage);p.puTimer=sp.time;p.v24BlastImmuneT=sp.time;break;
      case 'capacitor': line(p,sp.len,sp.w,mult(p,sp.m),sp.st,h);break;
      case 'turbine': p.v24Turbine={t:sp.t,r:sp.r,d:mult(p,sp.m),spd:sp.speed,h:h};break;
      case 'reveal': revealAll(sp.reveal||10);flash(p.x,p.y,h,sp.r||150);break;
      case 'cisplatin': hitNear(p.x,p.y,sp.r,mult(p,sp.m),sp.st,h,{statusTime:5});live().forEach(function(e){if(d2(e.x,e.y,p.x,p.y)<sp.r*sp.r){e.v24Organic=true;if(sp.mark)e.mark=Math.max(e.mark,6);}});break;
      case 'goldLeaf': shield(p,sp.shield,0);p.puArmor=sp.armor;p.puTimer=sp.time;if(sp.clearShots)clearEnemyShots(p,260);p.v24LaserImmuneT=sp.time;break;
      case 'levitation': p.v24HoverT=sp.time;p.v24GroundImmuneT=sp.time;p.adrenT=Math.max(p.adrenT,sp.time);p.puTimer=sp.time;break;
      case 'halogenRadiance': zone({anchor:'player',r:sp.r,t:sp.t,dmgMult:sp.m,status:sp.st,status2:sp.st2},p);break;
      case 'radonSeep': zone({anchor:'player',r:Math.max(window.W||1200,window.H||800)*.6,t:sp.t,dmgMult:sp.m,status:sp.st},p);break;
      case 'franciumBlast': for(var fb=0;fb<sp.count;fb++){var af=fb/sp.count*TAU2;var rr=80+fb*22;explosion(p,p.x+Math.cos(af)*rr,p.y+Math.sin(af)*rr,.65+fb*.07,sp.r,sp.m,sp.st);}break;
      case 'radiumGlow': zone({anchor:'player',r:sp.r,t:sp.t,dmgMult:.15,status:'weaken'},p);revealAll(sp.reveal||999);break;
      case 'alphaCascade': fan(p,sp.count,1.0,{d:mult(p,sp.m),sp:720,r:4,pierce:sp.pierce,poison:true,life:1.8});
        if(sp.chain){var ct=nearest(p);if(ct&&typeof arcChain==='function')arcChain(ct,mult(p,.45),5,h);}break;
      case 'moltenSalt': p.puRate=Math.max(p.puRate||1,sp.rate);p.puDamage=Math.max(p.puDamage||1,sp.damage);p.puTimer=sp.time;p.v24ShieldRegen=1;break;
      case 'transmute': live().forEach(function(e){if(d2(e.x,e.y,p.x,p.y)<sp.r*sp.r){if(sp.stripRes){e.v24ResistStripT=sp.t;e.v24ArmorBreakT=sp.t;e.v24ArmorBreakAmp=.7;}status(e,sp.st,sp.t);}});flash(p.x,p.y,h,sp.r);break;
      case 'plutoniumImplosion': q=atAim(p,sp.distance);explosion(p,q.x,q.y,sp.delay,sp.r,sp.m,sp.st);break;
      case 'curiumGlow': hitNear(p.x,p.y,sp.r,mult(p,sp.m),sp.st,h,{statusTime:3});live().forEach(function(e){if(d2(e.x,e.y,p.x,p.y)<sp.r*sp.r)status(e,sp.st2,5,mult(p,.3));});break;
      case 'precursor':
        var pb=fire(p,{d:mult(p,sp.m),sp:sp.sp,r:6,pierce:sp.pierce,life:1.5,radiation:true});
        setTimeout(function(){if(!R())return;var bx=pb&&pb.x||atAim(p,300).x,by=pb&&pb.y||atAim(p,300).y;for(var k2=0;k2<sp.secondBurst;k2++){var ak=k2/sp.secondBurst*TAU2;fire(p,{a:ak,d:mult(p,.48),sp:760,r:3,pierce:8,life:1.1,poison:true});}hitNear(bx,by,90,mult(p,.8),'shock',h);},420);break;
      case 'fissionEmitter':
        var r=R();r.v24NeutronEmitters=r.v24NeutronEmitters||[];r.v24NeutronEmitters.push({x:p.x,y:p.y,t:sp.t,rate:.36,m:sp.m,h:h,owner:p.id});flash(p.x,p.y,h,130);break;
      case 'distortion': p.v24ProjectileSlow={t:sp.t,m:sp.projectileSlow};clearEnemyShots(p,0);flash(p.x,p.y,h,sp.r);break;
      case 'vulnerability': live().forEach(function(e){if(d2(e.x,e.y,p.x,p.y)<sp.r*sp.r){e.v24VulnT=sp.t;e.v24VulnAll=1;status(e,'burn',sp.t);status(e,'poison',sp.t);status(e,'corrode',sp.t);status(e,'brittle',sp.t);status(e,'slow',sp.t);}});flash(p.x,p.y,h,sp.r);break;
      case 'nobel': for(var nb=0;nb<sp.count;nb++){var an=p.angle+(nb-(sp.count-1)/2)*.17;fire(p,{a:an,d:mult(p,sp.m),sp:640,r:7,pierce:2,life:1.9,expl:true,burn:true});}break;
      case 'cyclotron': p.v24InstantShots=true;p.v24ProjectileSpeed=sp.bulletSpeed;p.puDamage=Math.max(p.puDamage||1,sp.damage);p.puTimer=sp.time;flash(p.x,p.y,h,145);break;
      case 'goldScatter':
        fire(p,{d:mult(p,sp.m),sp:sp.sp,r:5,pierce:sp.pierce,life:1.3,mark:true});
        var q2=atAim(p,310);for(var gs=0;gs<sp.backscatter;gs++){var ag=(p.angle||0)+Math.PI+(gs-(sp.backscatter-1)/2)*.12;fire(p,{a:ag,d:mult(p,.7),sp:720,r:3,pierce:3,life:1.1,poison:true});}
        flash(q2.x,q2.y,h,80);break;
      case 'isomer':
        var ib=fire(p,{d:mult(p,sp.m),sp:sp.sp,r:6,pierce:sp.pierce,life:1.5,poison:true});setTimeout(function(){if(!R())return;for(var fi=0;fi<sp.fragment;fi++)fire(p,{a:(fi/sp.fragment)*TAU2,d:mult(p,.62),sp:760,r:3,pierce:4,hom:true,poison:true,life:1.25});},360);break;
      case 'orbitLeap':
        var x0=p.x,y0=p.y; if(typeof dashMove==='function')dashMove(p,sp.dash,.65); line({x:x0,y:y0,angle:Math.atan2(p.y-y0,p.x-x0)},sp.dash,22,mult(p,sp.m),sp.st,h);hitNear(p.x,p.y,sp.r,mult(p,.8),sp.st,h);break;
      case 'heavyStrike': q=atAim(p,sp.distance);hitNear(q.x,q.y,sp.r,mult(p,sp.m),sp.st,h,{statusTime:1.8,extra:function(e){if(sp.kb&&!e.boss){var aa=Math.atan2(e.y-q.y,e.x-q.x);e.x+=Math.cos(aa)*sp.kb;e.y+=Math.sin(aa)*sp.kb;}}});break;
      case 'orbitSpheres':
        var r0=R();r0.v24SecondOrbits=r0.v24SecondOrbits||[];r0.v24SecondOrbits.push({owner:p.id,x:p.x,y:p.y,t:sp.t,r:sp.r,n:sp.count,h:h,shoot:sp.deleteShots,mode:'spheres',dmg:mult(p,sp.m)});flash(p.x,p.y,h,120);break;
      case 'sunFlare': hitNear(p.x,p.y,sp.r,mult(p,sp.m),sp.st,h,{statusTime:1.4});shield(p,sp.shield,.3);break;
      case 'stabilityShield': shield(p,sp.shield,sp.ifr);p.v24DamageImmuneT=sp.time;p.v24StatusImmuneT=sp.time;p.puTimer=sp.time;break;
      case 'alphaSacrifice': p.hp=Math.max(1,(p.hp||0)-sp.hpCost);hitNear(p.x,p.y,sp.r,mult(p,sp.m),sp.st,h,{statusTime:5});break;
      case 'electronCloud': var ro=R();ro.v24SecondOrbits=ro.v24SecondOrbits||[];ro.v24SecondOrbits.push({owner:p.id,x:p.x,y:p.y,t:sp.t,r:sp.r,n:8,h:h,shoot:sp.deleteShots,mode:'cloud',dmg:mult(p,sp.m)});break;
    }
    p.activeCd=Math.max(p.activeCd||0,(sp.cd||0));
  }

  function updateZones(dt){
    var r=R();if(!r)return;
    r.v24SecondZones=(r.v24SecondZones||[]).filter(function(z){
      z.t-=dt; z.dt-=dt;
      if(z.dt<=0){z.dt=.18;var es=live();es.forEach(function(e){if(d2(e.x,e.y,z.x,z.y)<(z.r+e.r)*(z.r+e.r)){if(z.dmg)dmg(e,z.dmg);if(z.status)status(e,z.status,z.status==='freeze'?1.0:.8,z.dmg);if(z.status2)status(e,z.status2,2,z.dmg*.3);if(z.pull){var a=Math.atan2(z.y-e.y,z.x-e.x);e.x+=Math.cos(a)*z.pull;e.y+=Math.sin(a)*z.pull;}if(z.healPlayer){var op=r.players.find(function(q){return q.id===z.owner;});if(op)op.hp=Math.min(S().hp||100,op.hp+1);}}});if(z.deleteEnemyShots){r.ebullets=r.ebullets.filter(function(b){return d2(b.x,b.y,z.x,z.y)>(z.r*z.r);});}}
      return z.t>0;
    });
    r.v24SecondFuses=(r.v24SecondFuses||[]).filter(function(f){
      f.t-=dt; if(f.t<=0){hitNear(f.x,f.y,f.r,f.dmg,f.status,f.h);if(typeof burst==='function')burst(f.x,f.y,f.h);return false;} return true;
    });
    r.v24NeutronEmitters=(r.v24NeutronEmitters||[]).filter(function(e){
      e.t-=dt;e._t=(e._t||0)-dt;if(e._t<=0){e._t=e.rate;var owner=(r.players||[]).find(function(p){return p.id===e.owner;})||r.players[0];if(owner)fan(owner,7,.9,{d:mult(owner,e.m),sp:950,r:3,pierce:99,life:.95,poison:true});}return e.t>0;
    });
    r.v24SecondOrbits=(r.v24SecondOrbits||[]).filter(function(o){
      o.t-=dt;if(o.t<=0)return false;
      var owner=(r.players||[]).find(function(p){return p.id===o.owner;});if(!owner)return false;o.x=owner.x;o.y=owner.y;o._a=(o._a||0)+dt*(o.mode==='cloud'?2.1:1.45);
      for(var i=0;i<o.n;i++){
        var a=o._a+i*TAU2/o.n,xx=o.x+Math.cos(a)*o.r,yy=o.y+Math.sin(a)*o.r;
        if(o.shoot&&r.ebullets)r.ebullets=r.ebullets.filter(function(b){return d2(b.x,b.y,xx,yy)>64;});
        if((r.t||0)-(o._hitT||0)>.3){var es=live();for(var j=0;j<es.length;j++){if(d2(es[j].x,es[j].y,xx,yy)<(10+es[j].r)*(10+es[j].r)){dmg(es[j],o.dmg*.18);if(o.mode==='cloud')status(es[j],'slow',.8,o.dmg*.1);o._hitT=r.t||0;break;}}}
      }
      return true;
    });
    (r.players||[]).forEach(function(p){
      if(p.v24Thorns&&p.v24Thorns.t>0)p.v24Thorns.t-=dt;
      ['v24DodgeT','v24HoverT','v24GroundImmuneT','v24RetaliateT','v24LaserImmuneT','v24BlindImmuneT','v24DebuffImmuneT','v24DamageImmuneT','v24StatusImmuneT','v24ProjectileSpeed'].forEach(function(k){if(typeof p[k]==='number'&&k!=='v24ProjectileSpeed'&&p[k]>0)p[k]-=dt;});
    });
    if(r.v24SecondKillHooks!==true){r.v24SecondKillHooks=true;}
  }
  function renderFx(){
    var r=R();if(!r||typeof cx==='undefined')return;
    var arr=r.v24SecondOrbits||[];
    arr.forEach(function(o){
      var owner=(r.players||[]).find(function(p){return p.id===o.owner;});if(!owner)return;
      cx.save();cx.globalCompositeOperation='lighter';
      cx.strokeStyle='hsla('+o.h+',90%,70%,.22)';cx.lineWidth=2;cx.beginPath();cx.arc(owner.x,owner.y,o.r,0,TAU2);cx.stroke();
      for(var i=0;i<o.n;i++){var a=(o._a||0)+i*TAU2/o.n,x=owner.x+Math.cos(a)*o.r,y=owner.y+Math.sin(a)*o.r;var g=cx.createRadialGradient(x,y,0,x,y,10);g.addColorStop(0,'hsla('+o.h+',100%,85%,.95)');g.addColorStop(1,'transparent');cx.fillStyle=g;cx.beginPath();cx.arc(x,y,10,0,TAU2);cx.fill();}
      cx.restore();
    });
    (r.v24SecondZones||[]).forEach(function(z){
      cx.save();cx.globalCompositeOperation='lighter';cx.strokeStyle='hsla('+z.h+',90%,70%,.45)';cx.lineWidth=2;cx.beginPath();cx.arc(z.x,z.y,z.r*(.94+.06*Math.sin((r.t||0)*5)),0,TAU2);cx.stroke();cx.fillStyle='hsla('+z.h+',90%,60%,.035)';cx.fill();cx.restore();
    });
    (r.v24SecondFuses||[]).forEach(function(f){var pulse=1-Math.max(0,f.t)/Math.max(.001,f.life);var rate=3+18*rateCurve(pulse);cx.save();cx.strokeStyle='hsla('+f.h+',95%,70%,'+clamp(.35+.55*Math.sin((r.t||0)*rate*2),0,1)+')';cx.lineWidth=2.5;cx.beginPath();cx.arc(f.x,f.y,f.r*(.35+.65*pulse),0,TAU2);cx.stroke();cx.restore();});
  }
  function rateCurve(x){return x<.65?x*.45:(.2925+(x-.65)*2.02);}

  function install(){
    if(!window.DATA||!DATA.ELEMS)return;
    var count=0;
    Object.values(DATA.ELEMS).forEach(function(el){
      var n=Number(el.n);if(n<1||n>118)return;var c=el.choices&&el.choices[1];if(!c)return;var sp=SPEC[n];if(!sp)return;
      var oldName=c.name,oldDesc=c.desc;
      c.exec=(function(nn,ss){return function(p){runSpec(p,nn,ss);};})(n,sp);
      c.implemented=true;c.v24SecondContract=true;c.v24ContractId='element-'+n+'-ability-2';
      c.name=oldName;c.desc=oldDesc;el.choices[1]=c;el.signatures=el.choices;
      count++;
    });
    DATA.ISO_V24_SECOND_ABILITY_AUDIT=function(){
      var out=[];Object.values(DATA.ELEMS).forEach(function(el){var c=el.choices&&el.choices[1];out.push({n:el.n,name:el.name,ability:c&&c.name,description:c&&c.desc,implemented:!!(c&&c.v24SecondContract&&typeof c.exec==='function')});});return out;
    };
    console.log('ISO_ELEMENT_SECOND_V24 active:',count,'/118 second abilities now use dedicated description contracts.');
  }
  install();
  var u=window.update; if(typeof u==='function'&&!window.__ISO_V24_SECOND_UPDATE__){window.__ISO_V24_SECOND_UPDATE__=true;window.update=function(dt){u(dt);updateZones(dt);};}
  var rr=window.render;if(typeof rr==='function'&&!window.__ISO_V24_SECOND_RENDER__){window.__ISO_V24_SECOND_RENDER__=true;window.render=function(){rr();renderFx();};}
})();
