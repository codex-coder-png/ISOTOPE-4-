/* ISOTOPE V39 — FULL PROGRESS WIPE / 2000 COIN RESET
 * One-time migration for the V39 build. Clears all progression, unlocks,
 * bought upgrades, mastery, abilities, relics, compounds, and counters while
 * leaving the game with its required base element and exactly 2,000 coins.
 */
(function(){
  'use strict';
  if(!window.SAVE || !SAVE.raw || !SAVE.save) return;

  var MIG='isotope_v39_full_progress_wipe_applied';
  try{
    if(localStorage.getItem(MIG)==='1') return;
  }catch(e){}

  var S=SAVE.raw;

  // Exact progression wipe.
  S.coins=2000;
  S.sel='e1';
  S.sel2='e1';
  S.unlocked=['e1'];
  S.mols=[];
  S.favs=[];
  S.abil={};
  S.signatures={};
  S.mastery={};
  S.abilityMastery={};
  S.meta={};
  S.relicsFound=[];
  S.relicLoadout=[];
  S.plays={};
  S.achievements={};
  S.stats={runs:0,kills:0,bestWave:0,earned:0,mxp:0};
  S.synthesisLabUnlocked=false;

  // Remove progression-only flags from previous updates. Keep normal UI/audio settings.
  delete S.__isoMxp15;
  delete S.__megaSig;
  delete S.__megaUnlock;

  // Do not let the old V38 startup reward grant another 2,000 after this reset.
  S.v38RestartAccepted=true;

  SAVE.save();
  try{SAVE.refreshCoins();}catch(e){}
  try{localStorage.setItem(MIG,'1');}catch(e){}

  console.log('ISOTOPE V39: full progress wiped; starting coins set to exactly 2,000.');
})();
