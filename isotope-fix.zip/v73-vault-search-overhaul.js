/* ISOTOPE V73/V76 — Periodic Vault search overhaul + live ownership lock state
   - removes the old synthesized-compound strip under the 118-element table
   - expands searchable-result area to 2.4x the previous V71 height
   - adds compound unlock-recency sorting
   - hides locked compound identity/formula/stats behind ???
   - keeps locked compounds at the bottom in a NOT UNLOCKED section
   - adds a separator on/off toggle
   - makes search-result cards clickable when safely selectable
   - repairs clicks on all 118 periodic-table element tiles
*/
(function(){
  'use strict';
  if(window.__ISO_V73_VAULT_SEARCH__) return;
  window.__ISO_V73_VAULT_SEARCH__=true;

  const $=s=>document.querySelector(s);
  const $$=s=>Array.from(document.querySelectorAll(s));
  const E=()=>Object.values(DATA.ELEMS||{});
  const STAT_CACHE=new Map(), CAT_CACHE=new Map();
  let renderRAF=0, renderScheduled=false;
  const M=()=>Object.keys(DATA.MOLDEF||{}).map(k=>{
    const m=DATA.MOLDEF[k];
    if(!m||!m.mol) return null;
    if(!m.id) m.id=k;
    return m;
  }).filter(Boolean);

  function isCompound(x){ return !!(x&&x.mol); }
  function isUnlocked(x){
    try{ return !!(DATA.isOwned && DATA.isOwned(x.id)); }catch(e){ return false; }
  }
  function safeName(x){ return String(x&&x.name||x&&x.sym||x&&x.id||''); }
  function safeId(x){ return String(x&&x.id||''); }
  function category(x){
    const ck=safeId(x); if(CAT_CACHE.has(ck)) return CAT_CACHE.get(ck);
    let result;
    if(window.__ISO_V71_VAULT__ && x && typeof x.mol!=='undefined'){
      const s=(safeName(x)+' '+String(x.f||'')+' '+String(x.desc||'')).toLowerCase();
      if(isCompound(x)){
        const out=[];
        if(/acid|hydrogen chloride|nitric acid|sulfuric acid|acetic acid|carbonic acid|hydrofluoric/.test(s)) out.push('Acids');
        if(/base|hydroxide|ammonia|amine/.test(s)) out.push('Bases');
        if(/salt|chloride|bromide|iodide|fluoride|nitrate|sulfate|phosphate|carbonate|permanganate|chromate/.test(s)) out.push('Salts');
        if(/drug|alkaloid|nicotine|caffeine|ibuprofen|aspirin|morphine|codeine|dopamine|serotonin/.test(s)) out.push('Drugs / Alkaloids');
        if(/organic|carbon|methane|ethanol|glucose|glycine|benzene|acetone|urea|lipid|amino/.test(s)) out.push('Organic Compounds');
        if(/explosive|nitroglycerin|peroxide|trinitrotoluene|tnt|azide/.test(s)) out.push('Explosive / Reactive');
        if(/bio|protein|peptide|amino|dna|rna|glucose|glycine|serotonin/.test(s)) out.push('Biochemical');
        if(!out.length) out.push(/carbon|hydrogen|oxygen|nitrogen|silicon|phosph|sulfur|chlor|brom|iod|fluor/.test(s)?'Organic / Molecular':'Inorganic Compounds');
        result=out; CAT_CACHE.set(ck,result); return result;
      }
      const c=(DATA.CATS&&DATA.CATS[x.cat]||{}).n||'';
      const out=[];
      const synthetic=(x.n>=95 || ['Technetium','Promethium','Astatine','Polonium','Francium'].includes(x.name));
      const radioactive=(x.n>=84 || x.n===43 || x.n===61);
      if(synthetic) out.push('Synthetic');
      if(radioactive) out.push('Radioactive');
      if(/halogen/i.test(c)) out.push('Halogens');
      else if(/noble gas/i.test(c)) out.push('Noble Gases');
      else if(/metal/i.test(c)) out.push('Metals');
      else if(/metalloid/i.test(c)) out.push('Metalloids');
      else out.push('Nonmetals');
      result=out.length?out:[c||'Elements']; CAT_CACHE.set(ck,result); return result;
    }
    result=['Elements']; CAT_CACHE.set(ck,result); return result;
  }
  function stats(x){
    const ck=safeId(x); if(STAT_CACHE.has(ck)) return STAT_CACHE.get(ck);
    try{
      const s=DATA.baseCombat(x);
      const out={dmg:+s.dmg||0,rate:+s.rate||0,vel:+s.ps||0,hp:+s.hp||0,spd:+s.spd||0,crit:+s.crit||0,pierce:+s.pierce||0,react:isCompound(x)?0:(DATA.CATS[x.cat]||{}).react||0,toxic:isCompound(x)?0:(DATA.CATS[x.cat]||{}).tox||0}; STAT_CACHE.set(ck,out); return out;
    }catch(e){ const out={dmg:0,rate:0,vel:0,hp:0,spd:0,crit:0,pierce:0,react:0,toxic:0}; STAT_CACHE.set(ck,out); return out; }
  }
  function fav(x){
    try{ return !!(SAVE.isFav?SAVE.isFav(x.id):(SAVE.raw.favs||[]).includes(x.id)); }catch(e){ return false; }
  }
  function molIndex(x){
    if(!isCompound(x)) return -1;
    try{return (SAVE.raw.mols||[]).indexOf(String(x.id));}catch(e){return -1;}
  }
  function power(x){
    const s=stats(x);
    return s.dmg*2+s.rate*8+s.vel/70+s.hp/8+s.spd/20+s.crit*2+s.pierce*5+s.react*3+s.toxic*3;
  }

  function ensureSepToggle(){
    const host=$('#vault-v71-controls');
    if(!host) return null;
    let b=$('#vault-v73-separators');
    if(!b){
      b=document.createElement('button');
      b.type='button';
      b.id='vault-v73-separators';
      b.className='vault-v73-toggle';
      b.dataset.on='1';
      b.addEventListener('click',function(ev){
        ev.preventDefault();
        ev.stopPropagation();
        b.dataset.on=b.dataset.on==='1'?'0':'1';
        updateSepButton();
        queueRender();
        try{SFX.click()}catch(e){}
      });
    }
    /* Keep it underneath the search bar, in the same row as TYPE/SORT filters. */
    if(b.parentElement!==host) host.appendChild(b);
    updateSepButton();
    return b;
  }
  function updateSepButton(){
    const b=$('#vault-v73-separators'); if(!b) return;
    const on=b.dataset.on!=='0';
    b.textContent=on?'SEPARATORS ON':'SEPARATORS OFF';
    b.setAttribute('aria-pressed',String(on));
    b.classList.toggle('active',on);
  }
  function sepOn(){const b=$('#vault-v73-separators');return !b||b.dataset.on!=='0';}

  function ensureRecentSortOptions(){
    const sel=$('#vault-v71-sort'); if(!sel) return;
    const vals=[...sel.options].map(o=>o.value);
    if(!vals.includes('recent:desc')){
      const o1=document.createElement('option'); o1.value='recent:desc'; o1.textContent='NEWEST UNLOCKED COMPOUND → OLDEST'; sel.appendChild(o1);
    }
    if(!vals.includes('recent:asc')){
      const o2=document.createElement('option'); o2.value='recent:asc'; o2.textContent='OLDEST UNLOCKED COMPOUND → NEWEST'; sel.appendChild(o2);
    }
  }

  function safeSearchText(x){
    const cats=category(x).join(' ');
    /* Locked catalog entries may still be found by generic type/category searches,
       but their names, symbols, formulas and IDs are never exposed to the result renderer. */
    if(!isUnlocked(x)) return '??? not unlocked '+cats;
    return (safeName(x)+' '+String(x.sym||'')+' '+String(x.f||'')+' '+safeId(x)+' '+String(x.n||'')+' '+cats).toLowerCase();
  }

  function value(x,key){
    const s=stats(x);
    if(key==='name') return safeName(x).toLowerCase();
    if(key==='z') return Number(x.n)||0;
    if(key==='dmg') return s.dmg;
    if(key==='rate') return s.rate;
    if(key==='vel') return s.vel;
    if(key==='hp') return s.hp;
    if(key==='spd') return s.spd;
    if(key==='crit') return s.crit;
    if(key==='pierce') return s.pierce;
    if(key==='react') return s.react;
    if(key==='toxic') return s.toxic;
    if(key==='power') return power(x);
    if(key==='owned') return isUnlocked(x)?1:0;
    if(key==='fav') return fav(x)?1:0;
    if(key==='rarity') return Number(x.cost)||0;
    return 0;
  }

  function cmp(a,b,key,dir){
    if(key==='recent'){
      const ar=isCompound(a)&&isUnlocked(a), br=isCompound(b)&&isUnlocked(b);
      if(ar!==br) return ar?-1:1;
      if(!ar) return 0;
      const ai=molIndex(a), bi=molIndex(b);
      if(ai===bi) return 0;
      return dir==='desc'?bi-ai:ai-bi;
    }
    const av=value(a,key), bv=value(b,key);
    if(typeof av==='string'||typeof bv==='string') return dir==='asc'?String(av).localeCompare(String(bv)):String(bv).localeCompare(String(av));
    return dir==='asc'?av-bv:bv-av;
  }

  function makeCard(x){
    const unlocked=isUnlocked(x), compound=isCompound(x);
    const d=document.createElement('button');
    d.type='button';
    d.className='vault-v73-card'+(unlocked?' unlocked':' locked')+(fav(x)?' favorite':'')+(compound?' compound':' element');
    try{ d.dataset.id=DATA.canonicalId?DATA.canonicalId(x.id):String(x.id||''); }catch(e){ d.dataset.id=String(x.id||''); }
    const c=x.hue==null?'190':x.hue;
    d.style.setProperty('--vcol',`hsl(${c} 72% 62%)`);

    if(!unlocked){
      d.innerHTML='<strong class="v73-unknown">???</strong>';
      d.title='NOT UNLOCKED';
      d.setAttribute('aria-disabled','true');
      /* Locked entries are intentionally clickable only for feedback.  They
         must never expose identity or route into the Vault selection panel. */
      d.addEventListener('click',function(ev){
        ev.preventDefault();
        ev.stopPropagation();
        try{
          if(window.AUDIO&&AUDIO.SFX&&typeof AUDIO.SFX.select==='function') AUDIO.SFX.select();
          else if(window.AUDIO&&AUDIO.SFX&&typeof AUDIO.SFX.click==='function') AUDIO.SFX.click();
        }catch(e){}
      });
      return d;
    }

    const s=stats(x), cats=category(x).join(' · ');
    d.innerHTML=`<span class="v73-top"><b>${compound?'⚗':(x.sym||'')}</b><i>${fav(x)?'★':'☆'}</i></span><strong>${safeName(x)}</strong><small>${compound?(x.f||'COMPOUND'):'Z = '+(x.n||'?')} · ${cats}</small><span class="v73-stats">DMG ${s.dmg.toFixed(1)} · CRIT ${s.crit.toFixed(1)} · RATE ${s.rate.toFixed(2)} · HP ${Math.round(s.hp)}</span>`;
    d.addEventListener('click',function(ev){
      ev.preventDefault();ev.stopPropagation();
      try{ if(window.AUDIO&&AUDIO.SFX&&typeof AUDIO.SFX.select==='function') AUDIO.SFX.select(); else if(window.AUDIO&&AUDIO.SFX&&typeof AUDIO.SFX.click==='function') AUDIO.SFX.click(); }catch(e){}
      try{
        const targetId = DATA.canonicalId ? DATA.canonicalId(x.id || x.f || x.name) : x.id;
        if(typeof window.__ISO_SELECT_VAULT==='function') window.__ISO_SELECT_VAULT(targetId);
        else if(typeof selectVault==='function') selectVault(targetId);
      }catch(e){console.warn('V75 search card select',e)}
    });
    return d;
  }

  let renderDebounce=0;
  function queueRender(){
    clearTimeout(renderDebounce);
    renderDebounce=setTimeout(function(){
      if(renderScheduled)return; renderScheduled=true;
      if(renderRAF)cancelAnimationFrame(renderRAF);
      renderRAF=requestAnimationFrame(function(){renderScheduled=false;renderRAF=0;render();});
    },55);
  }

  function render(){
    const main=$('#vault-main'), search=$('#vault-element-search'), cat=$('#vault-v71-catalog');
    if(!main||!search||!cat) return;
    ensureSepToggle(); ensureRecentSortOptions();

    // Remove the old synthesized-compound strip; the catalog/search area is now the single result surface.
    const strip=$('#molstrip'); if(strip) strip.style.display='none';
    const favrow=$('#favrow'); if(favrow) favrow.style.display='none';

    const input=$('#vault-element-search-input');
    if(input) input.placeholder='SEARCH ELEMENTS OR COMPOUNDS BY NAME, SYMBOL, FORMULA, ID, NUMBER, OR TYPE';
    const term=(input?.value||'').trim().toLowerCase();
    const type=$('#vault-v71-type')?.value||'';
    const sort=$('#vault-v71-sort')?.value||'name:asc';
    const [key,dir]=sort.split(':');
    let items=E().concat(M());

    items=items.filter(x=>{
      if(type&&!category(x).includes(type)) return false;
      return !term || safeSearchText(x).includes(term);
    });

    // Nothing locked mixes into the owned/searchable result stream. Locked entries stay at the very bottom.
    const lockedItems=items.filter(x=>!isUnlocked(x));
    const normal=items.filter(x=>isUnlocked(x));
    normal.forEach((x,i)=>x.__v73Order=i);
    normal.sort((a,b)=>{const r=cmp(a,b,key,dir);return r||a.__v73Order-b.__v73Order;});
    normal.forEach(x=>{try{delete x.__v73Order}catch(e){}});

    cat.innerHTML='';
    if(!normal.length&&!lockedItems.length){
      cat.innerHTML='<div class="vault-v71-empty">NO MATCHES FOR THIS SEARCH / FILTER.</div>';
      return;
    }

    const appendSection=(title,arr,lockedSection)=>{
      if(!arr.length)return;
      const grid=document.createElement('div'); grid.className='vault-v73-grid';
      arr.forEach(x=>grid.appendChild(makeCard(x)));
      if(sepOn()){
        const sec=document.createElement('section');sec.className='vault-v73-group'+(lockedSection?' locked-section':'');
        const h=document.createElement('div');h.className='vault-v73-sep';h.innerHTML=title.toUpperCase()+` <span>· ${arr.length}</span>`;
        sec.appendChild(h);sec.appendChild(grid);cat.appendChild(sec);
      }else{
        cat.appendChild(grid);
      }
    };

    if(key==='recent' || key==='recent'){
      // With recency sorting, the unlocked compound subset has its own meaningful ordering.
      appendSection('SEARCH RESULTS',normal,false);
    }else if(sepOn()){
      const groups={};
      normal.forEach(x=>{const g=category(x)[0]||'Other';(groups[g]||(groups[g]=[])).push(x);});
      Object.keys(groups).sort((a,b)=>a.localeCompare(b)).forEach(g=>appendSection(g,groups[g],false));
    }else{
      appendSection('',normal,false);
    }

    if(lockedItems.length){
      // All locked elements/compounds are grouped separately at the absolute bottom.
      appendSection('NOT UNLOCKED',lockedItems,true);
    }
  }

  function syncElementSearchTiles(){
    const scr=$('#scr-vault'); if(!scr||scr.classList.contains('hidden')) return;
    $$('#ptable .pt[data-id]').forEach(tile=>{
      const id=tile.dataset.id;
      tile.style.pointerEvents='auto';
      tile.style.cursor='pointer';
      tile.style.touchAction='manipulation';
      tile.onclick=function(ev){
        ev.preventDefault();ev.stopPropagation();
        try{ if(window.AUDIO&&AUDIO.SFX&&typeof AUDIO.SFX.select==='function') AUDIO.SFX.select(); else if(window.AUDIO&&AUDIO.SFX&&typeof AUDIO.SFX.click==='function') AUDIO.SFX.click(); }catch(e){}
        try{
          const targetId=DATA.canonicalId?DATA.canonicalId(id):id;
          if(typeof window.__ISO_SELECT_VAULT==='function') window.__ISO_SELECT_VAULT(targetId); else if(typeof selectVault==='function') selectVault(targetId);
        }catch(e){console.warn('V75 periodic tile select',e)}
      };
    });
  }

  function bind(){
    const search=$('#vault-element-search');
    if(!search)return;
    ensureSepToggle();
    ensureRecentSortOptions();
    const input=$('#vault-element-search-input');
    if(input&&!input.__v73Bound){input.__v73Bound=true;input.addEventListener('input',queueRender);}
    const type=$('#vault-v71-type');
    if(type&&!type.__v73Bound){type.__v73Bound=true;type.addEventListener('change',queueRender);}
    const sort=$('#vault-v71-sort');
    if(sort&&!sort.__v73Bound){sort.__v73Bound=true;sort.addEventListener('change',queueRender);}
    syncElementSearchTiles();
    render();
  }

  // Capture-phase fallback: even if an older handler changes/stops propagation, a clicked
  // periodic-table element still resolves to the corresponding right-side detail panel.
  if(!window.__ISO_V73_PERIODIC_CLICK__){
    window.__ISO_V73_PERIODIC_CLICK__=true;
    document.addEventListener('click',function(ev){
      const t=ev.target&&ev.target.closest?ev.target.closest('#scr-vault #ptable .pt[data-id]'):null;
      if(!t)return;
      try{
        const id=t.dataset.id;
        const chooser=(typeof window.__ISO_SELECT_VAULT==='function') ? window.__ISO_SELECT_VAULT : (typeof selectVault==='function' ? selectVault : null);
        if(chooser){
          ev.preventDefault();
          ev.stopPropagation();
          try{ if(window.AUDIO&&AUDIO.SFX&&typeof AUDIO.SFX.select==='function') AUDIO.SFX.select(); else if(window.AUDIO&&AUDIO.SFX&&typeof AUDIO.SFX.click==='function') AUDIO.SFX.click(); }catch(e){}
          chooser(DATA.canonicalId?DATA.canonicalId(id):id);
        }
      }catch(e){console.warn('V73 document element click',e)}
    },true);
  }

  const oldShow=window.UI&&UI.show;
  if(oldShow&&!UI.__v73Show){
    UI.show=function(id){
      const r=oldShow.apply(this,arguments);
      if(id==='scr-vault'){
        requestAnimationFrame(bind);
      }
      return r;
    };
    UI.__v73Show=true;
  }

  document.addEventListener('click',function(ev){
    if(ev.target.closest&&ev.target.closest('[data-go="scr-vault"]')){
      requestAnimationFrame(bind);
    }
  },true);

  const style=document.createElement('style');
  style.textContent=`
    /* V73: search-result surface = 2.4x the previous 48vh V71 max-height (115.2vh). */
    #vault-v71-catalog{height:115.2vh;max-height:115.2vh;overflow:auto;scroll-behavior:auto}
    #molstrip,#favrow{display:none!important}
    #vault-v73-separators{flex:0 0 auto;margin-left:auto;border:1px solid var(--line);background:#0c1320;color:var(--tx2);font:9px var(--mono);padding:6px 8px;cursor:pointer;letter-spacing:.06em;white-space:nowrap}
    #vault-v73-separators.active{color:var(--cy);border-color:#2b7180;box-shadow:inset 0 0 0 1px rgba(79,216,235,.12)}
    #vault-v73-separators:hover{color:var(--tx);border-color:var(--cy)}
    .vault-v73-group{margin-bottom:15px}.vault-v73-sep{font:11px var(--mono);letter-spacing:.18em;color:var(--cy);padding:6px 4px;border-bottom:1px solid var(--line);margin-bottom:7px}.vault-v73-sep span{color:var(--tx3);letter-spacing:0}
    .vault-v73-group.locked-section .vault-v73-sep{color:var(--tx3);border-color:#2a3343}
    .vault-v73-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(175px,1fr));gap:7px}
    .vault-v73-card{position:relative;text-align:left;background:#0c1320;border:1px solid color-mix(in srgb,var(--vcol),transparent 45%);color:var(--tx);padding:8px;cursor:pointer;min-height:91px;font-family:var(--mono);transition:transform .1s,opacity .1s,border-color .1s}
    .vault-v73-card:hover{border-color:var(--vcol);transform:translateY(-1px)}
    .vault-v73-card.locked{opacity:.42;filter:grayscale(.72);cursor:pointer}
    .vault-v73-card.locked{border-color:#3b4350!important;color:#656e7c;display:flex;align-items:center;justify-content:center;text-align:center;min-height:70px;cursor:not-allowed!important;pointer-events:auto!important}.vault-v73-card.compound.locked{border-color:#3b4350;color:#656e7c}
    .vault-v73-card.compound.locked:hover{border-color:#5a6573;transform:none}
    .v73-unknown{font-size:20px;letter-spacing:.22em;color:#737b89}
    .v73-top{display:flex;justify-content:space-between;color:var(--vcol);font-size:16px}.v73-top i{font-style:normal;color:var(--am)}
    .vault-v73-card strong{display:block;color:var(--vcol);font-size:12px;margin-top:4px}.vault-v73-card small{display:block;color:var(--tx3);font-size:8px;line-height:1.3;margin-top:3px}.v73-stats{display:block;color:var(--tx2);font-size:8px;line-height:1.35;margin-top:5px}
    .vault-v73-card.element.locked{opacity:.34}
    @media(max-width:700px){#vault-v73-separators{padding:5px 6px;font-size:8px}.vault-v73-grid{grid-template-columns:1fr 1fr}#vault-v71-catalog{height:115.2vh;max-height:115.2vh}}
  `;
  document.head.appendChild(style);
  setTimeout(bind,0);
  console.log('ISOTOPE V73 VAULT SEARCH OVERHAUL active');
})();
