/* ISOTOPE V72 — screen-layer / main-menu frame safety
   The previous build had a malformed closing <div> around the main menu. That
   caused #app to close early, leaving every other .screen outside #app. Since
   #app is a full-screen z-index layer, the main-menu frame could then sit over
   the actual screen and swallow all scrolling/clicks.

   V72 keeps the corrected HTML structure and adds a small runtime guard so a
   future DOM mutation cannot recreate the same layering problem. It also makes
   the changelog panel invisible on non-menu screens so it can never intercept
   interaction outside the main menu. No gameplay/UI feature is removed. */
'use strict';
(function(){
  if(window.__ISO_V72_SCREEN_LAYER_FIX__) return;
  window.__ISO_V72_SCREEN_LAYER_FIX__ = true;

  function repairLayers(){
    var app=document.getElementById('app');
    if(!app) return;

    /* Any full-screen screen that ever escapes #app must be moved back into it.
       appendChild preserves the live element and all of its event listeners. */
    var screens=document.querySelectorAll('.screen');
    for(var i=0;i<screens.length;i++){
      var s=screens[i];
      if(s.parentElement!==app) app.appendChild(s);
    }

    var toasts=document.getElementById('toasts');
    if(toasts && toasts.parentElement!==app) app.appendChild(toasts);

    /* Keep the menu's changelog panel strictly confined to the menu screen. */
    var panel=document.getElementById('mega-update-panel');
    var menu=document.getElementById('scr-menu');
    if(panel && menu){
      var menuActive=!menu.classList.contains('hidden');
      panel.style.setProperty('display', menuActive ? 'block' : 'none', 'important');
      panel.style.setProperty('pointer-events', menuActive ? 'none' : 'none', 'important');
    }
  }

  repairLayers();
  setTimeout(repairLayers,0);
  setTimeout(repairLayers,100);
  setTimeout(repairLayers,500);
  setTimeout(repairLayers,1500);

  if(window.MutationObserver){
    try{
      var bodyObserver=new MutationObserver(function(){ repairLayers(); });
      if(document.body) bodyObserver.observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['class']});
    }catch(e){}
  }

  /* Use the actual navigation API when available instead of relying only on a
     click event. This also covers keyboard-triggered navigation and code paths
     that call UI.show() directly. */
  function hookUI(){
    if(!window.UI || typeof UI.show!=='function' || UI.__v72LayerHook) return;
    var base=UI.show;
    UI.show=function(id){
      var out=base.apply(this,arguments);
      setTimeout(repairLayers,0);
      setTimeout(repairLayers,60);
      return out;
    };
    UI.__v72LayerHook=true;
  }
  hookUI();
  setTimeout(hookUI,50);
  setTimeout(hookUI,250);

  console.log('ISOTOPE V72 SCREEN LAYER FIX active: corrected #app nesting, guarded screen layers, and isolated the update panel to the main menu.');
})();
