/* ISOTOPE V84 — Manual wave start, augmentation projectile scaling, clean cards,
   permanent Nicotine team allies, and runtime safety. */
(function(){
  'use strict';
  if(window.__ISO_V84_FINAL_FIXES__)return;
  window.__ISO_V84_FINAL_FIXES__=true;
  var C=window.ISO_V23_CORE||{};

  function run(){return window.RUN||null;}
  function local(){var r=run();return r&&r.players?((r.players[r.localNetId||0]||r.players[0])||null):null;}
  function alive(e){return !!e&&!e.dead;}
  function d2(x1,y1,x2,y2){var x=x1-x2,y=y1-y2;return x*x+y*y;}
  function host(){var r=run();return !r || !r.isOnline || !window.NET || NET.isHost;}
  function nicotine(p){var e=p&&p.elem;return !!(e&&e.mol&&String(e.name||'').toLowerCase()==='nicotine');}
  function hostiles(){var r=run();return r&&Array.isArray(r.enemies)?r.enemies.filter(function(e){return alive(e)&&!e.boss&&!e.befriended&&e.team!=='player';}):[];}
  function nicotineAllies(){var r=run();return r&&Array.isArray(r.allies)?r.allies.filter(function(a){return alive(a)&&a.befriended&&a.team==='player';}):[];}
  function owner(id){var r=run();if(!r||!r.players)return null;return r.players.find(function(p){return p&&p.id===id;})||r.players[0]||null;}
  function roleFor(e){
    var t=e&&e.type||'';
    if(['spitter','sniper','juggler','orbiter','drone','spark','voltconductor','mirror','glasslancer','emberdrone','echohound','ionserpent','stormbeacon'].indexOf(t)>=0)return 'ranged';
    if(['healer','pylon','shielder','anchor','frostbinder','voidsentry'].indexOf(t)>=0)return 'support';
    if(['bomber','charger','plasmacrusher','corroswirl','flareling'].indexOf(t)>=0)return 'breaker';
    if(['seeder','splitter','crystalwarden'].indexOf(t)>=0)return 'summoner';
    return 'melee';
  }

  /* ------------------------------------------------------------------
     Manual wave starts
     ------------------------------------------------------------------ */
  function normalizeIntermission(){
    var r=run();if(!r||r.mode==='pvp'||r.mode==='net_pvp')return;
    var auto=!!(SAVE.raw&&SAVE.raw.settings&&SAVE.raw.settings.autoWave);
    if(r.state==='inter' && !auto) r.interT=0;
  }
  var getUpdate=C.getUpdate,setUpdate=C.setUpdate;
  if(typeof getUpdate==='function'&&typeof setUpdate==='function'){
    var baseUpdate=getUpdate();
    if(typeof baseUpdate==='function'&&!baseUpdate.__v84WaveUpdate){
      var upd=function(dt){
        var out=baseUpdate.apply(this,arguments);
        var r=run();
        if(r){
          normalizeIntermission();
          (r.players||[]).forEach(function(p){
            if(!p)return;
            if(!Number.isFinite(Number(p.activeCd))||Number(p.activeCd)<0)p.activeCd=0;
            if(!Number.isFinite(Number(p.dashCd))||Number(p.dashCd)<0)p.dashCd=0;
          });
        }
        return out;
      };
      upd.__v84WaveUpdate=true;setUpdate(upd);
    }
  }
  /* Settings can be toggled while the game is paused/interstitial. */
  document.addEventListener('change',function(e){
    if(!e.target||e.target.id!=='auto-wave')return;
    var r=run();if(!r)return;
    r.interT=(e.target.checked?4:0);
  },true);

  /* ------------------------------------------------------------------
     Card pool cleanup
     ------------------------------------------------------------------ */
  function installCleanCards(){
    var cards=window.ALL_CARDS;if(!Array.isArray(cards))return;
    var removed={generated:0,stack:0,dupe:0};
    var keep=[];
    cards.forEach(function(c){
      if(!c){return;}
      var id=String(c.id||''),d=String(c.d||'');
      /* Generic percentage/progress cards from older generated pools are the
         duplicates the player asked to remove. Keep bespoke named ability cards. */
      var generic=/^(?:xcard_|content_card_|v50_stat_)/i.test(id) || !!c.extraStat;
      if(generic){removed.generated++;return;}
      if(/\bstack\b/i.test(d) && /%|progress|while equipped|to get \+?\d/i.test(d)){
        removed.stack++;return;
      }
      keep.push(c);
    });
    /* One direct card per clean stat mechanic. No stack/progress wording. */
    var defs=[
      ['dmg','⚔','Focused Damage','Projectiles deal +10% damage.','common',0.10],
      ['rate','↯','Rapid Fire','Fire rate is +8%.','uncommon',0.08],
      ['hp','♥','Reinforced Hull','Maximum HP is +12.','common',12],
      ['spd','➤','Thruster Boost','Movement speed is +8%.','common',0.08],
      ['crit','✧','Critical Mass','Critical chance is +8%.','rare',0.08],
      ['shield','◈','Shield Reserve','Maximum shield is +15.','uncommon',15],
      ['magnet','◎','Pickup Field','Pickup range is +10%.','uncommon',0.10],
      ['coin','◈','Coin Matrix','Coin gain is +10%.','rare',0.10],
      ['pierce','➤','Penetrator','Gain +1 pierce.','uncommon',1/1.25],
      ['aoe','✹','Reaction Radius','Ability and reaction radius is +10%.','uncommon',0.10/1.25],
      ['homing','⌖','Guidance Core','Homing strength is +10%.','uncommon',0.10],
      ['projs','⋔','Particle Split','Gain +1 additional projectile.','rare',1/1.5]
    ];
    defs.forEach(function(x){
      keep.push({id:'v84_direct_'+x[0],ic:x[1],n:x[2],d:x[3],rarity:x[4],max:1,extraStat:x[0],extraValue:x[5],finalTarget:x[5],unique:true,v84Direct:true});
    });
    /* Remove duplicate generated cards by mechanic, while leaving distinct
       bespoke ability/reaction cards alone. */
    var seenMechanic={};
    keep=keep.filter(function(c){
      if(!c.extraStat)return true;
      var k='extra:'+String(c.extraStat);
      if(seenMechanic[k]){removed.dupe++;return false;}
      seenMechanic[k]=1;return true;
    });
    /* Guarantee all surviving +projectile stat cards are Rare or above. */
    keep.forEach(function(c){
      if(c.extraStat==='projs'){
        c.rarity='rare';
        if(!c.d||/stack|progress/i.test(String(c.d)))c.d='Gain +1 additional projectile.';
      }
      if(/\+\s*1[^.]{0,24}projectile/i.test(String(c.n||'')+' '+String(c.d||''))){
        var order={common:0,uncommon:1,rare:2,epic:3,legendary:4,mythic:5};
        if((order[c.rarity||'common']||0)<2)c.rarity='rare';
      }
    });
    cards.length=0;Array.prototype.push.apply(cards,keep);
    window.ISO_V84_CARD_AUDIT={removed:removed,count:cards.length,projectileCards:cards.filter(function(c){return c.extraStat==='projs';}).map(function(c){return c.id;})};
  }
  installCleanCards();

  /* ------------------------------------------------------------------
     Permanent Nicotine befriending — all three signatures
     ------------------------------------------------------------------ */
  function convert(e,ownerId){
    var r=run();if(!r||!e||e.dead||e.boss||e.befriended||e.team==='player')return null;
    r.allies=r.allies||[];
    var count=r.allies.filter(function(a){return a&&a.befriended&&a.team==='player'&&a.hp>0;}).length;
    if(count>=40)return null;
    var p=owner(ownerId),maxhp=Math.max(1,Number(e.maxhp)||Number(e.hp)||20),hue=p&&p.elem&&Number.isFinite(+p.elem.hue)?+p.elem.hue:145;
    var a={
      eid:e.eid||('nico_'+Date.now()+'_'+Math.random()),sourceEid:e.eid,sourceEnemy:e.type,type:e.type||'mote',
      name:e.name||((window.DATA&&DATA.ETYPES&&DATA.ETYPES[e.type]||{}).name)||e.type||'ALLY',x:Number(e.x)||0,y:Number(e.y)||0,r:Number(e.r)||10,
      hp:Math.max(1,Math.min(maxhp,Number(e.hp)||maxhp*.75)),maxhp:maxhp,spd:Math.max(55,Number(e.spd)||100),dmg:Math.max(1,Number(e.dmg)||10),
      hue:hue,playerHue:hue,shape:e.shape||'dot',ownerId:p?p.id:ownerId,team:'player',befriended:true,permanent:true,nicotineAlly:true,incomingMul:.5,
      shootT:Math.max(.15,Number(e.shootT)||.6),specialT:Math.max(.4,Number(e.specialT)||1.2),healT:Math.max(.5,Number(e.healT)||1),chargeT:Math.max(.5,Number(e.chargeT)||2),
      charge:0,chargeTarget:0,targetEid:0,pickupT:0,hurtT:0,orb:Number(e.orb)||Math.random()*Math.PI*2,special:e.special||null,pat:e.pat||null,fast:!!e.fast,
      canCharge:!!e.canCharge,seed:e.seed||0,elite:!!e.elite,aiRole:roleFor(e),decay:Infinity,decayT:Infinity,_v84:true
    };
    r.allies.push(a);
    e.dead=true;e._befriended=true;e.befriended=true;e.team='player';e._v84Converted=true;e._removedFromEnemyTeam=true;e._nicotineFriend=false;e._nicotineOwner=null;e._nicotineFriendT=0;
    try{
      if(typeof window.ringFx==='function')window.ringFx(a.x,a.y,155,105);
      if(window.ISO_SFX&&ISO_SFX.charm)ISO_SFX.charm(); else if(window.SFX&&SFX.unlock)SFX.unlock();
      if(r.texts)r.texts.push({x:a.x,y:a.y-a.r-18,t:.9,life:.9,s:'ALLY JOINED',big:true,col:'#7ef0a6'});
    }catch(_){ }
    return a;
  }
  function shootCharm(p,slot){
    var r=run();if(!r||!p)return;
    if(slot===0){
      r._v84CharmShots=r._v84CharmShots||[];
      var a=p.angle||0, speed=Math.max(260,Number(ST&&ST.ps)||380);
      r._v84CharmShots.push({x:p.x+Math.cos(a)*18,y:p.y+Math.sin(a)*18,vx:Math.cos(a)*speed*1.6,vy:Math.sin(a)*speed*1.6,r:8,life:1.8,owner:p.id});
      return;
    }
    var hs=hostiles();
    if(slot===1){
      hs.sort(function(a,b){return d2(a.x,a.y,p.x,p.y)-d2(b.x,b.y,p.x,p.y);});
      if(hs[0])convert(hs[0],p.id);
      return;
    }
    /* Signature 3: visible radial BEFRIEND AURA. It recruits every hostile
       inside the aura, with no damage/ring attack attached to the cast. */
    var radius=Math.min(Number(window.W)||window.innerWidth||1280,Number(window.H)||window.innerHeight||720)*.25,r2=radius*radius;
    r._v85NicoAuraFx=r._v85NicoAuraFx||[];
    r._v85NicoAuraFx.push({x:p.x,y:p.y,r:radius,t:.34});
    for(var i=0;i<hs.length;i++)if(d2(hs[i].x,hs[i].y,p.x,p.y)<=r2)convert(hs[i],p.id);
  }
  function stepCharm(dt){
    var r=run();if(!r)return;
    if(r._v85NicoAuraFx){for(var af=r._v85NicoAuraFx.length-1;af>=0;af--){r._v85NicoAuraFx[af].t-=dt;if(r._v85NicoAuraFx[af].t<=0)r._v85NicoAuraFx.splice(af,1);}}
    if(!r._v84CharmShots)return;
    var shots=r._v84CharmShots;
    for(var i=shots.length-1;i>=0;i--){
      var b=shots[i];if(!b){shots.splice(i,1);continue;}
      b.life-=dt;b.x+=b.vx*dt;b.y+=b.vy*dt;
      if(b.life<=0||b.x<-40||b.x>W+40||b.y<-40||b.y>H+40){shots.splice(i,1);continue;}
      var hs=hostiles(),hit=null,bd=Infinity;
      for(var j=0;j<hs.length;j++){var e=hs[j],dd=d2(b.x,b.y,e.x,e.y),rr=(b.r+e.r)*(b.r+e.r);if(dd<rr&&dd<bd){bd=dd;hit=e;}}
      if(hit){convert(hit,b.owner);shots.splice(i,1);}
    }
  }
  var getUse=C.getUseActive,setUse=C.setUseActive;
  if(typeof getUse==='function'&&typeof setUse==='function'){
    var baseUse=getUse();
    if(typeof baseUse==='function'&&!baseUse.__v84NicotineUse){
      var use=function(p){
        if(nicotine(p)&&p&&!p.downed&&Number(p.activeCd||0)<=0){
          var slot=Math.max(0,Math.min(2,Number(p.signatureSlot)||0));
          p.activeCd=Math.max(.1,Number(ST&&ST.activeCd)||1.5);try{if(window.SFX&&SFX.active)SFX.active();}catch(_){ }
          if(slot===0){shootCharm(p,0);return;}
          shootCharm(p,slot);return;
        }
        return baseUse.apply(this,arguments);
      };
      use.__v84NicotineUse=true;setUse(use);
    }
  }
  var getUpdate2=C.getUpdate,setUpdate2=C.setUpdate;
  if(typeof getUpdate2==='function'&&typeof setUpdate2==='function'){
    var baseUpd=getUpdate2();
    if(typeof baseUpd==='function'&&!baseUpd.__v84NicotineUpdate){
      var u2=function(dt){
        stepCharm(dt);
        var out=baseUpd.apply(this,arguments);
        var r=run();
        if(r){
          if(r.enemies)r.enemies=r.enemies.filter(function(e){return alive(e)&&!e._v84Converted&&!e._befriended&&!e.befriended&&e.team!=='player';});
          r.allies=r.allies||[];
          for(var i=r.allies.length-1;i>=0;i--){
            var a=r.allies[i];
            if(!a||!a.befriended||a.team!=='player')continue;
            a.permanent=true;a.decay=Infinity;a.decayT=Infinity;a.nicotineAlly=true;
            if(a.hp<=0){r.allies.splice(i,1);continue;}
          }
        }
        return out;
      };
      u2.__v84NicotineUpdate=true;setUpdate2(u2);
    }
  }
  var getRender=C.getRender,setRender=C.setRender;
  if(typeof getRender==='function'&&typeof setRender==='function'){
    var baseRender=getRender();
    if(typeof baseRender==='function'&&!baseRender.__v84CharmRender){
      var rr=function(){
        baseRender();var r=run();if(!r)return;
        (r._v84CharmShots||[]).forEach(function(b){
          try{cx.save();cx.translate(b.x,b.y);cx.rotate(Math.atan2(b.vy,b.vx));cx.fillStyle='#d9ffe8';cx.strokeStyle='#7ef0a6';cx.shadowBlur=12;cx.shadowColor='#7ef0a6';cx.beginPath();cx.moveTo(9,0);cx.lineTo(-7,-4);cx.lineTo(-4,0);cx.lineTo(-7,4);cx.closePath();cx.fill();cx.stroke();cx.restore();}catch(_){ }
        });
        (r._v85NicoAuraFx||[]).forEach(function(f){if(!f)return;try{cx.save();cx.strokeStyle='rgba(126,240,166,'+Math.max(0,Math.min(1,f.t/.34))*.9+')';cx.lineWidth=4;cx.beginPath();cx.arc(f.x,f.y,f.r*(1-(f.t/.34)*.08),0,Math.PI*2);cx.stroke();cx.restore();}catch(_){}});
        (r.allies||[]).forEach(function(a){if(!a||!a.befriended||a.team!=='player'||a.hp<=0)return;try{var pulse=.8+.2*Math.sin((r.t||0)*5+(a.eid||0));cx.save();cx.strokeStyle='rgba(126,240,166,'+(.8*pulse)+')';cx.lineWidth=3;cx.beginPath();cx.arc(a.x,a.y,(a.r||10)+8,0,Math.PI*2);cx.stroke();cx.fillStyle='#7ef0a6';cx.font='bold 9px "Share Tech Mono"';cx.textAlign='center';cx.fillText('ALLY',a.x,a.y-(a.r||10)-14);cx.restore();}catch(_){ }});
      };
      rr.__v84CharmRender=true;setRender(rr);
    }
  }

  /* M1 25% weaken/slow guard, using stable base values instead of repeated multiplication. */
  var oldApply=(typeof C.getApplyElemHit==='function')?C.getApplyElemHit():null;
  if(typeof C.setApplyElemHit==='function'&&typeof oldApply==='function'&&!oldApply.__v84NicoM1){
    var ah=function(b,e){
      var out=oldApply.apply(this,arguments);
      if(b&&e&&b._v26NicoM1&&alive(e)&&!e.boss){
        if(e._v84NicoSpd==null)e._v84NicoSpd=Number(e.spd)||0;
        if(e._v84NicoDmg==null)e._v84NicoDmg=Number(e.dmg)||0;
        e._v84NicoSlowT=Math.max(Number(e._v84NicoSlowT)||0,2.75);e._v84NicoWeakT=Math.max(Number(e._v84NicoWeakT)||0,2.75);
        e.spd=e._v84NicoSpd*.75;e.dmg=e._v84NicoDmg*.75;
      }
      return out;
    };
    ah.__v84NicoM1=true;C.setApplyElemHit(ah);
  }
  /* Update debuff timers without multiplying values each frame. */
  if(typeof getUpdate2==='function'&&typeof setUpdate2==='function'){
    var bu=getUpdate2();
    if(typeof bu==='function'&&!bu.__v84DebuffFix){
      var du=function(dt){var out=bu.apply(this,arguments),r=run();if(r&&r.enemies){r.enemies.forEach(function(e){if(!e)return;if(e._v84NicoSlowT>0){e._v84NicoSlowT=Math.max(0,e._v84NicoSlowT-dt);if(e._v84NicoSpd!=null)e.spd=e._v84NicoSpd*.75;}else if(e._v84NicoSpd!=null)e.spd=e._v84NicoSpd;if(e._v84NicoWeakT>0){e._v84NicoWeakT=Math.max(0,e._v84NicoWeakT-dt);if(e._v84NicoDmg!=null)e.dmg=e._v84NicoDmg*.75;}else if(e._v84NicoDmg!=null)e.dmg=e._v84NicoDmg;});}return out;};
      du.__v84DebuffFix=true;setUpdate2(du);
    }
  }
  /* No ChromeOS throttling or artificial caps are introduced here. */
  console.log('ISOTOPE V84 FINAL: manual J wave start, +3 projectile augment levels, clean direct cards, permanent Nicotine ally trio.');
})();
