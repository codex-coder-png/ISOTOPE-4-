/* ISOTOPE V57 RUNTIME STABILITY
   - Prevent nested update() calls from forming recursive update chains.
   - Leaves the existing update stack intact; a re-entry is simply ignored.
   - Guards player iteration against null slots.
*/
(function(){
  'use strict';
  if(window.__ISO_V57_RUNTIME_FIX__) return;
  window.__ISO_V57_RUNTIME_FIX__=true;
  var base=window.update;
  if(typeof base==='function'&&!base.__isoV57Guard){
    var depth=0;
    var guarded=function(dt){
      if(depth>0) return;
      depth++;
      try{return base.call(this,dt);}finally{depth--;}
    };
    guarded.__isoV57Guard=true;
    guarded.__isoV57Base=base;
    window.update=guarded;
    try{window.CORE&&CORE.setUpdate&&CORE.setUpdate(guarded);}catch(_){ }
  }
  /* Make any externally exposed player update safe if a late module calls it. */
  if(typeof window.updPlayer==='function'&&!window.updPlayer.__isoV57Guard){
    var op=window.updPlayer;
    window.updPlayer=function(p,dt){if(!p)return;return op.call(this,p,dt);};
    window.updPlayer.__isoV57Guard=true;
  }
  try{
    var ac=window.audioCtx;
    if(ac&&ac.state==='suspended'){
      var resume=function(){try{if(ac.state==='suspended')ac.resume();}catch(_){}};
      window.addEventListener('pointerdown',resume,{once:true,passive:true});
      window.addEventListener('keydown',resume,{once:true,passive:true});
    }
  }catch(_){ }
  console.log('ISO_V57_RUNTIME_STABILITY active: turret damage scope, null-player safety, and update re-entry guard installed.');
})();
