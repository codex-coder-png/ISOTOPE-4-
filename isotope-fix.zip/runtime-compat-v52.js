/* ISOTOPE V52 runtime compatibility shim.
   Safe before game.js, and safe when late-loaded modules are cached or reordered. */
(function(){
  window.clamp=typeof window.clamp==='function'?window.clamp:function(v,a,b){return v<a?a:v>b?b:v;};
  window.d2=typeof window.d2==='function'?window.d2:function(ax,ay,bx,by){var dx=ax-bx,dy=ay-by;return dx*dx+dy*dy;};
  window.TAU=Number.isFinite(window.TAU)?window.TAU:Math.PI*2;
  if(!window.A)window.A={};
})();
