/* ISOTOPE V78 — ChromeOS-friendly Periodic Vault ownership sync
   - Performs one authoritative ownership scan whenever the Periodic Vault is entered.
   - No 1ms polling, no background Vault timer, and no continuous ownership rescans.
   - Uses explicit element/compound ownership from SAVE.
   - Locked entries stay hidden behind ??? and cannot open the detail/selection panel.
   - Locked/unlocked entries still use the audio.js select sound when clicked.
   - Removes the legacy compound-name reveal button anywhere it appears.
   - Keeps the separator toggle under the search bar beside the filters.
*/
'use strict';
(function(){
  if(window.__ISO_V78_VAULT_OWNERSHIP__) return;
  window.__ISO_V78_VAULT_OWNERSHIP__=true;

  function vaultVisible(){
    const s=document.getElementById('scr-vault');
    return !!(s && !s.classList.contains('hidden'));
  }

  function canonical(id){
    try{ return DATA&&DATA.canonicalId ? DATA.canonicalId(id) : String(id??''); }catch(e){ return String(id??''); }
  }

  /* This is the authoritative ownership rule for the Vault:
     elements live in SAVE.unlocked; compounds live in SAVE.mols using their
     canonical recipe keys.  This avoids false positives from display IDs. */
  function ownedNow(id){
    const key=canonical(id);
    try{
      const raw=SAVE&&SAVE.raw;
      if(!raw) return false;
      if(DATA&&DATA.ELEMS&&DATA.ELEMS[key]){
        return Array.isArray(raw.unlocked) && raw.unlocked.includes(key);
      }
      if(DATA&&DATA.MOLDEF&&DATA.MOLDEF[key]&&DATA.MOLDEF[key].mol){
        return Array.isArray(raw.mols) && raw.mols.includes(key);
      }
    }catch(e){}
    return false;
  }

  /* Replace the catalog ownership predicate with the same explicit rule so
     every existing Vault/UI caller sees exactly the live save state. */
  try{
    DATA.__isoV77OriginalIsOwned=DATA.isOwned;
    DATA.isOwned=function(id){ return ownedNow(id); };
  }catch(e){}

  /* Global selection bridge guard: old capture listeners can still try to route
     locked 118-table elements into selectVault.  Let the sound through, but
     refuse the selection itself when the entity is not owned. */
  try{
    const oldBridge=window.__ISO_SELECT_VAULT;
    if(typeof oldBridge==='function' && !window.__ISO_V78_SELECT_GUARD__){
      window.__ISO_V78_SELECT_GUARD__=true;
      window.__ISO_V78_UNGUARDED_SELECT_VAULT__=oldBridge;
      window.__ISO_SELECT_VAULT=function(id){
        var key=canonical(id);
        /* Locked ELEMENT tiles must still open the detail panel so the normal
           UNLOCK button can be used. Locked COMPOUNDS remain non-selectable
           here (admin-mode V89 can unlock them before this guard runs). */
        var isLockedCompound=false;
        try{ isLockedCompound=!!(DATA&&DATA.MOLDEF&&DATA.MOLDEF[key]&&DATA.MOLDEF[key].mol); }catch(e){}
        if(!ownedNow(key) && isLockedCompound){
          try{
            if(window.AUDIO&&AUDIO.SFX&&typeof AUDIO.SFX.select==='function') AUDIO.SFX.select();
            else if(window.AUDIO&&AUDIO.SFX&&typeof AUDIO.SFX.click==='function') AUDIO.SFX.click();
          }catch(e){}
          return false;
        }
        return oldBridge.apply(this,arguments);
      };
    }
  }catch(e){}

  function removeLegacyReveal(){
    const byId=document.getElementById('btn-reveal-compound-names');
    if(byId) byId.remove();
    document.querySelectorAll('button').forEach(function(b){
      const text=(b.textContent||'').trim().replace(/\s+/g,' ').toUpperCase();
      if(text==='REVEAL COMPOUND NAMES' || text==='SHOW COMPOUND FORMULAS') b.remove();
    });
  }

  function moveSeparator(){
    const b=document.getElementById('vault-v73-separators');
    const host=document.getElementById('vault-v71-controls');
    if(b && host && b.parentElement!==host) host.appendChild(b);
    if(b){
      const on=b.dataset.on!=='0';
      b.textContent=on?'TURN OFF SEPARATORS':'TURN ON SEPARATORS';
      b.title=on?'Hide category separators in search results':'Show category separators in search results';
      b.setAttribute('aria-label',b.textContent);
    }
  }

  function refreshOnceOnVaultEntry(){
    if(!vaultVisible()) return;
    removeLegacyReveal();
    moveSeparator();
    /* V73 owns the actual catalog renderer. Dispatching one input event asks it
       to rebuild from the current SAVE snapshot, with no polling required. */
    const input=document.getElementById('vault-element-search-input');
    if(input){
      try{ input.dispatchEvent(new Event('input',{bubbles:true})); }catch(e){}
    }
    document.querySelectorAll('#scr-vault #ptable .pt[data-id]').forEach(function(tile){
      const own=ownedNow(tile.dataset.id);
      tile.classList.toggle('locked',!own);
      tile.classList.toggle('sel', SAVE.sel===canonical(tile.dataset.id));
      tile.style.pointerEvents='auto';
      tile.style.cursor=own?'pointer':'not-allowed';
      tile.setAttribute('aria-disabled',String(!own));
    });
  }

  window.__ISO_V78_VAULT_SCAN=function(){ refreshOnceOnVaultEntry(); };

  /* Scan only when the player actually enters the Vault. */
  if(window.UI&&UI.show&&!UI.__v78OwnershipShow){
    const baseShow=UI.show;
    UI.show=function(id){
      const out=baseShow.apply(this,arguments);
      if(id==='scr-vault') setTimeout(refreshOnceOnVaultEntry,0);
      return out;
    };
    UI.__v78OwnershipShow=true;
  }

  document.addEventListener('click',function(ev){
    if(ev.target&&ev.target.closest&&ev.target.closest('[data-go="scr-vault"]')){
      setTimeout(refreshOnceOnVaultEntry,20);
    }
  },true);

  window.addEventListener('DOMContentLoaded',function(){ removeLegacyReveal(); });
  removeLegacyReveal();
  console.log('ISOTOPE V77 LIVE VAULT OWNERSHIP active.');
})();
