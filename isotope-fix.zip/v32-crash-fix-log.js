(function(){
  if(window.__ISO_V32_CRASH_FIX_LOG__)return;window.__ISO_V32_CRASH_FIX_LOG__=true;
  function add(){var p=document.getElementById('mega-update-panel');if(!p||p.dataset.v32)return;p.dataset.v32='1';p.insertAdjacentHTML('beforeend','<div class="urow"><div class="uver">V32 · CORE & NICOTINE FIX</div><div class="utxt">Restored the live game-core bridge required by the reaction systems and removed the Nicotine crash caused by an out-of-scope distance helper. Ally targeting stays isolated, one-shot, and safe against repeated same-enemy processing.</div></div>');try{p.scrollTop=p.scrollHeight;}catch(e){}}
  setTimeout(add,900);setInterval(add,1800);
})();
