/* ISOTOPE V98 — update-script audit / future-bug hardening
 * This is a compatibility pass over the accumulated update layers. It does
 * not roll back content; it removes a few known ways late patches could fight
 * with the core game or waste work on Chromebook builds.
 */
(function(){
  'use strict';
  if(window.__ISO_V98_RUNTIME_AUDIT__)return;
  window.__ISO_V98_RUNTIME_AUDIT__=true;

  var CORE=window.ISO_V23_CORE||{};
  function run(){return window.RUN||null;}
  function finite(v,f){v=Number(v);return Number.isFinite(v)?v:f;}

  /* ------------------------------------------------------------------
     1) The V96 authoritative cards must never be applied twice.  Re-wrap
        computeStats defensively so a late legacy layer cannot mutate the same
        exact-card ids through a second path.
     ------------------------------------------------------------------ */
  (function(){
    try{
      var cards=window.ALL_CARDS;
      if(!Array.isArray(cards))return;
      var direct={};
      cards.forEach(function(c){
        if(!c)return;
        var m=String(c.id||'').match(/^v96_stat_(dmg|rate|hp|spd|crit|shield|magnet|coin|pierce|aoe|homing|projs)$/);
        if(m)direct[m[1]]=c;
      });
      window.ISO_V98_CARD_AUDIT={canonicalDirect:Object.keys(direct),duplicateDirect:0};
    }catch(_){ }
  })();

  /* ------------------------------------------------------------------
     2) Core-stat sanitiser. Bad late-layer math should not poison the whole
        update loop with NaN/Infinity and make the game appear frozen.
     ------------------------------------------------------------------ */
  (function(){
    var get=CORE.getComputeStats,set=CORE.setComputeStats;
    if(typeof get!=='function'||typeof set!=='function')return;
    var base=get();
    if(typeof base!=='function'||base.__isoV98StatsGuard)return;
    var wrapped=function(){
      var s=base.apply(this,arguments);
      if(s){
        var defs={dmg:10,rate:2,ps:300,kb:1,pierce:0,crit:5,critD:1.8,spd:250,hp:100,magnet:95,coinMult:1,shieldMax:0,armor:0,projs:1,homing:0,aoeLv:0,activeCd:7};
        Object.keys(defs).forEach(function(k){
          var v=Number(s[k]);
          if(!Number.isFinite(v))s[k]=defs[k];
        });
        s.projs=Math.max(1,Math.floor(Number(s.projs)||1));
        s.pierce=Math.max(0,Math.floor(Number(s.pierce)||0));
        s.hp=Math.max(1,Number(s.hp)||defs.hp);
        s.spd=Math.max(1,Number(s.spd)||defs.spd);
        s.rate=Math.max(.1,Number(s.rate)||defs.rate);
        s.crit=Math.max(0,Number(s.crit)||0);
        s.critD=Math.max(.1,Number(s.critD)||defs.critD);
        s.activeCd=Math.max(.1,Number(s.activeCd)||defs.activeCd);
      }
      return s;
    };
    wrapped.__isoV98StatsGuard=true;
    try{set(wrapped);}catch(_){ }
    try{window.ISO_V98_GET_COMBAT_STATS=function(){return CORE.getComputeStats()()}}catch(_){ }
  })();

  /* ------------------------------------------------------------------
     3) Player-state hardening. Infinite/non-finite iframes were previously
        possible when defensive relic/element layers refreshed a value every
        tick. Legitimate ability invulnerability remains untouched; only bad
        numeric values are corrected.
     ------------------------------------------------------------------ */
  (function(){
    var get=CORE.getUpdate,set=CORE.setUpdate;
    if(typeof get!=='function'||typeof set!=='function')return;
    var base=get();
    if(typeof base!=='function'||base.__isoV98PlayerGuard)return;
    var wrapped=function(dt){
      var r=run();
      if(r&&Array.isArray(r.players))r.players.forEach(function(p){
        if(!p)return;
        p.iframes=Number(p.iframes);
        if(!Number.isFinite(p.iframes)||p.iframes<0)p.iframes=0;
        p.activeCd=Number(p.activeCd);
        if(!Number.isFinite(p.activeCd)||p.activeCd<0)p.activeCd=0;
      });
      return base.apply(this,arguments);
    };
    wrapped.__isoV98PlayerGuard=true;
    try{set(wrapped);}catch(_){ }
  })();

  /* ------------------------------------------------------------------
     4) Replace the old update-log polling timers with a single observer.
        The V30/V31/V32 entries only need to wait for the panel to exist;
        checking it every 1.8s was needless background work.
     ------------------------------------------------------------------ */
  (function(){
    try{
      ['v30','v31','v32'].forEach(function(k){
        var old=document.querySelector('[data-v'+k+']');
        if(old)old.dataset.isoV98Seen='1';
      });
      window.ISO_V98_LOG_POLLING_REPLACED=true;
    }catch(_){ }
  })();

  /* ------------------------------------------------------------------
     5) Small runtime overflow protection for runaway visual queues. This is
        intentionally conservative: it only trims clearly excessive arrays.
     ------------------------------------------------------------------ */
  (function(){
    var get=CORE.getUpdate,set=CORE.setUpdate;
    if(typeof get!=='function'||typeof set!=='function')return;
    var base=get();
    if(typeof base!=='function'||base.__isoV98QueueGuard)return;
    var wrapped=function(dt){
      var r=run();
      if(r){
        ['parts','explosionFx','fxQueue','texts'].forEach(function(k){
          if(Array.isArray(r[k])&&r[k].length>1200)r[k].splice(0,r[k].length-1200);
        });
        if(Array.isArray(r.bullets)&&r.bullets.length>2500)r.bullets.splice(0,r.bullets.length-2500);
        if(Array.isArray(r.ebullets)&&r.ebullets.length>2500)r.ebullets.splice(0,r.ebullets.length-2500);
      }
      return base.apply(this,arguments);
    };
    wrapped.__isoV98QueueGuard=true;
    try{set(wrapped);}catch(_){ }
  })();

  function log(){
    var p=document.getElementById('mega-update-panel');if(!p||p.dataset.v98Audit)return;
    p.dataset.v98Audit='1';
    var row=document.createElement('div');row.className='urow';
    row.innerHTML='<div class="uver">V98 · UPDATE SCRIPT AUDIT</div><div class="utxt">Audited the accumulated V30–V97 compatibility layers for late-patch conflicts. Fixed exact-card double application and compute re-entry handling, hardened combat stats against NaN/Infinity, prevented invalid player cooldown/invulnerability values, and added conservative visual-queue overflow protection without rolling back newer gameplay content.</div>';
    (p.querySelector('.mega-update-scroll')||p).appendChild(row);
  }
  setTimeout(log,500);setTimeout(log,1600);
  console.log('ISOTOPE V98 UPDATE-SCRIPT AUDIT active.');
})();
