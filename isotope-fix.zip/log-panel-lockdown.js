/* ISOTOPE — UPDATE LOG PANEL LOCKDOWN
   Confirmed via devtools: #mega-update-panel was the element that grows to
   cover the screen and blocks all interaction. Several files append their
   changelog entries with panel.insertAdjacentHTML('beforeend', ...)
   targeting #mega-update-panel itself instead of the .mega-update-scroll
   div inside it that's actually meant to hold and clip the entries. Those
   entries end up as direct children of the panel, outside the scrollable
   wrapper, so the panel has no way to contain them and grows to fit
   everything - eventually large enough to cover the screen and, since it's
   an ordinary element with default pointer-events, silently sit on top of
   every button and swallow every click and scroll.

   Fix: hard-cap the panel's size no matter what's inside it, move any
   stray content back into the scrollable wrapper automatically, and - per
   the simplest, most certain fix - just hide the whole panel outright
   whenever the main menu isn't the active screen, showing it again only
   on the main menu. If it's not visible, it cannot block anything. */
'use strict';
(function(){
  if(window.__ISO_LOG_PANEL_LOCKDOWN__)return;
  window.__ISO_LOG_PANEL_LOCKDOWN__=true;

  var css=document.createElement('style');
  css.textContent=
    '#mega-update-panel{'+
      'position:relative!important;'+
      'height:min(390px,48vh)!important;max-height:min(390px,48vh)!important;'+
      'overflow:hidden!important;'+
      'pointer-events:none!important;'+
    '}'+
    '#mega-update-panel .mega-update-head{pointer-events:auto!important;}'+
    '#mega-update-panel .mega-update-scroll{'+
      'display:block!important;height:100%!important;max-height:100%!important;'+
      'overflow-y:auto!important;overflow-x:hidden!important;'+
      'pointer-events:auto!important;'+
    '}'+
    '@media(max-width:900px){#mega-update-panel{height:min(340px,50vh)!important;max-height:min(340px,50vh)!important;}}'+
    '@media(max-width:640px){#mega-update-panel{height:min(300px,52vh)!important;max-height:min(300px,52vh)!important;}}';
  document.head.appendChild(css);

  function corral(){
    var panel=document.getElementById('mega-update-panel');
    if(!panel) return;
    var scroll=panel.querySelector('.mega-update-scroll');
    if(!scroll) return;
    var stray=[];
    Array.prototype.forEach.call(panel.children, function(child){
      if(child===scroll || child.classList.contains('mega-update-head')) return;
      stray.push(child);
    });
    stray.forEach(function(el){ scroll.appendChild(el); });
    if(stray.length){
      console.warn('ISO_LOG_PANEL_LOCKDOWN: moved '+stray.length+' stray changelog entries back into the scrollable area.');
    }
    try{ scroll.scrollTop=scroll.scrollHeight; }catch(_e){}
  }

  corral();
  setTimeout(corral,300);
  setTimeout(corral,1000);
  setTimeout(corral,3000);
  var moPanel=new MutationObserver(corral);
  try{
    var panel=document.getElementById('mega-update-panel');
    if(panel) moPanel.observe(panel,{childList:true});
  }catch(_e){}

  function syncVisibility(){
    var panel=document.getElementById('mega-update-panel');
    var menu=document.getElementById('scr-menu');
    if(!panel||!menu) return;
    var menuIsActive=!menu.classList.contains('hidden');
    panel.style.display = menuIsActive ? '' : 'none';
  }
  syncVisibility();
  setTimeout(syncVisibility,300);
  setTimeout(syncVisibility,1000);
  var screens=document.querySelectorAll('.screen');
  if(screens.length){
    var moVis=new MutationObserver(syncVisibility);
    screens.forEach(function(s){ moVis.observe(s,{attributes:true,attributeFilter:['class']}); });
  }
  document.addEventListener('click', function(){ setTimeout(syncVisibility,0); }, true);

  console.log('ISO_LOG_PANEL_LOCKDOWN active: update-log panel is hard-capped, corralled, and hidden on every screen except the main menu.');
})();
