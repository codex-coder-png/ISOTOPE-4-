/* ISOTOPE V80 — ChromeOS layout behavior */
(function(){
  'use strict';
  if(window.__ISO_V80_CHROMEOS_LAYOUT__) return;
  window.__ISO_V80_CHROMEOS_LAYOUT__=true;

  function compactState(){
    var w=window.innerWidth||document.documentElement.clientWidth||0;
    var h=window.innerHeight||document.documentElement.clientHeight||0;
    var chrome=/CrOS/i.test(navigator.userAgent||'');
    document.body.classList.toggle('iso-chromeos-compact',chrome||w<=1200||h<=820);
    document.body.classList.toggle('iso-v80-tight',h<=720);
  }
  function enhanceVault(){
    var panel=document.getElementById('vd');
    if(!panel) return;
    panel.setAttribute('data-follow-viewport','1');
    var btn=document.getElementById('vd-btn');
    if(btn){
      btn.setAttribute('data-v80-equip-follow','1');
      btn.title='Select / Equip the displayed element or compound';
    }
  }
  function hookShow(){
    if(!window.UI||typeof UI.show!=='function') return;
    if(UI.show.__v80Layout) return;
    var base=UI.show;
    var wrapped=function(id){
      var out=base.apply(this,arguments);
      compactState();
      if(id==='scr-vault') setTimeout(enhanceVault,0);
      return out;
    };
    wrapped.__v80Layout=true;
    UI.show=wrapped;
  }
  function boot(){
    compactState();
    enhanceVault();
    hookShow();
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot,{once:true});
  else boot();
  window.addEventListener('resize',compactState,{passive:true});
  window.addEventListener('orientationchange',compactState,{passive:true});
  setTimeout(boot,0);
  setTimeout(boot,250);
  console.log('ISOTOPE V80 layout active: ChromeOS-responsive menus + sticky Vault detail panel.');
})();
