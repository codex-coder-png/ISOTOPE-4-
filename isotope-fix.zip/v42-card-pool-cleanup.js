/* ISOTOPE V42 — CARD POOL CLEANUP
 * Removes repeated cards that serve the same exact mechanical purpose within
 * the same rarity. Keeps the first/original card and preserves separate
 * higher-rarity versions where their tier is intentionally different.
 * Also removes the common projectile-output cards the user asked to remove.
 */
(function(){
  'use strict';
  if(window.__ISO_V42_CARD_CLEANUP__) return;
  window.__ISO_V42_CARD_CLEANUP__=true;
  if(!Array.isArray(window.ALL_CARDS)) return;

  var cards=window.ALL_CARDS;
  var removed=[];

  function norm(s){
    return String(s||'')
      .toLowerCase()
      .replace(/[+−-]?\d+(?:\.\d+)?%/g,'#')
      .replace(/\b(rank|level|stack|while equipped|per run|per level)\b/g,'')
      .replace(/\s+/g,' ')
      .trim();
  }

  /* Original core cards have distinctive IDs but some generated cards copied
     their exact purpose. Map only the clearly stat-identical core effects. */
  var corePurpose={
    pow:'dmg', rate:'rate', multi:'projs', pierce:'pierce', homing:'homing',
    crit:'crit', magnet:'magnet', scavenger:'coin', hoarder:'xp',
    juggernaut:'hp', plating:'shield', windshear:'projSpeed'
  };

  function purposeKey(c){
    if(!c) return null;
    var id=String(c.id||'');
    if(corePurpose[id]) return 'stat:'+corePurpose[id];
    if(id.indexOf('xcard_')===0 || id.indexOf('content_card_')===0 || id.indexOf('qol_prism_')===0){
      return c.extraStat ? 'stat:'+String(c.extraStat) : null;
    }
    if(id.indexOf('research_')===0){
      return c.research&&c.research.stat ? 'stat:'+String(c.research.stat) : null;
    }
    if(id.indexOf('mega_')===0){
      var d=norm(c.d);
      /* Remove the small balancing sentence so repeated mechanics collapse. */
      d=d.replace(/\.\s*(?:\+|minus|−|-).*$/,'').trim();
      return 'mega:'+String(c.megaType||'')+':'+d;
    }
    return null;
  }

  var seen={};
  var kept=[];
  for(var i=0;i<cards.length;i++){
    var c=cards[i];
    var rarity=String(c&&c.rarity||'common').toLowerCase();

    /* Remove the common projectile-output family. Keep the original
       +1-projectile core card because it is a distinct mechanic rather than
       the duplicated +projectile-output stat-card family. */
    if(rarity==='common' && c && c.extraStat==='projs'){
      removed.push(c.id||c.n||'unknown');
      continue;
    }
    if(rarity==='common' && c && /\+\s*100%[^.]*projectile\s*output/i.test(String(c.d||''))){
      removed.push(c.id||c.n||'unknown');
      continue;
    }

    var key=purposeKey(c);
    var dedupe=key ? rarity+'|'+key : null;
    if(dedupe && seen[dedupe]){
      removed.push(c.id||c.n||'unknown');
      continue;
    }
    if(dedupe) seen[dedupe]=1;
    kept.push(c);
  }

  cards.splice(0,cards.length);
  Array.prototype.push.apply(cards,kept);

  /* Expose an audit for the Codex/debug panel. */
  window.ISO_V42_CARD_CLEANUP={
    removedCount: removed.length,
    removedIds: removed.slice(),
    remainingCount: cards.length,
    run:function(){ return {removedCount:removed.length,remainingCount:cards.length,removedIds:removed.slice()}; }
  };

  /* Update any already-open card picker immediately. The normal level-up
     picker reads ALL_CARDS, so future rolls use the cleaned pool. */
  try{
    var panel=document.getElementById('mega-update-panel');
    if(panel){
      var row=document.createElement('div');
      row.className='urow';
      row.innerHTML='<div class="uver">V42</div><div class="utxt">Duplicate card cleanup: repeated same-purpose cards within each rarity were removed, including the duplicated common projectile-output cards. Higher-rarity versions remain available as separate tiers.</div>';
      var wrap=panel.querySelector('.mega-update-scroll')||panel;
      wrap.appendChild(row);
      setTimeout(function(){panel.scrollTop=panel.scrollHeight;},0);
    }
  }catch(e){}

  console.log('ISOTOPE V42 CARD CLEANUP:',removed.length,'duplicates removed;',cards.length,'cards remain.');
})();
