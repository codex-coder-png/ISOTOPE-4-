/* ISOTOPE V70 - Periodic Vault search + favorite interaction + compound-name UI recovery */
(function(){
  'use strict';
  if(window.__ISO_V70_VAULT_FIX__) return;
  window.__ISO_V70_VAULT_FIX__ = true;

  function q(s){return document.querySelector(s)}
  function qa(s){return Array.prototype.slice.call(document.querySelectorAll(s))}
  function safeId(id){try{return DATA.canonicalId?DATA.canonicalId(id):id}catch(e){return id}}
  function owned(id){try{return !!DATA.isOwned(safeId(id))}catch(e){return false}}

  function ensureSearch(){
    var main=q('#vault-main'), strip=q('#molstrip');
    if(!main||!strip) return;
    var box=q('#vault-element-search');
    if(!box){
      box=document.createElement('div');
      box.id='vault-element-search';
      box.innerHTML='<span class="vault-search-icon">⌕</span><input id="vault-element-search-input" type="search" autocomplete="off" spellcheck="false" placeholder="SEARCH ELEMENTS BY NAME, SYMBOL, OR ATOMIC NUMBER"><button id="vault-element-search-clear" type="button">CLEAR</button>';
      main.insertBefore(box,strip);
      var input=box.querySelector('input'), clear=box.querySelector('button');
      function apply(){
        var term=(input.value||'').trim().toLowerCase();
        qa('#ptable .pt[data-id]').forEach(function(tile){
          var e; try{e=DATA.EL(tile.dataset.id)}catch(err){e=null}
          var text=e?[e.name,e.sym,e.id,String(e.z||'')].join(' ').toLowerCase():'';
          tile.style.display=(!term||text.indexOf(term)!==-1)?'':'none';
        });
        clear.style.visibility=term?'visible':'hidden';
      }
      input.addEventListener('input',apply);
      input.addEventListener('keydown',function(ev){if(ev.key==='Escape'){input.value='';apply();input.blur();}});
      clear.addEventListener('click',function(){input.value='';apply();input.focus();});
      box._apply=apply;
    }
    if(box._apply) box._apply();
  }

  /* Owned/favorited tiles must remain real buttons even while visual economy
     styling is being refreshed by older QOL modules. */
  function repairElementTiles(){
    qa('#ptable .pt[data-id]').forEach(function(tile){
      var id=safeId(tile.dataset.id), isOwned=owned(id);
      if(isOwned){
        tile.classList.remove('locked');
        tile.style.pointerEvents='auto';
        tile.style.cursor='pointer';
        tile.style.filter='none';
        tile.style.opacity='1';
      }
      if(!tile.__v70Bound){
        tile.__v70Bound=true;
        var originalClick=tile.onclick;
        tile.__v70OriginalClick=originalClick;
        tile.addEventListener('click',function(ev){
          ev.preventDefault(); ev.stopPropagation();
          try{
            if(typeof window.__ISO_SELECT_VAULT==='function'){
              window.__ISO_SELECT_VAULT(id);
              return;
            }
          }catch(e){console.warn('V70 select bridge',e)}
          try{
            if(typeof originalClick==='function'){
              originalClick.call(tile,ev);
              return;
            }
          }catch(e){console.warn('V70 original tile click',e)}
        },true);
      }
    });
  }

  /* The compound-name toggle rebuilds vault content. Explicitly restore the
     interactive state afterward so a stale overlay/disabled state cannot
     leave the Vault or Lab looking alive while eating all pointer input. */
  function recoverScreens(){
    ['scr-vault','scr-lab'].forEach(function(id){
      var s=document.getElementById(id); if(!s||s.classList.contains('hidden'))return;
      s.style.pointerEvents='auto';
      s.style.userSelect='text';
      s.style.touchAction='auto';
      qa('#'+id+' button,#'+id+' input,#'+id+' select,#'+id+' textarea,[data-go]').forEach(function(el){
        if(el.dataset.v70Disabled==='1'){el.disabled=false;el.dataset.v70Disabled='0'}
        el.style.pointerEvents='auto';
      });
    });
    /* Never let a stray non-game overlay block menu screens. */
    qa('.ov:not(.hidden)').forEach(function(ov){
      if(ov.id==='m-pause'||ov.id==='m-over'||ov.id==='m-brief'||ov.id==='m-deploy')return;
      if(!ov.closest('#scr-vault')&&!ov.closest('#scr-lab')){
        ov.style.pointerEvents='none';
      }
    });
  }

  function refreshVaultUI(){
    ensureSearch();
    repairElementTiles();
    recoverScreens();
  }

  /* Run after every vault render and every navigation, including the reveal-name
     toggle. */
  var oldShow=window.UI&&UI.show;
  if(oldShow&&!UI.__v70Show){
    UI.show=function(id){
      var r=oldShow.apply(this,arguments);
      setTimeout(function(){
        if(id==='scr-vault'||id==='scr-lab')refreshVaultUI();
      },0);
      setTimeout(function(){
        if(id==='scr-vault'||id==='scr-lab')refreshVaultUI();
      },80);
      return r;
    };
    UI.__v70Show=true;
  }

  document.addEventListener('click',function(ev){
    if(ev.target.closest&&ev.target.closest('#btn-reveal-compound-names')){
      setTimeout(refreshVaultUI,0);
      setTimeout(refreshVaultUI,80);
      setTimeout(refreshVaultUI,220);
    }
    if(ev.target.closest&&ev.target.closest('[data-go="scr-vault"],[data-go="scr-lab"]')){
      setTimeout(refreshVaultUI,20);
      setTimeout(refreshVaultUI,120);
    }
  },true);

  setInterval(function(){
    var v=q('#scr-vault');
    if(v&&!v.classList.contains('hidden'))refreshVaultUI();
  },500);

  var css=document.createElement('style');
  css.textContent=`
    #vault-element-search{display:flex;align-items:center;gap:7px;margin-top:12px;padding:7px 9px;border:1px solid var(--line);background:rgba(8,12,20,.82);min-height:34px;box-sizing:border-box}
    #vault-element-search .vault-search-icon{font-family:var(--mono);font-size:16px;color:var(--cy);line-height:1}
    #vault-element-search input{flex:1;min-width:0;border:0;outline:0;background:transparent;color:var(--tx);font-family:var(--mono);font-size:10px;letter-spacing:.08em;text-transform:uppercase}
    #vault-element-search input::placeholder{color:var(--tx3);opacity:.8}
    #vault-element-search button{border:1px solid var(--line);background:#0c1320;color:var(--tx2);font:10px var(--mono);padding:5px 8px;cursor:pointer;visibility:hidden}
    #vault-element-search button:hover{color:var(--tx);border-color:var(--cy)}
    #ptable .pt[data-id]{pointer-events:auto!important}
    #ptable .pt[data-id].locked{pointer-events:auto!important;cursor:pointer!important}
    #ptable .pt[data-id].locked{transition:box-shadow .1s,transform .1s!important}
    #scr-vault,#scr-lab{pointer-events:auto!important}
    #scr-vault input,#scr-vault button,#scr-lab input,#scr-lab button,#scr-lab select,#scr-lab textarea{pointer-events:auto}
  `;
  document.head.appendChild(css);

  setTimeout(refreshVaultUI,0);
  console.log('ISOTOPE V70 VAULT FIX active: element search, favorite tile click repair, name-toggle interaction recovery.');
})();
