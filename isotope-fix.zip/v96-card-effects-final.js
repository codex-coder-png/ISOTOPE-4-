/* ISOTOPE V96 — authoritative level-up card effects
 *
 * The level-up system had accumulated several generations of cards whose
 * labels, rarity math, and runtime effects could disagree.  This final layer
 * intentionally keeps only cards with a verified implementation and gives
 * every direct-stat card an explicit, exact effect.  Rarity is presentation;
 * it never silently changes the value written in the card text.
 */
(function(){
  'use strict';
  if(window.__ISO_V96_CARD_EFFECTS_FINAL__) return;
  window.__ISO_V96_CARD_EFFECTS_FINAL__=true;

  var OLD_DIRECT_IDS={
    dmg:['v95_direct_dmg','v93_stat_dmg','v84_direct_dmg','v50_stat_dmg_common','v50_stat_dmg_uncommon','v50_stat_dmg_rare','v50_stat_dmg_epic','v50_stat_dmg_legendary','v50_stat_dmg_mythic'],
    rate:['v95_direct_rate','v93_stat_rate','v84_direct_rate'],
    hp:['v95_direct_hp','v93_stat_hp','v84_direct_hp'],
    spd:['v95_direct_spd','v93_stat_spd','v84_direct_spd'],
    crit:['v95_direct_crit','v93_stat_crit','v84_direct_crit'],
    shield:['v95_direct_shield','v93_stat_shield','v84_direct_shield'],
    magnet:['v95_direct_magnet','v93_stat_magnet','v84_direct_magnet'],
    coin:['v95_direct_coin','v93_stat_coin','v84_direct_coin'],
    pierce:['v95_direct_pierce','v93_stat_pierce','v84_direct_pierce'],
    aoe:['v95_direct_aoe','v93_stat_aoe','v84_direct_aoe'],
    homing:['v95_direct_homing','v93_stat_homing','v84_direct_homing'],
    projs:['v95_direct_projs','v93_stat_projs','v84_direct_projs']
  };
  var OLD_SPECIAL_PREFIX=/^(?:xcard_|content_card_|qol_prism_|mega_|research_)/i;
  var ORIGINAL=[
    'orbit','nova','leech','chain','swift','fission','grav','thorns','vamp',
    'ricochet','mines','turret','freeze','execute','berserk','adrenaline',
    'phaseout','voltaic','scavenger','bloodlust','bulwark','static','lifeline',
    'hoarder','windup','splitshot','necroblast','juggernaut','windshear',
    'overdmg','lastwill','echo','momentum','tempo','flux','aegis','grit',
    'shatter','combust','scavenge','void','singularity','overclock','dilations',
    'dronecmd','critwave'
  ];
  var EXACT=[
    {stat:'dmg',id:'v96_stat_dmg',ic:'⚔',n:'Focused Damage',d:'Projectiles deal +10% damage.',rarity:'common',value:.10,mode:'mul',max:1},
    {stat:'rate',id:'v96_stat_rate',ic:'↯',n:'Rapid Fire',d:'Fire rate is +8%.',rarity:'uncommon',value:.08,mode:'mul',max:1},
    {stat:'hp',id:'v96_stat_hp',ic:'♥',n:'Reinforced Hull',d:'Maximum HP is +12.',rarity:'common',value:12,mode:'add',max:1},
    {stat:'spd',id:'v96_stat_spd',ic:'➤',n:'Thruster Boost',d:'Movement speed is +8%.',rarity:'common',value:.08,mode:'mul',max:1},
    {stat:'crit',id:'v96_stat_crit',ic:'✧',n:'Critical Mass',d:'Critical chance is +8 percentage points.',rarity:'rare',value:8,mode:'add',max:1},
    {stat:'shield',id:'v96_stat_shield',ic:'◈',n:'Shield Reserve',d:'Maximum shield is +15.',rarity:'uncommon',value:15,mode:'add',max:1},
    {stat:'magnet',id:'v96_stat_magnet',ic:'◎',n:'Pickup Field',d:'Pickup range is +10%.',rarity:'uncommon',value:.10,mode:'mul',max:1},
    {stat:'coin',id:'v96_stat_coin',ic:'◈',n:'Coin Matrix',d:'Coin gain is +10%.',rarity:'rare',value:.10,mode:'mul',max:1},
    {stat:'pierce',id:'v96_stat_pierce',ic:'➤',n:'Penetrator',d:'Gain +1 pierce.',rarity:'uncommon',value:1,mode:'add',max:1},
    {stat:'aoe',id:'v96_stat_aoe',ic:'✹',n:'Reaction Radius',d:'Ability and reaction radius is +10%.',rarity:'uncommon',value:.10,mode:'mul',max:1},
    {stat:'homing',id:'v96_stat_homing',ic:'⌖',n:'Guidance Core',d:'Homing strength is +10%.',rarity:'uncommon',value:.10,mode:'add',max:1},
    {stat:'projs',id:'v96_stat_projs',ic:'⋔',n:'Particle Split',d:'Gain +1 projectile to your normal base firing.',rarity:'rare',value:1,mode:'add',max:1}
  ];
  var EXACT_BY_ID={}; EXACT.forEach(function(c){EXACT_BY_ID[c.id]=c;});
  var LEGACY_ID_TO_STAT={};Object.keys(OLD_DIRECT_IDS).forEach(function(stat){OLD_DIRECT_IDS[stat].forEach(function(id){LEGACY_ID_TO_STAT[id]=stat;});});
  var SPECIAL_KEEP={
    'v23_orbit_core_103':1,
    'level_mend_card':1,
    'level_guard_card':1,
    'v50_cooldown_mythic':1,
    'v50_beam_mythic':1,
    'v50_charge_rare':1,
    'v50_team_epic':1
  };
  ['burn','freeze','poison','corrosion','rust','shock','brittle','drenched','slow','stun','mark','weaken','blind','confuse','radiation'].forEach(function(s){SPECIAL_KEEP['v23_onhit_'+s]=1;});

  function activeExactCards(){
    return (window.ALL_CARDS||[]).filter(function(c){return c&&c.exactStat;});
  }
  function hasOwnId(obj,id){return !!(obj&&Object.prototype.hasOwnProperty.call(obj,id));}
  function hasActiveId(id){return (window.ALL_CARDS||[]).some(function(c){return c&&c.id===id;});}
  function currentLegacyLevel(stat,r){
    var n=0,ids=OLD_DIRECT_IDS[stat]||[];
    ids.forEach(function(id){if(hasOwnId(r.ab,id)) n=Math.max(n,Number(r.ab[id])||0);});
    return n;
  }

  /* Rebuild the selectable pool with a verified implementation whitelist. */
  (function rebuildPool(){
    var src=Array.isArray(window.ALL_CARDS)?window.ALL_CARDS:[];
    var keep=[],seenId={},seenMechanic={};
    src.forEach(function(c){
      if(!c||!c.id) return;
      var id=String(c.id);
      if(EXACT_BY_ID[id]) return;
      if(OLD_SPECIAL_PREFIX.test(id)){
        /* Orbit Core 103 is the one explicitly implemented member of the old
           generated orbital family; all other generated/stat families are out. */
        if(!SPECIAL_KEEP[id]) return;
      }
      if(/^(?:v50_stat_|v84_direct_|v93_stat_|v95_direct_)/i.test(id)) return;
      if(/^(?:research_|content_card_|qol_prism_|xcard_|mega_)/i.test(id)) return;
      if(id==='pow'||id==='rate'||id==='multi'||id==='pierce'||id==='crit'||id==='magnet'||id==='homing'||id==='plating'||id==='scavenger') return;
      if(id==='phoenix') return; /* no live ST/runtime assignment exists for it */
      if(c.v14Type && id!=='level_mend_card' && id!=='level_guard_card') return;
      if(c.v23StatusOnHit && !SPECIAL_KEEP[id]) return;
      if(ORIGINAL.indexOf(id)>=0){
        var mech=id;
        if(id==='echo'||id==='momentum'||id==='tempo'||id==='flux'||id==='aegis'||id==='grit'||id==='shatter'||id==='combust'||id==='scavenge'||id==='void'||id==='singularity'||id==='overclock'||id==='dilations'||id==='dronecmd'||id==='critwave') mech='new:'+id;
        if(seenMechanic[mech]) return;
        seenMechanic[mech]=1;
      }
      if(SPECIAL_KEEP[id]||ORIGINAL.indexOf(id)>=0){
        if(seenId[id]) return;seenId[id]=1;keep.push(c);
      }
    });

    EXACT.forEach(function(c){
      keep.push({id:c.id,ic:c.ic,n:c.n,d:c.d,rarity:c.rarity,max:c.max,unique:true,exactStat:c.stat,exactValue:c.value,exactMode:c.mode,v96Exact:true});
    });
    /* Remove duplicate names/descriptions in the active pool without relying
       on rarity.  A mechanic can have different tiers only when the mechanic
       itself is intentionally different (none of the exact stat cards are). */
    var seenN={},seenD={},out=[];
    keep.forEach(function(c){
      var n=String(c.n||'').trim().toLowerCase().replace(/\s+/g,' ');
      var d=String(c.d||'').trim().toLowerCase().replace(/\s+/g,' ');
      if(n&&seenN[n]) return;
      if(d&&seenD[d]) return;
      if(n)seenN[n]=1;if(d)seenD[d]=1;out.push(c);
    });
    window.ALL_CARDS.splice(0,window.ALL_CARDS.length);Array.prototype.push.apply(window.ALL_CARDS,out);
    try{if(window.EXTRA_CARDS&&Array.isArray(window.EXTRA_CARDS))window.EXTRA_CARDS.length=0;}catch(_){ }
    window.ISO_V96_CARD_AUDIT={
      total:out.length,
      exact:EXACT.map(function(c){return c.id;}),
      duplicateNames:0,
      duplicateDescriptions:0,
      removedLegacyDirect:Object.keys(LEGACY_ID_TO_STAT),
      removedGenerated:out.filter(function(c){return /^xcard_|^content_card_|^research_|^mega_|^qol_prism_/.test(c.id);}).map(function(c){return c.id;})
    };
  })();

  /* Make the exact cards independent from the game's old rarity multiplier.
     The card's written value is the value the stat receives. */
  (function installExactCompute(){
    var prev=window.computeStats;
    if(typeof prev!=='function') return;
    var busy=false;
    function applyExact(S,R){
      var levels={};
      EXACT.forEach(function(c){levels[c.id]=Number(R.ab&&R.ab[c.id]||0);});
      /* Legacy direct cards are already interpreted by the base game's
         computeStats() through their original extraStat fields. Do NOT replay
         those saved levels here or they would be counted twice. */
      EXACT.forEach(function(c){
        var lv=levels[c.id]||0;
        if(!lv)return;
        var v=c.value*lv;
        if(c.stat==='dmg')S.dmg*=1+v;
        else if(c.stat==='rate')S.rate*=1+v;
        else if(c.stat==='hp')S.hp+=v;
        else if(c.stat==='spd')S.spd*=1+v;
        else if(c.stat==='crit')S.crit+=v;
        else if(c.stat==='shield')S.shieldMax+=v;
        else if(c.stat==='magnet')S.magnet*=1+v;
        else if(c.stat==='coin')S.coinMult*=1+v;
        else if(c.stat==='pierce')S.pierce+=v;
        else if(c.stat==='aoe')S.aoeLv+=v;
        else if(c.stat==='homing')S.homing+=v;
        else if(c.stat==='projs')S.projs+=v;
      });
    }
    var lastResult=null;
    var f=function(){
      /* A nested compute request should reuse the most recent result rather
         than returning an uninitialised local variable. */
      if(busy)return lastResult;
      busy=true;
      try{
        var result=prev.apply(this,arguments),R=window.RUN;
        if(result&&R)applyExact(result,R);
        lastResult=result||lastResult;
        return result;
      }finally{busy=false;}
    };
    f.__isoV96ExactCards=true;
    window.computeStats=f;
    try{if(window.CORE&&CORE.setComputeStats)CORE.setComputeStats(f);}catch(_){ }
  })();

  /* Replace misleading descriptions on retained bespoke cards so the UI and
     the actual implementation agree. */
  (function fixDescriptions(){
    var map={
      orbit:'Gain 2 orbiting electrons per rank. Each electron deals 55% of current projectile damage on contact, with a 0.35s per-target hit cooldown.',
      nova:'Every 5s, emit a radial blast. Radius: 140 + 32×rank. Damage: 110% + 45%×rank of current projectile damage.',
      leech:'Each kill restores 1 HP per rank to living operators.',
      chain:'Hits chain to additional enemies. Each rank adds one link; each link deals 50% of the previous link damage.',
      swift:'Movement speed +8% per rank and dash cooldown −12% per rank.',
      fission:'When a main projectile expires without piercing or ricocheting, it splits into 2 fragments per trigger.',
      grav:'Every 7s, create a 1.7s gravity well on a random living enemy. Higher ranks make the finishing burst stronger.',
      thorns:'When you are hit, blast nearby enemies for 50% of the incoming hit per rank.',
      vamp:'Critical hits restore 1 HP per rank.',
      ricochet:'Projectiles that cannot pierce may bounce to one new nearby target per rank.',
      mines:'Each dash drops 1 explosive mine per rank.',
      turret:'Every 4.6 − 0.5×rank seconds, fire an auto-barrage at up to 2 + rank targets.',
      freeze:'Critical hits stun non-boss enemies for 0.28s per rank.',
      execute:'Non-boss enemies at or below 6% of max HP × rank are immediately defeated.',
      berserk:'Below 30% max HP, deal +15% damage per rank.',
      adrenaline:'Each kill grants a +28% movement-speed rush lasting 0.7 + 0.4×rank seconds.',
      phaseout:'Dash invulnerability lasts 0.25s longer per rank.',
      voltaic:'Kills have a 22% × rank chance to trigger a 2-link chain for 60% current projectile damage.',
      scavenger:'Coin gain +15% per rank.',
      bloodlust:'Each kill adds 1 stack, up to 20. Each stack gives +2.5% fire rate per rank, capped at +60%.',
      bulwark:'After a hit, automatically block the next eligible hit. Recharge is 13 − 2×rank seconds.',
      static:'Deal 17% of current projectile damage every 0.5s to enemies within 100px per rank.',
      lifeline:'Each pickup restores 2% of max HP per rank.',
      hoarder:'XP gain +20% per rank.',
      windup:'While firing, fire rate ramps up to +26% per rank as sustained fire builds.',
      splitshot:'Piercing hits have a 50% chance per eligible hit to create 2 side shards; shard damage scales with rank.',
      necroblast:'Kills have an 18% × rank chance to detonate for 115% current projectile damage in a 90px radius.',
      juggernaut:'Maximum HP +6% and armor +3 percentage points per rank.',
      windshear:'Projectile speed +5% per rank.',
      overdmg:'Critical damage multiplier +0.25 per rank.',
      lastwill:'Grants 1 emergency revive on the run.'
    };
    (window.ALL_CARDS||[]).forEach(function(c){if(map[c.id])c.d=map[c.id];});

    var specials={
      v50_cooldown_mythic:'Ability cooldowns are 25% shorter.',
      v50_beam_mythic:'Compound beams gain +70% beam-power envelope.',
      v50_charge_rare:'Every 10 primary hits refunds 8% of the current active cooldown.',
      v50_team_epic:'Ability casts grant nearby teammates a shield equal to 3% of your current shield capacity.',
      level_mend_card:'Each level-up restores 8% of missing health.',
      level_guard_card:'Each level-up grants 20 shield.',
      v23_orbit_core_103:'Shots create orbiting motes that remain with the shot and each deal a small bonus hit.'
    };
    (window.ALL_CARDS||[]).forEach(function(c){if(specials[c.id])c.d=specials[c.id];});
  })();

  /* Guard against accidental future insertions that reintroduce a second
     homing/projectile stat card into the level-up pool. */
  window.ISO_V96_ASSERT_CARD=function(id){
    if(id==='v96_stat_homing')return {ok:true,stat:'homing',value:.10};
    if(id==='v96_stat_projs')return {ok:true,stat:'projs',value:1};
    return {ok:hasActiveId(id),stat:null,value:null};
  };

  /* Add a compact V96 audit entry to the existing update log. */
  function log(){
    var p=document.getElementById('mega-update-panel');if(!p||p.dataset.v96CardAudit)return;
    p.dataset.v96CardAudit='1';
    var row=document.createElement('div');row.className='urow';
    row.innerHTML='<div class="uver">V96 · CARDS</div><div class="utxt">Rebuilt the selectable level-up pool around verified mechanics only. Direct stat cards now use their exact written values, including Homing +10% and one Rare Particle Split card for exactly +1 normal projectile. Legacy generated/stat duplicates, unimplemented research cards, and duplicate projectile-output variants no longer appear in level-up rolls.</div>';
    var host=p.querySelector('.mega-update-scroll')||p;host.appendChild(row);host.scrollTop=host.scrollHeight;
  }
  setTimeout(log,120);
  setTimeout(log,700);
  console.log('ISOTOPE V96 CARD EFFECTS FINAL: exact stat values + verified mechanics only + duplicate-proof projectile/homing cards.');
})();
