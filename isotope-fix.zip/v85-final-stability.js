/* ISOTOPE V85 compatibility layer superseded by V86 authoritative final layer. */
window.__ISO_V85_FINAL_STABILITY_DISABLED_BY_V86__=true;
