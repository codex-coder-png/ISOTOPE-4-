/* ISOTOPE V79 — Signature Mastery: one locked path per element, 3 ranks max */
(function(){
  'use strict';
  if(window.__ISO_V79_SIGNATURE_MASTERY__)return;
  window.__ISO_V79_SIGNATURE_MASTERY__=true;
  var SFX=(window.AUDIO&&AUDIO.SFX)||{};
  var PATHS={
    damage:{label:'DAMAGE',desc:'+12% SIGNATURE DAMAGE / RANK',icon:'⚔'},
    range:{label:'RANGE',desc:'+18% SIGNATURE RANGE / RANK',icon:'⌁'},
    cooldown:{label:'COOLDOWN',desc:'-10% SIGNATURE COOLDOWN / RANK',icon:'⟳'}
  };
  var COSTS=[100,180,300];
  var pending=null;

  function selectedElement(){
    var head=document.getElementById('m-head');
    var txt=head?String(head.textContent||''):'';
    var up=txt.toUpperCase();
    return Object.values(DATA.ELEMS||{}).find(function(e){return up.indexOf(String(e.name||'').toUpperCase())>=0&&DATA.isOwned(e.id)})||DATA.EL(SAVE.sel);
  }
  function state(el){return SAVE.getSignatureUpgrade?SAVE.getSignatureUpgrade(el.id):{path:null,rank:0};}
  function currentSignature(el){
    var slot=SAVE.getSignature?SAVE.getSignature(el.id):0;
    var choices=el.choices||el.signatures||[];
    return {slot:slot,choice:choices[slot]||choices[0]||{name:'SIGNATURE '+(slot+1),desc:''}};
  }
  function removeLegacyCard(){
    var old=document.getElementById('ability-mastery');
    if(old)old.remove();
  }
  function panelHTML(el){
    var st=state(el),sig=currentSignature(el), chosen=st.path, rank=st.rank;
    var title='✦ SIGNATURE MASTERY';
    var sub='Choose ONE upgrade path for '+(el.name||'this element')+' Signature '+(sig.slot+1)+'. The path is permanent for this element and can be upgraded only 3 times.';
    var cards=Object.keys(PATHS).map(function(k){
      var p=PATHS[k],isChosen=chosen===k,isPending=pending&&pending.id===el.id&&pending.path===k;
      var disabled=!!chosen&&!isChosen;
      var label=isChosen?'PATH LOCKED':isPending?'ARE YOU SURE? CLICK AGAIN':'CHOOSE '+p.label;
      var pip=Array.from({length:3},function(_,i){return '<i class="'+(i<rank&&isChosen?'on':'')+'"></i>';}).join('');
      return '<button type="button" class="v79-sig-path '+(isChosen?'chosen ':'')+(disabled?'disabled ':'')+(isPending?'pending ':'')+'" data-v79-path="'+k+'" '+(disabled?'disabled':'')+'>'+
        '<span class="v79-sig-icon">'+p.icon+'</span><span class="v79-sig-main"><b>'+p.label+'</b><small>'+p.desc+'</small><span class="v79-sig-pips">'+pip+'</span></span><em>'+label+'</em></button>';
    }).join('');
    var cost=chosen&&rank<3?COSTS[rank]:0;
    var upgrade=chosen?'<div class="v79-sig-upgrade-row"><span><b>'+PATHS[chosen].label+' PATH · '+rank+'/3</b><small>'+(rank>=3?'MAXED':'Next rank: '+PATHS[chosen].desc+' · costs ◆ '+cost+' MASTERY XP')+'</small></span><button type="button" class="btn primary" id="v79-sig-buy" '+(rank>=3||SAVE.mxp(el.id).xp<cost?'disabled':'')+'>'+(rank>=3?'MAX':'UPGRADE · ◆ '+cost)+'</button></div>':'';
    return '<div id="v79-signature-mastery" class="panel2"><div class="v79-sig-title">'+title+'</div><div class="v79-sig-sub">'+sub+'</div><div class="v79-sig-equipped">EQUIPPED: <b>'+escapeHtml(sig.choice.name||('SIGNATURE '+(sig.slot+1)))+'</b></div><div class="v79-sig-path-grid">'+cards+'</div>'+upgrade+'</div>';
  }
  function escapeHtml(v){return String(v==null?'':v).replace(/[&<>\"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[c];});}

  function render(){
    if(!document.getElementById('scr-mastery')||document.getElementById('scr-mastery').classList.contains('hidden'))return;
    var detail=document.getElementById('m-detail'),tree=document.getElementById('m-tree'),el=selectedElement();
    if(!detail||!tree||!el)return;
    var badge=document.getElementById('mxp-badge');if(badge)badge.textContent='Exp: '+SAVE.mxp(el.id).xp;
    var chip=document.querySelector('#m-elems .mchip.sel');if(chip){var spans=chip.querySelectorAll('span');if(spans[1])spans[1].textContent=String(SAVE.mxp(el.id).xp);}
    removeLegacyCard();
    var old=document.getElementById('v79-signature-mastery');if(old)old.remove();
    var wrap=document.createElement('div');wrap.innerHTML=panelHTML(el);
    var panel=wrap.firstElementChild;
    /* Keep the new panel above the ordinary mastery nodes. */
    tree.parentNode.insertBefore(panel,tree);
    bind(panel,el);
  }
  function bind(panel,el){
    panel.querySelectorAll('[data-v79-path]').forEach(function(btn){
      btn.onclick=function(){
        var path=btn.dataset.v79Path,st=state(el);
        if(st.path)return;
        if(!(pending&&pending.id===el.id&&pending.path===path)){
          pending={id:el.id,path:path};
          if(SFX.click)SFX.click();
          render();
          return;
        }
        if(SAVE.chooseSignatureUpgradePath&&SAVE.chooseSignatureUpgradePath(el.id,path)){
          pending=null;
          if(SFX.unlock)SFX.unlock();
          render();
          toast('SIGNATURE '+PATHS[path].label+' PATH LOCKED IN','good');
        }else{
          if(SFX.error)SFX.error();
        }
      };
    });
    var buy=panel.querySelector('#v79-sig-buy');
    if(buy)buy.onclick=function(){
      var st=state(el);
      if(!st.path||st.rank>=3)return;
      var cost=COSTS[st.rank];
      if(SAVE.buySignatureUpgrade&&SAVE.buySignatureUpgrade(el.id)){
        pending=null;
        if(SFX.unlock)SFX.unlock();
        render();
        toast(PATHS[st.path].label+' SIGNATURE UPGRADE '+(st.rank+1)+'/3 PURCHASED · ◆ '+cost,'good');
      }else{
        if(SFX.error)SFX.error();
        toast('NOT ENOUGH MASTERY XP · NEED ◆ '+cost,'bad');
      }
    };
  }
  function toast(msg,cls){
    try{var host=document.getElementById('toasts');if(!host)return;var t=document.createElement('div');t.className='toast '+(cls||'');t.textContent=msg;host.appendChild(t);setTimeout(function(){t.style.opacity='0';t.style.transition='opacity .35s';setTimeout(function(){t.remove()},400)},2200);}catch(e){}
  }
  function hookMastery(){
    if(!window.UI||!UI.show)return;
    if(UI.show.__v79SignatureMastery)return;
    var old=UI.show;
    UI.show=function(id){var r=old.apply(this,arguments);if(id==='scr-mastery')setTimeout(render,0);return r;};
    UI.show.__v79SignatureMastery=true;
    var elems=document.getElementById('m-elems');
    if(elems&&!elems.__v79){
      elems.__v79=true;
      elems.addEventListener('click',function(){setTimeout(render,0);});
    }
    setTimeout(render,0);
  }
  /* The core game wrapper is intentionally installed after every prior ability
     module so the V79 Signature path is the final modifier in the chain. */
  function hookGame(){
    var helper=window.ISO_V79_WITH_SIGNATURE_UPGRADE_CONTEXT,old=window.useActive;
    if(typeof helper!=='function'||typeof old!=='function'||old.__v79Wrapped)return;
    var f=function(p){return helper(p,function(){return old(p);});};
    f.__v79Wrapped=true;
    window.useActive=f;
    try{if(window.ISO_V23_CORE&&ISO_V23_CORE.setUseActive)ISO_V23_CORE.setUseActive(f);}catch(e){}
    if(window.GAME)GAME.useActiveV79=f;
  }
  function boot(){hookMastery();hookGame();}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
  setTimeout(boot,0);setTimeout(boot,250);
  console.log('ISOTOPE V79 SIGNATURE MASTERY active: one locked path per element, three ranks, signature-only damage/range/cooldown modifiers.');
})();
