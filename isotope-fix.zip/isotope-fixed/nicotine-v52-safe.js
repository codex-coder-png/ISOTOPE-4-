/* ISOTOPE V52 — NICOTINE ALLY SAFETY LAYER
   Final-loaded isolation for Receptor Charm.
   Goals:
   - Ability 1 uses ONLY this isolated projectile queue.
   - One enemy can be converted only once for the entire run.
   - A charm projectile can consume only one target, once.
   - At most one conversion is committed per simulation frame.
   - Converted enemies live outside RUN.enemies/RUN.allies legacy containers,
     so old V20/V26/V28 ally loops cannot touch them.
   - Allies are permanently player-team members until their HP reaches zero.
*/
(function(){
  if(window.__ISO_V52_NICOTINE_SAFE__)return;
  window.__ISO_V52_NICOTINE_SAFE__=true;

  function R(){return window.RUN||null;}
  /* V52 runtime hardening: this file is completely self-contained for clamp/TAU/distance. */
  function safeClamp(v,a,b){return v<a?a:v>b?b:v;}
  var TAU=Number.isFinite(window.TAU)?window.TAU:Math.PI*2;
  /* V32 crash guard: this module cannot use game.js's private d2() helper.
     Keep a private copy so nearest-player/ally collision checks never throw. */
  function d2(ax,ay,bx,by){var dx=ax-bx,dy=ay-by;return dx*dx+dy*dy;}
  function isNico(p){
    var el=p&&p.elem;
    if(!el&&p&&p.elementId&&window.DATA&&DATA.EL)try{el=DATA.EL(p.elementId);}catch(_){ }
    var n=String(el&&el.name||el&&el.token||'').toLowerCase();
    return !!(el&&el.mol&&n==='nicotine');
  }
  function aliveHostiles(){
    var r=R();
    return (r&&Array.isArray(r.enemies)?r.enemies:[]).filter(function(e){
      return e&&!e.dead&&!e.boss&&!e._v29CharmLocked&&!e._v29Converted&&e.team!=='player';
    });
  }
  function owner(id){
    var r=R();
    if(!r||!Array.isArray(r.players))return null;
    return r.players.find(function(p){return p&&p.id===id;})||r.players[0]||null;
  }
  function hueForPlayer(id){
    var p=owner(id),el=p&&p.elem;
    return el&&Number.isFinite(+el.hue)?+el.hue:145;
  }
  function safeRing(x,y,h,r){try{if(window.ringFx)ringFx(x,y,h,r);}catch(_){}}
  function safeBurst(x,y,h){try{if(window.burst)burst(x,y,h);}catch(_){}}

  function ensureState(r){
    r._v29CharmShots=r._v29CharmShots||[];
    r._v29CharmUsed=r._v29CharmUsed||Object.create(null);
    r._v29CharmReserved=r._v29CharmReserved||Object.create(null);
    r._v29Allies=r._v29Allies||[];
    r._v29AllyBullets=r._v29AllyBullets||[];
    r._v29CharmFrame=-1;
    r._v29CharmCommittedFrame=-1;
  }

  function nearestHostileForAlly(a,range){
    var r=R(),arr=aliveHostiles(),best=null,bd=range*range;
    for(var i=0;i<arr.length;i++){
      var e=arr[i],d=d2(a.x,a.y,e.x,e.y);
      if(d<bd){bd=d;best=e;}
    }
    return best;
  }

  function convert(e,ownerId){
    var r=R();
    if(!r||!e||e.dead||e.boss||e._v29Converted||e.team==='player')return null;
    var key=String(e.eid!=null?e.eid:('enemy_'+Math.round(e.x)+'_'+Math.round(e.y)+'_'+Math.round(e.maxhp||0)));
    if(r._v29CharmUsed[key]||r._v29CharmReserved[key])return null;
    r._v29CharmUsed[key]=true;
    e._v29CharmLocked=true;
    e._v29Converted=true;
    e._befriended=true;
    e.team='player';
    e.dead=true;

    var p=owner(ownerId),ph=hueForPlayer(ownerId);
    var maxhp=Math.max(1,Number(e.maxhp)||Number(e.hp)||20);
    var ally={
      eid:e.eid, sourceEid:e.eid, sourceType:e.type||'mote', type:e.type||'mote',
      name:e.name||((window.ETYPES&&ETYPES[e.type]&&ETYPES[e.type].name)||e.type||'Ally'),
      x:Number(e.x)||0,y:Number(e.y)||0,r:Math.max(7,Number(e.r)||10),
      hp:Math.max(1,Math.min(maxhp,Number(e.hp)||maxhp*.72)),maxhp:maxhp,
      spd:Math.max(55,Number(e.spd)||100),dmg:Math.max(1,Number(e.dmg)||10),
      hue:ph,playerHue:ph,ownerId:p?p.id:ownerId,team:'player',befriended:true,
      permanent:true,nicotineAlly:true,incomingMul:.5,
      shootT:Math.max(.15,Number(e.shootT)||.7),specialT:Math.max(.4,Number(e.specialT)||1.4),
      healT:Math.max(.5,Number(e.healT)||1.8),orb:Number(e.orb)||0,
      charge:0,chargeT:Math.max(.5,Number(e.chgT)||2.5),targetEid:0,
      special:e.special||null,pat:e.pat||null,fast:!!e.fast,canCharge:!!e.canCharge,
      shape:e.shape||'dot',seed:e.seed||0,elite:!!e.elite,aiRole:e.aiRole||'melee',
      _v29:true
    };
    r._v29Allies.push(ally);

    /* Remove immediately from the hostile array. It is never allowed to remain
       in the same team container after conversion. */
    if(Array.isArray(r.enemies)){
      for(var i=r.enemies.length-1;i>=0;i--){if(r.enemies[i]===e||r.enemies[i]&&r.enemies[i]._v29Converted)r.enemies.splice(i,1);}
    }

    /* Small visual feedback only — deliberately NO "ALLY JOINED" text. */
    safeRing(ally.x,ally.y,ph,115);
    safeBurst(ally.x,ally.y,ph);
    return ally;
  }

  function charmStep(dt){
    var r=R(); if(!r||!Array.isArray(r._v29CharmShots))return;
    ensureState(r);
    var nowFrame=window.__isoV20Frame=(window.__isoV20Frame||0)+1;
    var pending=[];
    var reservedThisFrame=Object.create(null);

    for(var i=r._v29CharmShots.length-1;i>=0;i--){
      var b=r._v29CharmShots[i];
      if(!b){r._v29CharmShots.splice(i,1);continue;}
      b.life-=dt;b.x+=b.vx*dt;b.y+=b.vy*dt;
      if(b.life<=0||b.x<-50||b.x>window.W+50||b.y<-50||b.y>window.H+50){r._v29CharmShots.splice(i,1);continue;}

      var hit=null,arr=aliveHostiles();
      for(var j=0;j<arr.length;j++){
        var e=arr[j];
        var key=String(e.eid!=null?e.eid:('enemy_'+Math.round(e.x)+'_'+Math.round(e.y)));
        if(r._v29CharmUsed[key]||reservedThisFrame[key]||e._v29CharmLocked)continue;
        var rr=(b.r+e.r)*(b.r+e.r);
        if(d2(b.x,b.y,e.x,e.y)<=rr){hit=e;reservedThisFrame[key]=true;r._v29CharmReserved[key]=b.owner;break;}
      }
      /* The projectile is consumed BEFORE conversion is committed. This is the
         critical no-reentry rule: no collision loop may see this same projectile
         again after a successful contact. */
      if(hit){
        b.consumed=true;
        r._v29CharmShots.splice(i,1);
        pending.push({enemy:hit,owner:b.owner,key:String(hit.eid!=null?hit.eid:('enemy_'+Math.round(hit.x)+'_'+Math.round(hit.y)))});
        if(r._v29CharmCommittedFrame!==nowFrame){r._v29CharmCommittedFrame=nowFrame;}
        /* Only one conversion may be committed this simulation frame. */
        break;
      }
    }

    if(pending.length){
      var q=pending[0];
      if(!r._v29CharmUsed[q.key])convert(q.enemy,q.owner);
      delete r._v29CharmReserved[q.key];
    }

    /* Drop any duplicate reservations created by overlapping shots this frame. */
    Object.keys(r._v29CharmReserved).forEach(function(k){
      if(r._v29CharmUsed[k])delete r._v29CharmReserved[k];
    });
  }

  function allyShot(a,target,o){
    var r=R();if(!r||!target)return;
    r._v29AllyBullets.push({
      x:a.x,y:a.y,r:o.r||4,life:o.life||1.8,
      vx:Math.cos(o.angle!=null?o.angle:Math.atan2(target.y-a.y,target.x-a.x))*(o.speed||300),
      vy:Math.sin(o.angle!=null?o.angle:Math.atan2(target.y-a.y,target.x-a.x))*(o.speed||300),
      dmg:Math.max(1,a.dmg*(o.mult||.72)),ownerId:a.ownerId,source:a.eid,
      hue:a.playerHue||a.hue||145,pierce:o.pierce||0,hit:Object.create(null),homing:!!o.homing,
      status:o.status||null,spread:o.spread||0
    });
  }

  function allyStep(dt){
    var r=R();if(!r)return;
    ensureState(r);
    var A=r._v29Allies||[];
    for(var i=A.length-1;i>=0;i--){
      var a=A[i];
      if(!a||a.hp<=0){safeBurst(a?a.x:0,a?a.y:0,a?a.playerHue:145);A.splice(i,1);continue;}
      a.permanent=true;a.befriended=true;a.team='player';a.playerHue=hueForPlayer(a.ownerId);a.hue=a.playerHue;

      /* Allies can collect XP/coins, but only allied actors may trigger this. */
      if(Array.isArray(r.pickups)){
        var best=null,bd=175*175;
        for(var k=0;k<r.pickups.length;k++){
          var pk=r.pickups[k];if(!pk||pk.got||(pk.t!=='xp'&&pk.t!=='coin'))continue;
          var pd=d2(a.x,a.y,pk.x,pk.y);if(pd<bd){bd=pd;best=pk;}
        }
        if(best){
          var pd=Math.sqrt(bd)||1;
          if(pd>18){a.x+=(best.x-a.x)/pd*Math.max(130,a.spd*1.25)*dt;a.y+=(best.y-a.y)/pd*Math.max(130,a.spd*1.25)*dt;continue;}
          best.got=true;
          if(best.t==='xp'){try{gainXP(best.v||1);}catch(_){ }try{if(window.SFX&&SFX.xp)SFX.xp();}catch(_){ }}
          else {var c=Math.max(1,Math.floor((best.v||1)*.5*.6));try{r.coins+=c;}catch(_){ }try{if(window.SAVE&&SAVE.addCoins)SAVE.addCoins(c);}catch(_){ }try{if(window.SFX&&SFX.coin)SFX.coin();}catch(_){ }}
        }
      }

      var target=nearestHostileForAlly(a,820);
      if(target)a.targetEid=target.eid;
      a.shootT=(a.shootT||0)-dt;a.specialT=(a.specialT||0)-dt;a.healT=(a.healT||1)-dt;

      var type=String(a.type||'');
      if(type==='healer'&&a.healT<=0){
        a.healT=1.8;(r.players||[]).forEach(function(p){if(p&&!p.downed&&d2(a.x,a.y,p.x,p.y)<180*180)p.hp=Math.min(ST.hp,p.hp+ST.hp*.035);});safeRing(a.x,a.y,a.playerHue,95);continue;
      }
      if(type==='shielder'&&a.specialT<=0){
        a.specialT=3.5;(r.players||[]).forEach(function(p){if(p&&!p.downed&&d2(a.x,a.y,p.x,p.y)<170*170)p.sh=Math.min(ST.shieldMax,p.sh+8);});safeRing(a.x,a.y,a.playerHue,110);continue;
      }
      if(!target)continue;
      var dx=target.x-a.x,dy=target.y-a.y,d=Math.hypot(dx,dy)||1;

      if(['spitter','drone','spark','voltconductor','sniper','juggler','orbiter','mirror','glasslancer','emberdrone','echohound','ionserpent','stormbeacon'].indexOf(type)>=0){
        if(a.shootT<=0){
          if(type==='sniper'){a.shootT=3.1;allyShot(a,target,{mult:1.7,speed:470,r:6,pierce:2});}
          else if(type==='juggler'){a.shootT=2.2;for(var q=-1;q<=1;q++)allyShot(a,target,{mult:.56,speed:300,angle:Math.atan2(dy,dx)+q*.16,pierce:1});}
          else if(type==='orbiter'){a.shootT=1.35;allyShot(a,target,{mult:.62,speed:270,homing:true});}
          else if(type==='mirror'){a.shootT=2.6;allyShot(a,target,{mult:1.0,speed:320,pierce:2});allyShot(a,target,{mult:.58,speed:250,angle:Math.atan2(dy,dx)+.24});allyShot(a,target,{mult:.58,speed:250,angle:Math.atan2(dy,dx)-.24});}
          else if(type==='emberdrone'){a.shootT=2.8;allyShot(a,target,{mult:1.05,speed:220,r:6,status:'burn'});}
          else if(type==='spark'||type==='voltconductor'||type==='ionserpent'){a.shootT=1.2;for(var z=-1;z<=1;z++)allyShot(a,target,{mult:.5,speed:410,r:3,angle:Math.atan2(dy,dx)+z*.2});}
          else {a.shootT=1.5;allyShot(a,target,{mult:.72,speed:285});}
        }
        if(d>180){a.x+=dx/d*a.spd*.45*dt;a.y+=dy/d*a.spd*.45*dt;}
      }else if(type==='bomber'&&d<a.r+target.r+18){
        try{aoe(a.x,a.y,95,a.dmg*1.1,a.playerHue||145);}catch(_){dmgEnemy(target,a.dmg*1.2,{quiet:true});}a.hp=0;
      }else{
        if(d<=a.r+target.r+12){a.shootT=Math.max(a.shootT,0);if(a.shootT<=0){a.shootT=.72;try{dmgEnemy(target,a.dmg*.72,{quiet:true});}catch(_){ }}}
        else {a.x+=dx/d*a.spd*dt;a.y+=dy/d*a.spd*dt;}
      }
      a.x=safeClamp(a.x,a.r,window.W-a.r);a.y=safeClamp(a.y,a.r,window.H-a.r);
    }
  }

  function allyBulletsStep(dt){
    var r=R();if(!r||!Array.isArray(r._v29AllyBullets))return;
    for(var i=r._v29AllyBullets.length-1;i>=0;i--){
      var b=r._v29AllyBullets[i];if(!b){r._v29AllyBullets.splice(i,1);continue;}
      b.life-=dt;
      if(b.homing){
        var t=aliveHostiles().sort(function(a,c){return d2(a.x,a.y,b.x,b.y)-d2(c.x,c.y,b.x,b.y);})[0];
        if(t){var ang=Math.atan2(t.y-b.y,t.x-b.x),cur=Math.atan2(b.vy,b.vx),df=ang-cur;while(df>Math.PI)df-=TAU;while(df<-Math.PI)df+=TAU;cur+=safeClamp(df,-4*dt,4*dt);var sp=Math.hypot(b.vx,b.vy);b.vx=Math.cos(cur)*sp;b.vy=Math.sin(cur)*sp;}
      }
      b.x+=b.vx*dt;b.y+=b.vy*dt;
      var consumed=false;
      var es=aliveHostiles();
      for(var j=0;j<es.length;j++){
        var e=es[j],key=String(e.eid!=null?e.eid:('enemy_'+Math.round(e.x)+'_'+Math.round(e.y)));
        if(b.hit[key])continue;
        if(d2(b.x,b.y,e.x,e.y)<(b.r+e.r)*(b.r+e.r)){
          b.hit[key]=1;try{dmgEnemy(e,b.dmg,{quiet:true});}catch(_){ }
          if(b.status==='burn')try{addBurn(e,b.dmg*.18,1.5);}catch(_){ }
          safeRing(e.x,e.y,b.hue||145,35);
          if(b.pierce>0){b.pierce--;continue;}
          consumed=true;break;
        }
      }
      if(consumed||b.life<=0||b.x<-60||b.x>window.W+60||b.y<-60||b.y>window.H+60)r._v29AllyBullets.splice(i,1);
    }
  }

  function cleanNicotineTexts(){
    var r=R();
    if(!r||!Array.isArray(r.texts))return;
    r.texts=r.texts.filter(function(t){
      var s=String(t&&t.s||'').toUpperCase();
      return s!=='ALLY JOINED'&&s!=='WEAKENED 25%'&&s!=='WEAKEN 25%';
    });
  }

  /* Final useActive override is loaded after every other script. */
  var oldUse=window.useActive;
  window.useActive=function(p){
    if(isNico(p)&&p&&!p.downed&&(p.activeCd||0)<=0&&Number(p.signatureSlot||0)===0){
      var r=R();if(!r)return;
      ensureState(r);
      var a=p.angle||0,sp=Math.max(280,Number(ST&&ST.ps)||380);
      p.activeCd=Number(ST&&ST.activeCd)||1.5;
      try{if(window.SFX&&SFX.active)SFX.active();}catch(_){ }
      r._v29CharmShots.push({x:p.x+Math.cos(a)*18,y:p.y+Math.sin(a)*18,vx:Math.cos(a)*sp*1.55,vy:Math.sin(a)*sp*1.55,r:8,life:1.8,owner:p.id,consumed:false});
      return;
    }
    return typeof oldUse==='function'?oldUse(p):undefined;
  };

  /* If any old layer accidentally creates a charm projectile in RUN.bullets,
     delete it before the old collision code can touch it. */
  var oldUpdate=window.update;
  window.update=function(dt){
    var r=R();
    if(r){
      ensureState(r);
      if(Array.isArray(r.bullets))r.bullets=r.bullets.filter(function(b){return !(b&&((b._v26NicoCharm)||(b._v27NicoCharm)||(b._v28Charm)||(b.semanticType==='nicotine-recruiting-dart')));});
    }
    var ret=typeof oldUpdate==='function'?oldUpdate(dt):undefined;
    r=R();
    if(!r)return ret;
    cleanNicotineTexts();
    charmStep(dt);
    allyBulletsStep(dt);
    allyStep(dt);
    cleanNicotineTexts();
    return ret;
  };

  /* Hostiles can choose a permanent nicotine ally as a valid target. */
  var oldNearest=window.nearestPlayer;
  window.nearestPlayer=function(x,y){
    var r=R(),best=null,bd=1e30;
    if(r&&Array.isArray(r.players))r.players.forEach(function(p){if(!p||p.downed)return;var q=d2(x,y,p.x,p.y);if(q<bd){bd=q;best=p;}});
    if(r&&Array.isArray(r._v29Allies))r._v29Allies.forEach(function(a){if(!a||a.hp<=0)return;var q=d2(x,y,a.x,a.y);if(q<bd){bd=q;best=a;}});
    return best||((typeof oldNearest==='function')?oldNearest(x,y):null);
  };

  /* Enemy projectile -> ally collision, but NEVER ally projectile -> player. */
  var oldUpdBullets=window.updBullets;
  window.updBullets=function(dt){
    var ret=typeof oldUpdBullets==='function'?oldUpdBullets(dt):undefined;
    var r=R();if(!r||!Array.isArray(r.ebullets)||!Array.isArray(r._v29Allies))return ret;
    if(r.isOnline&&window.NET&&!NET.isHost)return ret;
    for(var i=r.ebullets.length-1;i>=0;i--){
      var b=r.ebullets[i];if(!b||b.life<=0)continue;
      var hit=false;
      for(var j=0;j<r._v29Allies.length;j++){
        var a=r._v29Allies[j];if(!a||a.hp<=0)continue;
        if(d2(b.x,b.y,a.x,a.y)<(b.r+a.r)*(b.r+a.r)){
          a.hp-=Math.max(0,b.dmg||0)*(a.incomingMul||.5);a.hurtT=.12;safeRing(a.x,a.y,145,30);b.life=0;hit=true;break;
        }
      }
      if(hit)r.ebullets.splice(i,1);
    }
    return ret;
  };

  /* Prevent direct hostile contact code from ever damaging a nicotine ally via
     the player's collision branch. Our explicit ally branch handles it. */
  var oldUpdEnemies=window.updEnemies;
  window.updEnemies=function(dt){
    var ret=typeof oldUpdEnemies==='function'?oldUpdEnemies(dt):undefined;
    var r=R();if(!r||!Array.isArray(r.enemies)||!Array.isArray(r._v29Allies))return ret;
    if(r.isOnline&&window.NET&&!NET.isHost)return ret;
    r.enemies.forEach(function(e){
      if(!e||e.dead)return;
      e._v29AllyTouchT=Math.max(0,(e._v29AllyTouchT||0)-dt);
      if(e._v29AllyTouchT>0)return;
      for(var i=0;i<r._v29Allies.length;i++){
        var a=r._v29Allies[i];if(!a||a.hp<=0)continue;
        if(d2(e.x,e.y,a.x,a.y)<(e.r+a.r+4)*(e.r+a.r+4)){
          a.hp-=Math.max(0,e.dmg||0)*(a.incomingMul||.5);a.hurtT=.12;e._v29AllyTouchT=.7;safeRing(a.x,a.y,145,26);break;
        }
      }
    });
    return ret;
  };

  /* Render only the player color + green team outline. No join/debuff text. */
  var oldRender=window.render;
  window.render=function(){
    var ret=typeof oldRender==='function'?oldRender():undefined;
    var r=R();if(!r)return ret;
    if(Array.isArray(r._v29Allies))r._v29Allies.forEach(function(a){
      if(!a||a.hp<=0)return;
      var pulse=.78+.22*Math.sin((r.t||0)*5+(a.eid||0));
      cx.save();cx.translate(a.x,a.y);
      cx.globalCompositeOperation='lighter';
      cx.shadowBlur=15;cx.shadowColor='hsla('+a.playerHue+',90%,65%,.55)';
      cx.fillStyle='hsla('+a.playerHue+',72%,54%,.88)';
      cx.beginPath();cx.arc(0,0,a.r,0,TAU);cx.fill();
      cx.shadowBlur=0;cx.globalCompositeOperation='source-over';
      cx.strokeStyle='rgba(126,240,166,'+(.8*pulse)+')';cx.lineWidth=3;
      cx.beginPath();cx.arc(0,0,a.r+7+2*pulse,0,TAU);cx.stroke();
      cx.restore();
    });
    if(Array.isArray(r._v29AllyBullets))r._v29AllyBullets.forEach(function(b){
      cx.save();cx.fillStyle='hsla('+(b.hue==null?145:b.hue)+',90%,68%,.95)';cx.shadowBlur=10;cx.shadowColor=cx.fillStyle;
      cx.beginPath();cx.arc(b.x,b.y,b.r,0,TAU);cx.fill();cx.restore();
    });
    return ret;
  };

  /* Multiplayer snapshots use a separate list so legacy RUN.allies handlers
     cannot merge/duplicate the same actor. */
  if(window.NET){
    var oldBroadcast=NET.broadcastSnapshot;
    NET.broadcastSnapshot=function(s){
      if(s&&R()){
        s.v29Allies=(R()._v29Allies||[]).filter(function(a){return a&&a.hp>0;}).map(function(a){
          return {eid:a.eid,type:a.type,name:a.name,x:a.x,y:a.y,hp:a.hp,maxhp:a.maxhp,r:a.r,
            hue:a.playerHue,playerHue:a.playerHue,ownerId:a.ownerId,team:'player',befriended:true,permanent:true,
            spd:a.spd,dmg:a.dmg,aiRole:a.aiRole,special:a.special||null};
        });
      }
      return typeof oldBroadcast==='function'?oldBroadcast(s):s;
    };
    var oldState=NET.onStateSnapshot;
    NET.onStateSnapshot=function(s){
      var ret=typeof oldState==='function'?oldState(s):s;
      var r=R();
      if(r&&s&&Array.isArray(s.v29Allies)){
        var sx=window.W/(r.hostW||window.W),sy=window.H/(r.hostH||window.H);
        r._v29Allies=s.v29Allies.map(function(a){return {eid:a.eid,type:a.type,name:a.name,x:a.x*sx,y:a.y*sy,hp:a.hp,maxhp:a.maxhp,r:a.r,
          hue:a.playerHue||145,playerHue:a.playerHue||145,ownerId:a.ownerId,team:'player',befriended:true,permanent:true,
          spd:a.spd||100,dmg:a.dmg||10,aiRole:a.aiRole||'melee',special:a.special||null,incomingMul:.5,shootT:.7,specialT:1.4,healT:1.8,_v29:true};});
      }
      return ret;
    };
  }

  /* Clean visual/status text inserted by older nicotine layers. */
  setTimeout(function(){
    var r=R();cleanNicotineTexts();
    try{
      var panel=document.getElementById('mega-update-panel');
      if(panel&&!panel.dataset.v29nico){
        panel.dataset.v29nico='1';
        panel.insertAdjacentHTML('beforeend','<div class="urow"><div class="uver">V29 · NICOTINE SAFETY</div><div class="utxt">Receptor Charm now uses a completely separate one-shot collision system. Each enemy can be converted only once, the charm projectile is consumed before conversion, only one conversion can happen per frame, and converted allies are kept outside the old hostile/legacy ally loops.</div></div>');
      }
    }catch(_){ }
  },650);

  console.log('ISO_REACTOR_V52_NICOTINE_SAFE active: isolated one-shot charm, single-conversion-per-frame latch, separate permanent ally container, no repeated same-enemy collision, and no nicotine status pop-up text.');
})();
