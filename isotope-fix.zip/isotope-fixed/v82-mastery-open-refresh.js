/* ISOTOPE V82 — Element Mastery opens with the equipped element/detail already rendered. */
(function(){
  'use strict';
  if(window.__ISO_V82_MASTERY_OPEN_REFRESH__) return;
  window.__ISO_V82_MASTERY_OPEN_REFRESH__=true;

  function openRefresh(){
    var scr=document.getElementById('scr-mastery');
    if(!scr || scr.classList.contains('hidden')) return;

    /* V59 rebuilds the left index from live ownership. Force that rebuild first,
       then click the already-selected chip so all existing mastery renderers
       (including V79 Signature Mastery) refresh their detail panes. */
    try{
      if(typeof window.ISO_REFRESH_MASTERY==='function') window.ISO_REFRESH_MASTERY();
    }catch(e){}

    function activateSelected(){
      var box=document.getElementById('m-elems');
      if(!box) return;
      var chip=box.querySelector('.mchip.sel');
      if(!chip){
        var first=box.querySelector('.mchip[data-id]');
        chip=first||null;
        if(chip) chip.classList.add('sel');
      }
      if(!chip) return;
      try{chip.click();}catch(e){
        try{chip.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:window}));}catch(_){}
      }
    }

    /* Two passes cover both the initial screen swap and V59's delayed live-index rebuild. */
    setTimeout(activateSelected,0);
    setTimeout(activateSelected,35);
    setTimeout(activateSelected,90);
  }

  function hook(){
    if(window.UI && typeof UI.show==='function' && !UI.show.__v82MasteryOpen){
      var base=UI.show;
      var wrapped=function(id){
        var out=base.apply(this,arguments);
        if(id==='scr-mastery') openRefresh();
        return out;
      };
      wrapped.__v82MasteryOpen=true;
      UI.show=wrapped;
    }
    /* Also expose a tiny manual refresh hook for other UI modules without
       introducing any polling. */
    window.ISO_REFRESH_MASTERY_OPEN=function(){openRefresh();};
  }

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',hook,{once:true});
  else hook();
  setTimeout(hook,0);
  setTimeout(hook,250);

  console.log('ISOTOPE V82 MASTERY OPEN REFRESH: equipped/selected element detail now appears immediately when entering Element Mastery.');
})();
