/* ISOTOPE V60 — NICOTINE ABILITY 1 HARD ROUTE
   A single large, fast projectile is fired from the authoritative useActive path.
   It has its own projectile queue so old V26/V29/V50 charm queues cannot swallow
   the shot or make five tiny darts. On contact, the first non-boss hostile becomes
   a permanent player ally through V50_NICO.befriend().
*/
(function(){
  'use strict';
  if(window.__ISO_V60_NICO_A1__)return;
  window.__ISO_V60_NICO_A1__=true;

  function run(){return window.RUN||null;}
  function isNico(p){
    var e=p&&p.elem;
    var n=String(e&&e.name||e&&e.token||'').toLowerCase();
    return !!(e&&e.mol&&(n==='nicotine'||n.indexOf('nicotine')>=0));
  }
  function clamp(v,a,b){v=Number(v);if(!Number.isFinite(v))v=a;return Math.max(a,Math.min(b,v));}
  function d2(ax,ay,bx,by){var dx=ax-bx,dy=ay-by;return dx*dx+dy*dy;}
  function segmentHit(px,py,x,y,ex,ey,r){
    var vx=x-px,vy=y-py,wx=ex-px,wy=ey-py;
    var vv=vx*vx+vy*vy;
    var t=vv>0?clamp((wx*vx+wy*vy)/vv,0,1):0;
    var qx=px+vx*t,qy=py+vy*t,dx=ex-qx,dy=ey-qy;
    return dx*dx+dy*dy<=r*r;
  }
  function hue(p){return Number(p&&p.elem&&p.elem.hue)||145;}
  function sfx(){try{if(window.SFX&&SFX.active)SFX.active();}catch(_){}}
  function ring(x,y,h,r){try{if(window.ringFx)ringFx(x,y,h,r);}catch(_){} }
  function burst(x,y,h){try{if(window.fxBurst)fxBurst(x,y,h,26);else if(window.burst)burst(x,y,h);}catch(_){} }

  function fireA1(p){
    var r=run();
    if(!r||!p||p.downed)return false;
    r._isoV60NicoA1=r._isoV60NicoA1||[];
    if(r._isoV60NicoA1.length>=2)return false;
    var st=window.ST||{};
    var a=Number(p.angle)||0;
    var base=Number(st.ps);
    if(!Number.isFinite(base)||base<=0)base=380;
    var speed=Math.max(900,base*2.35);
    var radius=18;
    var damage=Math.max(1,Number(st.dmg)||14)*1.35;
    var x=p.x+Math.cos(a)*28,y=p.y+Math.sin(a)*28;
    r._isoV60NicoA1.push({
      x:x,y:y,px:x,py:y,vx:Math.cos(a)*speed,vy:Math.sin(a)*speed,
      r:radius,life:1.15,owner:p.id,hue:hue(p),damage:damage,age:0,hit:false
    });
    p.activeCd=Math.max(1.8,Number(st.activeCd)||7);
    sfx();
    try{if(window.banner)banner('RECEPTOR CHARM',950);}catch(_){}
    ring(p.x,p.y,hue(p),64);burst(x,y,hue(p));
    return true;
  }

  function befriend(e,owner){
    try{
      if(window.ISO_V50_NICO&&typeof window.ISO_V50_NICO.befriend==='function'){
        return !!window.ISO_V50_NICO.befriend(e,owner,'nicotine-receptor-fast-projectile');
      }
    }catch(err){console.warn('V60 nicotine befriend',err);}
    return false;
  }

  function step(dt){
    var r=run();
    if(!r||!Array.isArray(r._isoV60NicoA1))return;
    var host=!(r.isOnline&&window.NET&&NET.isHost===false);
    if(!host)return;
    var arr=r._isoV60NicoA1;
    var enemies=Array.isArray(r.enemies)?r.enemies:[];
    for(var i=arr.length-1;i>=0;i--){
      var b=arr[i];
      if(!b){arr.splice(i,1);continue;}
      b.life-=dt;b.age+=dt;b.px=b.x;b.py=b.y;b.x+=b.vx*dt;b.y+=b.vy*dt;
      var hit=null;
      for(var j=0;j<enemies.length;j++){
        var e=enemies[j];
        if(!e||e.dead||e.boss||e.team==='player'||e._v29Converted||e._v26Converted||e._befriended)continue;
        var er=Math.max(8,Number(e.r)||10);
        if(segmentHit(b.px,b.py,b.x,b.y,e.x,e.y,b.r+er)){hit=e;break;}
      }
      if(hit){
        var ok=befriend(hit,b.owner);
        if(ok){ring(hit.x,hit.y,b.hue,138);burst(hit.x,hit.y,b.hue);}
        else {try{hit.flash=.18;}catch(_){} }
        arr.splice(i,1);continue;
      }
      if(b.life<=0||b.x<-120||b.x>Number(window.W||0)+120||b.y<-120||b.y>Number(window.H||0)+120)arr.splice(i,1);
    }
  }

  function draw(){
    var r=run();
    if(!r||!Array.isArray(r._isoV60NicoA1))return;
    var c=window.CORE&&CORE.ctx&&CORE.ctx();
    if(!c)return;
    r._isoV60NicoA1.forEach(function(b){
      var al=clamp(b.life/1.15,.12,1),ang=Math.atan2(b.vy,b.vx);
      var tx=b.x-Math.cos(ang)*52,ty=b.y-Math.sin(ang)*52;
      c.save();c.lineCap='round';
      c.shadowBlur=30;c.shadowColor='hsla('+b.hue+',100%,70%,'+(.75*al)+')';
      c.strokeStyle='hsla('+b.hue+',100%,66%,'+(.95*al)+')';c.lineWidth=b.r*1.8;
      c.beginPath();c.moveTo(tx,ty);c.lineTo(b.x,b.y);c.stroke();
      c.shadowBlur=14;c.strokeStyle='rgba(240,255,248,'+(.98*al)+')';c.lineWidth=Math.max(5,b.r*.72);
      c.beginPath();c.moveTo(tx+Math.cos(ang)*10,ty+Math.sin(ang)*10);c.lineTo(b.x,b.y);c.stroke();
      c.fillStyle='hsla('+((b.hue+25)%360)+',100%,88%,'+(.98*al)+')';
      c.beginPath();c.arc(b.x,b.y,b.r*.8*(1+.08*Math.sin(b.age*24)),0,Math.PI*2);c.fill();
      c.strokeStyle='hsla('+b.hue+',100%,82%,'+(.55*al)+')';c.lineWidth=2.5;
      c.beginPath();c.arc(b.x,b.y,b.r+6+2*Math.sin(b.age*15),0,Math.PI*2);c.stroke();
      c.restore();
    });
  }

  /* Hard-route both entry points used by different generations of the ability
     router. Slots 1 and 2 continue through the existing nicotine implementation. */
  var oldIso=window.ISO_NICOTINE_USE;
  window.ISO_NICOTINE_USE=function(p,slot,el){
    if(isNico(p)&&Number(slot)===0)return fireA1(p);
    return typeof oldIso==='function'?oldIso.apply(this,arguments):false;
  };

  var oldUse=window.useActive;
  var wrappedUse=function(p){
    if(isNico(p)&&p&&!p.downed&&(Number(p.activeCd)||0)<=0){
      var slot=Math.max(0,Math.min(2,Number(p.signatureSlot)||0));
      if(slot===0)return fireA1(p);
    }
    return typeof oldUse==='function'?oldUse.apply(this,arguments):undefined;
  };
  wrappedUse.__isoV60NicoA1=true;
  window.useActive=wrappedUse;
  try{useActive=wrappedUse;}catch(_){}
  try{if(window.CORE&&CORE.setUseActive)CORE.setUseActive(wrappedUse);}catch(_){}

  var oldUpdate=window.update;
  if(typeof oldUpdate==='function'&&!oldUpdate.__isoV60NicoUpdate){
    var u=function(dt){
      var out=oldUpdate.call(this,dt);
      try{step(Number(dt)||0);}catch(err){console.warn('V60 nicotine projectile update',err);}
      return out;
    };
    u.__isoV60NicoUpdate=true;
    window.update=u;
    try{update=u;}catch(_){}
    try{if(window.CORE&&CORE.setUpdate)CORE.setUpdate(u);}catch(_){}
  }

  var oldRender=window.render;
  if(typeof oldRender==='function'&&!oldRender.__isoV60NicoRender){
    var rr=function(){var out=oldRender.apply(this,arguments);try{draw();}catch(_){}return out;};
    rr.__isoV60NicoRender=true;window.render=rr;try{render=rr;}catch(_){}
    try{if(window.CORE&&CORE.setRender)CORE.setRender(rr);}catch(_){}
  }

  console.log('ISO_V60_NICOTINE_A1 active: one large fast receptor projectile with hard-routed befriend-on-hit behavior.');
})();
