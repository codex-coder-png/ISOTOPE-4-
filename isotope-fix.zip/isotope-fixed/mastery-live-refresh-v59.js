/* ISOTOPE V59 — LIVE ELEMENT MASTERY INDEX
   Rebuilds the Mastery left-hand index from the current saved unlock state
   every time the Mastery screen opens. Includes both owned elements and
   catalogued/owned real compounds (for example Nicotine and Nitroglycerin).
   Does not change the equipped element when a mastery chip is clicked.
*/
(function(){
  'use strict';
  if(window.__ISO_MASTERY_LIVE_V59__) return;
  window.__ISO_MASTERY_LIVE_V59__=true;

  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]);});}
  function canonical(id){try{return DATA&&DATA.canonicalId?DATA.canonicalId(id):id;}catch(_){return id;}}
  function owned(id){try{return DATA&&DATA.isOwned?DATA.isOwned(id):false;}catch(_){return false;}}

  function entries(){
    var out=[], seen=new Set();
    var elems=(DATA&&DATA.ELEMS)?Object.values(DATA.ELEMS):[];
    elems.forEach(function(e){
      if(!e||!e.id||seen.has(e.id)||!owned(e.id)) return;
      seen.add(e.id);
      out.push({id:e.id, kind:'element', order:Number(e.n)||0, label:e.sym||e.name||e.id, sub:String(e.n||''), name:e.name||e.id, hue:e.hue||190});
    });
    var mols=(DATA&&DATA.MOLDEF)?DATA.MOLDEF:{};
    var saved=(window.SAVE&&SAVE.raw&&Array.isArray(SAVE.raw.mols))?SAVE.raw.mols:[];
    var savedSet=new Set(saved.map(String));
    Object.keys(mols).forEach(function(k){
      var m=mols[k];
      if(!m||!m.mol||seen.has(k)||!savedSet.has(k)||!owned(k)) return;
      seen.add(k);
      out.push({id:k,kind:'compound',order:100000,name:m.name||k,label:m.f||m.name||k,sub:'⚗',hue:m.hue||285});
    });
    out.sort(function(a,b){
      if(a.kind!==b.kind) return a.kind==='element'?-1:1;
      if(a.kind==='element') return a.order-b.order;
      return a.name.localeCompare(b.name);
    });
    return out;
  }

  function chooseSelected(list){
    var current=null;
    try{current=canonical(window.__isoMasteryLiveSelected||SAVE.sel);}catch(_){current=SAVE.sel;}
    if(list.some(function(e){return e.id===current;})) return current;
    try{current=canonical(SAVE.sel);}catch(_){current=SAVE.sel;}
    if(list.some(function(e){return e.id===current;})) return current;
    return list.length?list[0].id:null;
  }

  function renderList(){
    var box=document.getElementById('m-elems');
    if(!box) return [];
    var list=entries(), selected=chooseSelected(list);
    window.__isoMasteryLiveSelected=selected;
    box.innerHTML='';
    if(!list.length){
      var empty=document.createElement('div');
      empty.className='m-empty';
      empty.textContent='NO OWNED ELEMENTS OR CATALOGUED COMPOUNDS YET';
      box.appendChild(empty);
      return list;
    }
    list.forEach(function(e){
      var d=document.createElement('div');
      d.className='mchip'+(e.kind==='compound'?' compound':'')+(selected===e.id?' sel':'');
      d.dataset.id=e.id;
      d.dataset.kind=e.kind;
      d.title=e.kind==='compound'?e.name+' · '+e.label:e.name+' · ELEMENT '+e.sub;
      d.style.borderColor='hsl('+e.hue+' 72% 62%)';
      d.style.color='hsl('+e.hue+' 72% 62%)';
      if(e.kind==='compound'){
        d.innerHTML='<span class="mchip-num">⚗</span><span class="mchip-formula">'+esc(e.label)+'</span><span class="mchip-name">'+esc(e.name)+'</span>';
      }else{
        d.innerHTML='<span class="mchip-num">'+esc(e.sub)+'</span><span style="font-weight:bold">'+esc(e.label)+'</span><span style="font-size:9px">'+esc(window.SAVE&&SAVE.mxp?SAVE.mxp(e.id).xp:0)+'</span>';
      }
      /* Intentionally do not mutate SAVE.sel. mega-overhaul's delegated
         #m-elems click handler handles the mastery detail view. */
      d.addEventListener('click',function(){window.__isoMasteryLiveSelected=e.id;box.querySelectorAll('.mchip').forEach(function(x){x.classList.toggle('sel',x===d);});});
      box.appendChild(d);
    });
    var idx=list.findIndex(function(e){return e.id===selected;});
    if(idx>=0) box.scrollTop=Math.max(0,idx*72-120);
    return list;
  }

  function refresh(){
    if(!window.document||!document.getElementById('scr-mastery')) return;
    var scr=document.getElementById('scr-mastery');
    if(scr.classList.contains('hidden')) return;
    var list=renderList();
    var selected=window.__isoMasteryLiveSelected;
    var badge=document.getElementById('mxp-badge');
    if(badge&&selected&&SAVE.mxp) badge.textContent='◆ '+SAVE.mxp(selected).xp;
    /* Give the existing mega mastery renderer a chance to redraw the detail
       pane after the list has been replaced. Its function is intentionally
       kept private; the chip's delegated click handler owns that redraw. */
    return list;
  }

  window.ISO_REFRESH_MASTERY=refresh;

  if(window.UI&&typeof UI.show==='function'&&!UI.__isoMasteryLiveV59){
    var baseShow=UI.show;
    UI.show=function(id){
      var out=baseShow.apply(this,arguments);
      if(id==='scr-mastery'){
        setTimeout(refresh,0);
        setTimeout(refresh,40);
      }
      return out;
    };
    UI.__isoMasteryLiveV59=true;
  }

  if(window.SAVE&&typeof SAVE.unlockElement==='function'&&!SAVE.__isoMasteryLiveUnlockV59){
    var baseUnlock=SAVE.unlockElement;
    SAVE.unlockElement=function(){
      var out=baseUnlock.apply(this,arguments);
      if(out) setTimeout(refresh,0);
      return out;
    };
    SAVE.__isoMasteryLiveUnlockV59=true;
  }

  /* Reconcile the visible index after lab cataloguing without changing game
     selection. This is deliberately cheap and only runs while Mastery is open. */
  var lastSig='';
  setInterval(function(){
    var scr=document.getElementById('scr-mastery');
    if(!scr||scr.classList.contains('hidden')) return;
    var list=entries(), sig=list.map(function(e){return e.id;}).join('|');
    if(sig!==lastSig){lastSig=sig;refresh();}
  },750);

  setTimeout(function(){
    var scr=document.getElementById('scr-mastery');
    if(scr&&!scr.classList.contains('hidden')) refresh();
  },0);

  console.log('ISOTOPE V59 MASTERY LIVE INDEX: open-refresh includes owned elements + catalogued compounds; mastery chips no longer equip elements.');
})();
