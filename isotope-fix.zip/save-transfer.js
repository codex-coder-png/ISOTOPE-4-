/* Portable save-file import/export. Uses the canonical SAVE API and migrates legacy keys. */
(function(){
  const KEY='isotope_save_v3';
  function byId(id){return document.getElementById(id)}
  function triggerDownload(text,name){
    const blob=new Blob([text],{type:'application/json'}), a=document.createElement('a');
    a.href=URL.createObjectURL(blob); a.download=name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(()=>URL.revokeObjectURL(a.href),1500);
  }
  function importFile(file){
    if(!file) return;
    const reader=new FileReader();
    reader.onload=()=>{
      try{
        SAVE.importSave(String(reader.result||''));
        alert('ISOTOPE save imported successfully.');
        location.reload();
      }catch(err){
        console.error('ISOTOPE save import failed:',err);
        alert('That save file could not be imported. Make sure it is an ISOTOPE .json save file.');
      }
    };
    reader.onerror=()=>alert('The browser could not read that save file.');
    reader.readAsText(file);
  }
  window.ISOTOPE_SAVE_TRANSFER={
    export(){triggerDownload(SAVE.exportSave(),'isotope-save-'+new Date().toISOString().slice(0,10)+'.json')},
    importFile
  };
  function wire(out,inn,file){
    if(!out||!inn||!file)return;
    out.addEventListener('click',()=>window.ISOTOPE_SAVE_TRANSFER.export());
    inn.addEventListener('click',()=>{file.value='';file.click()});
    file.addEventListener('change',()=>importFile(file.files&&file.files[0]));
  }
  wire(byId('btn-save-export'),byId('btn-save-import'),byId('inp-save-import'));
})();
