/* ISOTOPE V75 — Vault selection + compound-id resolution fix
   - Resolves real-compound IDs through DATA.canonicalId before selection.
   - Search-result cards are delegated at capture phase so regenerated cards stay clickable.
   - All element/compound selection clicks use the SFX defined by audio.js.
*/
'use strict';
(function(){
  if(window.__ISO_V75_VAULT_SELECTION_FIX__) return;
  window.__ISO_V75_VAULT_SELECTION_FIX__=true;

  function playSelect(){
    try{ if(window.AUDIO&&AUDIO.SFX&&typeof AUDIO.SFX.select==='function') AUDIO.SFX.select(); else if(window.AUDIO&&AUDIO.SFX&&typeof AUDIO.SFX.click==='function') AUDIO.SFX.click(); }catch(e){}
  }
  function resolve(id){
    try{ return window.DATA&&typeof DATA.canonicalId==='function' ? DATA.canonicalId(id) : id; }
    catch(e){ return id; }
  }
  function select(id){
    const rid=resolve(id);
    try{
      if(typeof window.__ISO_SELECT_VAULT==='function') return window.__ISO_SELECT_VAULT(rid);
    }catch(e){ console.warn('V75 bridge select',e); }
    return null;
  }

  window.__ISO_V75_SELECT_VAULT=function(id){ playSelect(); return select(id); };

  document.addEventListener('click',function(ev){
    const card=ev.target&&ev.target.closest ? ev.target.closest('#scr-vault #vault-v71-catalog .vault-v73-card.unlocked') : null;
    if(!card) return;
    /* The card itself owns the normal handler. This capture handler is a fallback
       for older/global listeners that stop propagation before the target. */
    ev.preventDefault();
    ev.stopPropagation();
    const id=card.dataset.id || card.getAttribute('data-id');
    if(id){ window.__ISO_V75_SELECT_VAULT(id); return; }
    const nameNode=card.querySelector('strong');
    const name=nameNode ? nameNode.textContent.trim() : '';
    const formula=(card.querySelector('small')||{}).textContent||'';
    let target=name;
    try{
      const all=Object.keys(DATA.MOLDEF||{});
      target=all.find(k=>{
        const m=DATA.MOLDEF[k];
        return m&&(String(k).toLowerCase()===name.toLowerCase()||String(m.id||'').toLowerCase()===name.toLowerCase()||String(m.name||'').toLowerCase()===name.toLowerCase()||String(m.f||'').toLowerCase()===formula.toLowerCase().split(' · ')[0]);
      })||name;
    }catch(e){}
    window.__ISO_V75_SELECT_VAULT(target);
  },true);

  /* Mark search cards with their stable key so CSS/DOM tooling and delegated
     selection never have to guess from display text. */
  function stamp(){
    document.querySelectorAll('#scr-vault #vault-v71-catalog .vault-v73-card').forEach(function(card){
      if(card.dataset.v75Stamped) return;
      const strong=card.querySelector('strong');
      if(!strong) return;
      const label=strong.textContent.trim();
      try{
        const candidates=Object.keys(DATA.MOLDEF||{});
        const key=candidates.find(function(k){
          const m=DATA.MOLDEF[k];
          return m && (String(k).toLowerCase()===label.toLowerCase() || String(m.id||'').toLowerCase()===label.toLowerCase() || String(m.name||'').toLowerCase()===label.toLowerCase());
        });
        if(key) card.dataset.id=key;
      }catch(e){}
      card.dataset.v75Stamped='1';
    });
  }
  stamp();

  const st=document.createElement('style');
  st.textContent='#scr-vault #vault-v71-catalog .vault-v73-card.unlocked{pointer-events:auto!important;cursor:pointer!important;}';
  document.head.appendChild(st);

  console.log('ISOTOPE V75 VAULT SELECTION FIX active.');
})();
