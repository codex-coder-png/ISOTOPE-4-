/* ISOTOPE V51 runtime compatibility shim.
   Keeps shared helpers available to late-loaded feature modules even when a
   browser has cached an older game.js/nicotine module. */
(function(){
  if(typeof window.clamp!=='function') window.clamp=function(v,a,b){return v<a?a:v>b?b:v;};
  if(typeof window.d2!=='function') window.d2=function(ax,ay,bx,by){var dx=ax-bx,dy=ay-by;return dx*dx+dy*dy;};
  if(!Number.isFinite(window.TAU)) window.TAU=Math.PI*2;
})();
