/* ISOTOPE — COMPLETE UPDATE LOG THROUGH V84
   Rebuilds the in-game changelog from the known merged history so every
   post-V36 update is visible in one place without duplicating stale rows. */
(function(){
  'use strict';
  if(window.__ISO_COMPLETE_UPDATE_LOG_V83__)return;
  window.__ISO_COMPLETE_UPDATE_LOG_V83__=true;

  var HISTORY=[
    ['V19 · STABILITY / QOL','Fixed recurring runtime crashes, made Deploy refresh relics, moved pause settings beside Resume/Restart/Abandon, and rebuilt the update log as one fixed-height scrolling panel.'],
    ['V21 · MERGED CURRENT PATCH','Merged the current stability, multiplayer, ally, ability, relic, mastery, Vault, local multiplayer, and content systems into one fixed build.'],
    ['V22 · SAVE IMPORT','Normalized legacy/new save formats and repaired save import compatibility.'],
    ['V23 · 9.0 REACTION OVERHAUL','Reworked all 118 element ability slots, added natural elemental reactions, guaranteed Legendary on-hit cards, dedicated beams/status behavior, compound ability sets, and stronger runtime safety.'],
    ['V24 · ELEMENT ABILITY 2','All 118 Ability 2 slots received dedicated runtime contracts while Ability 1 and Ability 3 were preserved. Damage, status, beam, field, defensive, movement, and reaction behaviors now follow each element description.'],
    ['V25 · NICOTINE M1','Separated Nicotine ordinary M1 fire from befriending: normal shots weaken/slow instead of recruiting enemies.'],
    ['V26 · NICOTINE ALLIES','Nicotine Ability 1 introduced permanent green-outlined player allies that stop attacking the player, attack hostiles, and can collect pickups for XP.'],
    ['V27 · NICOTINE STABILITY','Stabilized ally conversion/collision handling so converted enemies are not processed repeatedly or duplicated.'],
    ['V28 · RECEPTOR CHARM','Moved Receptor Charm out of the unsafe normal projectile path to prevent the recurring freeze/crash route.'],
    ['V29 · NICOTINE SAFETY','Made the Nicotine ally system authoritative and isolated, preventing old ally loops from re-processing converted enemies.'],
    ['V30 · ELEMENT ABILITY 3','Installed dedicated third-ability executors for all 118 base elements with distinct targeting, timing, damage, status, defensive, beam, field, or reaction behavior.'],
    ['V31 · CORE / SAVE BRIDGE','Normalized Nitroglycerin synthesis aliases and restored the live game-core bridge so late modules actually execute through the real game loop.'],
    ['V32 · CRASH FIX','Removed the out-of-scope Nicotine distance-helper crash and hardened the core/Nicotine bridge against malformed runtime state.'],
    ['V33 · ABILITY FEEDBACK','Added clearer ability names/descriptions and closed the missing global A/clamp runtime path used by late-loaded ability modules.'],
    ['V34 · NITROGLYCERIN','Corrected Nitroglycerin stats and its three-ability display/runtime data.'],
    ['V35 · POPUP REMOVAL','Removed the oversized in-round equipped/ability information popup while keeping the underlying ability and Vault systems intact.'],
    ['V36 · NITRO + LIQUID NITROGEN','Implemented Nitroglycerin Ability 2/3 combustion behavior, added the Liquid Nitrogen content package, and added the saved 200-point Synthesis Lab unlock.'],
    ['V37 · LIQUID NITROGEN REWORK','Liquid Nitrogen Ability 1 became a large-radius freeze field; its projectile behavior became a four-shard contact shatter with freeze/slow.'],
    ['V38 · FULL QOL','Added frozen-target visuals, Mastery refresh/Exp improvements, favorite selection fixes, augmentation consolidation, and the V38 startup decision prompt.'],
    ['V39 · RESET SAFETY','Identified the automatic progression-wipe migration problem and moved the reset behavior to an explicit optional flow.'],
    ['V40 · OPTIONAL FRESH START','Fresh-start reset became optional with confirmation, 200 starting coins, Hydrogen/Carbon/Oxygen unlocks, one selected starter relic, and stricter rarity power bands.'],
    ['V41 · PRISM OF CHOICE','Prism of Choice now boosts premium rarity weighting by 1.3x, rolls one exact rarity per level-up, and can open a full picker for every available card of that rarity.'],
    ['V42 · CARD CLEANUP','Removed repeated same-purpose cards and duplicated common projectile-output cards while retaining distinct higher-rarity versions.'],
    ['V50 · FINALE MERGE','Merged the large final content/ability/relic/mastery patch while preserving the original isotope-fixed codebase as the base.'],
    ['V50 · COMPOUNDS','Expanded the real-compound catalogue and gave playable compounds dedicated three-slot ability functions.'],
    ['V50 · CARDS / COOLDOWNS / BEAMS','Rebuilt the rarity ladder, removed known card duplicates, added new special cards, applied the requested cooldown pipeline, and tied beam reach/width/hitbox to compound properties.'],
    ['V50 · RELICS / MASTERY','Relic claims became per-player and synchronized; Deploy refreshes relics; the Mastery index rebuilds from live saved unlocks.'],
    ['V51 · NICOTINE RUNTIME','Added safe compatibility helpers, cache-busting, and explicit Nicotine clamp handling so late modules no longer depend on missing globals.'],
    ['V52 · RUNTIME HARDENING','Removed the remaining bare A/clamp dependency from late-loaded ability code and made the game export its ability table safely.'],
    ['V53 · NICOTINE + FRESH RESTART','Nicotine Ability 1 became the dedicated large fast receptor projectile; Settings received the one-time fresh restart and starter-relic flow.'],
    ['V54 · RECURSION FIX','Fixed the maximum-call-stack crash caused by recursive late update/render bridging. The core loop is now stable when wrappers capture it.'],
    ['V55 · RUNTIME STABILITY','Made the V50 stat wrapper re-entry safe, guarded null enemy/player targets, and restored suspended audio after interaction.'],
    ['V56 · LOOP / TARGET HARDENING','Further stabilized late combat wrappers so repeated update entry, missing targets, and partially initialized runtime state cannot turn an ability activation into a permanent broken loop.'],
    ['V57 · TURRET / INPUT FIX','Fixed turret shots using undefined damage/crit/SC values, ignored null player slots, added another update re-entry guard, and improved browser audio resume behavior.'],
    ['V58 · STATS INITIALIZATION','Stopped combat from reading an unavailable ST object during late stat calculation; added safe fallback stats and guaranteed valid player HP/shield initialization.'],
    ['V59 · MASTERY LIVE INDEX','Element Mastery now discovers the current saved unlock/catalog state whenever opened, including compounds such as Nicotine and Nitroglycerin.'],
    ['V60 · NICOTINE ABILITY 1','Hard-routed Nicotine Ability 1 to its large fast receptor projectile with swept collision and the permanent ally conversion path.'],
    ['V61 · COOLDOWN STABILITY','Fixed cooldown compounding: the 1.8x active/signature cooldown scale is applied exactly once during stat recomputation instead of multiplying an already-scaled value.'],
    ['V62 · NITROGLYCERIN HIT SAFETY','Normalized projectile hit arrays and added the missing hit[] field to Nitroglycerin projectiles so collision checks cannot crash the main loop.'],
    ['V63 · NITROGLYCERIN BURN','Nitroglycerin Ability 1 gained an authoritative combustion-projectile contract that reliably applies Burn on direct impact while preserving Abilities 2/3.'],
    ['V64 · EFFECT DAMAGE SCALING','Burn/poison overtime and explicit persistent/radius effect damage now use a 75% base factor of current player Damage without changing ordinary direct projectiles.'],
    ['V65 · ENEMY / BOSS SCALING','Doubled normal enemy wave-growth terms and raised boss per-wave HP growth to 4.5x the prior coefficient.'],
    ['V66 · ECONOMY / MAX SAVE','Reduced coin gain further to an effective 0.30x base pickup before other modifiers, added round-scaled coin drops, and created the max-save progression profile.'],
    ['V67 · TENNESSINE TEXT','Cleaned the Tennessine player-facing description so its signature text ends cleanly at the intended Signature ID.'],
    ['V68 · COMPOUND NAME REVEAL','Added the Periodic Vault compound-name/formula toggle, originally saved in progression preferences.'],
    ['V69 · ISSUES BUTTON','Added the main-menu bottom-right “Issues with the game?” button for reporting game problems.'],
    ['V70 · VAULT SEARCH / INTERACTION','Added element search, repaired favorite/grey-tile pointer interaction, and fixed stale UI overlays that could block Vault interaction.'],
    ['V71 · VAULT SORT / FILTER','Added A–Z/Z–A, weakest/strongest, stat-based sorting, ownership/favorite sorting, category/type filters, grouped separators, and broader element/compound search matching.'],
    ['V72 · SCREEN LAYER FIX','Fixed the extra closing div that let the full-screen main-menu frame cover other screens; added a runtime DOM guard and hid the update-log panel outside the menu.'],
    ['V73 · VAULT SEARCH OVERHAUL','Removed the old compound strip, expanded search results by 2.4x, added newest/oldest compound unlock sorting, locked-result privacy, NOT UNLOCKED grouping, and the separator toggle.'],
    ['V74 · VAULT CLICK BRIDGE','Restored the old working element selection path through a safe bridge so the 118 base tiles remain clickable and search results can open the correct Vault details.'],
    ['V75 · VAULT SELECTION','Fixed compound canonical IDs, restored unlocked compound selection, added dynamic delegated click handling, and made element/compound selection call the audio.js select sound.'],
    ['V76 · LIVE OWNERSHIP PRIVACY','Changed Vault ownership rendering to use saved unlock/molecule state, locking unknown entries to ??? and preventing hidden details from being exposed by search.'],
    ['V77 · OWNERSHIP / LOCKS','Tightened canonical ownership checks for elements and compounds, kept locked results unselectable, and preserved select feedback sound even for locked interactions.'],
    ['V78 · CHROMEOS VAULT / ERASE','Removed 1ms and other polling loops, switched Vault ownership to a scan when entering the Vault, and fixed ERASE so beforeunload cannot restore wiped progress.'],
    ['V79 · SIGNATURE MASTERY','Added the permanent per-element Signature path system: choose Damage, Range, or Cooldown, confirm once, then upgrade that chosen path exactly 3 times.'],
    ['V80 · CHROMEOS RESPONSIVE UI','Made the Vault detail panel follow the viewport and keep Select/Equip accessible; added responsive compact layouts for Chromebook-sized and short screens.'],
    ['V81 · COMBAT PERFORMANCE','Removed repeated background DOM/repaint work that caused post-Deploy micro-stutters while leaving the core combat simulation intact.'],
    ['V82 · MASTERY OPEN REFRESH','Element Mastery now opens directly on the currently equipped element and its equipped Signature instead of requiring a manual element click to refresh the panel.'],
    ['V83 · MASTERLY / RELIC / COMBAT STABILITY','Fixed mastery refresh races and runtime stack failures, made Signature Damage/Range/Cooldown upgrades affect only the chosen element Signature, removed legacy fake mastery/loadout UI that exposed hidden abilities, and completed the relic behavior/stability pass.'],
    ['V84 · MANUAL WAVE START','When Auto Wave is OFF, the run now waits indefinitely until J is pressed to start the next wave; Auto Wave still uses timed intermissions.'],
    ['V84 · PROJECTILE AUGMENTATION','Added Particle Splitter as an augmentation with +3 projectiles per upgrade. Element Mastery no longer contains a projectile upgrade so projectile count stays an augmentation-only path.'],
    ['V84 · CARD POOL CLEANUP','Removed generic duplicate/progress-stack cards, replaced them with direct one-effect cards, and enforced Rare-or-higher rarity for +1 projectile cards.'],
    ['V84 · NICOTINE TEAM OVERHAUL','Nicotine Signatures 1–3 now recruit permanent non-boss enemies into the player team; allies are removed from the hostile count, persist across waves until death, attack hostiles, can be targeted by enemies, collect XP/coins, and display a green ALLY outline. Nicotine M1 remains a separate 25% slow + 25% weaken effect.'],
    ['V84 · RUNTIME SAFETY','Added active-cooldown NaN/negative recovery and safer ally/charm collision handling without adding ChromeOS simulation throttles.'],
    ['V85 · STABILITY HANDOFF','Added the V85 compatibility marker and handed final update/re-entry authority to the V86 stability layer.'],
    ['V86 · FINAL STABILITY','Fixed the recursive update/ETYPES crash, authoritative fixed Signature cooldowns, one-time Element Mastery opening/selection, removed the legacy mastery loadout, removed the Phase Battery dash-damage ring, and smoothed Vault search input without ChromeOS throttling.'],
    ['V87 · NICOTINE BEFRIEND STABILITY','Kept Nicotine Ability 1 on the canonical recruiter projectile, blocked duplicate same-event conversions, and drained stale legacy charm queues so one enemy cannot be processed by multiple Nicotine systems.'],
    ['V88 · CONTENT EXPANSION + PER-ABILITY MASTERY','Expanded the real-compound catalogue with new drug/medical and non-drug compounds, gave each new compound three custom executable abilities, removed element/compound-exclusive cards, added the science splash menu, and introduced independent Signature 1/2/3 mastery storage and paths.'],
    ['V89 · PRIVATE CODES / ADMIN MODE','Added the local ADMINONLYABEL1 admin mode with relic/money controls and admin compound unlocks, plus the one-time BETAISOTOPE 750-coin code.'],
    ['V90 · PLAYER SPEED STABILITY','Rebased player movement speed from the selected element/compound combat stats when deploying and starting new rounds, with the original speed as a safe fallback when no valid speed stat exists.'],
    ['V91 · NICOTINE FREEZE HARDENING','Isolated Nicotine befriending/conversion processing, throttled large recruitment queues across frames, and removed legacy conversion routes that could process the same ally repeatedly.'],
    ['V92 · CHROMEOS VAULT INTERACTION','Restored Chromebook-friendly interaction for the main periodic-table elements, including normal click-to-select/unlock flow and the hover grow/shrink feedback.'],
    ['V93 · CARD / MASTERY / HELIUM FIXES','Normalized level-up cards so each card has one exact stat effect, removed duplicate projectile-count cards, restored independent per-ability mastery storage, centered the science splash, and removed Helium permanent iframe behavior.'],
    ['V94 · SIGNATURE MASTERY RESTORATION','Restored the Element Mastery Signature 1, Signature 2, and Signature 3 upgrade paths as three independent Damage/Range/Cooldown trees, with their own saved path and rank. Added a final UI guard so late legacy refreshes cannot wipe the three trees from the screen.'],
  ];

  function updateFooter(){
    document.querySelectorAll('.menu-update,#menufoot span:last-child').forEach(function(n){
      if(n.id==='menu-update') n.textContent='BUILD V94 · COMPLETE HISTORY';
      else if(/BUILD V|LOCAL CO-OP|V3\d|V4\d|V5\d|V6\d|V7\d|V8\d|V9\d/.test(n.textContent||'')) n.textContent='BUILD V94';
    });
  }

  function rebuild(){
    var panel=document.getElementById('mega-update-panel');
    if(!panel)return false;
    var head=panel.querySelector('.mega-update-head');
    panel.innerHTML='';
    if(head)panel.appendChild(head);
    var wrap=document.createElement('div');
    wrap.className='mega-update-scroll';
    HISTORY.forEach(function(row){
      var d=document.createElement('div');d.className='urow';
      var v=document.createElement('div');v.className='uver';v.textContent=row[0];
      var t=document.createElement('div');t.className='utxt';t.textContent=row[1];
      d.appendChild(v);d.appendChild(t);wrap.appendChild(d);
    });
    panel.appendChild(wrap);
    panel.dataset.completeV94='1';
    try{panel.scrollTop=panel.scrollHeight;wrap.scrollTop=wrap.scrollHeight;}catch(e){}
    updateFooter();
    return true;
  }

  function attempt(){
    if(rebuild())return;
    setTimeout(attempt,400);
  }
  setTimeout(attempt,120);
  setTimeout(rebuild,900);
  setTimeout(rebuild,1800);
  setTimeout(rebuild,3000);
  updateFooter();
  console.log('ISOTOPE COMPLETE UPDATE LOG through V94 active:',HISTORY.length,'entries');
})();
