/* ISOTOPE V90 — per-player round speed baseline
 * Uses the selected element/compound's combat speed as the player's stable
 * baseline for the round. The full computed speed is captured once on deploy
 * and again at each wave start, so accidental live ST.spd changes cannot make
 * movement permanently slow. Temporary movement multipliers (dash, haste,
 * anchor zones, etc.) still work normally.
 */
(function(){
  'use strict';
  if(window.__ISO_V90_PLAYER_SPEED_STABILITY__)return;
  window.__ISO_V90_PLAYER_SPEED_STABILITY__=true;

  var CORE=window.ISO_V23_CORE||{};
  var FALLBACK_SPEED=250;

  function run(){return window.RUN||null;}
  function players(){var r=run();return r&&Array.isArray(r.players)?r.players:[];}
  function finite(v,f){v=Number(v);return Number.isFinite(v)&&v>0?v:f;}
  function elementBaseSpeed(el){
    try{
      var bc=window.DATA&&DATA.baseCombat?DATA.baseCombat(el):null;
      return finite(bc&&bc.spd,FALLBACK_SPEED);
    }catch(_){return FALLBACK_SPEED;}
  }

  function captureOne(p){
    var r=run();if(!r||!p)return;
    var el=p.elem||r.el;
    var base=elementBaseSpeed(el);
    p._isoElementBaseSpeed=base;

    /*
       Keep the round baseline completely independent from the live global ST
       object.  ST is exposed by game.js as a read-only getter, and co-op P2
       must never temporarily replace the host player's global stat context.
       The requested baseline is the selected element/compound's own combat
       speed, so use that directly for every player. Temporary movement effects
       continue to multiply the baseline elsewhere in game.js.
    */
    p._isoRoundSpeed=base;
  }

  function captureAll(reason){
    var r=run();if(!r)return;
    /* Refresh the build first so P1's captured value includes all deployed
       stats/relics/cards currently active. */
    try{if(typeof CORE.getComputeStats==='function'){var fn=CORE.getComputeStats();if(typeof fn==='function')fn();}}catch(_){ }
    players().forEach(captureOne);
    r._isoSpeedLevel=Number(r.level)||1;
    r._isoSpeedWave=Number(r.wave)||0;
    r._isoSpeedReason=reason||'round';
  }

  /* Start/deploy: establish the initial baseline after every previous start
     wrapper has finished changing player elements. */
  if(typeof CORE.getUpdate==='function' && typeof CORE.setUpdate==='function'){
    var baseUpdate=CORE.getUpdate();
    if(typeof baseUpdate==='function'&&!baseUpdate.__isoV90SpeedUpdate){
      var upd=function(dt){
        var r=run();
        if(r){
          var lvl=Number(r.level)||1,wave=Number(r.wave)||0;
          if(r._isoSpeedLevel!==lvl){
            captureAll('level-up');
          }else if(r._isoSpeedWave!==wave && wave>0){
            captureAll('new-round');
          }
        }
        return baseUpdate.apply(this,arguments);
      };
      upd.__isoV90SpeedUpdate=true;
      CORE.setUpdate(upd);
      window.update=upd;
    }
  }



  /* Final start hook: this is loaded after V89, so it sees the complete start
     chain and can safely initialize the speed used by movement. */
  if(typeof CORE.getUseActive==='function'){
    /* no-op: bridge presence check keeps this patch compatible with older builds */
  }
  var startFn=window.GAME&&GAME.start;
  if(typeof startFn==='function'&&!startFn.__isoV90SpeedStart){
    var wrappedStart=function(){
      var out=startFn.apply(this,arguments);
      try{captureAll('deploy');}catch(e){try{console.warn('V90 speed capture',e);}catch(_){}}
      return out;
    };
    wrappedStart.__isoV90SpeedStart=true;
    GAME.start=wrappedStart;
  }

  /* Some builds expose startWave only through the core closure, so watch for a
     new wave in update as the authoritative transition hook. */
  window.ISO_REFRESH_PLAYER_SPEED=function(){try{captureAll('manual');}catch(_){}};
})();
