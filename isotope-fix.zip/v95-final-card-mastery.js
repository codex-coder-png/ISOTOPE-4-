/* ISOTOPE V95 — final card pool + mastery navigation
 *
 * Goals:
 *  1) Keep direct level-up stat cards available for repeated upgrades.
 *  2) Guarantee one selectable card per direct stat mechanic, with exact text.
 *  3) Hide legacy duplicate stat cards from future rolls without breaking
 *     already-earned stats.
 *  4) Mastery navigation may inspect ANY owned element/compound without
 *     changing the equipped element.
 *  5) The mastery signature-path panel shows ONLY the currently equipped
 *     Signature ability for the selected element/compound.
 */
(function(){
  'use strict';
  if(window.__ISO_V95_FINAL_CARD_MASTERY__) return;
  window.__ISO_V95_FINAL_CARD_MASTERY__=true;

  var DATA0=window.DATA||{}, SAVE0=window.SAVE||{};
  var PATHS={
    damage:{label:'DAMAGE',desc:'+12% SIGNATURE DAMAGE / RANK',icon:'⚔'},
    range:{label:'RANGE',desc:'+18% SIGNATURE RANGE / RANK',icon:'⌁'},
    cooldown:{label:'COOLDOWN',desc:'-10% SIGNATURE COOLDOWN / RANK',icon:'⟳'}
  };
  var COSTS=[100,180,300];
  var DIRECT={
    dmg:{ic:'⚔',n:'Focused Damage',d:'Projectiles deal +10% damage.',rarity:'common',raw:.10,max:6},
    rate:{ic:'↯',n:'Rapid Fire',d:'Fire rate is +8%.',rarity:'uncommon',raw:.08/1.25,max:6},
    hp:{ic:'♥',n:'Reinforced Hull',d:'Maximum HP is +12.',rarity:'common',raw:12,max:6},
    spd:{ic:'➤',n:'Thruster Boost',d:'Movement speed is +8%.',rarity:'common',raw:.08,max:6},
    crit:{ic:'✧',n:'Critical Mass',d:'Critical chance is +8%.',rarity:'rare',raw:.08/1.5,max:6},
    shield:{ic:'◈',n:'Shield Reserve',d:'Maximum shield is +15.',rarity:'uncommon',raw:15/1.25,max:6},
    magnet:{ic:'◎',n:'Pickup Field',d:'Pickup range is +10%.',rarity:'uncommon',raw:.10/1.25,max:6},
    coin:{ic:'◈',n:'Coin Matrix',d:'Coin gain is +10%.',rarity:'rare',raw:.10/1.5,max:6},
    pierce:{ic:'➤',n:'Penetrator',d:'Gain +1 pierce.',rarity:'uncommon',raw:1,max:6},
    aoe:{ic:'✹',n:'Reaction Radius',d:'Gain +1 reaction radius level.',rarity:'uncommon',raw:1,max:6},
    homing:{ic:'⌖',n:'Guidance Core',d:'Homing strength is +10%.',rarity:'uncommon',raw:.10/1.25,max:6},
    projs:{ic:'⋔',n:'Particle Split',d:'Gain +1 projectile.',rarity:'rare',raw:1,max:4}
  };
  var RARITY_MUL={common:1,uncommon:1.25,rare:1.5,epic:1.9,legendary:2.4,mythic:3.2};
  var OLD_CORE={pow:'dmg',rate:'rate',multi:'projs',pierce:'pierce',crit:'crit',magnet:'magnet',homing:'homing',plating:'shield',scavenger:'coin'};
  var OLD_PREFIX=/^(?:v50_stat_|v84_direct_|v93_stat_)/i;

  function canonical(id){try{return DATA0.canonicalId?DATA0.canonicalId(id):String(id)}catch(_){return String(id)}}
  function elOf(id){try{return DATA0.EL?DATA0.EL(canonical(id)):null}catch(_){return null}}
  function owned(id){try{return !!(DATA0.isOwned&&DATA0.isOwned(canonical(id)))}catch(_){return false}}
  function escapeHtml(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])})}

  /* ------------------------------- cards ------------------------------- */
  (function normalizeCards(){
    var cards=window.ALL_CARDS;
    if(!Array.isArray(cards)) return;
    var seenDirect={};
    var cleaned=[];
    for(var i=0;i<cards.length;i++){
      var c=cards[i]; if(!c) continue;
      var id=String(c.id||''), text=(String(c.n||'')+' '+String(c.d||''));
      var stat=c.extraStat&&DIRECT[c.extraStat]?String(c.extraStat):null;
      /* Any +1-projectile card that is not our canonical card is a duplicate
         mechanic. Hide it from future pools rather than silently changing the
         effect of an existing saved pickup. */
      var projectileDup=/(?:^|\b)(?:gain\s+)?\+1\s+(?:additional\s+)?projectile(?:\b|s)|projectile\s+(?:count|output)/i.test(text);
      var isLegacyDirect=!!OLD_CORE[id] || OLD_PREFIX.test(id);
      if(stat||isLegacyDirect||projectileDup){
        if(stat) seenDirect[stat]=1;
        /* Leave already-owned legacy records in the runtime for compatibility,
           but make them impossible to roll. max=-1 works with the game's
           `(a.max||5)` availability check. */
        c.max=-1;
        c.hiddenV95=true;
        cleaned.push(c);
      }else{
        cleaned.push(c);
      }
    }
    /* Remove duplicate bespoke cards with identical normalized descriptions;
       exact repeats are never useful as separate choices. */
    var seenDesc={};
    for(var j=cleaned.length-1;j>=0;j--){
      var cc=cleaned[j];
      if(!cc||cc.hiddenV95) continue;
      var key=String(cc.n||'').toLowerCase().replace(/\s+/g,' ').trim()+'|'+String(cc.d||'').toLowerCase().replace(/\s+/g,' ').trim();
      if(!key||key==='|') continue;
      if(seenDesc[key]) cleaned.splice(j,1); else seenDesc[key]=1;
    }
    /* One canonical, repeatable direct card per stat. */
    Object.keys(DIRECT).forEach(function(stat){
      var d=DIRECT[stat];
      cleaned.push({
        id:'v95_direct_'+stat,
        ic:d.ic,n:d.n,d:d.d,max:d.max,rarity:d.rarity,
        extraStat:stat,extraValue:d.raw,
        finalTarget:d.raw*(RARITY_MUL[d.rarity]||1),unique:true,v95Direct:true
      });
    });
    cards.length=0; Array.prototype.push.apply(cards,cleaned);
    window.ISO_V95_CARD_AUDIT={
      direct:Object.keys(DIRECT),
      selectableDirect:Object.keys(DIRECT).map(function(s){return 'v95_direct_'+s}),
      hiddenLegacy:cleaned.filter(function(c){return c&&c.hiddenV95}).map(function(c){return c.id})
    };
  })();

  /* The core computeStats already understands the canonical extraStat fields.
     The only special case worth correcting is the direct projectile count card:
     one card always means exactly +1 projectile. */
  (function guardProjectileStat(){
    var cards=window.ALL_CARDS||[];
    cards.forEach(function(c){
      if(c&&c.id==='v95_direct_projs'){
        c.extraStat='projs'; c.extraValue=1; c.finalTarget=1; c.max=4;
      }
    });
  })();

  /* ------------------------------ mastery ------------------------------ */
  var selectedId=null;
  function getEntries(){
    var out=[],seen={};
    var elems=DATA0&&DATA0.ELEMS?Object.values(DATA0.ELEMS):[];
    elems.forEach(function(e){
      if(!e||!e.id) return; var id=canonical(e.id); if(seen[id]||!owned(id)) return;
      seen[id]=1; out.push({id:id,kind:'element',order:Number(e.n)||0,label:e.sym||e.name||id,sub:String(e.n||''),name:e.name||id,hue:Number(e.hue)||190});
    });
    var mols=DATA0&&DATA0.MOLDEF?DATA0.MOLDEF:{};
    var saved=(SAVE0&&SAVE0.raw&&Array.isArray(SAVE0.raw.mols))?SAVE0.raw.mols:[];
    var savedSet={}; saved.forEach(function(x){savedSet[canonical(x)]=true;});
    Object.keys(mols).forEach(function(k){
      var m=mols[k],id=canonical(k); if(!m||!m.mol||seen[id]||!savedSet[id]||!owned(id))return;
      seen[id]=1; out.push({id:id,kind:'compound',order:100000,name:m.name||id,label:m.f||m.name||id,sub:'⚗',hue:Number(m.hue)||285});
    });
    out.sort(function(a,b){if(a.kind!==b.kind)return a.kind==='element'?-1:1;return a.kind==='element'?a.order-b.order:a.name.localeCompare(b.name)});
    return out;
  }
  function ensureSelected(list){
    var want=selectedId;
    if(!want)try{want=window.__isoMasteryLiveSelected||window.__ISO_MASTERY_VIEW_ID||SAVE0.sel}catch(_){want=SAVE0.sel}
    want=canonical(want);
    if(list.some(function(e){return e.id===want;})){selectedId=want;return want;}
    var saveSel=canonical(SAVE0.sel);
    selectedId=list.some(function(e){return e.id===saveSel;})?saveSel:(list[0]&&list[0].id)||null;
    return selectedId;
  }
  function getUpgrade(id,slot){try{return SAVE0.getSignatureUpgrade?SAVE0.getSignatureUpgrade(id,slot):{path:null,rank:0}}catch(_){return {path:null,rank:0}}}
  function equippedSlot(el){
    var s=0; try{s=SAVE0.getSignature?SAVE0.getSignature(el.id):0}catch(_){s=0}
    return Math.max(0,Math.min(2,Number(s)||0));
  }
  function injectStyle(){
    if(document.getElementById('v95-final-style'))return;
    var s=document.createElement('style');s.id='v95-final-style';s.textContent=''
      +'#scr-mastery #m-elems{cursor:default}'
      +'.v95-mastery{margin-top:12px;padding:14px;border:1px solid #28445e;background:rgba(7,15,26,.86)}'
      +'.v95-eq{border:1px solid #2a4762;background:rgba(9,19,32,.92);padding:13px;margin-top:10px}'
      +'.v95-eq-head{display:flex;align-items:flex-start;justify-content:space-between;gap:10px}.v95-title{font-family:var(--disp,Arial);font-size:18px;letter-spacing:.06em}.v95-desc{font-size:11px;color:#96abc0;line-height:1.4;margin-top:4px}.v95-state{font-size:10px;color:#72f2a0;white-space:nowrap}'
      +'.v95-paths{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin-top:11px}.v95-path{min-height:110px;padding:10px;text-align:left;border:1px solid #28445e;background:#0a1422;color:#d8e7f5;cursor:pointer}.v95-path:hover{border-color:#66ecff}.v95-path.chosen{border-color:#66f0a0;box-shadow:0 0 0 1px rgba(102,240,160,.14) inset}.v95-path.disabled{opacity:.35;cursor:not-allowed}.v95-path b{display:block;letter-spacing:.08em}.v95-path small{display:block;color:#91a7bd;line-height:1.3;margin-top:4px}.v95-pips{display:flex;gap:4px;margin-top:8px}.v95-pips i{display:block;width:24px;height:5px;border:1px solid #28445e}.v95-pips i.on{background:#66f0a0}.v95-action{font-size:9px;color:#b8cbe0;margin-top:7px;letter-spacing:.08em}'
      +'.v95-up{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-top:10px;padding-top:9px;border-top:1px solid #28445e}'
      +'@media(max-width:900px){.v95-paths{grid-template-columns:1fr}.v95-eq-head{display:block}.v95-state{margin-top:5px}}';
    document.head.appendChild(s);
  }
  function renderList(){
    var box=document.getElementById('m-elems'); if(!box)return [];
    var list=getEntries(),id=ensureSelected(list), frag=document.createDocumentFragment();
    list.forEach(function(e){
      var d=document.createElement('div'); d.className='mchip'+(e.kind==='compound'?' compound':'')+(e.id===id?' sel':''); d.dataset.id=e.id; d.dataset.kind=e.kind;
      d.style.borderColor='hsl('+e.hue+' 72% 62%)';d.style.color='hsl('+e.hue+' 72% 62%)';
      d.title=e.kind==='compound'?e.name+' · '+e.label:e.name+' · ELEMENT '+e.sub;
      if(e.kind==='compound')d.innerHTML='<span style="font-weight:bold">⚗</span><span style="font-size:9px">'+escapeHtml(e.label)+'</span><span style="font-size:9px">'+escapeHtml(e.name)+'</span>';
      else d.innerHTML='<span style="font-weight:bold">'+escapeHtml(e.label)+'</span><span style="font-size:9px">'+escapeHtml(String(e.sub||''))+'</span>';
      frag.appendChild(d);
    });
    box.innerHTML='';box.appendChild(frag);
    var idx=list.findIndex(function(e){return e.id===id;}); if(idx>=0)box.scrollTop=Math.max(0,idx*72-100);
    return list;
  }
  function renderDetail(id){
    var scr=document.getElementById('scr-mastery');if(!scr||scr.classList.contains('hidden'))return;
    var el=elOf(id||selectedId||SAVE0.sel);if(!el||!owned(el.id))return; selectedId=canonical(el.id);
    window.__isoMasteryLiveSelected=selectedId;window.__ISO_MASTERY_VIEW_ID=selectedId;window.__ISO_MASTERY_FORCED_ID=selectedId;
    injectStyle();
    var detail=document.getElementById('m-detail');if(!detail)return;
    var col='hsl('+(Number(el.hue)||190)+' 80% 68%)',slot=equippedSlot(el),choices=el.choices||el.signatures||[],sig=choices[slot]||choices[0]||{name:'SIGNATURE '+(slot+1),desc:'Ability not installed.',ic:['⚛','✦','◈'][slot]};
    var mx=SAVE0.mxp?SAVE0.mxp(el.id):{xp:0}; u=getUpgrade(el.id,slot);
    detail.innerHTML='';
    var head=document.createElement('div');head.innerHTML='<div style="font-family:var(--disp,Arial);font-size:24px;color:'+col+'">'+escapeHtml(el.name||el.sym||el.id).toUpperCase()+'</div><div class="sub">Mastery XP available: <b style="color:var(--gr,#66f0a0)">◆ '+escapeHtml(String(mx.xp||0))+'</b> · this panel follows the selected element/compound, not the equipped element.</div>';detail.appendChild(head);
    var wrap=document.createElement('div');wrap.className='v95-mastery';wrap.innerHTML='<div style="font-family:var(--disp,Arial);font-size:18px;letter-spacing:.08em;color:#66ecff">✦ SIGNATURE MASTERY</div><div class="sub" style="margin-top:5px">Only the currently equipped Signature ability is shown here. Its DAMAGE / RANGE / COOLDOWN path is saved independently for this '+(el.mol?'compound':'element')+' and ability slot '+(slot+1)+'.</div>';
    var box=document.createElement('div');box.className='v95-eq';
    var ownedSlot=slot===0||!SAVE0.abilOwned||SAVE0.abilOwned(el.id,slot);
    box.innerHTML='<div class="v95-eq-head"><div><div class="v95-title" style="color:'+col+'">SIGNATURE '+(slot+1)+' · '+escapeHtml(sig.ic||['⚛','✦','◈'][slot])+' '+escapeHtml(sig.name||('ABILITY '+(slot+1)))+'</div><div class="v95-desc">'+escapeHtml(sig.desc||'')+'</div></div><div class="v95-state">'+(ownedSlot?(u.path?'PATH: '+PATHS[u.path].label+' · '+u.rank+'/3':'NO PATH CHOSEN'):'LOCKED — PURCHASE ABILITY '+(slot+1))+'</div></div>';
    var grid=document.createElement('div');grid.className='v95-paths';
    Object.keys(PATHS).forEach(function(k){
      var pth=PATHS[k],chosen=u.path===k,btn=document.createElement('button');btn.type='button';btn.className='v95-path'+(chosen?' chosen':'')+((u.path&&!chosen)||!ownedSlot?' disabled':'');btn.disabled=!!((u.path&&!chosen)||!ownedSlot);
      var pips='';for(var i=0;i<3;i++)pips+='<i class="'+(chosen&&i<u.rank?'on':'')+'"></i>';
      btn.innerHTML='<span style="font-size:20px">'+pth.icon+'</span><span><b>'+pth.label+'</b><small>'+pth.desc+'</small><span class="v95-pips">'+pips+'</span><span class="v95-action">'+(chosen?'PATH LOCKED':'CHOOSE '+pth.label)+'</span></span>';
      btn.onclick=function(){
        if(!ownedSlot||u.path)return;
        if(!window.__ISO_V95_MASTERY_PENDING__)window.__ISO_V95_MASTERY_PENDING__={};
        var pending=window.__ISO_V95_MASTERY_PENDING__,key=selectedId+'|'+slot+'|'+k;
        if(!pending[key]){pending[key]=1;renderDetail(selectedId);return;}
        if(SAVE0.chooseSignatureUpgradePath&&SAVE0.chooseSignatureUpgradePath(selectedId,k,slot)){
          delete pending[key];try{if(window.SFX&&SFX.unlock)SFX.unlock()}catch(_){ }renderDetail(selectedId);
        }
      };
      grid.appendChild(btn);
    });
    box.appendChild(grid);
    if(u.path){
      var up=document.createElement('div');up.className='v95-up';var cost=u.rank<3?COSTS[u.rank]:0;up.innerHTML='<div><b>'+PATHS[u.path].label+' PATH · '+u.rank+'/3</b><div class="sub">'+(u.rank>=3?'MAXED':'Next rank costs ◆ '+cost+' mastery XP.')+'</div></div>';
      var buy=document.createElement('button');buy.type='button';buy.className='btn primary';buy.textContent=u.rank>=3?'MAX':'UPGRADE · ◆ '+cost;buy.disabled=u.rank>=3||Number(mx.xp||0)<cost;buy.onclick=function(){if(SAVE0.buySignatureUpgrade&&SAVE0.buySignatureUpgrade(selectedId,slot)){try{if(window.SFX&&SFX.unlock)SFX.unlock()}catch(_){ }renderDetail(selectedId)}};up.appendChild(buy);box.appendChild(up);
    }
    wrap.appendChild(box);detail.appendChild(wrap);
  }
  function select(id){
    id=canonical(id);if(!id||!owned(id))return;
    selectedId=id;window.__isoMasteryLiveSelected=id;window.__ISO_MASTERY_VIEW_ID=id;window.__ISO_MASTERY_FORCED_ID=id;
    renderList();
    /* Older V79/V93 handlers queue a render on the same click. Render again
       after those queued callbacks so they cannot snap the screen back. */
    renderDetail(id);setTimeout(function(){renderList();renderDetail(id)},40);setTimeout(function(){renderDetail(id)},160);
  }
  function disconnectLegacyObserver(){
    try{var d=document.getElementById('m-detail');if(d&&d.__isoV94Observer){d.__isoV94Observer.disconnect();delete d.__isoV94Observer;}}catch(_){ }
  }
  function hook(){
    disconnectLegacyObserver();
    /* Final UI.show wrapper: do not mutate SAVE.sel. */
    if(window.UI&&typeof UI.show==='function'&&!UI.show.__isoV95Mastery){
      var base=UI.show;
      UI.show=function(id){
        var out=base.apply(this,arguments);
        if(id==='scr-mastery'){
          selectedId=canonical(window.__isoMasteryLiveSelected||window.__ISO_MASTERY_VIEW_ID||SAVE0.sel);
          renderList();
          setTimeout(function(){disconnectLegacyObserver();renderList();renderDetail(selectedId)},220);
          setTimeout(function(){disconnectLegacyObserver();renderDetail(selectedId)},420);
        }
        return out;
      };
      UI.show.__isoV95Mastery=true;
    }
    document.addEventListener('click',function(e){
      var chip=e.target&&e.target.closest?e.target.closest('#m-elems .mchip[data-id]'):null;
      if(!chip)return;
      var id=canonical(chip.dataset.id);if(!id||!owned(id))return;
      /* This is a VIEW-ONLY selection; it must never equip the clicked entry. */
      e.preventDefault();e.stopImmediatePropagation();
      try{if(window.SFX&&SFX.click)SFX.click()}catch(_){ }
      select(id);
    },true);
    window.ISO_V93_RENDER_MASTERY=renderDetail;
    window.ISO_V88_RENDER_MASTERY=renderDetail;
    window.ISO_RENDER_MASTERY=renderDetail;
    window.ISO_V95_RENDER_MASTERY=renderDetail;
    window.ISO_REFRESH_MASTERY=function(){if(!document.getElementById('scr-mastery')||document.getElementById('scr-mastery').classList.contains('hidden'))return;renderList();setTimeout(function(){renderDetail(selectedId||SAVE0.sel)},25);};
    /* Keep the selected entry stable across future list refreshes. */
    if(window.MutationObserver){
      var box=document.getElementById('m-elems');
      if(box&&!box.__isoV95Obs){
        var obs=new MutationObserver(function(){
          if(document.getElementById('scr-mastery')&&!document.getElementById('scr-mastery').classList.contains('hidden')){
            var selectedNow=selectedId; if(selectedNow&&box.querySelector('.mchip[data-id="'+String(selectedNow).replace(/"/g,'\\"')+'"]'))return;
            setTimeout(function(){renderList()},0);
          }
        });
        obs.observe(box,{childList:true});box.__isoV95Obs=obs;
      }
    }
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',hook,{once:true});else hook();
  window.addEventListener('load',hook,{once:true});
  setTimeout(hook,250);
  setTimeout(hook,1000);
  console.log('ISOTOPE V95 ACTIVE: repeatable exact stat cards + duplicate-proof pool + view-only mastery selection + equipped-signature-only mastery path.');
})();
