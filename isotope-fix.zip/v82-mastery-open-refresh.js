/* ISOTOPE V82 — superseded by V83 deterministic Mastery open selection. */
