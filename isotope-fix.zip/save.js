'use strict';window.SAVE={};
(function(){
const KEY='isotope_save_v3';
function def(){return{coins:0,sel:'e1',unlocked:['e1','e6','e8'],mols:[],meta:{},
 mastery:{},signatures:{},signatureUpgrades:{},stats:{runs:0,kills:0,bestWave:0,earned:0,mxp:0},
 set:{sfx:80,mus:50,music:1,shake:1,dmg:1,heartbeat:1,killstreaks:1,achToast:1,quickcomm:1,pingBadge:1,ambient:1},
 brief:false,abil:{},favs:[],plays:{},achievements:{}}}
function readStoredPayload(){
  const primary=localStorage.getItem(KEY);
  if(primary) return primary;
  for(const legacy of ['isotope_save','isotope_save_v2']){const v=localStorage.getItem(legacy);if(v) return v;}
  return '{}';
}
let S;try{S={...def(),...JSON.parse(readStoredPayload())};
 S.stats={...def().stats,...(S.stats||{})};S.set={...def().set,...(S.set||{})};
 S.meta=S.meta||{};S.mastery=S.mastery||{};S.signatures=S.signatures||{};S.signatureUpgrades=(S.signatureUpgrades&&typeof S.signatureUpgrades==='object'&&!Array.isArray(S.signatureUpgrades))?S.signatureUpgrades:{};S.abil=S.abil||{};
 S.favs=Array.isArray(S.favs)?S.favs:[];S.plays=S.plays||{};S.achievements=S.achievements||{};
 S.unlocked=[...new Set(Array.isArray(S.unlocked)?S.unlocked:[])];
 S.mols=[...new Set(Array.isArray(S.mols)?S.mols:[])];
 if(!S.unlocked.includes('e1')) S.unlocked.unshift('e1');
 if(!S.sel || (String(S.sel).startsWith('e') && !S.unlocked.includes(S.sel))) S.sel='e1';
 save();
}catch(e){S=def()}
function save(){try{if(SAVE.__erasingProgress)return; localStorage.setItem(KEY,JSON.stringify(S)); localStorage.removeItem('isotope_save'); localStorage.removeItem('isotope_save_v2');}catch(e){}}
function eraseProgress(){
  try{
    SAVE.__erasingProgress=true;
    localStorage.removeItem(KEY);
    localStorage.removeItem('isotope_save');
    localStorage.removeItem('isotope_save_v2');
    // Clear Isotope migration/compatibility flags too, without touching unrelated site data.
    for(let i=localStorage.length-1;i>=0;i--){
      const k=localStorage.key(i);
      if(k && /^isotope(?:_|$)/i.test(k)) localStorage.removeItem(k);
    }
  }catch(e){}
  location.reload();
}
function refreshCoins(){document.querySelectorAll('.coinv').forEach(b=>b.textContent=Number(S.coins||0).toLocaleString())}
function cloneDefaults(){const d=def();d.stats={...d.stats};d.set={...d.set};return d}
function normalizeImportedSave(input){
  let data=input;
  if(data && typeof data==='object' && data.save && typeof data.save==='object' && !Array.isArray(data.save)) data=data.save;
  else if(data && typeof data==='object' && data.data && typeof data.data==='object' && !Array.isArray(data.data) && (data.type==='isotope-save'||data.version)) data=data.data;
  if(!data || typeof data!=='object' || Array.isArray(data)) throw Error('invalid save object');
  const out=cloneDefaults();
  Object.keys(data).forEach(k=>{out[k]=data[k]});
  out.coins=Number.isFinite(Number(out.coins)) ? Math.max(0,Math.min(Number(out.coins),Number.MAX_SAFE_INTEGER)) : 0;
  out.unlocked=[...new Set(Array.isArray(out.unlocked)?out.unlocked.map(String):[])];
  out.mols=[...new Set(Array.isArray(out.mols)?out.mols.map(String):[])];
  out.favs=Array.isArray(out.favs)?[...new Set(out.favs.map(String))]:[];
  out.relicsFound=Array.isArray(out.relicsFound)?[...new Set(out.relicsFound.map(String))]:[];
  out.relicLoadout=Array.isArray(out.relicLoadout)?[...new Set(out.relicLoadout.map(String))]:[];
  out.settings=(out.settings&&typeof out.settings==='object'&&!Array.isArray(out.settings))?out.settings:{};
  out.abilityMastery=(out.abilityMastery&&typeof out.abilityMastery==='object'&&!Array.isArray(out.abilityMastery))?out.abilityMastery:{};
  out.abil=(out.abil&&typeof out.abil==='object'&&!Array.isArray(out.abil))?out.abil:{};
  out.mastery=(out.mastery&&typeof out.mastery==='object'&&!Array.isArray(out.mastery))?out.mastery:{};
  out.signatures=(out.signatures&&typeof out.signatures==='object'&&!Array.isArray(out.signatures))?out.signatures:{};
  out.signatureUpgrades=(out.signatureUpgrades&&typeof out.signatureUpgrades==='object'&&!Array.isArray(out.signatureUpgrades))?out.signatureUpgrades:{};
  out.meta=(out.meta&&typeof out.meta==='object'&&!Array.isArray(out.meta))?out.meta:{};
  out.stats={...cloneDefaults().stats,...(out.stats&&typeof out.stats==='object'?out.stats:{})};
  out.set={...cloneDefaults().set,...(out.set&&typeof out.set==='object'?out.set:{})};
  out.plays=(out.plays&&typeof out.plays==='object')?out.plays:{};
  out.achievements=(out.achievements&&typeof out.achievements==='object')?out.achievements:{};
  if(!out.unlocked.includes('e1')) out.unlocked.unshift('e1');
  return out;
}
function importSave(input){
  const data=typeof input==='string' ? JSON.parse(input) : input;
  const next=normalizeImportedSave(data);
  S=next;
  try{S.sel=DATA&&DATA.canonicalId?DATA.canonicalId(S.sel):S.sel}catch(e){}
  if(!S.sel || (String(S.sel).startsWith('e') && !S.unlocked.includes(S.sel))) S.sel='e1';
  if(S.signatures[S.sel]==null) S.signatures[S.sel]=0;
  save(); refreshCoins();
  return true;
}
function exportSave(){return JSON.stringify(S,null,2)}
function addCoins(v){S.coins+=v;S.stats.earned+=Math.max(0,v);refreshCoins()}
function spend(v){if(S.coins<v)return false;S.coins-=v;refreshCoins();save();return true}
function unlockElement(id,cost){
 id=DATA.canonicalId(id);
 if(!id.startsWith('e') || S.unlocked.includes(id)) return S.unlocked.includes(id);
 if(S.coins<cost) return false;
 S.coins-=cost; S.unlocked.push(id); S.unlocked=[...new Set(S.unlocked)];
 if(S.signatures[id]==null) S.signatures[id]=0; if(!S.abil[id]) S.abil[id]={};
 S.sel=id;
 refreshCoins(); save(); return true
}
function abilCost(el){
 if(!el) return 700;
 return el.mol ? 700 : Math.max(20, Math.round((Number(el.cost)||30)*2/5)*5);
}
function abilOwned(id, slot){
 try{id=DATA.canonicalId(id);}catch(e){}
 if(slot===0) return true;
 return !!(S.abil[id] && S.abil[id][slot]);
}
function buyAbil(id, slot, el){
 try{id=DATA.canonicalId(id);}catch(e){}
 if(slot===0) return true;
 if(abilOwned(id, slot)) return true;
 const cost = abilCost(el || (window.DATA && DATA.EL ? DATA.EL(id) : null));
 if(S.coins < cost) return false;
 S.coins -= cost;
 if(!S.abil[id]) S.abil[id] = {};
 S.abil[id][slot] = true;
 refreshCoins(); save(); return true;
}
function isFav(id){return S.favs.includes(id);}
function toggleFav(id){
 const i=S.favs.indexOf(id);
 if(i>=0) S.favs.splice(i,1); else S.favs.push(id);
 save();
}
function trackPlay(id){S.plays[id]=(S.plays[id]||0)+1;save();}
function grantAchievement(key){
 if(S.achievements[key]) return false;
 S.achievements[key]=Date.now();save();return true;
}
function hasAchievement(key){return !!S.achievements[key];}
function dailySeed(){
 const d=new Date();
 return d.getFullYear()*10000+d.getMonth()*100+d.getDate();
}
function mxp(id){return S.mastery[id]||{xp:0,nodes:{}}}
function addMxp(id,v){const m=mxp(id);m.xp+=v;S.mastery[id]=m;S.stats.mxp+=v}
function nodeRank(id,key){return mxp(id).nodes[key]||0}

/* V79 Signature Mastery: one permanent path per element, three ranks max.
   The chosen path follows the element's currently equipped Signature ability;
   it never touches base attacks, cards, relics, or normal mastery nodes. */
const SIG_UPGRADE_PATHS={
 damage:{label:'DAMAGE',desc:'+12% SIGNATURE DAMAGE / RANK',multPerRank:.12},
 range:{label:'RANGE',desc:'+18% SIGNATURE RANGE / RANK',multPerRank:.18},
 cooldown:{label:'COOLDOWN',desc:'-10% SIGNATURE COOLDOWN / RANK',multPerRank:.10}
};
const SIG_UPGRADE_COSTS=[100,180,300];
function getSignatureUpgrade(id){
 try{id=DATA.canonicalId(id)}catch(e){}
 const u=S.signatureUpgrades[id];
 if(!u||typeof u!=='object')return {path:null,rank:0};
 const path=Object.prototype.hasOwnProperty.call(SIG_UPGRADE_PATHS,String(u.path))?String(u.path):null;
 const rank=Math.max(0,Math.min(3,Math.floor(Number(u.rank)||0)));
 return {path,rank};
}
function chooseSignatureUpgradePath(id,path){
 try{id=DATA.canonicalId(id)}catch(e){}
 if(!SIG_UPGRADE_PATHS[path]||getSignatureUpgrade(id).path)return false;
 S.signatureUpgrades[id]={path:String(path),rank:0};save();return true;
}
function signatureUpgradeCost(id){const u=getSignatureUpgrade(id);return u.path&&u.rank<3?SIG_UPGRADE_COSTS[u.rank]:0}
function buySignatureUpgrade(id){
 try{id=DATA.canonicalId(id)}catch(e){}
 const u=getSignatureUpgrade(id);
 if(!u.path||u.rank>=3)return false;
 const m=mxp(id),cost=SIG_UPGRADE_COSTS[u.rank];
 if(m.xp<cost)return false;
 m.xp-=cost; m.nodes=m.nodes||{}; S.mastery[id]=m;
 S.signatureUpgrades[id]={path:u.path,rank:u.rank+1};save();return true;
}
function getSignatureUpgradeStats(id){
 const u=getSignatureUpgrade(id),r=u.rank;
 return {path:u.path,rank:r,damageMult:u.path==='damage'?1+.12*r:1,rangeMult:u.path==='range'?Math.pow(1.18,r):1,cooldownMult:u.path==='cooldown'?Math.pow(.90,r):1,cost:signatureUpgradeCost(id)};
}
function buyNode(elemId,nodeIdx){const t=DATA.MNODES[nodeIdx],m=mxp(elemId),r=m.nodes[t.key]||0;
 if(r>=t.max)return false;const c=DATA.mxCost(nodeIdx,r);
 if(m.xp<c)return false;m.xp-=c;m.nodes[t.key]=r+1;S.mastery[elemId]=m;save();return true}
function metaLv(id){return S.meta[id]||0}
function metaCost(m,lv){return Math.round(m.base*Math.pow(lv+1,1.7)/10)*10}
function getSignature(id){ return S.signatures[id] || 0 }
function setSignature(id,slot){ id=DATA.canonicalId(id); slot=Math.max(0,Math.min(2,+slot||0)); S.signatures[id]=slot; save(); return slot }
function equipElement(id){ id=DATA.canonicalId(id); if(id.startsWith('e') && !S.unlocked.includes(id)) return false; S.sel=id; if(S.signatures[id]==null) S.signatures[id]=0; save(); return true }

Object.assign(SAVE,{save,refreshCoins,addCoins,spend,unlockElement,
 mxp,addMxp,nodeRank,buyNode,getSignature,setSignature,equipElement,metaLv,metaCost,getSignatureUpgrade,chooseSignatureUpgradePath,signatureUpgradeCost,buySignatureUpgrade,getSignatureUpgradeStats,
 abilCost,abilOwned,buyAbil,isFav,toggleFav,trackPlay,grantAchievement,hasAchievement,dailySeed,
 importSave,exportSave,normalizeImportedSave,eraseProgress});
Object.defineProperty(SAVE,'raw',{configurable:true,get:()=>S});
Object.defineProperty(SAVE,'coins',{configurable:true,get:()=>S.coins});
Object.defineProperty(SAVE,'unlocked',{get:()=>S.unlocked});
Object.defineProperty(SAVE,'mols',{get:()=>S.mols});
Object.defineProperty(SAVE,'set',{get:()=>S.set,set:v=>{S.set=v||S.set||{}}});
Object.defineProperty(SAVE,'stats',{get:()=>S.stats});
Object.defineProperty(SAVE,'meta',{get:()=>S.meta});
Object.defineProperty(SAVE,'sel',{get:()=>S.sel,set:v=>{S.sel=v}});
})();