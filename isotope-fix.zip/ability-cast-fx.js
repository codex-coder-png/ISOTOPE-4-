/* ISOTOPE V32 — ABILITY CAST FEEDBACK
   Every ability now shows a clear "something just happened" pop/burst the
   instant it's cast, in the player's own element color:
     - A quick expanding ring + particle burst at the player, so even
       abilities with subtle or invisible projectile effects read clearly.
     - A SECOND burst at the cursor, for the abilities that act on whatever
       is near the mouse (a lot of these had no cast feedback there at all,
       so the effect looked like it "did nothing" even when it worked).
   This wraps window.useActive (loaded last, after every other ability
   system), so it fires for every element, every compound, every slot,
   without touching any individual ability's own code.
*/
'use strict';
(function(){
  if(window.__ISO_V32_ABILITY_CAST_FX__)return;
  window.__ISO_V32_ABILITY_CAST_FX__=true;

  function castPop(p){
    try{
      var r=window.RUN; if(!r||!p) return;
      var hue=(p.elem&&Number.isFinite(+p.elem.hue))?+p.elem.hue:(r.hue||190);
      if(window.ringFx) ringFx(p.x,p.y,hue,70,10);
      if(window.fxBurst) fxBurst(p.x,p.y,hue,16);
      if(window.fxRing) fxRing(p.x,p.y,hue,60,6,.35);

      /* Cursor feedback: only meaningfully different from the player-position
         pop when the cursor is actually some distance from the player, which
         is exactly the case for cursor/area-targeted abilities. */
      var m=window.mouse;
      if(m && Number.isFinite(m.x) && Number.isFinite(m.y)){
        var dx=m.x-p.x, dy=m.y-p.y;
        if((dx*dx+dy*dy) > 60*60){
          if(window.ringFx) ringFx(m.x,m.y,hue,50,6);
          if(window.fxBurst) fxBurst(m.x,m.y,hue,10);
        }
      }
    }catch(_e){}
  }

  var oldUseActive=window.useActive;
  window.useActive=function(p){
    var cdBefore = p ? (p.activeCd||0) : 0;
    var ret = typeof oldUseActive==='function' ? oldUseActive(p) : undefined;
    /* An ability only actually fired if it put the cooldown on cooldown (it
       was ready before, and is on cooldown now). This avoids popping a
       burst effect for a press that did nothing because the ability was
       still cooling down or the player was downed. */
    if(p && cdBefore<=0 && (p.activeCd||0)>0) castPop(p);
    return ret;
  };

  console.log('ISO_V32_ABILITY_CAST_FX active: every ability now shows a player-position pop and a cursor-position pop when it actually fires.');
})();
