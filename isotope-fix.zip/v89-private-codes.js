/* ISOTOPE V89 — PRIVATE CODES / LOCAL ADMIN MODE
 * Client-side convenience codes for the game's local save.
 * ADMINONLYABEL1 unlocks a persistent local admin/god mode.
 * BETAISOTOPE grants 750 coins once per save.
 *
 * Note: because Isotope runs client-side, this is a secret-code gate, not
 * cryptographic authentication. Anyone with the game source could inspect it.
 */
(function(){
  'use strict';
  if(window.__ISO_V89_PRIVATE_CODES__) return;
  window.__ISO_V89_PRIVATE_CODES__ = true;

  var ADMIN_CODE = 'ADMINONLYABEL1';
  var BETA_CODE = 'BETAISOTOPE';
  var ADMIN_FLAG = '__isoAdminGodMode';

  function raw(){ return window.SAVE && SAVE.raw ? SAVE.raw : null; }
  function settings(){
    var s = raw();
    if(!s) return null;
    s.settings = (s.settings && typeof s.settings === 'object' && !Array.isArray(s.settings)) ? s.settings : {};
    return s.settings;
  }
  function adminOn(){
    var s = settings();
    return !!(s && s[ADMIN_FLAG]);
  }
  function save(){ try{ if(window.SAVE && typeof SAVE.save==='function') SAVE.save(); }catch(_){} }
  function toast(msg, type){
    try{ if(window.UI && UI.toast) UI.toast(msg,type||'good'); else if(window.toast) window.toast(msg,type); else alert(msg); }catch(_){ try{ alert(msg); }catch(e){} }
  }
  function allRelicIds(){
    var list=[];
    [window.RELICS, window.DATA && DATA.RELICS].forEach(function(arr){
      if(!Array.isArray(arr)) return;
      arr.forEach(function(r){ if(r && r.id && list.indexOf(r.id)<0) list.push(String(r.id)); });
    });
    return list;
  }
  function activateAdmin(){
    var s=settings();
    if(!s || !raw()) return false;
    s[ADMIN_FLAG] = true;
    /* Max out permanent relic ownership and explicitly enable every relic.
       This matches the current owned+enabled relic model. */
    var ids=allRelicIds(), f=Array.isArray(raw().relicsFound)?raw().relicsFound:[], l=Array.isArray(raw().relicLoadout)?raw().relicLoadout:[];
    ids.forEach(function(id){ if(f.indexOf(id)<0) f.push(id); if(l.indexOf(id)<0) l.push(id); });
    raw().relicsFound=f; raw().relicLoadout=l;
    save();
    try{ if(window.ISO_REFRESH_RELIC_PANEL) ISO_REFRESH_RELIC_PANEL(); }catch(_){}
    try{ if(window.renderVault) renderVault(); }catch(_){}
    return true;
  }
  function claimBeta(){
    var s=settings();
    if(!s || !raw()) return false;
    s.__isoRedeemedCodes = (Array.isArray(s.__isoRedeemedCodes)?s.__isoRedeemedCodes:[]);
    if(s.__isoRedeemedCodes.indexOf(BETA_CODE)>=0) return false;
    s.__isoRedeemedCodes.push(BETA_CODE);
    raw().coins = Math.max(0, Number(raw().coins)||0) + 750;
    try{ if(window.SAVE.refreshCoins) SAVE.refreshCoins(); }catch(_){}
    save();
    return true;
  }
  function adminUnlockCompound(id){
    if(!adminOn()) return false;
    var s=raw(); if(!s) return false;
    var key;
    try{ key=DATA && DATA.canonicalId ? DATA.canonicalId(id) : id; }catch(_){ key=id; }
    var el=null;
    try{ el=DATA && DATA.EL ? DATA.EL(key) : null; }catch(_){ }
    if(!el || !el.mol) return false;

    /* Mirror the normal Synthesis Lab success path: catalog the real
       compound in SAVE.raw.mols, initialize its Signature 1 state, keep it
       available for the Lab inventory, and persist it.  We do not merely
       mark the Vault card visually unlocked. */
    s.mols=Array.isArray(s.mols)?s.mols:[];
    var wasKnown=s.mols.indexOf(key)>=0;
    if(!wasKnown) s.mols.push(key);
    s.mols=[...new Set(s.mols)];
    s.signatures=(s.signatures&&typeof s.signatures==='object'&&!Array.isArray(s.signatures))?s.signatures:{};
    if(s.signatures[key]==null) s.signatures[key]=0;
    s.abil=(s.abil&&typeof s.abil==='object'&&!Array.isArray(s.abil))?s.abil:{};
    if(!s.abil[key]) s.abil[key]={};
    save();
    return {key:key,el:el,wasKnown:wasKnown};
  }
  function patchVaultSelection(){
    if(window.__ISO_V89_VAULT_PATCH__) return;
    var prev=window.__ISO_SELECT_VAULT;
    if(typeof prev!=='function') return;
    window.__ISO_V89_VAULT_PATCH__=true;
    window.__ISO_SELECT_VAULT=function(id){
      try{ adminUnlockCompound(id); }catch(_){}
      return prev(id);
    };
  }
  function wireLockedCompounds(){
    if(!adminOn()) return;

    /* V73 renders undiscovered entries in #vault-v71-catalog as locked
       buttons. Use one capture-phase delegated handler for those cards so
       regenerated search results remain clickable without attaching a new
       listener to every card on every render. */
    if(window.__ISO_V89_LOCKED_COMPOUND_CLICKS__) return;
    window.__ISO_V89_LOCKED_COMPOUND_CLICKS__=true;

    document.addEventListener('click',function(e){
      if(!adminOn()) return;
      var card=e.target&&e.target.closest ? e.target.closest('#scr-vault #vault-v71-catalog .vault-v73-card.locked.compound') : null;
      if(!card) return;

      var key=card.dataset.id || card.getAttribute('data-id');
      if(!key) return;
      try{ key=DATA&&DATA.canonicalId ? DATA.canonicalId(key) : key; }catch(_){ }

      var unlocked=adminUnlockCompound(key);
      if(!unlocked) return;

      e.preventDefault();
      e.stopPropagation();
      try{ if(window.SFX&&SFX.unlock) SFX.unlock(); }
      catch(_){
        try{ if(window.AUDIO&&AUDIO.SFX&&typeof AUDIO.SFX.unlock==='function') AUDIO.SFX.unlock(); }catch(e2){}
      }

      var m=null;
      try{ m=DATA&&DATA.MOLDEF ? DATA.MOLDEF[key] : null; }catch(_){ }
      var name=m&&m.name ? m.name : (m&&m.f ? m.f : key);
      toast(unlocked.wasKnown ? 'ADMIN MODE · '+name+' ALREADY CATALOGUED' : 'ADMIN MODE · '+name+' CATALOGUED','gold');

      /* Refresh the same surfaces affected by a successful synthesis: the
         Lab inventory/book and the Vault ownership cards. This makes the
         newly catalogued compound immediately available as a normal playable
         compound, rather than leaving it looking/behaving like a locked entry. */
      try{ if(window.renderLab) renderLab(); }catch(_){ }
      try{ if(window.renderVault) renderVault(); }catch(_){ }
    },true);
  }

  function renderAdminPanel(){
    var rows=document.getElementById('set-rows');
    if(!rows || document.getElementById('iso-private-codes')) return;
    var box=document.createElement('div');
    box.id='iso-private-codes';
    box.className='setrow panel';
    box.innerHTML=''
      +'<label style="display:block">CODES <small style="color:var(--tx3)">redeem a code</small></label>'
      +'<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:8px">'
      +'<input id="iso-code-input" type="text" autocomplete="off" autocapitalize="characters" spellcheck="false" placeholder="ENTER CODE" style="flex:1;min-width:220px;padding:10px 12px;background:rgba(4,9,17,.75);border:1px solid #334052;color:var(--tx);font:12px var(--mono);outline:none">'
      +'<button class="btn chamf" id="iso-code-submit">REDEEM</button>'
      +'</div>'
      +'<div id="iso-admin-panel" style="display:none;margin-top:12px;padding-top:12px;border-top:1px solid #273143">'
      +'<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">'
      +'<span style="color:var(--am);font-family:var(--mono);font-size:11px;letter-spacing:.12em">ADMIN / GOD MODE</span>'
      +'<span id="iso-admin-status" style="color:var(--gr);font:10px var(--mono)">ACTIVE</span>'
      +'</div>'
      +'<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:10px">'
      +'<input id="iso-money-input" type="number" min="0" step="1" placeholder="SET MONEY" style="width:180px;padding:10px 12px;background:rgba(4,9,17,.75);border:1px solid #334052;color:var(--tx);font:12px var(--mono);outline:none">'
      +'<button class="btn chamf" id="iso-money-set">SET MONEY</button>'
      +'<button class="btn chamf" id="iso-money-max">MAX MONEY</button>'
      +'</div>'
      +'<small style="display:block;margin-top:8px;color:var(--tx3)">Admin mode also owns and enables every current relic. Clicking any compound in the Vault unlocks it instantly.</small>'
      +'</div>';
    rows.appendChild(box);

    var input=box.querySelector('#iso-code-input');
    var submit=box.querySelector('#iso-code-submit');
    var panel=box.querySelector('#iso-admin-panel');
    var money=box.querySelector('#iso-money-input');
    function paint(){
      panel.style.display=adminOn()?'block':'none';
      if(adminOn()) wireLockedCompounds();
    }
    function redeem(){
      var code=String(input.value||'').trim().toUpperCase();
      if(!code){toast('ENTER A CODE','bad');return;}
      if(code===ADMIN_CODE){
        activateAdmin(); input.value=''; paint(); wireLockedCompounds(); toast('ADMIN MODE ACTIVATED · ALL RELICS ENABLED','gold');
        try{ if(window.renderVault) renderVault(); }catch(_){}
        return;
      }
      if(code===BETA_CODE){
        if(claimBeta()){ input.value=''; toast('BETAISOTOPE · +750 COINS','good'); }
        else toast('BETAISOTOPE HAS ALREADY BEEN REDEEMED','bad');
        return;
      }
      toast('INVALID CODE','bad');
    }
    submit.addEventListener('click',function(){try{if(window.SFX&&SFX.click)SFX.click();}catch(_){};redeem();});
    input.addEventListener('keydown',function(e){if(e.key==='Enter'){e.preventDefault();redeem();}});
    money.value = String(Math.max(0,Number(raw()&&raw().coins||0)));
    box.querySelector('#iso-money-set').addEventListener('click',function(){
      if(!adminOn()){toast('ADMIN MODE REQUIRED','bad');return;}
      var v=Math.max(0,Math.floor(Number(money.value)));
      if(!isFinite(v)){toast('ENTER A VALID MONEY AMOUNT','bad');return;}
      raw().coins=v;save();try{if(window.SAVE.refreshCoins)SAVE.refreshCoins();}catch(_){};money.value=String(v);toast('MONEY SET TO ◈ '+v.toLocaleString(),'good');
    });
    box.querySelector('#iso-money-max').addEventListener('click',function(){
      if(!adminOn()){toast('ADMIN MODE REQUIRED','bad');return;}
      var v=Number.MAX_SAFE_INTEGER;raw().coins=v;save();try{if(window.SAVE.refreshCoins)SAVE.refreshCoins();}catch(_){};money.value=String(v);toast('MONEY MAXED','good');
    });
    paint();
  }

  function boot(){
    patchVaultSelection();
    renderAdminPanel();
    wireLockedCompounds();
    setTimeout(patchVaultSelection,120);
    setTimeout(renderAdminPanel,300);
    setTimeout(wireLockedCompounds,350);
    setInterval(function(){
      patchVaultSelection();
      wireLockedCompounds();
    },1000);
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot); else boot();

  window.ISO_ADMIN_UNLOCK_COMPOUND=adminUnlockCompound;
  window.ISO_ADMIN_MODE_ENABLED=adminOn;
  console.log('ISO V89 PRIVATE CODES active');
})();
