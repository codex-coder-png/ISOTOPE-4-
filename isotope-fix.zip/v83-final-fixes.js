/* ISOTOPE V83 — Mastery stability, signature stats, and complete relic behavior. */
(function(){
  'use strict';
  if(window.__ISO_V83_FINAL_FIXES__)return;
  window.__ISO_V83_FINAL_FIXES__=true;

  var C=window.ISO_V23_CORE||{};
  function has(id){return !!(window.RUN&&Array.isArray(RUN.relics)&&RUN.relics.indexOf(id)>=0);}
  function localPlayer(){var r=window.RUN;return r&&r.players?((r.players[r.localNetId||0]||r.players[0])||null):null;}
  function alive(e){return !!e&&!e.dead;}
  function clampArmor(v){return Math.max(0,Math.min(.85,Number(v)||0));}
  function eachEnemy(fn){if(!RUN||!RUN.enemies)return;for(var i=0;i<RUN.enemies.length;i++){var e=RUN.enemies[i];if(alive(e))fn(e);}}
  function safeSave(){try{if(window.SAVE&&SAVE.save)SAVE.save();}catch(e){}}

  /* ---- Correct older Build-6/V14 relic stat mistakes without removing
     their UI/ownership systems. The final layer is the source of truth. ---- */
  var getCompute=C.getComputeStats,setCompute=C.setComputeStats;
  if(typeof getCompute==='function'&&typeof setCompute==='function'){
    var baseCompute=getCompute();
    if(typeof baseCompute==='function'&&!baseCompute.__v83RelicCompute){
      var compute=function(){
        baseCompute();
        if(!RUN||!ST)return;
        var rr=RUN.relics||[], hasR=function(id){return rr.indexOf(id)>=0;};
        /* Restore the intended conditional versions of effects accidentally
           applied unconditionally by older compatibility layers. */
        if(hasR('phase_prism'))ST.aoeLv=Math.max(0,(Number(ST.aoeLv)||0)-1);
        if(hasR('cryogenic_loop'))ST.slowLv=Math.max(0,(Number(ST.slowLv)||0)-1);
        if(hasR('toxic_reservoir'))ST.poisonLv=Math.max(0,(Number(ST.poisonLv)||0)-1);
        if(hasR('twin_core'))ST.projs=Math.max(1,(Number(ST.projs)||1)-Math.floor((RUN.wave||1)/2));
        if(hasR('iron_oath'))ST.armor=clampArmor((Number(ST.armor)||0)-.08);
        if(hasR('star_map')){
          ST.spd/=1.08;
          var p=localPlayer(), full=p&&Number(ST.shieldMax)>0&&(Number(p.sh||0)>=Number(ST.shieldMax)-.01);
          if(full)ST.spd*=1.18;
        }
        if(hasR('golden_filter'))ST.magnet*=1.05;
        if(hasR('twin_core') && ((Number(RUN.wave)||1)%2===0))ST.projs+=1;
        if(hasR('iron_oath')){
          var ip=localPlayer();
          if(ip&&Number(ip.hp)>0&&Number(ST.hp)>0&&ip.hp<ST.hp*.4)ST.armor=clampArmor(ST.armor+.25);
        }
        if(hasR('hex_archivist'))ST.rarityFocus=true;
      };
      compute.__v83RelicCompute=true;
      setCompute(compute);
    }
  }

  /* ---- Signature mastery: no global helper monkey-patching, no save wiping.
     The helper lives in game.js and is invoked by V79 around active Signature. ---- */

  /* ---- Projectile relics ---- */
  var getUpdate=C.getUpdate,setUpdate=C.setUpdate;
  if(typeof getUpdate==='function'&&typeof setUpdate==='function'){
    var baseUpdate=getUpdate();
    if(typeof baseUpdate==='function'&&!baseUpdate.__v83RelicUpdate){
      var update=function(dt){
        var r=RUN;
        if(!r||!r.relics){return baseUpdate(dt);}
        r.__v83=r.__v83||{};
        var meta=r.__v83;
        var poisonBefore=[];
        if(has('toxic_reservoir'))eachEnemy(function(e){if(e.poison)poisonBefore.push({e:e,dps:Number(e.poison.dps)||0,hue:e.poison.hue||r.hue});});

        /* Stable enemy movement relics; never compound speed multipliers. */
        if(has('heavy_gravity')||has('gravity_anchor')){
          eachEnemy(function(e){
            if(!Number.isFinite(e.__v83BaseSpd))e.__v83BaseSpd=Number(e.spd)||Number(e.spdBase)||0;
            if(e.__v83BaseSpd>0)e.spd=e.__v83BaseSpd*.88;
          });
        }else if(r.__v83GravityWasOn){
          eachEnemy(function(e){if(Number.isFinite(e.__v83BaseSpd))e.spd=e.__v83BaseSpd;});
        }
        r.__v83GravityWasOn=has('heavy_gravity')||has('gravity_anchor');

        /* Null Compass keeps enemy telegraphs readable and exposes hidden threats. */
        if(has('null_compass')){
          eachEnemy(function(e){
            ['tele','charge','charging'].forEach(function(k){
              if(typeof e[k]==='number'&&e[k]>0)e[k]+=dt*(k==='tele'?.35:k==='charge'?.20:.22);
            });
          });
        }

        /* Phase Prism: every ninth projectile becomes a piercing +70% phase shot. */
        if(has('phase_prism')){
          var bullets=r.bullets||[];
          for(var i=0;i<bullets.length;i++){
            var b=bullets[i];
            if(!b||b._v83PhaseTagged)continue;
            if(!b._v83NoCount){
              meta.phaseCount=(meta.phaseCount||0)+1;
              if(meta.phaseCount%9===0){
                b._v83PhaseTagged=true;b._v83NoCount=true;b.phase=true;
                b.pierce=999999;b.dmg=Number(b.dmg||ST.dmg||1)*1.7;
              }
            }else b._v83PhaseTagged=true;
          }
        }

        /* Echo Chamber: every 11th projectile is repeated from the previous
           player position. The echo does not recursively count as another shot. */
        if(has('echo_chamber')){
          var p=localPlayer();
          if(p){
            var origin=meta.echoOrigin||{x:p.x,y:p.y};
            var bs=r.bullets||[];
            for(var q=0;q<bs.length;q++){
              var eb=bs[q];
              if(!eb||eb._v83EchoSeen||eb._v83NoCount)continue;
              if(eb.owner===p.id||eb.owner===undefined){
                meta.echoCount=(meta.echoCount||0)+1;eb._v83EchoSeen=true;
                if(meta.echoCount%11===0){
                  var dup=Object.assign({},eb);
                  dup.x=origin.x;dup.y=origin.y;dup.hit=[];dup._v83NoCount=true;dup._v83Echo=true;
                  if(Array.isArray(dup.hit))dup.hit=[];
                  r.bullets.push(dup);
                }
              }
            }
            meta.echoOrigin={x:p.x,y:p.y};
          }
        }

        /* Salvage Drone: gentle vacuum toward pickups; the existing pickup
           system performs the actual collection and rewards. */
        if(has('salvage_drone')){
          meta.salvageT=(meta.salvageT||0)-dt;
          if(meta.salvageT<=0){
            meta.salvageT=0.12;
            r.pickups&&r.pickups.forEach(function(k){
              if(!k||k.got||k.t==='relic')return;
              var lp=localPlayer();if(!lp)return;
              if(Math.abs(k.x-lp.x)>280||Math.abs(k.y-lp.y)>280)return;
              k.vx+=(lp.x-k.x)*.22;k.vy+=(lp.y-k.y)*.22;
            });
          }
        }

        /* Corona Ring: full-shield pulse every four seconds. */
        if(has('corona_ring')){
          var cp=localPlayer();
          if(cp&&ST&&Number(ST.shieldMax)>0&&Number(cp.sh||0)>=Number(ST.shieldMax)-.01){
            meta.coronaT=(meta.coronaT===undefined?4:meta.coronaT)-dt;
            if(meta.coronaT<=0){
              meta.coronaT=4;
              try{var ao=window.aoe;if(typeof ao==='function')ao(cp.x,cp.y,78,Number(ST.dmg)*.55,Number(RUN.hue)||190,{effect:true});}catch(e){}
              if(typeof window.ringFx==='function')try{window.ringFx(cp.x,cp.y,RUN.hue,90);}catch(e){}
            }
          }else meta.coronaT=0;
        }

        /* Star Map is a conditional stat, so recompute only when the condition
           changes instead of polling continuously. */
        if(has('star_map')){
          var sp=localPlayer(),fullKey=sp&&ST&&ST.shieldMax>0&&Number(sp.sh||0)>=Number(ST.shieldMax)-.01?'F':'f';
          if(meta.starKey!==fullKey){meta.starKey=fullKey;try{computeStats();}catch(e){}}
        }

        baseUpdate(dt);

        /* Temporary shield from Reactor Bloom. */
        if(meta.reactorShield){
          for(var z=0;z<meta.reactorShield.length;z++){
            var sh=meta.reactorShield[z],loss=Math.min(sh.amount,dt*4);
            sh.t-=dt;sh.amount-=loss;
            if(sh.p&&loss>0)sh.p.sh=Math.max(0,(sh.p.sh||0)-loss);
          }
          meta.reactorShield=meta.reactorShield.filter(function(v){return v.t>0&&v.amount>0;});
        }

        /* Catalyst pickups: 35% active cooldown reset + +20% damage for 5s. */
        r.pickups&&r.pickups.forEach(function(k){
          if(k&&k.t==='catalyst'&&!k.got){
            var p0=localPlayer();
            if(p0&&((p0.x-k.x)*(p0.x-k.x)+(p0.y-k.y)*(p0.y-k.y))<30*30){
              k.got=true;p0.activeCd=Math.max(0,(p0.activeCd||0)*.65);
              p0.puDamage=Math.max(p0.puDamage||1,1.2);p0.puTimer=Math.max(p0.puTimer||0,5);
              if(typeof window.SFX!=='undefined'&&SFX.unlock)SFX.unlock();
            }
          }
        });

        /* Poison Reservoir: only a true poison-expiry event propagates. */
        if(has('toxic_reservoir')){
          poisonBefore.forEach(function(v){
            if(!v.e||v.e.dead||v.e.poison||!v.dps)return;
            var target=null,best=150*150;
            eachEnemy(function(e){
              if(e===v.e||e.poison)return;
              var dx=e.x-v.e.x,dy=e.y-v.e.y,d2=dx*dx+dy*dy;
              if(d2<best){best=d2;target=e;}
            });
            if(target&&typeof window.addPoison==='function')window.addPoison(target,v.dps,2.5,v.hue);
          });
        }
        return;
      };
      update.__v83RelicUpdate=true;
      setUpdate(update);
    }
  }

  /* ---- Kill, XP, drop, dash, ability, status and render hooks ---- */
  var getKill=C.getKillEnemy,setKill=C.setKillEnemy;
  if(typeof getKill==='function'&&typeof setKill==='function'){
    var baseKill=getKill();
    if(typeof baseKill==='function'&&!baseKill.__v83RelicKill){
      var kill=function(e){
        var wasBoss=!!(e&&e.boss), beforeAlive=RUN&&RUN.kills||0;
        var out=baseKill.apply(this,arguments);
        if(RUN&&RUN.relics&&e&&!wasBoss&&e.dead){
          RUN.__v83=RUN.__v83||{};
          var m=RUN.__v83;
          if(has('volatile_cell')){
            m.volatileKills=(m.volatileKills||0)+1;
            if(m.volatileKills%7===0){
              RUN.timedExplosions=RUN.timedExplosions||[];
              RUN.timedExplosions.push({x:e.x,y:e.y,r:95,dmg:Number(ST.dmg)*1.8,hue:e.hue==null?RUN.hue:e.hue,t:.7,total:.7});
            }
          }
          if(has('neutron_seed')&&Math.random()<.12){
            dropSafe(e.x,e.y,'catalyst',null);
          }
          if(has('wild_reactor')&&e.elite){
            /* Richer elite rewards: add a modest bonus packet on top of normal drops. */
            try{dropSafe(e.x,e.y,'coin',Math.max(1,Math.round(Number(e.coin||1)*.35)));}catch(x){}
            try{dropSafe(e.x,e.y,'xp',Math.max(1,Math.round(Number(e.xp||1)*.25)));}catch(x){}
          }
        }
        return out;
      };
      kill.__v83RelicKill=true;setKill(kill);
    }
  }

  function dropSafe(x,y,t,v){try{var d=getDrop&&getDrop();if(typeof d==='function')return d(x,y,t,v);}catch(e){}try{if(RUN)RUN.pickups.push({t:t,x:x,y:y,v:v,vx:0,vy:0});}catch(e){}return null;}
  var getDrop=C.getDrop,setDrop=C.setDrop;
  if(typeof getDrop==='function'&&typeof setDrop==='function'){
    var baseDrop=getDrop();
    if(typeof baseDrop==='function'&&!baseDrop.__v83RelicDrop){
      var drop=function(x,y,t,v){
        /* Alchemy Dice changes the individual pickup amount/strength rather
           than multiplying permanent stats. */
        if(t!=='relic'&&has('alchemy_dice')&&typeof v==='number')v=Math.max(1,Math.round(v*(.65+Math.random()*1)));
        return baseDrop.call(this,x,y,t,v);
      };
      drop.__v83RelicDrop=true;setDrop(drop);
    }
  }

  var getGain=C.getGainXP,setGain=C.setGainXP;
  if(typeof getGain==='function'&&typeof setGain==='function'){
    var baseGain=getGain();
    if(typeof baseGain==='function'&&!baseGain.__v83RelicXP){
      var gain=function(v){
        var before=RUN?Number(RUN.level)||0:0,out=baseGain.apply(this,arguments);
        if(RUN&&has('reactor_bloom')&&Number(RUN.level)>before){
          RUN.__v83=RUN.__v83||{};RUN.__v83.reactorShield=RUN.__v83.reactorShield||[];
          RUN.players.forEach(function(p){
            if(!p||p.downed)return;
            p.hp=Math.min(ST.hp,p.hp+ST.hp*.10);
            p.sh=Math.min(ST.shieldMax,(p.sh||0)+20);
            RUN.__v83.reactorShield.push({p:p,amount:20,t:5});
          });
        }
        return out;
      };
      gain.__v83RelicXP=true;setGain(gain);
    }
  }

  var getElem=C.getApplyElemHit,setElem=C.setApplyElemHit;
  if(typeof getElem==='function'&&typeof setElem==='function'){
    var baseElem=getElem();
    if(typeof baseElem==='function'&&!baseElem.__v83RelicElem){
      var elemHit=function(b,e){
        var critical=!!(b&&b.crit),out=baseElem.apply(this,arguments);
        if(critical&&has('cryogenic_loop')&&e&&!e.dead&&Math.random()<.25){
          var rr=85,r2=rr*rr;
          eachEnemy(function(o){if(o===e)return;var dx=o.x-e.x,dy=o.y-e.y;if(dx*dx+dy*dy<r2&&typeof window.addFreeze==='function')window.addFreeze(o,.9);});
          if(typeof window.ringFx==='function')try{window.ringFx(e.x,e.y,195,65);}catch(x){}
        }
        return out;
      };
      elemHit.__v83RelicElem=true;setElem(elemHit);
    }
  }

  var getDash=C.getTryDash,setDash=C.setTryDash;
  if(typeof getDash==='function'&&typeof setDash==='function'){
    var baseDash=getDash();
    if(typeof baseDash==='function'&&!baseDash.__v83RelicDash){
      var dash=function(p){
        var oldX=p&&p.x,oldY=p&&p.y,out=baseDash.apply(this,arguments);
        return out;
      };
      dash.__v83RelicDash=true;setDash(dash);
    }
  }

  var getUse=C.getUseActive,setUse=C.setUseActive;
  if(typeof getUse==='function'&&typeof setUse==='function'){
    var baseUse=getUse();
    if(typeof baseUse==='function'&&!baseUse.__v83RelicUse){
      var use=function(p){
        var out=baseUse.apply(this,arguments);
        if(has('signal_lens')&&p&&Number(p.activeCd||0)>0){
          eachEnemy(function(e){e.__v83WeakT=Math.max(e.__v83WeakT||0,3);});
        }
        return out;
      };
      use.__v83RelicUse=true;setUse(use);
    }
  }

  var getDmg=C.getDmgEnemy,setDmg=C.setDmgEnemy;
  if(typeof getDmg==='function'&&typeof setDmg==='function'){
    var baseDmg=getDmg();
    if(typeof baseDmg==='function'&&!baseDmg.__v83WeakDmg){
      var dmg=function(e,d,o){
        if(e&&e.__v83WeakT>0&&has('signal_lens'))d*=1.35;
        return baseDmg.call(this,e,d,o);
      };
      dmg.__v83WeakDmg=true;setDmg(dmg);
    }
  }

  /* Final render annotations + ticking weak-point timers. */
  var getRender=C.getRender,setRender=C.setRender;
  if(typeof getRender==='function'&&typeof setRender==='function'){
    var baseRender=getRender();
    if(typeof baseRender==='function'&&!baseRender.__v83RelicRender){
      var render=function(){
        if(RUN){
          var dt=(RUN.__v83&&RUN.__v83.lastRenderT!=null)?Math.max(0,Math.min(.1,performance.now()/1000-RUN.__v83.lastRenderT)):0;
          RUN.__v83=RUN.__v83||{};RUN.__v83.lastRenderT=performance.now()/1000;
          eachEnemy(function(e){if(e.__v83WeakT>0)e.__v83WeakT-=dt;});
        }
        baseRender();
        if(!RUN||typeof cx==='undefined')return;
        cx.save();
        if(has('signal_lens')){
          eachEnemy(function(e){
            if(e.__v83WeakT>0){
              cx.strokeStyle='rgba(255,238,120,.95)';cx.lineWidth=2;cx.beginPath();cx.arc(e.x,e.y,(e.r||10)+7,0,Math.PI*2);cx.stroke();
              cx.beginPath();cx.moveTo(e.x-8,e.y);cx.lineTo(e.x+8,e.y);cx.moveTo(e.x,e.y-8);cx.lineTo(e.x,e.y+8);cx.stroke();
            }
          });
        }
        if(has('null_compass')){
          eachEnemy(function(e){
            if(e.invuln&&e.hidden){
              cx.strokeStyle='rgba(150,210,255,.7)';cx.lineWidth=1.5;cx.beginPath();cx.arc(e.x,e.y,(e.r||9)+12,0,Math.PI*2);cx.stroke();
            }
          });
        }
        cx.restore();
      };
      render.__v83RelicRender=true;setRender(render);
    }
  }

  /* Wild Reactor: guarantee one extra elite per wave rather than merely
     adding one ordinary spawn slot. */
  if(typeof C.getStartWave==='function'&&typeof C.setStartWave==='function'&&typeof C.getSpawnEnemy==='function'&&typeof C.getPickType==='function'){
    var oldSW=C.getStartWave();
    if(typeof oldSW==='function'&&!oldSW.__v83Wild){
      var spawn= C.getSpawnEnemy(), pick=C.getPickType();
      var sw=function(){
        var out=oldSW.apply(this,arguments);
        if(has('wild_reactor')&&RUN&&typeof spawn==='function'&&typeof pick==='function'){
          try{spawn(pick(),undefined,undefined,true);}catch(e){}
        }
        return out;
      };
      sw.__v83Wild=true;C.setStartWave(sw);
    }
  }

  /* Compatibility flags used by the game loop and no ChromeOS throttling. */
  console.log('ISOTOPE V83 FINAL: signature/mastery stability and complete relic behavior installed; no ChromeOS simulation throttling.');
})();
