/* ISOTOPE V38 — LIQUID NITROGEN + LAB + AUGMENTATION + MASTERY/QOL PASS
 *
 * This final late-load patch intentionally works after every previous V36/V37
 * layer so the requested values/order are the canonical live values.
 */
(function(){
  'use strict';
  if(!window.DATA || !window.SAVE) return;
  var DATA=window.DATA, SAVE=window.SAVE, CORE=window.ISO_V23_CORE;
  var LN_HUE=195;

  function nameOf(el){ return String(el && el.name || ''); }
  function isLNEl(el){ return /^Liquid Nitrogen$/i.test(nameOf(el)); }
  function st(){ try{return window.ST||{};}catch(e){return {};} }
  function d2(a,b,c,d){var x=a-c,y=b-d;return x*x+y*y;}
  function liveEnemies(){return window.RUN&&Array.isArray(RUN.enemies)?RUN.enemies:[];}
  function ringFx(x,y,r,hue,width){
    try{ if(window.RUN&&window.RUN.parts){ RUN.parts.push({ring:true,x:x,y:y,r0:Math.max(4,r*.06),grow:r,t:.55,life:.55,hue:hue,fxWidth:width||4}); } }catch(e){}
  }

  /* ---------- Liquid Nitrogen: hard-canonical ability order ---------- */
  var ln=null;
  Object.keys(DATA.MOLDEF||{}).some(function(k){
    var m=DATA.MOLDEF[k];
    if(m && /^Liquid Nitrogen$/i.test(String(m.name||''))){ln=m;return true;}
    return false;
  });
  if(ln){
    ln.f='N₂'; ln.name='Liquid Nitrogen'; ln.mol=true; ln.hue=LN_HUE; ln.combustLv=0; ln.trait='chill';
    ln.desc='Low-damage cryogenic rounds freeze and slow enemies; each round shatters into four shards on contact.';
    ln.mods=Object.assign({},ln.mods||{},{dmg:.62,rate:1.08,ps:1.12,hp:.92,spd:1.03});
    var LNKEY='N+N';
    DATA.MOLDEF[LNKEY]=ln;
    DATA.RECIPES[LNKEY]=LNKEY; DATA.RECIPES['N2']=LNKEY; DATA.RECIPES['N₂']=LNKEY;

    function freezeTarget(e,seconds){
      if(!e||e.dead||e.boss)return;
      seconds=seconds||1.8;
      try{if(CORE&&CORE.addFreeze)CORE.addFreeze(e,seconds);else e.freeze=Math.max(e.freeze||0,seconds);}catch(err){e.freeze=Math.max(e.freeze||0,seconds);}
      e.slowT=Math.max(Number(e.slowT)||0,Math.max(seconds,2.8));
      e._v38LNFrozen=1;
    }
    function freezeRadius(p,radius){
      liveEnemies().forEach(function(e){
        if(!e||e.dead||e.boss)return;
        var rr=radius+(Number(e.r)||0);
        if(d2(e.x,e.y,p.x,p.y)<=rr*rr) freezeTarget(e,2.35);
      });
      ringFx(p.x,p.y,radius,LN_HUE,4);
    }
    function lnRound(p,a,tag){
      var S=st(), speed=Number(S.ps)||380, dmg=Math.max(1,(Number(S.dmg)||14)*.62);
      return {x:p.x,y:p.y,vx:Math.cos(a)*speed*1.35,vy:Math.sin(a)*speed*1.35,dmg:dmg,r:7,pierce:0,hit:[],life:1.8,owner:p.id,
        _isoV38LN:true,_isoV38LNShard:false,semanticType:tag||'liquid-nitrogen-round',hue:LN_HUE,freeze:false,expl:false,burn:false};
    }
    function shatter(b){
      if(!window.RUN||b._isoV38LNShattered)return;
      b._isoV38LNShattered=1; b.life=0; b.pierce=0;
      var S=st(),speed=Number(S.ps)||380,dmg=Math.max(1,(Number(b.dmg)||Number(S.dmg)||14)*.34),base=Math.atan2(b.vy||0,b.vx||1);
      for(var i=0;i<4;i++){
        var a=base+i*Math.PI/2;
        RUN.bullets.push({x:b.x,y:b.y,vx:Math.cos(a)*speed*1.12,vy:Math.sin(a)*speed*1.12,dmg:dmg,r:4,pierce:0,hit:[],life:.82,owner:b.owner,
          _isoV38LN:true,_isoV38LNShard:true,semanticType:'liquid-nitrogen-shard',hue:LN_HUE,freeze:true,expl:false,burn:false});
      }
      try{for(var k=0;k<8;k++){var aa=Math.random()*Math.PI*2;RUN.parts.push({x:b.x,y:b.y,vx:Math.cos(aa)*105,vy:Math.sin(aa)*105,t:.22,life:.22,hue:LN_HUE,r:1.8});}}catch(e){}
    }

    ln.choices=[
      {name:'Liquid Nitrogen — Cryogenic Field',ic:'❄',slot:0,main:true,cd:6,
       desc:'Freezes and slows non-boss enemies in a large radius around you.',
       exec:function(p){if(!window.RUN)return;p.activeCd=(st().activeCd||6);freezeRadius(p,300);}},
      {name:'Liquid Nitrogen — Shatter Volley',ic:'❄️',slot:1,cd:7,
       desc:'Fires three cryogenic bullets outward. Each breaks into four shards on enemy contact; the shards freeze and slow enemies they hit.',
       exec:function(p){if(!window.RUN)return;p.activeCd=(st().activeCd||7);var a=p.angle||0;for(var i=-1;i<=1;i++)RUN.bullets.push(lnRound(p,a+i*.25,'liquid-nitrogen-volley'));}},
      {name:'Liquid Nitrogen — Cryogenic Shatter',ic:'🧊',slot:2,cd:5.5,
       desc:'Fires a low-damage cryogenic bullet that freezes and slows on impact, then shatters into four outward shards.',
       exec:function(p){if(!window.RUN)return;p.activeCd=(st().activeCd||5.5);RUN.bullets.push(lnRound(p,p.angle||0,'liquid-nitrogen-shatter'));}}
    ];
    ln.signatures=ln.choices; ln.act=ln.choices[0];

    /* Ensure every late alias resolves to the same object and thus the same 3 choices. */
    Object.keys(DATA.MOLDEF).forEach(function(k){var m=DATA.MOLDEF[k];if(m&&/^Liquid Nitrogen$/i.test(String(m.name||'')))DATA.MOLDEF[k]=ln;});

    /* Normal Liquid Nitrogen shots: consume on first enemy contact and make four
       shards. No circular explosion/AOE and no recursive shatter. Every direct
       LN hit still freezes a non-boss enemy. */
    if(CORE && !window.__ISO_V38_LN_HIT__){
      window.__ISO_V38_LN_HIT__=1;
      var prevHit=CORE.getApplyElemHit();
      CORE.setApplyElemHit(function(b,e){
        if(b&&b._isoV38LN){
          var already=b._isoV38LNHit;
          if(already)return;
          b._isoV38LNHit=1;
          /* Run the ordinary damage/drop/death chain, but strip inherited blast flags. */
          var oldExpl=b.expl, oldFreeze=b.freeze, oldBurn=b.burn;
          b.expl=false; b.freeze=false; b.burn=false;
          if(typeof prevHit==='function'){
            try{prevHit(b,e);}catch(err){console.error('V38 LN base hit chain',err);}
          }
          b.expl=oldExpl; b.freeze=oldFreeze; b.burn=oldBurn;
          if(e&&!e.dead&&!e.boss)freezeTarget(e,1.8);
          if(!b._isoV38LNShard)shatter(b);
          return;
        }
        if(typeof prevHit==='function')return prevHit(b,e);
      });
    }

    /* Tag every normal M1 bullet as a Liquid Nitrogen round without changing
       other elements. Also supports the 3-shot prime state from older saves. */
    if(CORE && !window.__ISO_V38_LN_FIRE__){
      window.__ISO_V38_LN_FIRE__=1;
      var prevFire=CORE.getFire();
      CORE.setFire(function(p){
        var before=window.RUN&&RUN.bullets?RUN.bullets.length:0;
        if(typeof prevFire==='function')prevFire(p);
        if(!window.RUN||!Array.isArray(RUN.bullets)||!isLNEl(p&&p.elem))return;
        for(var i=before;i<RUN.bullets.length;i++){
          var b=RUN.bullets[i];
          if(!b||!b.main||b.owner!==p.id)continue;
          b._isoV38LN=true; b._isoV38LNShard=false; b.expl=false; b.burn=false; b.freeze=false; b.hue=LN_HUE;
          b.dmg=Math.max(1,(Number(st().dmg)||14)*.62);
          if((p._v36LNNext||0)>0)p._v36LNNext--;
        }
      });
    }

    /* Frozen visual: very slight jitter + light-blue body + explicit blue circle.
       This augments the game's existing freeze drawing rather than replacing it. */
    if(CORE && !window.__ISO_V38_FREEZE_RENDER__){
      window.__ISO_V38_FREEZE_RENDER__=1;
      var prevRender=CORE.getRender();
      CORE.setRender(function(){
        if(typeof prevRender==='function')prevRender();
        if(!window.RUN)return;
        var c=CORE.ctx(); if(!c)return;
        RUN.enemies.forEach(function(e){
          if(!e||e.dead||e.boss||!(e.freeze>0))return;
          var j=Math.sin(RUN.t*10.5+(e.seed||0))*1.0;
          var r=Math.max(6,Number(e.r)||10);
          c.save();c.translate(e.x+j,e.y);
          c.strokeStyle='rgba(55,145,255,.96)';c.lineWidth=2.5;c.beginPath();c.arc(0,0,r+8+Math.sin(RUN.t*7+(e.seed||0))*.65,0,Math.PI*2);c.stroke();
          c.strokeStyle='rgba(120,205,255,.9)';c.lineWidth=1.1;c.beginPath();c.arc(0,0,r+11,0,Math.PI*2);c.stroke();c.restore();
        });
      });
    }
  }

  /* ---------- Synthesis Lab locked/grey button ---------- */
  var LAB_COST=200;
  function labUnlocked(){return SAVE.raw.synthesisLabUnlocked===true;}
  function refreshLabButtonV38(){
    var b=document.querySelector('[data-go="scr-lab"]'); if(!b)return;
    b.classList.toggle('v38-lab-locked',!labUnlocked());
    b.innerHTML=labUnlocked()?'SYNTHESIS LAB<small>real chemistry · unlocked</small>':'SYNTHESIS LAB<small>🔒 '+LAB_COST+' POINTS TO UNLOCK</small>';
    if(!labUnlocked()){
      b.style.filter='grayscale(1)';b.style.opacity='.52';b.style.borderColor='#59616b';b.style.color='#8a929c';
    }else{b.style.filter='';b.style.opacity='';b.style.borderColor='';b.style.color='';}
  }
  refreshLabButtonV38();setTimeout(refreshLabButtonV38,200);setTimeout(refreshLabButtonV38,900);
  if(!window.__ISO_V38_LAB_REFRESH__){
    window.__ISO_V38_LAB_REFRESH__=1;
    setInterval(refreshLabButtonV38,500);
  }

  /* ---------- Favorite row: every favorited element/compound becomes selectable ---------- */
  function favoriteClick(id){
    id=DATA.canonicalId(id); if(!DATA.isOwned(id))return;
    SAVE.sel=id; if(SAVE.getSignature&&SAVE.signatures&&SAVE.signatures[id]==null)SAVE.signatures[id]=0; SAVE.save();
    if(window.UI&&UI.show)UI.show('scr-vault');
    setTimeout(function(){
      var t=document.querySelector('#ptable .pt[data-id="'+CSS.escape(id)+'"]');
      if(!t){var mts=document.querySelectorAll('#molstrip .mtile[data-v38-id]');for(var i=0;i<mts.length;i++)if(mts[i].dataset.v38Id===id){t=mts[i];break;}}
      if(t&&typeof t.click==='function')t.click();
    },20);
  }
  function repairFavoriteTargets(){
    var ms=document.getElementById('molstrip'); if(ms){
      /* Annotate owned compound tiles with canonical IDs; preserve their existing click handlers. */
      var known=SAVE.raw.mols||[]; var tiles=ms.querySelectorAll('.mtile');
      known.forEach(function(id){
        var m=DATA.EL(id); if(!m)return;
        for(var i=0;i<tiles.length;i++){
          var t=tiles[i]; if(t.dataset.v38Id)continue;
          if((t.textContent||'').trim().replace(/\s+/g,'')===String(m.f||'').slice(0,4).replace(/\s+/g,'')){t.dataset.v38Id=id;break;}
        }
      });
    }
    var fr=document.getElementById('favrow'); if(!fr)return;
    var favs=SAVE.raw.favs||[];
    var old=favs.map(function(id){return DATA.EL(id);}).filter(function(e){return e&&DATA.isOwned(e.id);});
    var head='<span style="font-family:var(--mono);font-size:11px;color:var(--am);letter-spacing:.2em;margin-right:8px">FAVORITES ▸</span>';
    var body=old.length?old.map(function(e){return '<button class="mtile v38-fav-select" type="button" data-v38-fav="'+e.id+'" title="Select '+e.name+'">★ '+(e.mol?String(e.f||'').slice(0,4):e.sym)+'</button>';}).join(''):'<span class="dim" style="font-size:11px">none yet - star elements in the vault</span>';
    fr.innerHTML=head+body;
    fr.querySelectorAll('[data-v38-fav]').forEach(function(b){b.onclick=function(ev){ev.preventDefault();ev.stopPropagation();favoriteClick(b.dataset.v38Fav);};});
  }
  var lastFavoriteSignature='';
  function ensureFavoriteRow(){
    var vault=document.getElementById('scr-vault');
    if(!vault||vault.classList.contains('hidden'))return;
    var ms=document.getElementById('molstrip');if(!ms)return;
    var fr=document.getElementById('favrow');
    if(!fr){fr=document.createElement('div');fr.id='favrow';fr.style.cssText='display:flex;gap:8px;margin-top:10px;flex-wrap:wrap;align-items:center';ms.parentElement.insertBefore(fr,ms);}
    var sig=JSON.stringify(SAVE.raw.favs||[])+'|'+JSON.stringify(SAVE.raw.mols||[])+'|'+String(SAVE.sel||'');
    if(sig!==lastFavoriteSignature){repairFavoriteTargets();lastFavoriteSignature=sig;}
  }
  setInterval(ensureFavoriteRow,500);
  document.addEventListener('click',function(e){
    if(e.target&&e.target.closest&&e.target.closest('[data-go="scr-vault"]'))setTimeout(ensureFavoriteRow,40);
  },true);

  /* ---------- Augmentations: only the nine screenshot augmentations ---------- */
  var AUGS=[
    {id:'dmg',n:'Ion Lance',d:'+5% damage /lv',max:10,base:60,mult:.5},
    {id:'hp',n:'Plated Hull',d:'+12 max HP /lv',max:8,base:50,mult:.5},
    {id:'spd',n:'Thruster Tuning',d:'+3% speed /lv',max:6,base:50,mult:.5},
    {id:'mag',n:'Magnet Core',d:'+18% pickup range /lv',max:6,base:40,mult:.5},
    {id:'luck',n:'Alchemy Core',d:'+8% coins /lv',max:8,base:70,mult:1},
    {id:'crit',n:'Weakpoint Scanner',d:'+2.5% crit /lv',max:8,base:65,mult:.5},
    {id:'shield',n:'Reactive Shield',d:'+15 shield /lv',max:5,base:90,mult:.5},
    {id:'head',n:'Head Start',d:'Start with 1 random ability /lv',max:3,base:150,mult:2},
    {id:'revive',n:'Emergency Cell',d:'Revive once per run',max:3,base:250,mult:4},
    {id:'projs',n:'Particle Splitter',d:'+3 projectiles /lv',max:3,base:260,mult:4}
  ];
  function augCost(a,lv){return Math.round(a.base*a.mult*Math.pow(lv+1,1.7)*10)/10;}
  var lastAugRenderKey='';
  function renderAugV38(force){
    var g=document.getElementById('aug-grid');if(!g)return;
    var key=AUGS.map(function(a){return a.id+':'+Number(SAVE.metaLv(a.id)||0);}).join('|')+'|coins:'+Number(SAVE.coins||0);
    if(!force&&g.dataset.v38Only==='1'&&key===lastAugRenderKey)return;
    lastAugRenderKey=key;
    g.innerHTML='';g.dataset.v38Only='1';
    AUGS.forEach(function(a,i){
      var lv=Number(SAVE.metaLv(a.id)||0), locked=i>0&&!Number(SAVE.metaLv(AUGS[i-1].id)||0), maxed=lv>=a.max, cost=augCost(a,lv);
      var d=document.createElement('div'); d.className='augcard panel'+(locked?' locked':'');
      var pips='';for(var p=0;p<a.max;p++)pips+='<i class="'+(p<lv?'on':'')+'"></i>';
      var canBuy=!locked&&!maxed&&SAVE.coins>=cost;
      d.innerHTML='<h4>'+a.n+(locked?' 🔒':'')+'</h4><p>'+a.d+'</p><div class="pips2">'+pips+'</div><div class="augfoot"><span class="cost">'+(maxed?'MAXED':locked?'LOCKED':'◈ '+String(cost).replace(/\.0$/,''))+'</span>'+(locked||maxed?'':'<button class="btn chamf" '+(canBuy?'':'disabled')+'>BUY</button>')+'</div>';
      var btn=d.querySelector('button');
      if(btn)btn.onclick=function(){var cur=Number(SAVE.metaLv(a.id)||0),nowLocked=i>0&&!Number(SAVE.metaLv(AUGS[i-1].id)||0),price=augCost(a,cur);if(nowLocked||cur>=a.max||!SAVE.spend(price))return;SAVE.raw.meta[a.id]=cur+1;SAVE.save();renderAugV38();try{AUDIO.SFX.unlock();}catch(e){}if(window.UI&&UI.toast)UI.toast(a.n+' → LV '+(cur+1),'good');};
      g.appendChild(d);
    });
    var deep=document.getElementById('mega-deep-augs');if(deep)deep.remove();
    var content=document.getElementById('content-augments');if(content)content.remove();
    g.querySelectorAll('.content-aug').forEach(function(x){x.remove();});
  }
  function augmentSweep(){
    var g=document.getElementById('aug-grid');if(!g)return;
    if(g.dataset.v38Only==='1'){
      /* Keep it clean if another old loader tries to append extra cards. */
      Array.from(g.children).forEach(function(c){if(!c.classList.contains('augcard'))c.remove();});
      g.querySelectorAll('.content-aug').forEach(function(x){x.remove();});
      var deep=document.getElementById('mega-deep-augs');if(deep)deep.remove();
      return;
    }
    renderAugV38();
  }
  var augObs=null;
  function observeAug(){
    var g=document.getElementById('aug-grid');if(!g||augObs)return;
    augObs=new MutationObserver(function(){setTimeout(augmentSweep,0);});augObs.observe(g,{childList:true,subtree:true});
  }
  observeAug();
  if(window.UI&&UI.show&&!UI.__ISO_V38_AUG__){
    var baseShow=UI.show;UI.show=function(id){
      var out=baseShow.apply(this,arguments);
      if(id==='scr-aug'){setTimeout(function(){renderAugV38();observeAug();},10);setTimeout(renderAugV38,80);}
      return out;
    };UI.__ISO_V38_AUG__=1;
  }
  setInterval(function(){var s=document.getElementById('scr-aug');if(s&&!s.classList.contains('hidden')){renderAugV38();}},700);

  /* Also make every legacy caller of SAVE.metaCost use the new chain prices. */
  SAVE.metaCost=function(m,lv){
    var a=AUGS.find(function(x){return x.id===m.id;});
    return a?augCost(a,lv):0;
  };

  /* ---------- Mastery: 50ms synchronization + exact selected-element Exp ---------- */
  var lastMasterySignature='';
  function currentMasteryId(){
    try{
      var chips=document.querySelectorAll('#m-elems .mchip.sel');
      if(chips.length&&chips[0].dataset&&chips[0].dataset.id)return chips[0].dataset.id;
    }catch(e){}
    return SAVE.sel;
  }


  /* ---------- V38 startup decision gate ---------- */
  var PROMPT_KEY='v38RestartAccepted';
  function showV38Prompt(){
    if(SAVE.raw[PROMPT_KEY]===true||document.getElementById('v38-start-prompt'))return;
    var ov=document.createElement('div');ov.id='v38-start-prompt';
    ov.style.cssText='position:fixed;inset:0;z-index:100000;background:rgba(2,6,12,.96);display:flex;align-items:center;justify-content:center;padding:24px;font-family:var(--mono,monospace);';
    var modal=document.createElement('div');modal.style.cssText='width:min(720px,92vw);border:1px solid #4c84b9;background:linear-gradient(155deg,#0c1522,#080d15);box-shadow:0 0 45px rgba(20,110,210,.18);padding:30px;text-align:center;';
    var q=document.createElement('div');q.style.cssText='font-family:var(--disp,sans-serif);font-size:clamp(22px,3vw,34px);letter-spacing:.08em;color:#d9efff;margin-bottom:14px;';
    var sub=document.createElement('div');sub.style.cssText='font-size:13px;line-height:1.7;color:#9dacbe;max-width:590px;margin:0 auto 24px;';
    var count=0;
    function paint(){
      var qs=['Would you like to restart for the V38 update?','ARE YOU SURE?','ARE YOU SURE SURE?','ARE YOU SURE SURE SURE?','ARE YOU ABSOLUTELY SURE?'];
      q.textContent=qs[Math.min(count,4)];
      sub.innerHTML=count===0?'A V38 restart migration can give you a fresh-start bonus of <b style="color:#7ef0a6">2,000 coins</b>. Your choice stays saved if you choose YES.': 'Choosing NO keeps your current save. You will be asked again the next time you open the game.';
    }
    var row=document.createElement('div');row.style.cssText='display:flex;justify-content:center;gap:16px;';
    var yes=document.createElement('button'),no=document.createElement('button');
    [yes,no].forEach(function(b){b.style.cssText='min-width:150px;padding:13px 22px;border:1px solid #547da8;background:#101c2b;color:#dcecff;font-family:var(--mono);font-weight:700;cursor:pointer;';});
    yes.textContent='YES';no.textContent='NO';
    yes.onclick=function(){
      SAVE.raw[PROMPT_KEY]=true;
      SAVE.addCoins(2000);
      try{AUDIO.SFX.unlock();}catch(e){}
      SAVE.save();
      location.reload();
    };
    no.onclick=function(){
      count++;
      if(count>=5){ov.remove();return;}
      paint();
    };
    row.appendChild(yes);row.appendChild(no);modal.appendChild(q);modal.appendChild(sub);modal.appendChild(row);ov.appendChild(modal);document.body.appendChild(ov);paint();
    document.addEventListener('keydown',function block(ev){if(!document.getElementById('v38-start-prompt')){document.removeEventListener('keydown',block,true);return;}ev.preventDefault();ev.stopImmediatePropagation();},true);
    document.addEventListener('click',function blockOutside(ev){if(!document.getElementById('v38-start-prompt')){document.removeEventListener('click',blockOutside,true);return;}if(!modal.contains(ev.target)){ev.preventDefault();ev.stopPropagation();}},true);
  }
  setTimeout(showV38Prompt,250);

  /* ---------- V38 update log entry ---------- */
  function addV38Log(){
    var p=document.getElementById('mega-update-panel');if(!p||p.dataset.v38Update)return;
    p.dataset.v38Update='1';
    p.insertAdjacentHTML('beforeend','<div class="urow"><div class="uver">V38 · REWORK + QOL</div><div class="utxt">Liquid Nitrogen now uses a large-radius freeze field as Signature 1, keeps the three-shot shatter volley as Signature 2, and moves the original cryogenic shatter shot to Signature 3. Frozen non-boss enemies jitter very slightly, turn light blue, and gain a blue freeze ring. The Synthesis Lab stays greyed out until its saved 200-point unlock is purchased. Favorites are selectable, augmentations are limited to the nine research upgrades, and Element Mastery now keeps its selected element during live refresh with an Exp readout.</div></div>');
    p.scrollTop=p.scrollHeight;
  }
  setTimeout(addV38Log,450);setTimeout(addV38Log,1200);

  console.log('ISOTOPE V38 FULL QOL ACTIVE');
})();
