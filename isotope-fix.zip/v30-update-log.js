/* ISOTOPE V30 update-log entry for the 118 base-element Ability 3 overhaul. */
'use strict';
(function(){
  if(window.__ISO_V30_UPDATE_LOG__)return;window.__ISO_V30_UPDATE_LOG__=true;
  function add(){
    var p=document.getElementById('mega-update-panel');
    if(!p||p.dataset.v30)return;
    p.dataset.v30='1';
    p.insertAdjacentHTML('beforeend','<div class="urow"><div class="uver">V30 · ELEMENTS</div><div class="utxt">All 118 base elements now have a dedicated third ability executor matched to the ability description, with unique targeting, timing, damage, status, defensive, beam, field, or reaction behavior. Ability damage follows the player\'s current in-run damage bonus, third-ability effects use element colors, and delayed effects are isolated to their run.</div></div>');
    setTimeout(function(){try{p.scrollTop=p.scrollHeight;}catch(_e){}},0);
  }
  setTimeout(add,800);
})();
