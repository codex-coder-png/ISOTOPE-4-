/* ISOTOPE V31 update-log entry for the window/internal loop bridge fix. */
'use strict';
(function(){
  if(window.__ISO_V31_UPDATE_LOG__)return;window.__ISO_V31_UPDATE_LOG__=true;
  function add(){
    var p=document.getElementById('mega-update-panel');
    if(!p||p.dataset.v31)return;
    p.dataset.v31='1';
    p.insertAdjacentHTML('beforeend','<div class="urow"><div class="uver">V31 · CRITICAL FIX</div><div class="utxt">Found the actual reason Nicotine\'s Receptor Charm ability could freeze the game, and why V25 through V29\'s fixes never stopped it happening: several files (combat FX, element zones, Ability 3, and the V29 nicotine safety rewrite) all correctly patch window.update/window.render/window.useActive - but nothing ever connected those to the real game loop, which called its own internal copies directly. Every one of those patches, including V29\'s dedicated safe charm system, was silently never running at all; the old, unguarded conversion code was the only thing that ever actually fired. The real loop now runs through window.update/window.render/window.useActive/window.updBullets/window.updEnemies/window.nearestPlayer, so every one of those files\' fixes - V29\'s nicotine safety system included - actually executes now.</div></div>');
    setTimeout(function(){try{p.scrollTop=p.scrollHeight;}catch(_e){}},0);
  }
  setTimeout(add,900);
  setInterval(function(){if(document.readyState!=='loading')add();},1800);
})();
