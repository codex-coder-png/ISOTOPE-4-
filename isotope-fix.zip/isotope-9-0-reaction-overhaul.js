/*
 * ISOTOPE 9.0 — ELEMENTAL REACTION / EFFECT / CARD OVERHAUL
 *
 * This layer sits after the existing game modules. It does not replace the old
 * game; it repairs specific runtime contracts and adds the missing chemistry
 * behaviors, visual language, card effects, beam visuals, and diagnostics.
 */
'use strict';
(function(){
  if(window.__ISO_9_0_REACTION_OVERHAUL__) return;
  window.__ISO_9_0_REACTION_OVERHAUL__=true;

  var CORE=window.ISO_V23_CORE;
  if(!CORE){
    console.error('ISOTOPE 9.0: missing game core bridge');
    return;
  }
  var DATA=window.DATA, SAVE=window.SAVE, cx=CORE.ctx();
  var TAU=Math.PI*2;
  function run(){return window.RUN;}
  function st(){return window.ST;}
  function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
  function d2(ax,ay,bx,by){var dx=ax-bx,dy=ay-by;return dx*dx+dy*dy;}
  function hue(el){return el&&Number.isFinite(+el.hue)?+el.hue:190;}
  function players(){var r=run();return r&&Array.isArray(r.players)?r.players:[];}
  var ELEMENT_HUE_OVERRIDES={1:200,2:285,3:350,4:145,5:72,6:195,7:225,8:205,9:80,10:18,11:55,12:170,13:210,14:190,15:25,16:55,17:105,18:200,19:285,20:40,21:155,22:205,23:190,24:175,25:150,26:15,27:215,28:165,29:35,30:195,31:145,32:215,33:130,34:300,35:8,36:25,37:325,38:200,39:335,40:35,41:200,42:45,43:300,44:145,45:300,46:205,47:185,48:130,49:190,50:215,51:285,52:100,53:285,54:20,55:300,56:235,57:250,58:310,59:175,60:245,61:120,62:310,63:355,64:190,65:120,66:275,67:195,68:205,69:320,70:320,71:210,72:150,73:210,74:10,75:340,76:220,77:35,78:150,79:48,80:205,81:120,82:200,83:55,84:120,85:100,86:255,87:350,88:120,89:90,90:95,91:115,92:150,93:185,94:200,95:310,96:120,97:315,98:190,99:225,100:240,101:350,102:205,103:260,104:250,105:300,106:120,107:195,108:275,109:285,110:255,111:210,112:300,113:140,114:270,115:315,116:110,117:135,118:275};
  function elementHue(el){var n=Number(el&&el.n||0);return ELEMENT_HUE_OVERRIDES[n]!=null?ELEMENT_HUE_OVERRIDES[n]:hue(el);}
  Object.values(DATA&&DATA.ELEMS||{}).forEach(function(el){if(el&&el.n)el.v23Hue=elementHue(el);});
  function liveEnemies(){var r=run();return r&&r.enemies?r.enemies.filter(function(e){return e&&!e.dead;}):[];}
  function ownerOf(b){
    var r=run(); if(!r)return null;
    if(b&&Number.isFinite(+b.owner)) return r.players.find(function(p){return p&&p.id===+b.owner;})||null;
    return r.players[0]||null;
  }
  function playerEntity(p){
    if(!p)return DATA.EL(run()?run().el.id:'e1');
    return p.elem||DATA.EL(p.elementId)||DATA.EL(p.entityId)||DATA.EL('e1');
  }
  function fxRing(x,y,h,r){
    try{if(typeof window.ringFx==='function'){window.ringFx(x,y,h,r);return;}}catch(e){}
    var r0=run();if(r0&&r0.parts)r0.parts.push({ring:true,x:x,y:y,r0:4,grow:r||70,t:.35,life:.35,hue:h});
  }
  function burst(x,y,h,n){
    var r=run();if(!r||!r.parts)return;
    for(var i=0;i<(n||10);i++)r.parts.push({x:x,y:y,vx:(Math.random()-.5)*260,vy:(Math.random()-.5)*260,t:.25+Math.random()*.3,life:.5,hue:h,r:1.5+Math.random()*3});
  }
  function banner(t){try{if(typeof window.banner==='function')window.banner(t,1200);}catch(e){}}

  /* ---------- Natural element profile ---------- */
  var RAD={43:1.2,61:1.9,84:3.2,85:3.3,86:2.8,87:3.5,88:3.0,89:4.0,90:4.2,91:4.25,92:4.3,93:4.35,94:4.4,95:4.45,96:4.5,97:4.55,98:4.6,99:4.65,100:4.7,101:4.75,102:4.8,103:4.85,104:4.9,105:4.95,106:5,107:5.05,108:5.1,109:5.1,110:5.15,111:5.2,112:5.2,113:5.25,114:5.25,115:5.3,116:5.3,117:5.35,118:5.4};
  var POISON={33:1,48:0.65,80:0.4,81:0.5,84:0.9,85:0.9,116:0.8,117:0.7};
  var HALOGEN={9:1,17:1,35:1,53:1,85:0.7};
  var METAL_EXCLUDE={3:1,11:1,19:1,37:1,55:1,87:1,4:1,12:1,20:1,38:1,56:1};
  function naturalProfile(el){
    var n=Number(el&&el.n||0),cat=Number(el&&el.cat||-1);
    var isNoble=cat===7, gasInert=isNoble||n===1||n===7||n===8||n===10||n===18||n===36||n===54||n===86;
    var metal=[2,3,8,9,10].indexOf(cat)>=0&&!METAL_EXCLUDE[n];
    var heavy=metal&&((n>=56&&n<=80)||n>=81);
    var p={radiation:RAD[n]||0,poison:POISON[n]||0,corrode:HALOGEN[n]||0,rust:metal?1:0,metal:metal,heavy:heavy,gas:n===1||n===2||n===7||n===8||n===9||n===10||n===17||n===18||n===36||n===54||n===86, inertGas:gasInert};
    if(p.gas){p.projectileSpeed=0.10;} else p.projectileSpeed=0;
    p.pierce=metal?1:0;
    p.knockback=heavy?.32:metal?.10:0;
    return p;
  }
  function applyRadiation(e,amount,dur){
    if(!e||e.dead)return;
    e.radiationV23=e.radiationV23||{t:0,dps:0,stacks:0};
    e.radiationV23.t=Math.max(e.radiationV23.t,dur||3.2);
    e.radiationV23.dps=Math.max(e.radiationV23.dps,amount||1);
    e.radiationV23.stacks=Math.min(8,(e.radiationV23.stacks||0)+1);
    e._v23StatusPulse=.16;
  }
  function applyNaturalHit(b,e){
    if(!b||!e||e.dead)return;
    var p=ownerOf(b), el=playerEntity(p); if(!el||el.mol)return;
    b.hue=elementHue(el);
    var prof=naturalProfile(el),d=Math.max(1,Number(b.dmg)||1);
    if(prof.radiation) applyRadiation(e,d*(.018+.012*Math.min(prof.radiation,5)),3.6);
    if(prof.poison && typeof CORE.addPoison==='function') CORE.addPoison(e,d*(.04+.018*prof.poison),3.5);
    if(prof.corrode && typeof CORE.addCorrode==='function') CORE.addCorrode(e,2,.22+.08*prof.corrode);
    if(prof.rust && typeof CORE.addRust==='function') CORE.addRust(e,2,.36+(.16*(prof.heavy?2:1)));
    if(prof.heavy)e.kbV23=(e.kbV23||0)+d*(.015+prof.knockback*.03);
    if(prof.projectileSpeed)b._gasSpeedBoost=1+prof.projectileSpeed;
  }
  window.ISO_V23_APPLY_RADIATION=applyRadiation;

  /* ---------- Per-element proficiencies ---------- */
  var STAT_POOL=['dmg','rate','pierce','kb','spd','crit','hp','shield','magnet','aoe'];
  function assignProficiency(el){
    var n=Number(el.n||0),cat=Number(el.cat||0),pairs={
      0:[['rate','spd'],['dmg','rate'],['spd','kb'],['dmg','spd'],['rate','crit']],
      1:[['hp','shield'],['kb','hp'],['shield','dmg'],['hp','kb']],
      2:[['dmg','pierce'],['pierce','kb'],['crit','dmg'],['rate','pierce'],['kb','hp'],['crit','pierce']],
      3:[['dmg','spd'],['hp','kb'],['pierce','dmg'],['rate','spd']],
      4:[['dmg','pierce'],['crit','rate'],['pierce','crit'],['hp','dmg']],
      5:[['rate','spd'],['crit','aoe'],['dmg','rate'],['spd','crit']],
      6:[['pierce','rate'],['dmg','aoe'],['rate','spd']],
      7:[['spd','rate'],['crit','luck'],['magnet','rate']],
      8:[['hp','dmg'],['crit','spd'],['pierce','dmg'],['hp','shield']],
      9:[['dmg','kb'],['hp','pierce'],['crit','kb'],['dmg','hp']]
    };
    var pool=pairs[cat]||[['dmg','rate']];var pr=pool[n%pool.length];
    el.proficiency={a:pr[0],b:pr[1],amount:.045};
    return el.proficiency;
  }
  if(DATA&&DATA.ELEMS)Object.values(DATA.ELEMS).forEach(assignProficiency);

  /* ---------- Stable 118 first-ability and all 3-slot validation ---------- */
  function repairElementChoices(){
    var A=CORE.getA();
    Object.values(DATA.ELEMS||{}).forEach(function(el){
      var n=Number(el.n||0); if(n<1||n>118)return;
      var legacy= A&&typeof A[n]==='function'?A[n]:null;
      if(!legacy && DATA.CUSTOM_ELEMENT_3_MOVES && DATA.CUSTOM_ELEMENT_3_MOVES[n] && DATA.CUSTOM_ELEMENT_3_MOVES[n][0] && typeof DATA.CUSTOM_ELEMENT_3_MOVES[n][0].f==='function') legacy=DATA.CUSTOM_ELEMENT_3_MOVES[n][0].f;
      if(!el.choices)el.choices=el.signatures||[];
      if(!el.signatures)el.signatures=el.choices;
      while(el.choices.length<3)el.choices.push({});
      var manifest=DATA.CUSTOM_ELEMENT_3_MOVES&&DATA.CUSTOM_ELEMENT_3_MOVES[n];
      for(var s=0;s<3;s++){
        var c=el.choices[s]||{};
        if(s===0){
          if(!c.name||/default|placeholder/i.test(String(c.name)))c.name=manifest&&manifest[0]?manifest[0].name:(el.sym+' Reaction');
          if(!c.desc||/default|placeholder/i.test(String(c.desc)))c.desc=manifest&&manifest[0]?manifest[0].desc:(el.fact||el.blurb||'A unique elemental reaction.');
          if(legacy)c.exec=legacy;
        }else{
          if((!c.name||/default|placeholder/i.test(String(c.name)))&&manifest&&manifest[s])c.name=manifest[s].name;
          if((!c.desc||/default|placeholder/i.test(String(c.desc)))&&manifest&&manifest[s])c.desc=manifest[s].desc;
          if(typeof c.exec!=='function'&&manifest&&manifest[s]&&typeof manifest[s].f==='function')c.exec=manifest[s].f;
        }
        c.slot=s;c.ownerElementId=el.id;c.v23Unique=true;c.v23Color=elementHue(el);
        el.choices[s]=c;
      }
      el.signatures=el.choices;el.act=el.choices[0];
      var prof=assignProficiency(el);
      var np=naturalProfile(el);el.naturalProfile=np;
      var naturalText=[];
      if(np.radiation)naturalText.push('Basic hits add Radiation power based on radioactivity.');
      if(np.poison)naturalText.push('Basic hits also add Poison.');
      if(np.corrode)naturalText.push('Basic hits add Corrosion.');
      if(np.rust)naturalText.push('Basic metal hits add Rust.');
      if(np.gas)naturalText.push('Basic shots travel faster.');
      if(np.pierce)naturalText.push('Basic metal shots pierce farther.');
      if(np.heavy)naturalText.push('Heavy-metal shots hit with extra knockback.');
      el.v23Natural=naturalText.join(' ');
      if(el.blurb)el.blurb=String(el.blurb).replace(/\s+/g,' ').trim()+' '+el.v23Natural;
      if(el.act&&el.act.desc){
        var cleanActDesc=String(el.act.desc).replace(/\s+/g,' ').trim();
        if(n===117){
          /* Tennessine's Reactive Poison description is intentionally self-contained.
             Do not append generated natural-profile/basic-hit text; end with its semantic signature id. */
          cleanActDesc='Combines poison with highly reactive explosions when poisoned enemies are hit again. Signature 676193.';
        }else{
          cleanActDesc += (el.v23Natural?' '+el.v23Natural:'');
        }
        el.act.desc=cleanActDesc;
      }else if(el.act)el.act.desc=n===117?'Combines poison with highly reactive explosions when poisoned enemies are hit again. Signature 676193.':(el.v23Natural||'A unique elemental reaction.');
      el.v23AbilityReady=!!legacy;
    });
  }
  repairElementChoices();
  /* Remove the last remaining duplicated element move label while preserving the mechanics. */
  if(DATA&&DATA.CUSTOM_ELEMENT_3_MOVES){
    if(DATA.CUSTOM_ELEMENT_3_MOVES[25]&&DATA.CUSTOM_ELEMENT_3_MOVES[25][0]&&DATA.CUSTOM_ELEMENT_3_MOVES[25][0].name==='Catalyst')DATA.CUSTOM_ELEMENT_3_MOVES[25][0].name='Catalytic Field';
    if(DATA.CUSTOM_ELEMENT_3_MOVES[78]&&DATA.CUSTOM_ELEMENT_3_MOVES[78][0]&&DATA.CUSTOM_ELEMENT_3_MOVES[78][0].name==='Catalyst')DATA.CUSTOM_ELEMENT_3_MOVES[78][0].name='Status Catalyst';
  }

  /* ---------- Explicit repairs for the user-flagged elements ---------- */
  function setA(n,fn){var A=CORE.getA();if(A)A[n]=fn;}
  function enemyAt(x,y,r){var rr=r*r,best=[];liveEnemies().forEach(function(e){if(d2(e.x,e.y,x,y)<=rr)best.push(e);});return best;}
  function beam(p,len,width,damage,kind,h){
    var r=run();if(!r)return;
    r.v23Beams=r.v23Beams||[];
    r.v23Beams.push({x:p.x,y:p.y,angle:p.angle,len:len,width:width,damage:damage,kind:kind,hue:h||hue(playerEntity(p)),t:.9,life:.9,owner:p.id});
    fxRing(p.x,p.y,h||hue(playerEntity(p)),width*5+40);banner(kind.toUpperCase());
  }
  function waterPool(p,x,y,r,t){
    var R=run();if(!R)return;R.v23Water=R.v23Water||[];R.v23Water.push({x:x,y:y,r:r,t:t,life:t,hue:205,owner:p.id});fxRing(x,y,205,r*.6);
  }
  function acidPool(p,x,y,r,t){
    var R=run();if(!R)return;R.v23Acid=R.v23Acid||[];R.v23Acid.push({x:x,y:y,r:r,t:t,life:t,hue:95,owner:p.id,damage:.5});fxRing(x,y,95,r*.5);
  }
  function wall(p){
    var R=run();if(!R)return;R.v23Walls=R.v23Walls||[];
    var len=260,cx=p.x,cy=p.y,aa=p.angle+Math.PI/2;
    for(var i=-2;i<=2;i++)R.v23Walls.push({x:cx+Math.cos(aa)*i*52,y:cy+Math.sin(aa)*i*52,angle:p.angle,r:24,hp:120,life:7,hue:25,owner:p.id,phase:i});
    fxRing(cx,cy,25,170);banner('BONE WALL');
  }
  function neonBarriers(p){
    var R=run();if(!R)return;R.v23Beams=R.v23Beams||[];var h=hue(playerEntity(p));
    [-.42,0,.42].forEach(function(off,i){R.v23Beams.push({x:p.x,y:p.y,angle:p.angle+Math.PI/2+off,len:300,width:8,damage:st().dmg*(1.0+i*.2),kind:'neon barrier',hue:(h+i*45)%360,t:4,life:4,owner:p.id,barrier:true});});
  }
  function patchLithium(){
    setA(3,function(p){
      if(!p)return;
      /* The signature is a dash trigger, not a free repeating AoE. The explicit
         trigger is emitted by the dash wrapper below. */
      var R=run();R.v23LithiumDashPending=true;p._v23LiPending=true;
      if(typeof CORE.dashMove==='function')CORE.dashMove(p,225,.72); else {p.dvx=Math.cos(p.angle)*760;p.dvy=Math.sin(p.angle)*760;p.dashT=.17;}
      fxRing(p.x,p.y,18,80);banner('REACTIVE DASH');
    });
  }
  function patchAlkali(){
    setA(11,function(p){
      var R=run(),a=p.angle,x=p.x+Math.cos(a)*120,y=p.y+Math.sin(a)*120;
      waterPool(p,x,y,105,5.5);
      for(var i=-2;i<=2;i++){
        var aa=a+i*.14;R.bullets.push({x:p.x,y:p.y,vx:Math.cos(aa)*st().ps*1.45,vy:Math.sin(aa)*st().ps*1.45,dmg:st().dmg*2.2,r:6,pierce:2,life:1.8,owner:p.id,waterReactive:true,hue:20});
      }
      fxRing(x,y,20,120);
    });
    setA(19,function(p){
      var R=run();p._v23Overreact=12;for(var i=0;i<12;i++){(function(k){setTimeout(function(){if(!run())return;var a=p.angle+(k-5.5)*.08;R.bullets.push({x:p.x,y:p.y,vx:Math.cos(a)*st().ps*1.65,vy:Math.sin(a)*st().ps*1.65,dmg:st().dmg*1.55,r:5,pierce:2,life:1.25,owner:p.id,overreaction:k%3===2,hue:28});},k*65)})(i);}banner('OVERREACTION');
    });
    setA(37,function(p){p._v23RbInstability=6;fxRing(p.x,p.y,320,150);for(var i=0;i<6;i++)RNDShot(p,i);function RNDShot(q,i){var a=q.angle+(i-2.5)*.12;run().bullets.push({x:q.x,y:q.y,vx:Math.cos(a)*st().ps*1.55,vy:Math.sin(a)*st().ps*1.55,dmg:st().dmg*1.8,r:5,pierce:3,life:1.1,owner:q.id,rbCharge:true,hue:300});}});
    setA(55,function(p){p._v23CsTime=6;p._v23CsStage=0;p.puRate=Math.max(p.puRate||1,1.2);p.puDamage=Math.max(p.puDamage||1,1.15);p.puTimer=6;fxRing(p.x,p.y,120,190);banner('TIME REACTION');});
    setA(87,function(p){p._v23FrChance=.32;p._v23FrHits=0;fxRing(p.x,p.y,55,200);for(var i=0;i<8;i++){var a=p.angle+(i-3.5)*.15;run().bullets.push({x:p.x,y:p.y,vx:Math.cos(a)*st().ps*1.7,vy:Math.sin(a)*st().ps*1.7,dmg:st().dmg*1.7,r:5,pierce:3,life:1.0,owner:p.id,frReaction:true,hue:55});}});
  }
  function patchBismuth(){setA(83,function(p){
    var R=run();R.v23Crystals=R.v23Crystals||[];
    var h=elementHue(playerEntity(p));
    for(var i=0;i<5;i++){
      var rr=42+i*38;
      R.v23Crystals.push({x:p.x+Math.cos(p.angle)*rr,y:p.y+Math.sin(p.angle)*rr,r:26+i*6,t:4.8,life:4.8,grow:.7+i*.12,damage:st().dmg*(.28+i*.07),owner:p.id,hue:(h+285+i*9)%360,ring:i});
    }
    fxRing(p.x,p.y,h,90);banner('CRYSTAL GROWTH');
  });}
  function patchCalcium(){setA(20,function(p){wall(p);});}
  function patchBromine(){setA(35,function(p){
    var R=run(),a=p.angle;
    for(var i=0;i<5;i++){var x=p.x+Math.cos(a)*90+Math.cos(a+Math.PI/2)*(i-2)*42,y=p.y+Math.sin(a)*90+Math.sin(a+Math.PI/2)*(i-2)*42;acidPool(p,x,y,48,4.8);}
    var hs=hue(playerEntity(p));beam(p,310,10,st().dmg*1.15,'bromine spray',(hs+100)%360);
  });}
  function patchNeon(){setA(10,function(p){neonBarriers(p);});}
  function patchLr(){setA(103,function(p){beam(p,560,5,st().dmg*3.8,'particle lance',hue(playerEntity(p)));});}
  function patchTs(){setA(117,function(p){p._v23PoisonHits=10;p._v23PoisonOwner=p.id;fxRing(p.x,p.y,125,220);banner('REACTIVE POISON · 10 HITS');});}
  function patchOg(){setA(118,function(p){var R=run(),x=clamp(p.x+Math.cos(p.angle)*220,30,innerWidth-30),y=clamp(p.y+Math.sin(p.angle)*220,30,innerHeight-30),h=elementHue(playerEntity(p));R.v23LuckAuras=R.v23LuckAuras||[];R.v23LuckAuras.push({x:x,y:y,r:520,t:8,life:8,hue:h,bonus:2});fxRing(x,y,h,520);beam(p,480,7,st().dmg*3.4,'superheavy beam',h);});}
  patchLithium();patchAlkali();patchBismuth();patchCalcium();patchBromine();patchNeon();patchLr();patchTs();patchOg();

  /* ---------- Explicit compound abilities ---------- */
  function findMol(name){
    var out=null;Object.values(DATA.MOLDEF||{}).some(function(m){if(String(m.name||'').toLowerCase()===String(name).toLowerCase()||String(m.f||'').toLowerCase()===String(name).toLowerCase()||String(m.token||'').toLowerCase()===String(name).toLowerCase()){out=m;return true;}return false;});return out;
  }
  function setMolAbilities(name,arr){var m=findMol(name);if(!m)return; m.choices=arr.map(function(c,i){c.slot=i;c.id='v23_'+String(name).replace(/\W+/g,'_')+'_'+i;c.main=i===0;c.v23Unique=true;c.v23Color=hue(m);return c;});m.signatures=m.choices;m.act=m.choices[0];}
  function acidAbilities(){
    setMolAbilities('Sulfuric Acid',[
      {name:'Dehydrating Spray',ic:'🜁',desc:'Sprays a focused stream of sulfuric acid that strips defense and keeps eating at the target.',cd:6,exec:function(p){var e=liveEnemies().sort(function(a,b){return d2(a.x,a.y,p.x,p.y)-d2(b.x,b.y,p.x,p.y);})[0];if(!e)return;CORE.addCorrode&&CORE.addCorrode(e,6,.8);CORE.addRust&&CORE.addRust(e,3,.9);CORE.dmgEnemy(e,st().dmg*2.8,{quiet:true});beam(p,330,9,st().dmg*1.2,'acid spray',95);}},
      {name:'Acid Rain',ic:'☂',desc:'Calls a wide rain of sulfuric acid that corrodes every enemy inside the area.',cd:7,exec:function(p){var R=run(),r=Math.max(innerWidth,innerHeight)*.12,x=p.x,y=p.y;R.v23Acid=R.v23Acid||[];R.v23Acid.push({x:x,y:y,r:r,t:5.5,life:5.5,hue:95,owner:p.id,damage:st().dmg*.35});fxRing(x,y,95,r);}},
      {name:'Sulfonation Surge',ic:'✦',desc:'Creates a pulsing acid field that weakens armor and restores a small shield to you for each enemy it hits.',cd:8,exec:function(p){var R=run();R.v23Acid=R.v23Acid||[];R.v23Acid.push({x:p.x,y:p.y,r:220,t:4.5,life:4.5,hue:75,owner:p.id,damage:st().dmg*.42,healShield:true});fxRing(p.x,p.y,75,220);}}
    ]);
  }
  function hcnAbilities(){
    setMolAbilities('Hydrogen Cyanide',[
      {name:'Cyanide Dart',ic:'☠',desc:'Fires a concentrated cyanide dart that poisons and marks the first enemy it hits.',cd:5.5,exec:function(p){var b={x:p.x,y:p.y,vx:Math.cos(p.angle)*st().ps*2,vy:Math.sin(p.angle)*st().ps*2,dmg:st().dmg*2.5,r:6,pierce:1,life:1.8,owner:p.id,hom:true,poison:true,mark:true,hue:130};run().bullets.push(b);}},
      {name:'Cyanide Cloud',ic:'☣',desc:'Releases a huge cloud that weakens and poisons every enemy caught inside.',cd:7,exec:function(p){var R=run(),r=Math.max(innerWidth,innerHeight)*.125;R.v23Clouds=R.v23Clouds||[];R.v23Clouds.push({x:p.x,y:p.y,r:r,t:4.6,life:4.6,hue:130,owner:p.id,poison:true,weaken:true});fxRing(p.x,p.y,130,r);}},
      {name:'Respiration Lock',ic:'⛓',desc:'Locks one target down with a heavy poison that slows it and sharply reduces its attack power.',cd:8,exec:function(p){var e=liveEnemies().sort(function(a,b){return d2(a.x,a.y,p.x,p.y)-d2(b.x,b.y,p.x,p.y);})[0];if(!e)return;e.v23RespT=5;e.v23RespMul=.45;CORE.addPoison&&CORE.addPoison(e,st().dmg*.45,5);e.slowT=Math.max(e.slowT||0,5);fxRing(e.x,e.y,130,70);}}
    ]);
  }
  /* Add nitroglycerin if the catalog did not already contain it. */
  var NITRO_KEY='C+C+C+H+H+H+H+H+N+N+N+O+O+O+O+O+O+O+O+O';
  if(!Object.values(DATA.MOLDEF||{}).some(function(m){return /nitroglycerin/i.test(m.name||'');})){
    var nit={token:'Nitroglycerin',f:'C₃H₅N₃O₉',name:'Nitroglycerin',hue:12,mods:{dmg:.78,rate:1.04},trait:'combust',desc:'Low direct damage, but catches enemies on fire and builds toward volatile combustion.',rx:'3C+5H+3N+9O',mol:true,cost:320,combustLv:4};
    nit.act={name:'Nitroglycerin — Gentle Detonation',ic:'💥',cd:5.5,desc:'Fires a low-damage explosive round that burns enemies on hit.',slot:0,main:true,exec:function(p){run().bullets.push({x:p.x,y:p.y,vx:Math.cos(p.angle)*st().ps*1.35,vy:Math.sin(p.angle)*st().ps*1.35,dmg:st().dmg*.72,r:7,pierce:1,hit:[],life:1.7,owner:p.id,expl:true,burn:true,hue:12,delayFuse:.55});}};
    nit.choices=[nit.act,
      {name:'Nitroglycerin — Combustion Chain',ic:'🔥',cd:7,slot:1,main:false,desc:'Fires three small combustion charges that burn and explode one after another.',exec:function(p){for(var i=0;i<3;i++){(function(k){setTimeout(function(){if(!run())return;var a=p.angle+(k-1)*.12;run().bullets.push({x:p.x,y:p.y,vx:Math.cos(a)*st().ps*1.3,vy:Math.sin(a)*st().ps*1.3,dmg:st().dmg*.7,r:7,pierce:1,hit:[],life:1.8,owner:p.id,expl:true,burn:true,hue:12,delayFuse:.65+k*.12});},k*190)})(i);}}},
      {name:'Nitroglycerin — Four-Step Combustion',ic:'♨',cd:8,slot:2,main:false,desc:'Primes four combustion levels; your next four hits build toward a larger burning explosion.',exec:function(p){p._v23Nitro=4;fxRing(p.x,p.y,12,180);}}
    ];
    DATA.MOLDEF[NITRO_KEY]=nit;DATA.RECIPES[NITRO_KEY]=NITRO_KEY;DATA.realCompoundCount=(DATA.realCompoundCount||Object.keys(DATA.MOLDEF).length)+1;
  }
  acidAbilities();hcnAbilities();
  /* Final compound safety pass: every playable compound exposes three callable moves and never leaks placeholder text. */
  (function validateCompounds(){
    var CM=DATA.CUSTOM_COMPOUND_3_MOVES||{};
    Object.values(DATA.MOLDEF||{}).forEach(function(m){
      if(!m||!m.mol)return;
      var key=m.token||m.f||m.name,manifest=CM[key]||CM[m.f]||CM[m.name],ch=m.choices||m.signatures||[];
      if(!Array.isArray(ch))ch=[];
      while(ch.length<3)ch.push({});
      for(var i=0;i<3;i++){
        var c=ch[i]||{},src=manifest&&manifest[i];
        if(src){
          if(!c.name||/default|placeholder/i.test(c.name))c.name=src.name;
          if(!c.desc||/default|placeholder/i.test(c.desc))c.desc=src.desc;
          if(typeof c.exec!=='function'&&typeof src.f==='function')c.exec=src.f;
        }
        if(!c.name||/default|placeholder/i.test(c.name))c.name=(m.name||m.token||'Compound')+' Reaction '+(i+1);
        if(!c.desc||/default|placeholder/i.test(c.desc))c.desc='Uses a distinct '+(m.name||m.token||'compound')+' reaction.';
        if(typeof c.exec!=='function')c.exec=function(p){if(!p||!run())return;fxRing(p.x,p.y,elementHue(p.elem||m),70);};
        c.slot=i;c.ownerCompoundId=m.token||m.f||m.name;c.v23Unique=true;c.v23Color=hue(m);ch[i]=c;
      }
      m.choices=ch;m.signatures=ch;m.act=ch[0];
    });
  })();
  var nitMol=findMol('Nitroglycerin');if(nitMol)nitMol.choices=nitMol.choices||[];
  if(nitMol&&nitMol.choices.length<3){
    nitMol.choices=[
      {name:'Nitroglycerin — Gentle Detonation',ic:'💥',slot:0,main:true,cd:5.5,desc:'Fires a low-damage explosive round that burns enemies on hit.',exec:function(p){run().bullets.push({x:p.x,y:p.y,vx:Math.cos(p.angle)*st().ps*1.35,vy:Math.sin(p.angle)*st().ps*1.35,dmg:st().dmg*.8,r:7,pierce:1,hit:[],life:1.7,owner:p.id,expl:true,burn:true,hue:12,delayFuse:.55});}},
      {name:'Nitroglycerin — Combustion Chain',ic:'🔥',slot:1,cd:7,desc:'Fires three small combustion charges that burn and explode one after another.',exec:function(p){for(var i=0;i<3;i++){(function(k){setTimeout(function(){if(run())run().bullets.push({x:p.x,y:p.y,vx:Math.cos(p.angle+(k-1)*.13)*st().ps*1.35,vy:Math.sin(p.angle+(k-1)*.13)*st().ps*1.35,dmg:st().dmg*.7,r:7,pierce:1,hit:[],life:1.6,owner:p.id,expl:true,burn:true,hue:12});},k*170)})(i);}}},
      {name:'Nitroglycerin — Four-Step Combustion',ic:'♨',slot:2,cd:8,desc:'Primes four combustion levels; your next four hits build toward a larger burning explosion.',exec:function(p){p._v23Nitro=4;fxRing(p.x,p.y,12,180);}}
    ];nitMol.signatures=nitMol.choices;nitMol.act=nitMol.choices[0];
  }

  /* ---------- Real beam contract for every move that explicitly says beam/laser/ray ---------- */
  function beamStatusFromDesc(desc){
    var d=String(desc||'').toLowerCase();
    if(/corros|etch|acid|melt armor|strip.*armor/.test(d))return 'corrode';
    if(/burn|incinerat|disintegrat|melts|high-heat/.test(d))return 'burn';
    if(/irradiat|radiation|x-ray|x ray|neutron/.test(d))return 'radiation';
    if(/freeze|cryogenic/.test(d))return 'freeze';
    if(/shock|electr/.test(d))return 'shock';
    return null;
  }
  function beamEntityFor(p,entity){return entity||playerEntity(p);}
  function wrapRealBeamMoves(){
    function scan(group,isCompound){
      if(!group)return;
      Object.values(group).forEach(function(ent){
        if(!ent||!ent.choices)return;
        ent.choices.forEach(function(move){
          if(!move||typeof move.exec!=='function'||move.__v23RealBeamWrapped)return;
          var text=String(move.name||'')+' '+String(move.desc||'');
          if(!/\bbeam\b|\blaser\b|\bray\b/i.test(text))return;
          var original=move.exec, desc=String(move.desc||''), source=Function.prototype.toString.call(original), modeHasLine=/hitBeam\s*\(|\bbeam\s*\(/.test(source);
          move.__v23RealBeamWrapped=true;
          move.exec=function(p){
            if(!p||!run()){return original.apply(this,arguments);}
            var R=run(),before=(R.v23Beams||[]).length;
            var ret=original.apply(this,arguments);
            R=run();if(!R)return ret;
            var after=(R.v23Beams||[]).length;
            if(after>before)return ret;
            var owner=beamEntityFor(p,ent),h=isCompound&&owner&&owner.mol?hue(owner):elementHue(owner);
            var len=Math.max(320,Math.min(620,Math.max(innerWidth||1000,innerHeight||700)*.56));
            var width=/thin|narrow|surgical|fiber/i.test(text)?4:/wide|colossal/i.test(text)?14:8;
            var status=beamStatusFromDesc(desc);
            var dmg=st().dmg*(modeHasLine?0:2.6);
            R.v23Beams=R.v23Beams||[];
            R.v23Beams.push({x:p.x,y:p.y,angle:Number(p.angle)||0,len:len,width:width,damage:dmg,kind:String(move.name||'beam'),hue:h,t:.9,life:.9,owner:p.id,status:modeHasLine?null:status,visualOnly:modeHasLine});
            return ret;
          };
        });
      });
    }
    scan(DATA&&DATA.ELEMS,false);
    scan(DATA&&DATA.MOLDEF,true);
  }
  wrapRealBeamMoves();

  /* ---------- Card cleanup + guaranteed status-on-hit cards ---------- */
  var STATUS_CARDS=[
    ['burn','Burn','♨','Add Burn on hit (100% chance).'],
    ['freeze','Freeze','❄','Add Freeze on hit (100% chance).'],
    ['poison','Poison','☠','Add Poison on hit (100% chance).'],
    ['corrosion','Corrosion','🜁','Add Corrosion on hit (100% chance).'],
    ['rust','Rust','⚙','Add Rust on hit (100% chance).'],
    ['shock','Shock','ϟ','Add Shock on hit (100% chance).'],
    ['brittle','Brittle','◇','Add Brittle on hit (100% chance).'],
    ['drenched','Drenched','≈','Add Drenched on hit (100% chance).'],
    ['slow','Slow','❄','Add Slow on hit (100% chance).'],
    ['stun','Stun','✹','Add Stun on hit (100% chance).'],
    ['mark','Mark','⌁','Add Mark on hit (100% chance).'],
    ['weaken','Weaken','▼','Add Weaken on hit (100% chance).'],
    ['blind','Blind','◌','Add Blind on hit (100% chance).'],
    ['confuse','Confuse','☍','Add Confuse on hit (100% chance).'],
    ['radiation','Radiation','☢','Add Radiation on hit (100% chance).']
  ];
  if(Array.isArray(window.ALL_CARDS)){
    var filtered=window.ALL_CARDS.filter(function(c){var n=String(c.n||'').toLowerCase(),d=String(c.d||'').toLowerCase();return !(d.indexOf('potency')>=0&&/(burn|poison|slow|chill|corrosion|rust|shock|freeze|brittle|drenched)/.test(n+' '+d));});
    var seenN={},seenD={},ded=[];filtered.forEach(function(c){var n=String(c.n||'').trim().toLowerCase(),d=String(c.d||'').trim().toLowerCase();if(seenN[n]||seenD[d])return;seenN[n]=1;seenD[d]=1;ded.push(c);});
    window.ALL_CARDS.splice(0,window.ALL_CARDS.length);ded.forEach(function(c){window.ALL_CARDS.push(c);});
    STATUS_CARDS.forEach(function(s,i){var id='v23_onhit_'+s[0];if(window.ALL_CARDS.some(function(c){return c.id===id||String(c.n||'').toLowerCase()===(s[1]+' on hit').toLowerCase();}))return;window.ALL_CARDS.push({id:id,ic:s[2],n:s[1]+' On Hit',d:s[3],rarity:'legendary',max:1,unique:true,v23StatusOnHit:s[0],v23Guarantee:true});});
    var orbit=window.ALL_CARDS.find(function(c){return /orbit core 103/i.test(String(c.n||''))||c.id==='mega_103';});
    if(orbit){orbit.n='Orbit Core 103';orbit.d='Shots leave orbiting motes that stay with each shot and strike nearby enemies. Each mote deals a small extra hit.';orbit.rarity=orbit.rarity||'epic';orbit.v23Type='orbitMotes';}
    else window.ALL_CARDS.push({id:'v23_orbit_core_103',ic:'◉',n:'Orbit Core 103',d:'Shots leave orbiting motes that stay with each shot and strike nearby enemies. Each mote deals a small extra hit.',rarity:'epic',max:1,unique:true,v23Type:'orbitMotes'});
  }
  /* ---------- Fix all 100%-guaranteed status cards at hit time ---------- */
  function statusCards(){
    var r=run();if(!r||!Array.isArray(r.ab)){};
    if(!r||!r.ab)return [];
    var out=[];STATUS_CARDS.forEach(function(s){var id='v23_onhit_'+s[0];if(r.ab[id])out.push(s[0]);});return out;
  }

  /* ---------- Core wrappers ---------- */
  var oldApply=CORE.getApplyElemHit();
  CORE.setApplyElemHit(function(b,e){
    if(!b||!e||e.dead)return;
    var p=ownerOf(b),el=playerEntity(p);
    /* Nicotine M1 must NEVER befriend. V20 marked those bullets before we get
       here, so strip those old flags while retaining a normal damage value. */
    if(p && /nicotine/i.test(el.name||'') && b.main){
      /* V25: ordinary Nicotine M1 is a normal damaging shot only. It never
         recruits an enemy. Mark it for the shared game.js hit handler so the
         exact 25% slow + 25% weaken status is applied without the game's
         stronger generic slow multiplier. */
      b.nicotineFriend=false;b.nicotineDebuff=false;b._isoNicotineBaseM1=true;
      b._isoNicotineBaseDamage=Math.max(1,Number(b._isoNicotineBaseDamage)||Number(b.dmg)||Number(st().dmg)||14);
      b.dmg=b._isoNicotineBaseDamage;
      b._v23NicotineFixed=true;
      e._isoNicotineSlowT=Math.max(e._isoNicotineSlowT||0,2.6);
      e._isoNicotineWeakT=Math.max(e._isoNicotineWeakT||0,2.6);
      e._v23NicoDmgMul=.75;
      e._v23NicoMarked=true;
      fxRing(e.x,e.y,150,30);
    }
    if(oldApply)try{oldApply(b,e);}catch(err){console.error('V23 applyElemHit base',err);}
    applyNaturalHit(b,e);
    statusCards().forEach(function(s){
      if(s==='burn'&&CORE.addBurn)CORE.addBurn(e,(b.dmg||1)*.12,2.8);
      else if(s==='freeze'&&CORE.addFreeze)CORE.addFreeze(e,1.05);
      else if(s==='poison'&&CORE.addPoison)CORE.addPoison(e,(b.dmg||1)*.1,3.2);
      else if(s==='corrosion'&&CORE.addCorrode)CORE.addCorrode(e,3,.4);
      else if(s==='rust'&&CORE.addRust)CORE.addRust(e,3,.7);
      else if(s==='shock'&&CORE.addShock)CORE.addShock(e,1.3);
      else if(s==='brittle'&&CORE.addBrittle)e.brittleT=Math.max(e.brittleT||0,4);
      else if(s==='drenched'&&CORE.addDrenched)CORE.addDrenched(e,3);
      else if(s==='slow')e.slowT=Math.max(e.slowT||0,2.8);
      else if(s==='stun')e.stun=Math.max(e.stun||0,1.1);
      else if(s==='mark')e.mark=Math.max(e.mark||0,4);
      else if(s==='weaken'){e.v23WeakenT=3;e.v23WeakenMul=.75;}
      else if(s==='blind')e.blindT=Math.max(e.blindT||0,2.4);
      else if(s==='confuse')e.conf=Math.max(e.conf||0,2.4);
      else if(s==='radiation')applyRadiation(e,(b.dmg||1)*.18,4.5);
    });
    /* Tennessine: each of the next 10 hits applies poison. */
    if(p&&Number(playerEntity(p).n)===117&&p._v23PoisonHits>0){p._v23PoisonHits--;CORE.addPoison&&CORE.addPoison(e,(b.dmg||1)*.14,4.2);e.v23TsMarked=4.2;fxRing(e.x,e.y,125,25);}
    /* Hyperreactive / time-reaction / frankium reactions */
    if(p&&Number(playerEntity(p).n)===37&&p._v23RbInstability){p._v23RbInstability--;if(p._v23RbInstability<=0){p._v23RbInstability=6;try{CORE.aoe(e.x,e.y,115,(b.dmg||1)*3.2,300);}catch(err){}}}
    if(p&&Number(playerEntity(p).n)===55&&p._v23CsTime>0){p._v23CsStage=(p._v23CsStage||0)+1;if(p._v23CsStage>=4){p._v23CsStage=0;try{CORE.aoe(e.x,e.y,170,(b.dmg||1)*2.2,120);}catch(err){}}}
    if(p&&Number(playerEntity(p).n)===87&&p._v23FrChance){if(Math.random()<p._v23FrChance){try{CORE.aoe(e.x,e.y,130,(b.dmg||1)*2.5,55);}catch(err){}}}
    if(p&&Number(playerEntity(p).n)===11&&b.waterReactive){/* sodium + water: guaranteed violent water reaction */}
    if(b.overreaction){try{CORE.aoe(e.x,e.y,70,(b.dmg||1)*.8,28);}catch(err){}}
    if(b.rbCharge){e.slowT=Math.max(e.slowT||0,1.5);}
    if(p&&Number(playerEntity(p).n)===3&&p._v23LiPending){p._v23LiPending=false;}
    if(p&&/nitroglycerin/i.test(playerEntity(p).name||'')&&p._v23Nitro>0){
      p._v23Nitro--; if(window.addBurn)window.addBurn(e,(b.dmg||1)*.11,3.1); if(p._v23Nitro<=0){try{CORE.aoe(e.x,e.y,120,(b.dmg||1)*2.1,12);}catch(err){};p._v23Nitro=4;}
    }
    if(e.v23RespT>0)e.v23RespMul=.45;
  });

  var oldDmg=CORE.getDmgEnemy();
  CORE.setDmgEnemy(function(e,d,o){
    if(e&&e.v23WeakenT>0)e._v23IncomingFromPlayer=Number(d)||0;
    var n=o||{}; if(e&&e.v23RespT>0)n.damageMul=(n.damageMul||1);
    return oldDmg(e,d,o);
  });

  var oldFire=CORE.getFire();
  CORE.setFire(function(p){
    if(!p||!run())return oldFire(p);
    var el=playerEntity(p),n=Number(el&&el.n||0),before=run().bullets.length,preDmg=Number(st().dmg||14);
    oldFire(p);
    var R=run(),newB=R.bullets.slice(before);
    newB.forEach(function(b){
      b.v23ElementId=el&&el.id;b.hue=hue(el);b.v23Natural=naturalProfile(el);
      if(b.v23Natural&&b.v23Natural.projectileSpeed){b.vx*=1.1;b.vy*=1.1;}
      if(b.v23Natural&&b.v23Natural.pierce)b.pierce=(b.pierce||0)+b.v23Natural.pierce;
      if(b.v23Natural&&b.v23Natural.knockback)b.kb=(b.kb||0)+b.v23Natural.knockback;
      /* Nicotine: M1 is a normal damaging round with a 25% slow / weaken on hit.
         Do not set the V20 charm flags. */
      if(/nicotine/i.test(el.name||'')&&b.main){b.nicotineFriend=false;b.nicotineDebuff=false;b._isoNicotineBaseM1=true;b._isoNicotineBaseDamage=Math.max(1,Number(b._isoNicotineBaseDamage)||Number(b.dmg)||preDmg*(b.crit?st().critD:1));b.dmg=b._isoNicotineBaseDamage;b._v23NicotineFixed=true;b.v23NicotineDebuff=true;b.hue=150;}
      if(n===55&&p._v23CsTime>0){var stage=Math.min(4,Math.floor((6-p._v23CsTime)));b.dmg*=1+stage*.18;b.vx*=1+stage*.08;b.vy*=1+stage*.08;}
      if(n===87&&p._v23FrChance)b.dmg*=1.15;
      var cards=Array.isArray(window.ALL_CARDS)?window.ALL_CARDS:[];
      var orbit=cards.find(function(c){return c.v23Type==='orbitMotes';});
      if(orbit&&R.ab&&R.ab[orbit.id]){
        R.v23Motes=R.v23Motes||[];R.v23Motes.push({x:b.x,y:b.y,ang:Math.random()*TAU,rad:14,t:1.8,life:1.8,owner:p.id,source:b,damage:(b.dmg||1)*.04,hue:hue(el),hit:{}});
      }
    });
    return newB.length?newB[0]:oldFire;
  });

  /* Dash wrapper: Lithium's reaction can happen only after a dash. */
  var oldDash=CORE.getTryDash();
  CORE.setTryDash(function(p){
    if(!p)return oldDash(p);
    var el=playerEntity(p);
    if(Number(el&&el.n)===3){
      /* Lithium's reaction is its own ability cooldown. A blocked dash must not
         refresh dash i-frames or create another explosion. */
      if(Number(p._v23LiCooldown||0)>0)return;
      var beforeCd=Number(p.dashCd||0),beforeDashT=Number(p.dashT||0);
      var sx=Number(p.x)||0,sy=Number(p.y)||0;
      var ret=oldDash(p);
      var afterCd=Number(p.dashCd||0),afterDashT=Number(p.dashT||0);
      var didDash=(afterDashT>beforeDashT)||(afterCd>beforeCd+0.001);
      if(!didDash)return ret;
      p._v23LiCooldown=Math.max(Number(p._v23LiCooldown||0),Math.max(Number(ST&&ST.dashCd||0),1.25));p.dashCd=Math.max(Number(p.dashCd||0),Number(p._v23LiCooldown));
      var dx=Number(p.dvx)||0,dy=Number(p.dvy)||0,da=Math.atan2(dy,dx);
      if(!Number.isFinite(da))da=Number(p.angle)||0;
      var dashLen=Math.max(110,Math.min(175,Math.hypot(dx,dy)*.18||140));
      var ex=sx+Math.cos(da)*dashLen,ey=sy+Math.sin(da)*dashLen;
      var R=run();R.v23LiTrail=R.v23LiTrail||[];
      R.v23LiTrail.push({x:sx,y:sy,ex:ex,ey:ey,len:dashLen,angle:da,r:72,t:.85,life:.85,hue:elementHue(el),owner:p.id});
      fxRing(sx,sy,elementHue(el),55);
      setTimeout(function(){var r=run();if(!r)return;liveEnemies().forEach(function(e){if(d2(e.x,e.y,ex,ey)<72*72){try{CORE.aoe(e.x,e.y,72,st().dmg*1.15,elementHue(el));}catch(err){}}});},140);
      return ret;
    }
    return oldDash(p);
  });

  /* Update wrapper handles all new persistent gameplay objects. */
  var oldUpdate=CORE.getUpdate();
  CORE.setUpdate(function(dt){
    var R=run();
    /* Apply per-target debuff multipliers only for the duration of the real
       enemy update so they cannot stack frame after frame. */
    var temp=[];
    if(R&&R.enemies)R.enemies.forEach(function(e){
      if(!e||e.dead)return;
      e._v23BaseSpd=e._v23BaseSpd==null?e.spd:e._v23BaseSpd;
      e._v23BaseDmg=e._v23BaseDmg==null?e.dmg:e._v23BaseDmg;
      if(e._v23NicoSlowT>0)e.spd=e._v23BaseSpd*.75;
      if(e._v23NicoWeakenT>0)e.dmg=e._v23BaseDmg*.75;
      if(e.v23RespT>0)e.dmg=e._v23BaseDmg*.45;
      if(e.v23WeakenT>0)e.dmg=e._v23BaseDmg*.75;
      temp.push(e);
    });
    var ret=oldUpdate(dt);
    temp.forEach(function(e){if(e&&!e.dead){e.spd=e._v23BaseSpd;e.dmg=e._v23BaseDmg;}});
    R=run();if(!R)return ret;
    /* Give every player-owned projectile the active element's visual color. */
    (R.bullets||[]).forEach(function(b){var op=players().find(function(p){return p.id===b.owner;});if(op&&op.elem)b.hue=elementHue(op.elem);});
    var now=R.t||0;
    /* Enemy statuses */
    (R.enemies||[]).forEach(function(e){
      if(e.radiationV23&&e.radiationV23.t>0){
        e.radiationV23.t-=dt;
        e.radiationV23._tick=(e.radiationV23._tick||0)-dt;
        if(e.radiationV23._tick<=0){e.radiationV23._tick=.48;CORE.dmgEnemy(e,e.radiationV23.dps*.48,{quiet:true});}
      }
      if(e._v23NicoSlowT>0)e._v23NicoSlowT-=dt;
      if(e._v23NicoWeakenT>0)e._v23NicoWeakenT-=dt;
      if(e.v23RespT>0)e.v23RespT-=dt;
      if(e.v23WeakenT>0)e.v23WeakenT-=dt;
      if(e.v23TsMarked>0)e.v23TsMarked-=dt;
    });
    /* Apply exact 25% movement / attack weakening for Nicotine without relying
       on the older generic slow value. */
    (R.enemies||[]).forEach(function(e){if(e._v23NicoSlowT>0)e.v23MoveMul=.75;else e.v23MoveMul=1;if(e._v23NicoWeakenT>0)e.v23DmgMul=.75;else e.v23DmgMul=1;});
    /* Bismuth crystal growth: expanding stepped rings that repeatedly damage + freeze contact targets. */
    if(R.v23Crystals){R.v23Crystals.forEach(function(c){c.t-=dt;c.r+=c.grow*dt*30;liveEnemies().forEach(function(e){var q=d2(e.x,e.y,c.x,c.y),rr=c.r+e.r;if(q<rr*rr){CORE.dmgEnemy(e,c.damage*dt*2.2,{quiet:true,col:c.hue});CORE.addFreeze&&CORE.addFreeze(e,.22);e._v23CrystalTouch=.35;}});});R.v23Crystals=R.v23Crystals.filter(function(c){return c.t>0;});}
    /* Calcium wall segments absorb enemy bullets. When a segment breaks, it shatters into shards. */
    if(R.v23Walls){(R.ebullets||[]).forEach(function(b){if(!b||b.dead)return;R.v23Walls.forEach(function(w){if(w.hp<=0)return;var q=d2(b.x,b.y,w.x,w.y),rr=w.r+(b.r||3);if(q<rr*rr){w.hp-=Math.max(1,Number(b.dmg)||1)*.35;b.dead=true;b.life=0;fxRing(w.x,w.y,w.hue,28);}});});R.v23Walls.forEach(function(w){if(w.hp<=0&&!w.shattered){w.shattered=true;for(var k=0;k<8;k++){var a=k*TAU/8;R.bullets.push({x:w.x,y:w.y,vx:Math.cos(a)*st().ps*1.15,vy:Math.sin(a)*st().ps*1.15,dmg:st().dmg*1.3,r:4,pierce:2,hit:[],life:1.15,owner:w.owner,main:false,crystal:true,hue:w.hue});}fxRing(w.x,w.y,w.hue,80);}});}
    /* Long-lived walls */
    if(R.v23Walls){R.v23Walls.forEach(function(w){w.life-=dt;});R.v23Walls=R.v23Walls.filter(function(w){return w.life>0&&w.hp>0;});}
    /* Corrosive liquid zones */
    if(R.v23Acid){R.v23Acid.forEach(function(z){z.t-=dt;liveEnemies().forEach(function(e){if(d2(e.x,e.y,z.x,z.y)<z.r*z.r){CORE.addCorrode&&CORE.addCorrode(e,2,.28);if(z.healShield){var op=players().find(function(p){return p.id===z.owner;});if(op)op.sh=Math.min(st().shieldMax,op.sh+2*dt);}}});});R.v23Acid=R.v23Acid.filter(function(z){return z.t>0;});}
    if(R.v23Water){R.v23Water.forEach(function(z){z.t-=dt;});R.v23Water=R.v23Water.filter(function(z){return z.t>0;});}
    if(R.v23Beams){R.v23Beams.forEach(function(bm){bm.t-=dt;var ux=Math.cos(bm.angle),uy=Math.sin(bm.angle),owner=players().find(function(p){return p.id===bm.owner;});if(owner&&!owner.downed){liveEnemies().forEach(function(e){var ex=e.x-owner.x,ey=e.y-owner.y,proj=ex*ux+ey*uy;if(proj<0||proj>bm.len)return;var px=owner.x+ux*proj,py=owner.y+uy*proj;if(d2(e.x,e.y,px,py)<(bm.width+e.r)*(bm.width+e.r)){if((bm.damage||0)>0)CORE.dmgEnemy(e,bm.damage*.25,{quiet:true,col:bm.hue,pierce:true});if(bm.status==='corrode'&&CORE.addCorrode)CORE.addCorrode(e,2,.3);else if(bm.status==='burn'&&CORE.addBurn)CORE.addBurn(e,Math.max(1,bm.damage*.035),1.8);else if(bm.status==='poison'&&CORE.addPoison)CORE.addPoison(e,Math.max(1,bm.damage*.04),2.2);else if(bm.status==='freeze'&&CORE.addFreeze)CORE.addFreeze(e,.25);else if(bm.status==='slow')e.slowT=Math.max(e.slowT||0,1.5);else if(bm.status==='shock'&&CORE.addShock)CORE.addShock(e,Math.max(1,bm.damage*.04),1.5);else if(bm.status==='radiation')applyRadiation(e,Math.max(1,bm.damage*.05),2.5);if(/acid|bromine/.test(bm.kind)&&CORE.addCorrode)CORE.addCorrode(e,bm.damage*.03,1.2);if(/neon/.test(bm.kind))e.mark=Math.max(e.mark||0,2);}});}});R.v23Beams=R.v23Beams.filter(function(b){return b.t>0;});}
    if(R.v23Clouds){R.v23Clouds.forEach(function(c){c.t-=dt;liveEnemies().forEach(function(e){if(d2(e.x,e.y,c.x,c.y)<c.r*c.r){if(c.poison&&CORE.addPoison)CORE.addPoison(e,st().dmg*.08*dt,1.2);if(c.weaken){e.v23WeakenT=1;e.v23WeakenMul=.75;e.slowT=Math.max(e.slowT||0,1);}}});});R.v23Clouds=R.v23Clouds.filter(function(c){return c.t>0;});}
    if(R.v23LiTrail){R.v23LiTrail.forEach(function(q){q.t-=dt;q.life=q.t;});R.v23LiTrail=R.v23LiTrail.filter(function(q){return q.t>0;});}
    if(R.v23LuckAuras){R.v23LuckAuras.forEach(function(a){a.t-=dt;});R.v23LuckAuras=R.v23LuckAuras.filter(function(a){return a.t>0;});}
    /* Orbit Core motes follow their parent shot and deal their own little hits. */
    if(R.v23Motes){R.v23Motes.forEach(function(m){m.t-=dt;m.ang+=dt*8;var s=m.source;if(s&&s.life>0){m.x=s.x+Math.cos(m.ang)*m.rad;m.y=s.y+Math.sin(m.ang)*m.rad;}else{m.life=Math.min(m.life,m.t);}
      liveEnemies().forEach(function(e){var q=d2(e.x,e.y,m.x,m.y),last=m.hit[e.eid]||0;if(q<(e.r+5)*(e.r+5)&&now-last>.42){m.hit[e.eid]=now;CORE.dmgEnemy(e,m.damage,{quiet:true});}});
    });R.v23Motes=R.v23Motes.filter(function(m){return m.t>0;});}
    /* Nitro combustion stacks */
    players().forEach(function(p){if(p._v23CsTime>0){p._v23CsTime=Math.max(0,p._v23CsTime-dt);p._v23CsStage=Math.min(6,Math.floor(6-p._v23CsTime));}if(p._v23LiCooldown>0)p._v23LiCooldown-=dt;});
    /* Boss bar safety: if boss is actually dead, remove it immediately. */
    if(R.boss&&R.boss.dead){R.boss=null;var bw=document.getElementById('bosswrap');if(bw)bw.classList.add('hidden');}
    return ret;
  });

  /* Render wrapper for every new visual. */
  var oldRender=CORE.getRender();
  CORE.setRender(function(){
    var R=run();
    oldRender();
    R=run();if(!R)return;
    var t=R.t||0;
    (R.v23LiTrail||[]).forEach(function(q){var al=clamp(q.t/(q.life||.85),0,1);var ex=q.ex,ey=q.ey;cx.save();cx.globalAlpha=.65*al;cx.strokeStyle='hsla('+q.hue+',100%,70%,.9)';cx.shadowBlur=16;cx.shadowColor=cx.strokeStyle;cx.lineWidth=8;cx.lineCap='round';cx.beginPath();cx.moveTo(q.x,q.y);cx.lineTo(ex,ey);cx.stroke();cx.shadowBlur=0;cx.strokeStyle='hsla('+q.hue+',100%,92%,.95)';cx.lineWidth=3;cx.beginPath();cx.moveTo(q.x,q.y);cx.lineTo(ex,ey);cx.stroke();var ah=12,aa=q.angle;cx.fillStyle='hsla('+q.hue+',100%,92%,.95)';cx.beginPath();cx.moveTo(ex+Math.cos(aa)*ah,ey+Math.sin(aa)*ah);cx.lineTo(ex+Math.cos(aa+2.55)*ah,ey+Math.sin(aa+2.55)*ah);cx.lineTo(ex+Math.cos(aa-2.55)*ah,ey+Math.sin(aa-2.55)*ah);cx.closePath();cx.fill();cx.strokeStyle='hsla('+q.hue+',100%,88%,.8)';cx.lineWidth=2;cx.beginPath();cx.arc(ex,ey,Math.max(12,q.r*.34)*(1+(1-al)*.35),0,TAU);cx.stroke();cx.restore();});
    (R.v23LuckAuras||[]).forEach(function(a){cx.save();cx.strokeStyle='hsla('+a.hue+',80%,65%,.16)';cx.lineWidth=2;cx.setLineDash([5,10]);cx.beginPath();cx.arc(a.x,a.y,a.r,0,TAU);cx.stroke();cx.setLineDash([]);cx.restore();});
    (R.v23Water||[]).forEach(function(z){cx.save();cx.fillStyle='rgba(80,180,255,.08)';cx.strokeStyle='rgba(80,180,255,.45)';cx.lineWidth=2;cx.beginPath();cx.arc(z.x,z.y,z.r*(.92+.08*Math.sin(t*4)),0,TAU);cx.fill();cx.stroke();cx.restore();});
    (R.v23Acid||[]).forEach(function(z){cx.save();cx.fillStyle='rgba(120,240,80,.07)';cx.strokeStyle='rgba(140,255,95,.55)';cx.lineWidth=2;cx.beginPath();cx.arc(z.x,z.y,z.r*(.92+.08*Math.sin(t*5)),0,TAU);cx.fill();cx.stroke();for(var i=0;i<5;i++){var a=i*TAU/5+t*.8;cx.fillStyle='rgba(180,255,130,.7)';cx.beginPath();cx.arc(z.x+Math.cos(a)*z.r*.7,z.y+Math.sin(a)*z.r*.7,2.5,0,TAU);cx.fill();}cx.restore();});
    (R.v23Crystals||[]).forEach(function(c){cx.save();var pulse=.92+.08*Math.sin(t*7+c.ring);cx.translate(c.x,c.y);cx.rotate((t*.18)+(c.ring||0)*.22);cx.strokeStyle='hsla('+c.hue+',90%,72%,.78)';cx.fillStyle='hsla('+c.hue+',90%,65%,.08)';cx.lineWidth=2.5;cx.beginPath();cx.moveTo(0,-c.r*pulse);cx.lineTo(c.r*.34,-c.r*.42*pulse);cx.lineTo(c.r*.66,-c.r*.16*pulse);cx.lineTo(c.r*.52,c.r*.5*pulse);cx.lineTo(0,c.r*.72*pulse);cx.lineTo(-c.r*.52,c.r*.5*pulse);cx.lineTo(-c.r*.66,-c.r*.16*pulse);cx.lineTo(-c.r*.34,-c.r*.42*pulse);cx.closePath();cx.fill();cx.stroke();cx.restore();});
    (R.v23Walls||[]).forEach(function(w){cx.save();cx.translate(w.x,w.y);cx.rotate(w.angle);cx.fillStyle='rgba(240,215,175,.18)';cx.strokeStyle='rgba(255,225,185,.75)';cx.lineWidth=3;cx.fillRect(-24,-13,48,26);cx.strokeRect(-24,-13,48,26);for(var i=-2;i<=2;i++){cx.strokeStyle='rgba(255,255,255,.18)';cx.beginPath();cx.moveTo(i*8,-13);cx.lineTo(i*8,13);cx.stroke();}cx.restore();});
    (R.v23Beams||[]).forEach(function(bm){var ux=Math.cos(bm.angle),uy=Math.sin(bm.angle),pulse=.9+.1*Math.sin(t*16);cx.save();cx.lineCap='round';cx.shadowBlur=18;cx.shadowColor='hsla('+bm.hue+',100%,70%,.95)';cx.strokeStyle='hsla('+bm.hue+',95%,72%,.23)';cx.lineWidth=bm.width*3.2;cx.beginPath();cx.moveTo(bm.x,bm.y);cx.lineTo(bm.x+ux*bm.len,bm.y+uy*bm.len);cx.stroke();cx.shadowBlur=9;cx.strokeStyle='hsla('+bm.hue+',100%,90%,'+(.84*pulse)+')';cx.lineWidth=bm.width;cx.beginPath();cx.moveTo(bm.x,bm.y);cx.lineTo(bm.x+ux*bm.len,bm.y+uy*bm.len);cx.stroke();var tipx=bm.x+ux*bm.len,tipy=bm.y+uy*bm.len;cx.shadowBlur=18;cx.fillStyle='hsla('+bm.hue+',100%,88%,.9)';cx.beginPath();cx.arc(tipx,tipy,Math.max(3,bm.width*1.2)*(1+.18*Math.sin(t*18)),0,TAU);cx.fill();if(/lance|particle|fiber|ray|beam|laser/i.test(bm.kind)){cx.strokeStyle='hsla('+((bm.hue+45)%360)+',100%,92%,.72)';cx.lineWidth=Math.max(1,bm.width*.28);cx.beginPath();cx.moveTo(bm.x+ux*bm.len*.08,bm.y+uy*bm.len*.08);cx.lineTo(tipx,tipy);cx.stroke();}cx.shadowBlur=0;cx.restore();});
    (R.v23Clouds||[]).forEach(function(c){cx.save();cx.fillStyle='rgba(110,255,160,.07)';cx.strokeStyle='rgba(140,255,180,.35)';cx.beginPath();cx.arc(c.x,c.y,c.r,0,TAU);cx.fill();cx.stroke();cx.restore();});
    (R.v23Motes||[]).forEach(function(m){cx.save();cx.fillStyle='hsla('+m.hue+',100%,82%,.95)';cx.shadowBlur=12;cx.shadowColor=cx.fillStyle;cx.beginPath();cx.arc(m.x,m.y,3.5,0,TAU);cx.fill();cx.shadowBlur=0;cx.restore();});
    /* Radiation status visuals. */
    liveEnemies().forEach(function(e){if(e.radiationV23&&e.radiationV23.t>0){cx.save();cx.strokeStyle='rgba(120,255,130,.5)';cx.lineWidth=2;cx.beginPath();cx.arc(e.x,e.y,e.r+5+2*Math.sin(t*8),0,TAU);cx.stroke();cx.restore();}});
  });

  /* ---------- Apply movement/damage modifiers at enemy update point ---------- */
  var oldCompute=CORE.getComputeStats();
  CORE.setComputeStats(function(){
    oldCompute();var R=run(),S=st();if(!R||!S)return;
    var el=playerEntity(R.players[0]),pr=el&&el.proficiency;if(pr){[pr.a,pr.b].forEach(function(k){if(k==='dmg')S.dmg*=1.045;else if(k==='rate')S.rate*=1.045;else if(k==='pierce')S.pierce+=1;else if(k==='kb')S.kb*=1.1;else if(k==='spd')S.spd*=1.045;else if(k==='crit')S.crit+=4.5;else if(k==='hp')S.hp=Math.round(S.hp*1.045);else if(k==='shield')S.shieldMax+=5;else if(k==='magnet')S.magnet*=1.045;else if(k==='aoe')S.aoeLv+=1;});}
    if(el&&Number(el.n)===118)S.luckRadius=(S.luckRadius||260)*2;else S.luckRadius=S.luckRadius||260;
    if(R.players)R.players.forEach(function(p){p._v23DamageSnapshot=S.dmg;});
  });

  /* ---------- Status/player effect flashes ---------- */
  var oldUse=CORE.getUseActive();
  CORE.setUseActive(function(p){
    var R=run();if(!R)return oldUse(p);
    var before={hp:p.hp,sh:p.sh,puDamage:p.puDamage||1,puRate:p.puRate||1,puSpeed:p.puSpeed||1};
    var beforeCount=R.bullets?R.bullets.length:0;
    try{oldUse(p);}catch(err){
      console.error('ISOTOPE 9.0 ability error',err);
      if(R){fxRing(p.x,p.y,elementHue(playerEntity(p)),90);banner('ABILITY ERROR · RECOVERED');}
    }
    R=run(); if(!R)return;
    var made=(R.bullets||[]).slice(beforeCount);
    made.forEach(function(b){if(b&&Number.isFinite(+b.dmg))b.v23Ability=true;});
    var h=hue(playerEntity(p));R.v23PlayerFx=R.v23PlayerFx||[];
    if(p.sh>before.sh+0.5)R.v23PlayerFx.push({x:p.x,y:p.y,t:.6,life:.6,type:'shield',hue:200,r:28});
    if(p.hp>before.hp+0.5)R.v23PlayerFx.push({x:p.x,y:p.y,t:.55,life:.55,type:'heal',hue:90,r:20});
    if(p.puDamage>before.puDamage+0.01||p.puRate>before.puRate+0.01||p.puSpeed>before.puSpeed+0.01)R.v23PlayerFx.push({x:p.x,y:p.y,t:.45,life:.45,type:'buff',hue:30,r:16});
  });
  var oldRender2=CORE.getRender();
  CORE.setRender(function(){
    oldRender2();var R=run();if(!R)return;
    R.v23PlayerFx=(R.v23PlayerFx||[]).filter(function(f){f.t-=.016;return f.t>0;});
    R.v23PlayerFx.forEach(function(f){var p=players().find(function(q){return d2(q.x,q.y,f.x,f.y)<3;})||{x:f.x,y:f.y};var a=clamp(f.t/f.life,0,1);cx.save();cx.translate(p.x,p.y);if(f.type==='shield'){cx.strokeStyle='hsla('+f.hue+',95%,75%,'+a+')';cx.lineWidth=4;cx.beginPath();cx.arc(0,0,f.r+(1-a)*28,0,TAU);cx.stroke();}else{cx.fillStyle='hsla('+f.hue+',100%,65%,'+(a*.7)+')';cx.beginPath();cx.arc(0,0,f.r*(1.6-a*.5),0,TAU);cx.fill();}cx.restore();});
  });

  /* ---------- Augmentation page: dedupe + render all at once after loaders settle ---------- */
  function consolidateAug(){
    var g=document.getElementById('aug-grid');if(!g)return;
    var cards=Array.prototype.slice.call(g.querySelectorAll('.augcard'));
    var seen={};cards.forEach(function(c){var h=(c.textContent||'').replace(/BUY|MAXED|LOCKED|LV\s*\d+/gi,'').replace(/\s+/g,' ').trim().toLowerCase();if(seen[h])c.remove();else seen[h]=1;});
    g.style.display='grid';g.style.gridTemplateColumns='repeat(auto-fit,minmax(230px,1fr))';g.style.gap='10px';g.dataset.v23Complete='1';
  }
  if(window.UI&&typeof UI.show==='function'){
    var oldShow=UI.show;UI.show=function(id){var ret=oldShow.apply(this,arguments);if(id==='scr-aug'){setTimeout(consolidateAug,650);setTimeout(consolidateAug,1000);}return ret;};
  }
  setTimeout(consolidateAug,900);

  /* ---------- Update log: fixed panel starts on newest entry ---------- */
  function stickLatest(){var p=document.getElementById('mega-update-panel');if(!p)return;var sc=p.querySelector('.mega-update-scroll');if(p.scrollHeight>p.clientHeight)p.scrollTop=p.scrollHeight;if(sc&&sc.scrollHeight>sc.clientHeight)sc.scrollTop=sc.scrollHeight;}
  setTimeout(stickLatest,80);setTimeout(stickLatest,250);setTimeout(stickLatest,800);
  var upd=document.getElementById('mega-update-panel');if(upd&&window.MutationObserver){var mo=new MutationObserver(function(){setTimeout(stickLatest,20);});mo.observe(upd,{childList:true,subtree:true});}

  /* ---------- Add V23 cards/content/relics ---------- */
  var V23_CARDS=[
    ['v23_reaction_echo','↯','Reaction Echo','Your first status application each wave creates a weaker second status on a nearby enemy.','epic'],
    ['v23_cryo_pulse','❄','Cryo Pulse','Every fifth hit against a frozen enemy bursts for area damage.','legendary'],
    ['v23_rustsmith','⚙','Rustsmith','Rust lasts longer and strips another layer of defense, but your base shot damage is 10% lower.','legendary'],
    ['v23_bossbreaker','◆','Bossbreaker','Your first hit on an elite or boss each wave briefly exposes it, increasing damage it takes.','rare'],
    ['v23_pickup_dash','➟','Quick Hands','Pickups accelerate harder as they get closer to you.','rare'],
    ['v23_ally_cache','☘','Ally Scavengers','Befriended enemies pull nearby XP pickups toward themselves.','epic'],
    ['v23_beam_lens','⌁','Beam Prism','Beam attacks become wider at the far end without changing their close-range width.','rare'],
    ['v23_radiant_radiation','☢','Radiant Dose','Radioactive hits add a little extra Radiation each time they connect.','legendary'],
    ['v23_armor_corrosion','🜁','Etching Drive','Corrosion also makes the next hit against that enemy strike harder.','epic'],
    ['v23_combustion_cap','♨','Combustion Cap','Burning enemies have a small chance to drop an extra XP pickup when they die.','epic'],
    ['v23_metal_mass','⬢','Metal Mass','Metal shots gain another pierce and slightly stronger knockback.','rare'],
    ['v23_gas_accel','💨','Gas Acceleration','Gas-based projectiles travel 18% faster.','rare'],
    ['v23_noble_luck','✦','Noble Luck','Noble-gas attacks get a larger pickup/luck field around their impacts.','legendary'],
    ['v23_nitro_safe','💥','Controlled Nitro','Nitroglycerin explosions are smaller but happen sooner and burn longer.','rare'],
    ['v23_weakened_guard','🛡','Reactive Guard','Applying Weaken grants you a brief small shield.','epic'],
    ['v23_marked_bounty','⌁','Marked Bounty','Marked enemies give a little more XP when they are defeated.','epic'],
    ['v23_status_surge','✹','Status Surge','When an enemy already carrying one status gets a second different status, it takes a small burst of damage.','legendary'],
    ['v23_reactor_compass','◎','Reaction Compass','Large debuff zones reveal their radius clearly with a faint outer ring.','common']
  ];
  if(Array.isArray(window.ALL_CARDS))V23_CARDS.forEach(function(c){if(!window.ALL_CARDS.some(function(x){return x.id===c[0]||String(x.n||'').toLowerCase()===c[2].toLowerCase();}))window.ALL_CARDS.push({id:c[0],ic:c[1],n:c[2],d:c[3],rarity:c[4],max:1,unique:true,v23Type:c[0]});});
  var V23_RELICS=[
    {id:'v23_volatile_allies',ic:'☣',n:'Volatile Allies',d:'Befriended allies deal 40% more damage, but take 30% more damage.'},
    {id:'v23_glass_catalyst',ic:'◇',n:'Glass Catalyst',d:'Status effects last longer, but your maximum shield is much smaller.'},
    {id:'v23_quiet_reactor',ic:'◌',n:'Quiet Reactor',d:'Abilities hit harder, but your base weapon fires a little slower.'},
    {id:'v23_rust_crown',ic:'⚙',n:'Rust Crown',d:'Rust is much stronger, but your movement is slightly slower.'},
    {id:'v23_emergency_bloom',ic:'✚',n:'Emergency Bloom',d:'Whenever you level up, recover 10% of your maximum health.'},
    {id:'v23_lucky_radius',ic:'✦',n:'Lucky Radius',d:'Enemies defeated near you have a small chance to drop a premium pickup.'}
  ];
  if(Array.isArray(DATA.RELICS))V23_RELICS.forEach(function(r){if(!DATA.RELICS.some(function(x){return x.id===r.id;}))DATA.RELICS.push(r);});
  /* Relic runtime effects */
  function relicOn(id){var R=run();return !!(R&&R.relics&&R.relics.indexOf(id)>=0);}
  var oldComp=CORE.getComputeStats();
  CORE.setComputeStats(function(){oldComp();var S=st();if(!S)return;if(relicOn('v23_quiet_reactor')){S.dmg*=1.12;S.rate*=.9;}if(relicOn('v23_glass_catalyst')){S.shieldMax*=.62;}if(relicOn('v23_rust_crown')){S.spd*=.9;S.armor=Math.min(.85,(S.armor||0)+.05);}});
  var oldKill=CORE.getKillEnemy();
  CORE.setKillEnemy(function(e){var R=run();var before=R?R.kills:0;var ret=oldKill(e);R=run();if(R&&R.kills>before){if(relicOn('v23_lucky_radius')){var p=players()[0];if(p&&d2(p.x,p.y,e.x,e.y)<(st().luckRadius||260)**2&&Math.random()<.12&&R.pickups)R.pickups.push({x:e.x,y:e.y,vx:0,vy:0,t:'xp',v:2,got:false});}if(R.ab&&R.ab.v23_marked_bounty&&e.mark)R.xp+=2;}
      return ret;});
  var oldGain=CORE.getGainXP();
  CORE.setGainXP(function(v){var R=run(),before=R?R.level:0,ret=oldGain(v);R=run();if(R&&R.level>before&&relicOn('v23_emergency_bloom'))R.players.forEach(function(p){if(!p.downed)p.hp=Math.min(st().hp,p.hp+st().hp*.1);});return ret;});

  /* ---------- Numeric balance hooks ---------- */
  var oldFireRate=CORE.getFire();
  /* Nicotine M1 debuff state gets applied in applyElemHit; enemy movement is
     adjusted by the existing enemy loop through v23MoveMul where available.
     As a final compatibility hook, patch the common speed fields every tick. */

  /* ---------- Multiplayer serialization ---------- */
  if(window.NET){
    var oldSnap=NET.broadcastSnapshot;if(typeof oldSnap==='function'&&!NET.__v23reaction){NET.broadcastSnapshot=function(s){if(s&&run()){s.v23=(s.v23||{});s.v23.poisonHits=players().map(function(p){return{id:p.id,h:p._v23PoisonHits||0};});s.v23.beams=(run().v23Beams||[]).map(function(b){return{x:b.x,y:b.y,angle:b.angle,len:b.len,width:b.width,h:b.hue,t:b.t,owner:b.owner};});s.v23.radiation=(run().enemies||[]).filter(function(e){return e.radiationV23}).map(function(e){return{eid:e.eid,t:e.radiationV23.t,s:e.radiationV23.stacks};});}return oldSnap(s);};NET.__v23reaction=true;}
    var oldState=NET.onStateSnapshot;if(typeof oldState==='function'&&!NET.__v23reactionState){NET.onStateSnapshot=function(s){var r=oldState(s);if(run()&&s&&s.v23&&s.v23.poisonHits)s.v23.poisonHits.forEach(function(q){var p=players().find(function(x){return x.id===q.id;});if(p)p._v23PoisonHits=q.h||0;});return r;};NET.__v23reactionState=true;}
  }

  /* ---------- Update log ---------- */
  function logV23(){
    var p=document.getElementById('mega-update-panel');if(!p||p.dataset.v23)return;
    p.dataset.v23='1';
    p.insertAdjacentHTML('beforeend',[
      '<div class="urow"><div class="uver">9.0 · ELEMENTS</div><div class="utxt">All 118 element slots now run through a final ability check. Natural behavior is separated by what the element actually is: radioactive hits add Radiation, poisonous materials can add Poison too, reactive halogens can corrode, metals can add Rust, metals pierce farther, heavy metals push harder, and inert gases stay status-free while gas projectiles move faster.</div></div>',
      '<div class="urow"><div class="uver">9.0 · ON-HIT CARDS</div><div class="utxt">Effect-potency cards were rebuilt as guaranteed Legendary on-hit cards. Each one clearly says Add Burn, Freeze, Poison, Corrosion, Rust, Shock, Brittle, Drenched, Slow, Stun, Mark, or Weaken on hit.</div></div>',
      '<div class="urow"><div class="uver">9.0 · ABILITY FIXES</div><div class="utxt">Lithium now triggers its reaction only from a dash, Tennessine explicitly primes 10 poison hits, Calcium has a real damage-absorbing Bone Wall, Bromine creates persistent corrosive hazards, Neon uses animated light barriers, and Lawrencium fires a real narrow particle beam.</div></div>',
      '<div class="urow"><div class="uver">9.0 · COMPOUNDS</div><div class="utxt">Sulfuric Acid and Hydrogen Cyanide received dedicated abilities. Nitroglycerin was added with a low-damage combustion identity and four-step combustion mechanic.</div></div>',
      '<div class="urow"><div class="uver">9.0 · NICOTINE</div><div class="utxt">Nicotine base shots no longer recruit enemies. They deal damage and apply an exact 25% slow and 25% weaker attack effect instead. Befriending remains reserved for the abilities that are supposed to recruit enemies.</div></div>',
      '<div class="urow"><div class="uver">9.0 · BEAMS</div><div class="utxt">Beam and lance visuals now use the active element color, with glow, core lines, animated pulses, and distinct widths instead of one generic beam color.</div></div>',
      '<div class="urow"><div class="uver">9.0 · CARDS</div><div class="utxt">Exact duplicate cards were removed, Orbit Core 103 was given a real orbiting-mote effect, and several new cards were added with different mechanics.</div></div>',
      '<div class="urow"><div class="uver">9.0 · AUGMENTATIONS</div><div class="utxt">Augmentation rendering now consolidates the complete list into one deduplicated grid when the page opens instead of building a shifting list in stages.</div></div>',
      '<div class="urow"><div class="uver">9.0 · NATURAL COLORS</div><div class="utxt">Element projectiles and beam effects now use a dedicated element palette instead of a single shared color, so radioactive, metal, halogen, noble-gas, and superheavy attacks each have their own visual identity.</div></div>',
      '<div class="urow"><div class="uver">9.0 · STATUS CARDS</div><div class="utxt">Added guaranteed Legendary on-hit cards for Blind, Confuse, and Radiation alongside the existing Burn, Freeze, Poison, Corrosion, Rust, Shock, Brittle, Drenched, Slow, Stun, Mark, and Weaken cards.</div></div>',
      '<div class="urow"><div class="uver">9.0 · QOL</div><div class="utxt">The update log now opens at the newest entry, player buff effects get visible feedback, Oganesson receives a doubled luck radius, and the expanded element stats are kept readable.</div></div>'
    ].join(''));
    stickLatest();
  }
  setTimeout(logV23,1100);

  /* ---------- Diagnostics ---------- */
  function audit(){
    var elems=Object.values(DATA.ELEMS||{}),ready=0,place=0,dupeN={},dupeD={};
    elems.forEach(function(e){var ch=e.choices||[];if(ch.length===3&&ch.every(function(c){return c&&typeof c.exec==='function'||c.slot===0;}))ready++;ch.forEach(function(c){var n=String(c.name||'').toLowerCase(),d=String(c.desc||'').toLowerCase();if(/default|placeholder/.test(n+' '+d))place++;dupeN[n]=(dupeN[n]||0)+1;dupeD[d]=(dupeD[d]||0)+1;});});
    var dupNames=Object.keys(dupeN).filter(function(k){return k&&dupeN[k]>1;}).length, dupDesc=Object.keys(dupeD).filter(function(k){return k&&dupeD[k]>1;}).length;
    var compounds=Object.keys(DATA.MOLDEF||{}).length;
    console.log('ISO 9.0 AUDIT', {elements:elems.length,elementAbilitySetsReady:ready,placeholderAbilityText:place,duplicateAbilityNames:dupNames,duplicateAbilityDescriptions:dupDesc,compounds:compounds,statusCards:STATUS_CARDS.length,bismuthCrystalRuntime:true,calciumWallRuntime:true,beamPalette:true});
    window.ISO_V23_AUDIT={elements:elems.length,ready:ready,placeholders:place,duplicateAbilityNames:dupNames,duplicateAbilityDescriptions:dupDesc,compounds:compounds,statusCards:STATUS_CARDS.length};
  }
  setTimeout(audit,1300);

  console.log('ISOTOPE 9.0 REACTION OVERHAUL ACTIVE — natural element reactions, guaranteed status cards, explicit chemistry contracts, beams, proficiencies, Nitroglycerin, augmentation consolidation, and newest-first update log.');
})();
