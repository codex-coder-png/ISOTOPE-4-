/* ISOTOPE V94 — PER-ABILITY SIGNATURE MASTERY RESTORATION
 * Final layer after V93. Makes the three independent Signature upgrade trees
 * authoritative and resilient to legacy/late UI refreshes that can overwrite
 * #m-detail after the Mastery screen opens.
 */
(function(){
  'use strict';
  if(window.__ISO_V94_MASTERY_RESTORATION__)return;
  window.__ISO_V94_MASTERY_RESTORATION__=true;

  function visible(){
    var s=document.getElementById('scr-mastery');
    return !!(s&&!s.classList.contains('hidden'));
  }
  function ensure(){
    if(!visible())return;
    var d=document.getElementById('m-detail');
    if(!d)return;
    /* V93 is the authoritative renderer. Only call it when its three ability
       sections are missing; this avoids a paint/update loop. */
    var paths=d.querySelectorAll('.v93-sig');
    if(paths.length>=3)return;
    try{
      if(typeof window.ISO_V93_RENDER_MASTERY==='function'){
        window.ISO_V93_RENDER_MASTERY(window.__ISO_MASTERY_VIEW_ID||window.SAVE&&SAVE.sel);
      }
    }catch(err){
      try{console.warn('ISOTOPE V94 mastery restore',err);}catch(_){ }
    }
  }

  function hook(){
    var d=document.getElementById('m-detail');
    if(d&&!d.__isoV94Observer&&window.MutationObserver){
      var obs=new MutationObserver(function(){
        if(visible())setTimeout(ensure,0);
      });
      obs.observe(d,{childList:true,subtree:true});
      d.__isoV94Observer=obs;
    }
    if(window.UI&&typeof UI.show==='function'&&!UI.show.__isoV94Mastery){
      var base=UI.show;
      var wrapped=function(id){
        var out=base.apply(this,arguments);
        if(id==='scr-mastery'){
          requestAnimationFrame(ensure);
          setTimeout(ensure,80);
          setTimeout(ensure,180);
        }
        return out;
      };
      wrapped.__isoV94Mastery=true;
      UI.show=wrapped;
    }
    ensure();
  }

  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',hook,{once:true});
  else hook();
  window.addEventListener('load',hook,{once:true});
  setTimeout(hook,250);
  setTimeout(hook,900);
  console.log('ISOTOPE V94 ACTIVE: per-ability Signature 1/2/3 mastery restored and protected from late UI overwrites.');
})();
