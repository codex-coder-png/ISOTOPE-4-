/* ISOTOPE V63 — NITROGLYCERIN A1 BURN CONTRACT
   Nitroglycerin Ability 1 explicitly produces a combustion projectile and applies
   burn on contact. The hit flag is also checked by the authoritative hit hook so
   burn cannot be lost when another ability/status layer rewrites projectile data.
*/
(function(){
  'use strict';
  if(window.__ISO_V63_NITRO_BURN_FIX__) return;
  window.__ISO_V63_NITRO_BURN_FIX__=true;

  function getRun(){ return window.RUN||null; }
  function getStats(){ return window.ST||{}; }
  function findNitro(){
    try{
      var D=window.DATA;
      if(!D) return null;
      var pool=D.MOLDEF||{};
      var vals=Object.values(pool);
      for(var i=0;i<vals.length;i++){
        var m=vals[i];
        if(m && /nitroglycerin/i.test(String(m.name||m.token||''))) return m;
      }
    }catch(_){ }
    return null;
  }
  function hueOf(p){ return Number(p&&p.elem&&p.elem.hue)||12; }
  function burn(e,dmg){
    if(!e||e.dead) return;
    var d=Math.max(1,Number(dmg)||1);
    try{
      if(window.CORE&&typeof CORE.addBurn==='function') CORE.addBurn(e,d*.35,4,1);
      else if(typeof window.addBurn==='function') window.addBurn(e,d*.35,4,1);
      else {
        e.burn=e.burn||{dps:0,t:0,s:0};
        e.burn.dps=Math.max(Number(e.burn.dps)||0,d*.35);
        e.burn.t=Math.max(Number(e.burn.t)||0,4);
        e.burn.s=Math.min(5,(Number(e.burn.s)||0)+1);
      }
      e._isoV63NitroBurnT=4;
    }catch(err){ console.warn('V63 nitroglycerin burn',err); }
  }

  /* Authoritative hit hook: any V63 Nitro A1 projectile burns the enemy that it
     actually collides with. This is deliberately separate from generic cards. */
  try{
    var CORE=window.CORE;
    if(CORE&&CORE.getApplyElemHit&&CORE.setApplyElemHit){
      var oldHit=CORE.getApplyElemHit();
      if(typeof oldHit==='function'&&!oldHit.__isoV63NitroBurn){
        var wrapped=function(b,e){
          if(b&&b._isoV63NitroA1&&e&&!e.dead) burn(e,b.dmg);
          oldHit(b,e);
        };
        wrapped.__isoV63NitroBurn=true;
        CORE.setApplyElemHit(wrapped);
      }
    }
  }catch(err){ console.warn('V63 hit hook install',err); }

  /* Replace only Nitroglycerin Ability 1's executor; abilities 2/3 stay intact. */
  try{
    var nit=findNitro();
    if(nit){
      var list=nit.choices||nit.signatures||[];
      if(Array.isArray(list)&&list.length){
        var a1=list[0];
        var oldName=a1&&a1.name||'Nitroglycerin — Gentle Detonation';
        var oldCd=Number(a1&&a1.cd)||5.5;
        var replacement=Object.assign({},a1,{
          name:oldName, slot:0, main:true, cd:oldCd,
          desc:'Fires a fast explosive projectile that ignites enemies on direct impact.',
          exec:function(p){
            var R=getRun();
            if(!R||!p||p.downed||!Array.isArray(R.bullets)) return false;
            var S=getStats(), ang=Number(p.angle)||0;
            var speed=Math.max(780,(Number(S.ps)||380)*1.35);
            var dmg=Math.max(1,(Number(S.dmg)||14)*.78);
            var b={
              x:p.x+Math.cos(ang)*24,
              y:p.y+Math.sin(ang)*24,
              vx:Math.cos(ang)*speed,
              vy:Math.sin(ang)*speed,
              dmg:dmg,
              r:8,
              pierce:1,
              hit:[],
              life:1.7,
              owner:p.id,
              expl:true,
              _isoV63NitroA1:true,
              hue:12
            };
            R.bullets.push(b);
            try{ if(typeof window.ringFx==='function') window.ringFx(p.x,p.y,12,54); }catch(_){ }
            try{ if(typeof window.fxBurst==='function') window.fxBurst(b.x,b.y,12,18); }catch(_){ }
            return true;
          }
        });
        list[0]=replacement;
        nit.choices=list;
        nit.signatures=list;
        nit.act=list[0];
      }
    }
  }catch(err){ console.warn('V63 Nitro A1 install',err); }

  console.log('ISOTOPE V63 NITROGLYCERIN A1 BURN FIX active: direct impact always applies burn.');
})();
