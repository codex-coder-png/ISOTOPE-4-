/* ISOTOPE V40 — OPTIONAL FRESH-START RESET + STARTING RELIC + RARITY LADDER
 * V39's automatic wipe is removed. The reset happens only after the player
 * explicitly confirms YES in the startup decision gate.
 */
(function(){
  'use strict';
  if(!window.DATA || !window.SAVE) return;
  var DATA=window.DATA, SAVE=window.SAVE;

  /* ---------- disable the legacy V38 prompt without changing progression ---------- */
  try { SAVE.raw.v38RestartAccepted=true; SAVE.save(); } catch(e){}

  /* ---------- one-time migration into V40's prompt system ---------- */
  var INIT_KEY='isotope_v40_prompt_initialized';
  var INIT=false;
  try{ INIT=localStorage.getItem(INIT_KEY)==='1'; }catch(e){}
  if(!INIT){
    try{
      /* This only removes obsolete migration flags. It NEVER resets progression. */
      localStorage.removeItem('isotope_v39_full_progress_wipe_applied');
      localStorage.setItem(INIT_KEY,'1');
    }catch(e){}
    delete SAVE.raw.v40RestartAccepted;
    delete SAVE.raw.__v40FreshReset;
    delete SAVE.raw.__v40SelectedRelic;
    SAVE.save();
  }

  var PROMPT_KEY='v40RestartAccepted';
  var FRESH_KEY='__v40FreshReset';
  var RELIC_KEY='__v40SelectedRelic';
  var qs=[
    'Would you like to restart for the V40 update?',
    'ARE YOU SURE?',
    'ARE YOU SURE SURE?',
    'ARE YOU SURE SURE SURE?',
    'ARE YOU ABSOLUTELY SURE?'
  ];

  function esc(v){return String(v==null?'':v).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
  function relics(){
    var arr=Array.isArray(DATA.RELICS)?DATA.RELICS.filter(Boolean):[];
    var seen={};return arr.filter(function(r){
      if(!r||!r.id||seen[r.id])return false;seen[r.id]=1;return true;
    });
  }

  /* Keep normal preferences, but erase every known progression/buyable field. */
  function wipeProgressAndPrepare(){
    var S=SAVE.raw;
    S.coins=200;
    /* Hydrogen remains as the required base element; Carbon and Oxygen are
       unlocked as the two intended free starter elements. */
    S.sel='e6';
    S.sel2='e8';
    S.unlocked=['e1','e6','e8'];
    S.mols=[];
    S.favs=[];
    S.abil={};
    S.signatures={};
    S.mastery={};
    S.abilityMastery={};
    S.meta={};
    S.relicsFound=[];
    S.relicLoadout=[];
    S.plays={};
    S.achievements={};
    S.stats={runs:0,kills:0,bestWave:0,earned:0,mxp:0};
    S.synthesisLabUnlocked=false;
    delete S.__isoMxp15;
    delete S.__megaSig;
    delete S.__megaUnlock;
    delete S.v39FullWipeApplied;
    S[PROMPT_KEY]=true;
    S[FRESH_KEY]=true;
    delete S[RELIC_KEY];
    SAVE.save();
  }

  function finalizeFreshReset(){
    var S=SAVE.raw;
    if(S[FRESH_KEY]!==true)return false;
    var chosen=S[RELIC_KEY];
    var ok=chosen && relics().some(function(r){return r.id===chosen;});
    S.coins=200;
    S.unlocked=['e1','e6','e8'];
    S.sel='e6'; S.sel2='e8';
    S.mols=[]; S.favs=[]; S.abil={}; S.signatures={}; S.mastery={}; S.abilityMastery={}; S.meta={};
    S.relicsFound=ok?[chosen]:[];
    S.relicLoadout=ok?[chosen]:[];
    S.plays={}; S.achievements={}; S.stats={runs:0,kills:0,bestWave:0,earned:0,mxp:0};
    S.synthesisLabUnlocked=false;
    S[PROMPT_KEY]=true;
    delete S[FRESH_KEY];
    delete S[RELIC_KEY];
    SAVE.save();
    try{SAVE.refreshCoins();}catch(e){}
    return true;
  }

  /* Runs after legacy starter-relic seeding so a confirmed fresh save ends with
     exactly one chosen relic and nothing else. */
  if(finalizeFreshReset()){
    console.log('ISOTOPE V40: finalized confirmed fresh-start save with one chosen relic.');
  }

  function buildOverlay(){
    if(SAVE.raw[PROMPT_KEY]===true || document.getElementById('v40-start-prompt'))return;
    var ov=document.createElement('div');ov.id='v40-start-prompt';
    ov.style.cssText='position:fixed;inset:0;z-index:100000;background:rgba(2,6,12,.97);display:flex;align-items:center;justify-content:center;padding:24px;font-family:var(--mono,monospace);';
    var modal=document.createElement('div');
    modal.style.cssText='width:min(860px,94vw);max-height:90vh;overflow:auto;border:1px solid #4c84b9;background:linear-gradient(155deg,#0c1522,#080d15);box-shadow:0 0 45px rgba(20,110,210,.18);padding:30px;text-align:center;';
    var q=document.createElement('div');q.style.cssText='font-family:var(--disp,sans-serif);font-size:clamp(22px,3vw,34px);letter-spacing:.08em;color:#d9efff;margin-bottom:14px;';
    var sub=document.createElement('div');sub.style.cssText='font-size:13px;line-height:1.7;color:#9dacbe;max-width:720px;margin:0 auto 24px;';
    var row=document.createElement('div');row.style.cssText='display:flex;justify-content:center;gap:16px;';
    var yes=document.createElement('button'),no=document.createElement('button');
    [yes,no].forEach(function(b){b.style.cssText='min-width:150px;padding:13px 22px;border:1px solid #547da8;background:#101c2b;color:#dcecff;font-family:var(--mono);font-weight:700;cursor:pointer;';});
    yes.textContent='YES';no.textContent='NO';
    var count=0;
    function paint(){
      q.textContent=qs[Math.min(count,4)];
      if(count===0){
        sub.innerHTML='<b style="color:#f3d17a">This is optional.</b><br><br>Choosing YES wipes progression, buyables, mastery, compounds, favorites, achievements, augment levels, relics, and other unlocks, then starts the save with <b style="color:#7ef0a6">200 coins</b>. <b style="color:#8fdcff">Carbon and Oxygen are automatically unlocked.</b> You will then choose <b style="color:#ffd86b">exactly 1 relic</b> to start with.<br><br>Choosing NO keeps the current save and asks again the next time the game is opened.';
      }else{
        sub.textContent='Choosing NO keeps the current save. You will be asked again the next time the game is opened.';
      }
    }

    function showRelicChoice(){
      q.textContent='CHOOSE 1 STARTING RELIC';
      sub.innerHTML='Your restart is ready. Your old relics were wiped. Choose exactly <b style="color:#ffd86b">one</b> relic to keep as your only starting relic.';
      yes.remove(); no.remove();
      var grid=document.createElement('div');grid.style.cssText='display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:9px;text-align:left;';
      relics().forEach(function(r){
        var b=document.createElement('button');b.type='button';b.style.cssText='padding:12px;border:1px solid #31455c;background:#0d1724;color:#e9f5ff;text-align:left;cursor:pointer;min-height:82px;';
        b.innerHTML='<div style="font-weight:800;font-size:14px">'+esc(r.ic||'✦')+' '+esc(r.n||r.id)+'</div><div style="font-size:11px;color:#9dacbe;line-height:1.4;margin-top:5px">'+esc(r.d||'')+'</div>';
        b.onclick=function(){
          var id=r.id;
          SAVE.raw[RELIC_KEY]=id;
          SAVE.raw[PROMPT_KEY]=true;
          wipeProgressAndPrepare();
          SAVE.raw[RELIC_KEY]=id;
          SAVE.save();
          q.textContent='RESTART READY';
          sub.innerHTML='<b style="color:#7ef0a6">'+esc(r.n||id)+'</b> selected. The fresh save will start with 200 coins, Carbon + Oxygen unlocked, and this one relic.';
          grid.remove();
          ov.remove();
          try{SAVE.refreshCoins();}catch(e){}
          location.reload();
        };
        grid.appendChild(b);
      });
      modal.appendChild(grid);
    }

    yes.onclick=function(){ showRelicChoice(); };
    no.onclick=function(){ count++; if(count>=5){ov.remove();return;} paint(); };
    row.appendChild(yes);row.appendChild(no);modal.appendChild(q);modal.appendChild(sub);modal.appendChild(row);ov.appendChild(modal);document.body.appendChild(ov);paint();
    document.addEventListener('keydown',function block(ev){var x=document.getElementById('v40-start-prompt');if(!x){document.removeEventListener('keydown',block,true);return;}ev.preventDefault();ev.stopImmediatePropagation();},true);
    document.addEventListener('click',function blockOutside(ev){var x=document.getElementById('v40-start-prompt');if(!x){document.removeEventListener('click',blockOutside,true);return;}if(!modal.contains(ev.target)){ev.preventDefault();ev.stopPropagation();}},true);
  }
  setTimeout(buildOverlay,260);

  /* ---------- strict, non-overlapping rarity power bands ---------- */
  var RANGES={
    common:[.020,.040],
    uncommon:[.050,.080],
    rare:[.090,.130],
    epic:[.140,.200],
    legendary:[.220,.320],
    mythic:[.350,.600]
  };
  var MULT={common:1,uncommon:1.18,rare:1.42,epic:1.80,legendary:2.30,mythic:3.10};
  function rarityClamp(){
    if(!Array.isArray(window.ALL_CARDS))return;
    ALL_CARDS.forEach(function(c){
      var r=c.rarity||'common', range=RANGES[r]; if(!range)return;
      if(typeof c.extraValue==='number'){
        c.extraValue=Math.max(range[0],Math.min(range[1],c.extraValue));
      }
      c.rarityPower= MULT[r];
      c.rarityPowerTier= r;
      if(r==='mythic'){c.mythic=true;c.runDefining=true;c.max=Math.min(2,Math.max(1,c.max||1));}
    });
  }
  function patchChoose(){
    if(window.__ISO_V40_RARITY_PATCHED__)return;
    if(typeof window.chooseCard==='function'){
      var raw=window.chooseCard;
      window.chooseCard=function(pid,key){return raw.apply(this,arguments);};
      window.__ISO_V40_RARITY_PATCHED__=true;
    }
    rarityClamp();
  }
  rarityClamp(); setTimeout(rarityClamp,100); setTimeout(rarityClamp,700);

  /* Update the on-screen changelog with the complete current history. */
  var HISTORY=[
    ['V19','Stability fixes, deploy relic refresh, direct pause settings, and a fixed-height scrolling update log.'],
    ['V21','Merged QOL, content, co-op, combat, vault, mastery, local multiplayer, relic-loadout, wave-control, and content-overhaul work.'],
    ['V22','Save import compatibility was repaired and old/new save formats were normalized.'],
    ['V23','Elemental reaction overhaul, guaranteed on-hit status cards, beams, proficiencies, reaction effects, and Nitroglycerin support.'],
    ['V24','Element Ability 2 implementations were bound to their intended descriptions and runtime behavior.'],
    ['V25','Nicotine M1 was separated from recruiting behavior so ordinary shots only weaken/slow instead of befriending enemies.'],
    ['V26','Nicotine Ability 1 introduced permanent player-team allies with isolated team behavior and pickup/XP support.'],
    ['V27','Nicotine ally/befriend collision handling was stabilized against duplicate conversions and frame-loop issues.'],
    ['V28','Receptor Charm was moved out of the normal bullet collision path to prevent the recurring freeze/crash route.'],
    ['V29','Nicotine became an authoritative isolated ally system; old ally loops were prevented from re-processing converted enemies.'],
    ['V30','Dedicated third abilities were installed for all 118 base elements with distinct element-specific effects and an audit system.'],
    ['V31','Nitroglycerin synthesis key and formula aliases were normalized for reliable Lab lookup.'],
    ['V32','Core bridge and Nicotine crash fixes restored safe communication between the reaction layers and the real game loop.'],
    ['V33','Ability feedback/display systems were added for names and descriptions; runtime hardening also closed the missing global A/clamp crash path used by late-loaded ability modules.'],
    ['V34','Nitroglycerin received the intended 78 HP / Combust 4 profile and corrected three-ability display data.'],
    ['V35','The large in-round equipped/ability information popup was removed; ability functionality and Vault descriptions stayed intact.'],
    ['V36','Nitroglycerin Ability 2/3 combustion behavior was implemented; Liquid Nitrogen and the 200-point Synthesis Lab unlock were added.'],
    ['V37','Liquid Nitrogen Ability 1 became the large-radius freeze field; projectiles became non-explosive four-shard contact shatters with freeze/slow.'],
    ['V38','Liquid Nitrogen visuals gained light-blue frozen targets, subtle jitter and blue freeze rings; favorites became selectable; nine augmentations were consolidated; Mastery refresh/Exp display was improved; the V38 startup decision prompt was introduced.'],
    ['V39','A full progression wipe was introduced in error as an automatic migration; V40 removes that automatic behavior.'],
    ['V40','Fresh-start reset is now optional and only happens after YES. A confirmed reset leaves 200 coins, Carbon + Oxygen unlocked, all other progression wiped, and exactly 1 player-chosen starting relic. Rarity power bands are now strictly separated so higher rarities cannot share the same value range as lower rarities.'],
    ['V41','Prism of Choice now makes premium rarities 1.3x easier to roll while keeping COMMON possible. Each level-up rolls one rarity and opens a full-screen scrolling picker containing every currently available card from that exact rarity.']
  ];
  function refreshLog(){
    var panel=document.getElementById('mega-update-panel');if(!panel||panel.dataset.v40History)return false;
    var head=panel.querySelector('.mega-update-head');
    panel.innerHTML='';
    if(head)panel.appendChild(head);
    var wrap=document.createElement('div');wrap.className='mega-update-scroll';
    HISTORY.forEach(function(h){var row=document.createElement('div');row.className='urow';row.innerHTML='<div class="uver">'+h[0]+'</div><div class="utxt">'+esc(h[1])+'</div>';wrap.appendChild(row);});
    panel.appendChild(wrap);panel.dataset.v40History='1';
    setTimeout(function(){panel.scrollTop=panel.scrollHeight;},0);
    return true;
  }
  setTimeout(refreshLog,500);setTimeout(refreshLog,1400);setTimeout(refreshLog,2500);
  console.log('ISOTOPE V40 OPTIONAL FRESH-START + STARTER RELIC + STRICT RARITY LADDER ACTIVE');
})();
