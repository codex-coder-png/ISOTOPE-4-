/* ISOTOPE V87 — NICOTINE BEFRIEND STABILITY
   Keeps the current V60 nicotine projectile as the only Ability 1 projectile
   route, blocks duplicate conversion calls, and drains stale legacy charm queues
   left behind by older nicotine patches.  No gameplay rollback is performed. */
(function(){
  'use strict';
  if(window.__ISO_V87_NICOTINE_BEFRIEND_STABILITY__)return;
  window.__ISO_V87_NICOTINE_BEFRIEND_STABILITY__=true;

  function run(){return window.RUN||null;}
  function isNico(p){
    var e=p&&p.elem,n=String(e&&e.name||e&&e.token||'').toLowerCase();
    return !!(e&&e.mol&&n==='nicotine');
  }
  function purgeLegacyQueues(r){
    if(!r)return;
    /* V60 owns the live Ability 1 projectile. These queues belong to superseded
       V28/V29/V50/V53/V84 implementations and must never be stepped alongside it. */
    if(Array.isArray(r._v29CharmShots))r._v29CharmShots.length=0;
    if(Array.isArray(r._v28CharmShots))r._v28CharmShots.length=0;
    if(Array.isArray(r._v84CharmShots))r._v84CharmShots.length=0;
    if(Array.isArray(r._isoV53NicoRounds))r._isoV53NicoRounds.length=0;
    /* Defensive cleanup for old normal-bullet nicotine charm objects. */
    if(Array.isArray(r.bullets)){
      r.bullets=r.bullets.filter(function(b){
        return !(b&&((b._v26NicoCharm)||(b._v27NicoCharm)||(b._v28Charm)||b.semanticType==='nicotine-recruiting-dart'));
      });
    }
    /* V60 only needs a single live recruiter. A second one could otherwise be
       left over by repeated input events before the cooldown gate catches up. */
    if(Array.isArray(r._isoV60NicoA1)&&r._isoV60NicoA1.length>1){
      r._isoV60NicoA1.splice(0,r._isoV60NicoA1.length-1);
    }
  }

  /* One synchronous gate around the final public ability entry point. This is
     intentionally tiny: it only suppresses duplicate same-event nicotine casts. */
  if(typeof window.useActive==='function'&&!window.useActive.__v87NicoUseGate){
    var oldUse=window.useActive;
    var use=function(p){
      if(isNico(p)){
        var now=performance.now();
        if(Number(p.__isoNicoUseGateUntil||0)>now)return false;
        p.__isoNicoUseGateUntil=now+90;
      }
      return oldUse.apply(this,arguments);
    };
    use.__v87NicoUseGate=true;
    window.useActive=use;
    try{if(window.ISO_V23_CORE&&ISO_V23_CORE.setUseActive)ISO_V23_CORE.setUseActive(use);}catch(_){ }
  }

  /* V50's shared converter is still called by the current V60 projectile.
     Make conversion itself idempotent even when an older queue/wrapper reaches
     the same target in the same frame. */
  try{
    var api=window.ISO_V50_NICO;
    if(api&&typeof api.befriend==='function'&&!api.befriend.__v87NicoOnce){
      var raw=api.befriend;
      var wrapped=function(e,ownerId,reason){
        if(!e)return false;
        var now=performance.now();
        if(Number(e.__isoNicoBefriendBusyUntil||0)>now)return false;
        if(e.dead||e.befriended||e.team==='player'||e._v29Converted||e._v84Converted||e._v60Converted)return false;
        e.__isoNicoBefriendBusyUntil=now+120;
        try{
          var out=raw.apply(this,arguments);
          if(out){
            e._v60Converted=true;
            e.__isoNicoBefriendBusyUntil=Number.POSITIVE_INFINITY;
          }else{
            e.__isoNicoBefriendBusyUntil=now+30;
          }
          return out;
        }catch(err){
          e.__isoNicoBefriendBusyUntil=0;
          throw err;
        }
      };
      wrapped.__v87NicoOnce=true;
      api.befriend=wrapped;
    }
  }catch(_){ }

  /* Outermost update guard: clear obsolete conversion queues before any nested
     legacy wrappers execute, then clear them again after the frame. */
  if(typeof window.update==='function'&&!window.update.__v87NicoUpdate){
    var oldUpdate=window.update;
    var upd=function(dt){
      var r=run();
      purgeLegacyQueues(r);
      var out=oldUpdate.apply(this,arguments);
      purgeLegacyQueues(run());
      return out;
    };
    upd.__v87NicoUpdate=true;
    window.update=upd;
    try{update=upd;}catch(_){ }
    try{if(window.ISO_V23_CORE&&ISO_V23_CORE.setUpdate)ISO_V23_CORE.setUpdate(upd);}catch(_){ }
  }

  console.log('ISO_V87_NICOTINE_BEFRIEND_STABILITY active: canonical V60 A1, duplicate conversion gate, legacy charm queue cleanup.');
})();
