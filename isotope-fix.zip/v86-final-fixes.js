/* ISOTOPE V86 — authoritative mastery UI, fixed signature cooldowns,
   recursion/ETYPES safety, stable player speed, Nicotine aura, and Vault input smoothing. */
(function(){
  'use strict';
  if(window.__ISO_V86_FINAL_FIXES__)return;
  window.__ISO_V86_FINAL_FIXES__=true;

  var CORE=window.ISO_V23_CORE||{};
  function run(){return window.RUN||null;}
  function localPlayer(){var r=run();return r&&r.players?((r.players[r.localNetId||0]||r.players[0])||null):null;}
  function arrHas(a,id){return Array.isArray(a)&&a.indexOf(id)>=0;}
  function elementFor(p){try{return (p&&p.elem)||(run()&&RUN.el)||null;}catch(_){return null;}}
  function canonical(id){try{return window.DATA&&DATA.canonicalId?DATA.canonicalId(id):id;}catch(_){return id;}}
  function owned(id){try{return !!(DATA&&DATA.isOwned&&DATA.isOwned(canonical(id)));}catch(_){return false;}}
  function saveSig(el){
    try{
      var slot=SAVE.getSignature?Number(SAVE.getSignature(el.id)):0;
      var list=el&&((el.choices||el.signatures)||[]);
      slot=Math.max(0,Math.min(Math.max(0,list.length-1),slot||0));
      return {slot:slot,choice:list[slot]||list[0]||null};
    }catch(_){return {slot:0,choice:null};}
  }
  function fixedCooldown(p){
    try{
      var el=elementFor(p)||{};
      var list=el.choices||el.signatures||[], sig=saveSig(el), choice=sig.choice||{};
      var cat=(DATA&&DATA.CATS&&DATA.CATS[el.cat])||{}, act=el.act||cat.act||{};
      var cd=Number(choice.cd||act.cd||7);
      if(!Number.isFinite(cd)||cd<=0)cd=7;
      var r=run()||{};
      if(arrHas(r.relics,'battery'))cd*=.7;
      var cards=window.ALL_CARDS||[], ab=r.ab||{};
      for(var i=0;i<cards.length;i++){
        var c=cards[i], lv=Number(ab[c&&c.id]||0);
        if(!lv||!c||c.extraSpecial!=='cooldown')continue;
        cd*=Math.max(.15,1-(Number(c.extraValue)||.25)*lv);
      }
      var up=window.SAVE&&SAVE.getSignatureUpgradeStats?SAVE.getSignatureUpgradeStats(el.id):null;
      if(up&&up.path==='cooldown'&&Number(up.rank)>0)cd*=Math.pow(.9,Number(up.rank));
      return Math.max(.1,cd);
    }catch(_){return Math.max(.1,Number(window.ST&&ST.activeCd)||7);}
  }

  /* ----------------------------------------------------------------------
     Runtime safety: close the recursive update loop created by old additive
     wrappers. A nested update is ignored; the current frame continues normally.
     ---------------------------------------------------------------------- */
  (function installUpdateGuard(){
    var get=CORE.getUpdate;
    if(typeof get!=='function')return;
    var base=get();
    if(typeof base!=='function'||base.__v86ReentryGuard)return;
    var busy=false;
    var wrapped=function(dt){
      if(busy)return;
      busy=true;
      try{return base.apply(this,arguments);}
      catch(err){
        try{console.error('ISOTOPE V86 update recovery',err);}catch(_){ }
        return;
      }finally{busy=false;}
    };
    wrapped.__v86ReentryGuard=true;
    try{CORE.setUpdate(wrapped);}catch(_){window.update=wrapped;}
    try{window.update=wrapped;}catch(_){ }
  })();

  /* Keep the late modules from ever seeing undefined ETYPES/W/H. */
  try{if(window.DATA&&DATA.ETYPES)window.ETYPES=DATA.ETYPES;}catch(_){ }
  try{window.W=window.innerWidth;window.H=window.innerHeight;}catch(_){ }
  window.addEventListener('resize',function(){try{window.W=window.innerWidth;window.H=window.innerHeight;}catch(_){ }},{passive:true});

  /* ----------------------------------------------------------------------
     Fixed active ability cooldown. The displayed value and the actual ability
     gate are both derived from the current Signature's base cooldown. No round
     or cast-count multiplier is allowed to compound it.
     ---------------------------------------------------------------------- */
  (function installCooldown(){
    var get=CORE.getComputeStats,set=CORE.setComputeStats;
    if(typeof get==='function'&&typeof set==='function'){
      var base=get();
      if(typeof base==='function'&&!base.__v86CooldownAuthoritative){
        var busy=false;
        var compute=function(){
          if(busy)return window.ST;
          busy=true;
          try{
            var out=base.apply(this,arguments),p=localPlayer(),cd=fixedCooldown(p);
            if(window.ST)ST.activeCd=cd;
            if(p){p.__isoFixedActiveCd=cd;p.__isoCooldownBase=cd;}
            return out;
          }finally{busy=false;}
        };
        compute.__v86CooldownAuthoritative=true;
        set(compute);
      }
    }

    var gu=CORE.getUseActive, su=CORE.setUseActive;
    if(typeof gu==='function'&&typeof su==='function'){
      var raw=gu();
      if(typeof raw==='function'&&!raw.__v86CooldownAuthoritative){
        var useBusy=false;
        var use=function(p){
          if(!p)return raw.apply(this,arguments);
          if(Number(p.activeCd||0)>0)return false;
          if(useBusy)return false;
          useBusy=true;
          try{
            var cd=fixedCooldown(p);
            p.__isoFixedActiveCd=cd;
            if(window.ST)ST.activeCd=cd;
            var before=Number(p.activeCd)||0;
            var out=raw.apply(this,arguments);
            var fired=(out!==false)&&(Number(p.activeCd||0)>0 || Number(p.activeCd||0)!==before);
            if(fired||out!==false){
              p.activeCd=cd;
              p.__isoFixedActiveCd=cd;
              if(window.ST)ST.activeCd=cd;
            }
            return out;
          }finally{useBusy=false;}
        };
        use.__v86CooldownAuthoritative=true;
        su(use);window.useActive=use;
      }
    }
  })();

  /* ----------------------------------------------------------------------
     Remove the accidental Phase Battery dash damage/ring effect while giving
     the relic a harmless utility bonus through the existing dash cooldown.
     ---------------------------------------------------------------------- */
  (function(){
    try{
      var txt=document.documentElement.className; /* keeps this IIFE intentionally tiny */
      if(window.RUN&&RUN.__v83)delete RUN.__v83.lastDashPos;
    }catch(_){ }
  })();

  /* ----------------------------------------------------------------------
     Authoritative Element Mastery. It is deliberately rebuilt only when the
     menu opens or the user changes the visible element; it never polls.
     ---------------------------------------------------------------------- */
  var masteryOpen=false, masteryView=null, pendingPath=null;
  var PATHS={
    damage:{label:'DAMAGE',desc:'+12% SIGNATURE DAMAGE / RANK',icon:'⚔'},
    range:{label:'RANGE',desc:'+18% SIGNATURE RANGE / RANK',icon:'⌁'},
    cooldown:{label:'COOLDOWN',desc:'-10% SIGNATURE COOLDOWN / RANK',icon:'⟳'}
  };
  var COSTS=[100,180,300];

  function masteryEl(){
    var id=canonical(masteryView||((run()&&RUN.el&&RUN.el.id)||SAVE.sel));
    if(owned(id)&&DATA&&DATA.EL)return DATA.EL(id);
    var fallback=canonical(SAVE.sel);
    return DATA&&DATA.EL?DATA.EL(fallback):null;
  }
  function masteryState(id){
    try{return SAVE.getSignatureUpgrade?SAVE.getSignatureUpgrade(id):{path:null,rank:0};}
    catch(_){return {path:null,rank:0};}
  }
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]);});}
  function toast(msg,kind){
    try{
      var host=document.getElementById('toasts');if(!host)return;
      var t=document.createElement('div');t.className='toast '+(kind||'');t.textContent=msg;host.appendChild(t);
      setTimeout(function(){t.style.opacity='0';t.style.transition='opacity .35s';setTimeout(function(){t.remove();},400);},1900);
    }catch(_){ }
  }
  function masteryCSS(){
    if(document.getElementById('v86-mastery-style'))return;
    var s=document.createElement('style');s.id='v86-mastery-style';s.textContent='\
#scr-mastery #m-detail{min-width:0}\
.v86-sig-wrap{margin-top:10px;padding:14px;border:1px solid #28445e;background:rgba(8,18,32,.72)}\
.v86-sig-title{font-family:var(--disp,Arial);font-size:20px;letter-spacing:.08em;color:#66ecff;margin-bottom:6px}\
.v86-sig-sub{font-size:12px;color:var(--tx2,#9ab0c7);margin-bottom:9px}\
.v86-sig-equipped{padding:9px;border:1px solid #28445e;background:rgba(12,24,40,.7);margin-bottom:10px}\
.v86-sig-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}\
.v86-sig-path{min-height:118px;text-align:left;display:flex;gap:9px;align-items:flex-start;padding:11px;border:1px solid #28445e;background:#0a1422;color:#d8e7f5;cursor:pointer}\
.v86-sig-path:hover{border-color:#66ecff}\
.v86-sig-path.chosen{border-color:#66f0a0;box-shadow:0 0 0 1px rgba(102,240,160,.14) inset}\
.v86-sig-path.disabled{opacity:.38;cursor:not-allowed}\
.v86-sig-path .ico{font-size:22px}.v86-sig-path b{display:block;letter-spacing:.08em}.v86-sig-path small{display:block;color:#91a7bd;margin-top:4px;line-height:1.3}.v86-sig-pips{display:flex;gap:4px;margin-top:9px}.v86-sig-pips i{display:block;width:25px;height:6px;border:1px solid #28445e}.v86-sig-pips i.on{background:#66f0a0;box-shadow:0 0 7px rgba(102,240,160,.45)}\
.v86-sig-action{margin-top:6px;font-size:10px;color:#b8cbe0;text-transform:uppercase;letter-spacing:.08em}.v86-sig-up{display:flex;justify-content:space-between;gap:12px;align-items:center;margin-top:10px;padding:10px;border-top:1px solid #28445e}\
@media(max-width:800px){.v86-sig-grid{grid-template-columns:1fr}.v86-sig-path{min-height:0}}';document.head.appendChild(s);
  }
  function rebuildElementChips(el){
    var box=document.getElementById('m-elems');if(!box||!DATA||!DATA.ELEMS)return;
    box.innerHTML='';
    Object.values(DATA.ELEMS).filter(function(e){return owned(e.id);}).forEach(function(e){
      var b=document.createElement('button');b.type='button';b.className='mchip'+(canonical(e.id)===canonical(el.id)?' sel':'');b.dataset.id=e.id;
      var col='hsl('+(Number(e.hue)||190)+' 72% 62%)';b.style.borderColor=col;b.style.color=col;b.innerHTML='<span style="font-weight:bold">'+esc(e.sym||'')+'</span><span style="font-size:9px">'+String(SAVE.mxp(e.id).xp||0)+'</span>';
      b.onclick=function(ev){ev.preventDefault();ev.stopPropagation();var id=canonical(e.id);if(!owned(id))return;masteryView=id;pendingPath=null;try{SFX.click();}catch(_){ }renderMastery(id);};
      box.appendChild(b);
    });
  }
  function buildPathCard(k,st,el){
    var p=PATHS[k], chosen=st.path===k, disabled=!!st.path&&!chosen;
    var pending=pendingPath&&pendingPath.id===el.id&&pendingPath.path===k;
    var btn=document.createElement('button');btn.type='button';btn.className='v86-sig-path'+(chosen?' chosen':'')+(disabled?' disabled':'');btn.disabled=disabled;
    var pip='';for(var i=0;i<3;i++)pip+='<i class="'+(chosen&&i<st.rank?'on':'')+'"></i>';
    btn.innerHTML='<span class="ico">'+p.icon+'</span><span><b>'+p.label+'</b><small>'+p.desc+'</small><span class="v86-sig-pips">'+pip+'</span><span class="v86-sig-action">'+(chosen?'PATH LOCKED':pending?'ARE YOU SURE? CLICK AGAIN':'CHOOSE '+p.label)+'</span></span>';
    btn.onclick=function(){
      if(st.path)return;
      if(!(pendingPath&&pendingPath.id===el.id&&pendingPath.path===k)){
        pendingPath={id:el.id,path:k};try{SFX.click();}catch(_){ }renderMastery(el.id);return;
      }
      if(SAVE.chooseSignatureUpgradePath&&SAVE.chooseSignatureUpgradePath(el.id,k)){
        pendingPath=null;try{SFX.unlock();}catch(_){ }renderMastery(el.id);toast('SIGNATURE '+p.label+' PATH LOCKED IN','good');
      }else{try{SFX.error();}catch(_){ }}
    };
    return btn;
  }
  function renderMastery(id){
    var scr=document.getElementById('scr-mastery');if(!scr||scr.classList.contains('hidden'))return;
    if(id)masteryView=canonical(id);
    var el=masteryEl();if(!el)return;
    masteryView=canonical(el.id);
    masteryCSS();
    var detail=document.getElementById('m-detail');if(!detail)return;
    var state=masteryState(el.id),sig=saveSig(el),mx=SAVE.mxp(el.id),col='hsl('+(Number(el.hue)||190)+' 80% 68%)';
    /* Replace the entire detail area so no legacy nodes, hidden loadouts, or
       generic five-rank ability cards can survive the old render pipeline. */
    detail.innerHTML='';
    var head=document.createElement('div');head.id='m-head';detail.appendChild(head);
    var tree=document.createElement('div');tree.id='m-tree';detail.appendChild(tree);
    head.innerHTML='<div style="font-family:var(--disp,Arial);font-size:24px;color:'+col+'">'+esc(el.name||el.sym||el.id).toUpperCase()+'</div><div class="sub">Mastery XP available: <b style="color:var(--gr,#66f0a0)">◆ '+String(mx.xp||0)+'</b> · earn more by fighting as '+esc(el.name||el.sym||el.id)+'.</div>';
    if(sig.choice){
      var eq=document.createElement('div');eq.className='panel2';eq.style.marginTop='10px';eq.style.borderColor=col+'88';eq.innerHTML='<div class="tag" style="color:'+col+'">EQUIPPED SIGNATURE '+(sig.slot+1)+'</div><b style="display:block;margin-top:5px;color:'+col+'">'+esc(sig.choice.ic||'✦')+' '+esc(sig.choice.name||('SIGNATURE '+(sig.slot+1)))+'</b><div class="sub" style="margin-top:4px">'+esc(sig.choice.desc||'')+'</div>';head.appendChild(eq);
    }
    var wrap=document.createElement('div');wrap.className='v86-sig-wrap';
    wrap.innerHTML='<div class="v86-sig-title">✦ SIGNATURE MASTERY</div><div class="v86-sig-sub">Choose ONE upgrade path for '+esc(el.name||'this element')+' Signature '+(sig.slot+1)+'. The path is permanent for this element and can be upgraded only 3 times.</div><div class="v86-sig-equipped">Current path: <b>'+esc(state.path?PATHS[state.path].label:'NOT CHOSEN')+'</b> · Rank <b>'+Number(state.rank||0)+'/3</b></div>';
    var grid=document.createElement('div');grid.className='v86-sig-grid';['damage','range','cooldown'].forEach(function(k){grid.appendChild(buildPathCard(k,state,el));});wrap.appendChild(grid);
    if(state.path){
      var up=document.createElement('div');up.className='v86-sig-up';
      var rank=Number(state.rank)||0,cost=rank<3?COSTS[rank]:0,ok=rank<3&&(Number(mx.xp)||0)>=cost;
      up.innerHTML='<div><b>'+PATHS[state.path].label+' PATH · '+rank+'/3</b><div class="sub">'+(rank>=3?'MAXED — this element cannot switch paths.':'Next: '+esc(PATHS[state.path].desc)+' · costs ◆ '+cost+' mastery XP')+'</div></div>';
      var b=document.createElement('button');b.type='button';b.className='btn primary';b.disabled=!ok;b.textContent=rank>=3?'MAX':'UPGRADE · ◆ '+cost;b.onclick=function(){if(rank>=3)return;if(SAVE.buySignatureUpgrade&&SAVE.buySignatureUpgrade(el.id)){pendingPath=null;try{SFX.unlock();}catch(_){ }renderMastery(el.id);toast(PATHS[state.path].label+' SIGNATURE UPGRADE '+(rank+1)+'/3 PURCHASED','good');}else{try{SFX.error();}catch(_){ }}};up.appendChild(b);wrap.appendChild(up);
    }
    tree.appendChild(wrap);
    rebuildElementChips(el);
  }

  (function hookMasteryUI(){
    masteryCSS();
    if(!window.UI||typeof UI.show!=='function'||UI.show.__v86Mastery)return;
    var base=UI.show;
    UI.show=function(id){
      var entering=id==='scr-mastery'&&!masteryOpen;
      if(entering){
        var equip=canonical(SAVE.sel);masteryView=owned(equip)?equip:null;pendingPath=null;masteryOpen=true;
      }
      var out=base.apply(this,arguments);
      if(id==='scr-mastery'){
        /* The legacy layers have delayed refreshes of their own. Render twice on
           this one menu entry so our authoritative panel wins without polling. */
        requestAnimationFrame(function(){renderMastery(masteryView);});
        setTimeout(function(){if(masteryOpen)renderMastery(masteryView);},40);
      }else if(id==='scr-menu'){
        masteryOpen=false;
        pendingPath=null;
      }
      return out;
    };
    UI.show.__v86Mastery=true;
  })();
  document.addEventListener('click',function(ev){
    var chip=ev.target&&ev.target.closest?ev.target.closest('#scr-mastery #m-elems .mchip[data-id]'):null;
    if(!chip||!masteryOpen)return;
    var id=canonical(chip.dataset.id);if(!owned(id))return;
    ev.preventDefault();ev.stopImmediatePropagation();
    masteryView=id;pendingPath=null;try{SFX.click();}catch(_){ }
    renderMastery(id);
  },true);
  window.ISO_V86_RENDER_MASTERY=function(id){if(id)masteryView=canonical(id);renderMastery(masteryView);};

  /* ----------------------------------------------------------------------
     Disable V79/V85 ownership of the mastery UI so only this layer controls it.
     ---------------------------------------------------------------------- */
  window.__ISO_MASTERY_VIEW_ID=masteryView;

  /* Final cooldown HUD correction: the core HUD reads this field, so it always
     shows the exact current Signature cooldown instead of a round-scaled value. */
  try{
    if(window.ISO_V23_CORE&&typeof ISO_V23_CORE.getComputeStats==='function'){
      var g=ISO_V23_CORE.getComputeStats(),old=g;
      if(typeof old==='function'&&!old.__v86HudCooldown){
        var h=function(){var out=old.apply(this,arguments),p=localPlayer(),cd=fixedCooldown(p);if(window.ST)ST.activeCd=cd;if(p)p.__isoFixedActiveCd=cd;return out;};h.__v86HudCooldown=true;ISO_V23_CORE.setComputeStats(h);
      }
    }
  }catch(_){ }

  console.log('ISOTOPE V86 FINAL: fixed cooldowns, authoritative Signature Mastery, runtime safety, no ChromeOS throttling.');
})();
