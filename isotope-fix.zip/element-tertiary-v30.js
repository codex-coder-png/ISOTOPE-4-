/* ============================================================================
 * ISOTOPE V30 - 118 BASE ELEMENT ABILITY 3 CONTRACTS
 *
 * This layer owns ONLY elemental Ability 3 (slot index 2). It preserves the
 * current displayed name/description and replaces the old generic executor
 * with a dedicated, description-matched runtime for each of the 118 elements.
 * It is loaded last so it cannot be overwritten by older ability routers.
 * ========================================================================== */
'use strict';
(function(){
  if(window.__ISO_ELEMENT_TERTIARY_V30__) return;
  window.__ISO_ELEMENT_TERTIARY_V30__=true;

  var TAU=Math.PI*2;
  function R(){return window.RUN||null;}
  function S(){return window.ST||{};}
  function d2(ax,ay,bx,by){var dx=ax-bx,dy=ay-by;return dx*dx+dy*dy;}
  function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
  function hue(n){
    try{var e=DATA&&DATA.ELEMS&&DATA.ELEMS['e'+n];if(e&&Number.isFinite(+e.hue))return +e.hue;}catch(_e){}
    return (n*29)%360;
  }
  function alive(){
    var r=R();
    if(!r||!Array.isArray(r.enemies))return [];
    return r.enemies.filter(function(e){return e&&!e.dead&&!e.ally&&!e.befriended;});
  }
  function target(p){
    var mx=(typeof mouse!=='undefined'&&mouse&&Number.isFinite(mouse.x))?mouse.x:p.x+Math.cos(p.angle||0)*260;
    var my=(typeof mouse!=='undefined'&&mouse&&Number.isFinite(mouse.y))?mouse.y:p.y+Math.sin(p.angle||0)*260;
    return {x:clamp(mx,26,(window.W||1200)-26),y:clamp(my,26,(window.H||800)-26)};
  }
  function dmg(p,m){
    /* ST.dmg already contains permanent damage upgrades; puDamage carries the
       current temporary in-run damage-up percentage and therefore belongs in
       special-ability damage as well. */
    return (Number(S().dmg)||14)*(Number(p&&p.puDamage)||1)*(Number(m)||1);
  }
  function ring(x,y,h,r){if(typeof ringFx==='function')ringFx(x,y,h,r||90);}
  function burst(x,y,h,n){
    var r=R();if(!r||!Array.isArray(r.parts))return;
    n=n||14;
    for(var i=0;i<n;i++){
      var a=Math.random()*TAU,s=70+Math.random()*260;
      r.parts.push({x:x,y:y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,t:.45,life:.45,hue:h,r:1.5+Math.random()*3.5});
    }
  }
  function hit(e,p,m){
    if(!e||e.dead)return;
    if(typeof dmgEnemy==='function')dmgEnemy(e,dmg(p,m),{quiet:true});
  }
  function status(e,k,t,a){
    if(!e||e.dead)return;
    try{
      if(k==='burn'&&typeof addBurn==='function')addBurn(e,a||dmg({puDamage:1},.3),t||4);
      else if(k==='poison'&&typeof addPoison==='function')addPoison(e,a||dmg({puDamage:1},.35),t||4);
      else if(k==='corrode'&&typeof addCorrode==='function')addCorrode(e,t||4,.55);
      else if(k==='rust'&&typeof addRust==='function')addRust(e,t||4,.86);
      else if(k==='freeze'&&typeof addFreeze==='function')addFreeze(e,t||1.6);
      else if(k==='shock'&&typeof addShock==='function')addShock(e,t||1.5);
      else if(k==='brittle'&&typeof addBrittle==='function')addBrittle(e,t||4);
      else if(k==='drenched'&&typeof addDrenched==='function')addDrenched(e,t||4);
      else if(k==='slow')e.slowT=Math.max(e.slowT||0,t||3);
      else if(k==='stun')e.stun=Math.max(e.stun||0,t||1.2);
      else if(k==='confuse'){e.conf=Math.max(e.conf||0,t||2.5);e.v30ConfuseT=Math.max(e.v30ConfuseT||0,t||2.5);}
      else if(k==='silence'){e.v30SilenceT=Math.max(e.v30SilenceT||0,t||3);e.specialT=Math.max(e.specialT||0,t||3);e.shootT=Math.max(e.shootT||0,t||3);}
      else if(k==='weaken'){e.v30WeakenT=Math.max(e.v30WeakenT||0,t||4);e.v30WeakenMul=0.75;}
      else if(k==='radiation'){e.v30RadiationT=Math.max(e.v30RadiationT||0,t||5);if(typeof addPoison==='function')addPoison(e,a||dmg({puDamage:1},.28),t||5);}
      else if(k==='mark')e.mark=Math.max(e.mark||0,t||6);
    }catch(_e){}
  }
  function pointAOE(p,x,y,r,m,k){
    var h=hue(p.elem&&p.elem.n||0),es=alive();
    for(var i=0;i<es.length;i++){
      var e=es[i];if(d2(x,y,e.x,e.y)<(r+e.r)*(r+e.r)){if(m)hit(e,p,m);if(k)status(e,k,5,dmg(p,m*.25));}
    }
    ring(x,y,h,r);burst(x,y,h,Math.min(28,8+Math.floor(r/18)));
  }
  function lineHit(p,len,width,m,k){
    var a=p.angle||0,cx=p.x,cy=p.y,co=Math.cos(a),si=Math.sin(a),es=alive();
    for(var i=0;i<es.length;i++){
      var e=es[i],dx=e.x-cx,dy=e.y-cy,t=dx*co+dy*si;
      if(t<0||t>len)continue;
      var px=cx+co*t,py=cy+si*t;
      if(d2(e.x,e.y,px,py)<(width+e.r)*(width+e.r)){if(m)hit(e,p,m);if(k)status(e,k,5,dmg(p,m*.2));}
    }
    ring(cx+co*len*.5,cy+si*len*.5,hue(p.elem&&p.elem.n||0),width*2.5);
  }
  function fire(p,a,s,m,o){
    var r=R();if(!r||!Array.isArray(r.bullets))return null;o=o||{};
    var b={x:p.x,y:p.y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,dmg:dmg(p,m),r:o.r||5,pierce:o.pierce||0,hit:[],life:o.life||1.6,owner:p.id};
    ['hom','expl','burn','poison','corrode','rust','shock','freeze','brittle','drenched','mark','pull','kb','fission','main'].forEach(function(k){if(o[k]!=null)b[k]=o[k];});
    r.bullets.push(b);return b;
  }
  function fan(p,n,spread,s,m,o){for(var i=0;i<n;i++)fire(p,(p.angle||0)+(n===1?0:(i/(n-1)-.5)*spread),s,m,o||{});}
  function clearHostileShots(x,y,r){
    var rr=R(),cut=r*r,count=0;if(!rr||!Array.isArray(rr.ebullets))return 0;
    rr.ebullets=rr.ebullets.filter(function(b){if(d2(b.x,b.y,x,y)<=cut){count++;return false;}return true;});return count;
  }
  function playerShield(p,amt,ifr){
    p.sh=Math.min((S().shieldMax||90)+amt,(p.sh||0)+amt);if(ifr)p.iframes=Math.max(p.iframes||0,ifr);
    ring(p.x,p.y,hue(p.elem&&p.elem.n||0),95);burst(p.x,p.y,hue(p.elem&&p.elem.n||0),18);
  }
  function playerBuff(p,field,value,time){
    if(field==='rate')p.puRate=Math.max(p.puRate||1,value);
    if(field==='damage')p.puDamage=Math.max(p.puDamage||1,value);
    if(field==='crit')p.puCrit=1;
    if(field==='speed')p.v30SpeedT=Math.max(p.v30SpeedT||0,time||5);
    if(field==='armor')p.puArmor=Math.max(p.puArmor||0,value);
    p.puTimer=Math.max(p.puTimer||0,time||5);
    ring(p.x,p.y,hue(p.elem&&p.elem.n||0),105);burst(p.x,p.y,hue(p.elem&&p.elem.n||0),20);
  }
  function delay(p,ms,fn){
    var r=R(),token=r&&r.__isoT3Token;if(!r)return;
    setTimeout(function(){if(window.RUN!==r||r.__isoT3Token!==token)return;try{fn();}catch(e){console.error('T3 delayed action',e);}},ms);
  }
  function addZone(p,z){
    var r=R();if(!r)return;r.isoT3=r.isoT3||{zones:[],beams:[],fuses:[],orbits:[],walls:[]};
    z.owner=p.id;z.h=z.h==null?hue(p.elem&&p.elem.n||0):z.h;r.isoT3.zones.push(z);ring(z.x,z.y,z.h,z.r||100);
  }
  function enemyKnock(e,ox,oy,amount){
    if(e.boss)return;var a=Math.atan2(e.y-oy,e.x-ox);e.x+=Math.cos(a)*amount;e.y+=Math.sin(a)*amount;
  }
  function globalStatus(k,t,p,m){alive().forEach(function(e){status(e,k,t,dmg(p,m||.2));});}
  function standardKill(e,p,m){
    if(!e||e.dead)return;
    if(e.boss)hit(e,p,m);else hit(e,p,Math.max(m,5));
  }

  function executeThird(n,p){
    var r=R(),t=target(p),h=hue(p.elem&&p.elem.n||n);if(!r)return;
    r.isoT3=r.isoT3||{zones:[],beams:[],fuses:[],orbits:[],walls:[]};
    switch(n){
      case 1: { // Hydro-Magnetic Singularity
        addZone(p,{type:'vortex',x:t.x,y:t.y,r:190,t:2.8,pull:155,dps:dmg(p,0.28)});
        r.isoT3.fuses.push({x:t.x,y:t.y,t:2.8,life:2.8,r:220,dmg:dmg(p,4.2),status:'shock',h:h});
        break;
      }
      case 2: { // Cryogenic Superfluid
        addZone(p,{type:'cryo',x:t.x,y:t.y,r:320,t:6,slow:.28,nullify:true,dps:dmg(p,.16),status:'freeze'});
        break;
      }
      case 3: { // Carmine Flame Wave
        lineHit(p,520,42,3.3,'burn');
        alive().forEach(function(e){if(d2(e.x,e.y,p.x,p.y)<540*540){status(e,'corrode',4);}});
        break;
      }
      case 4: { // Emerald Shard Fan
        fan(p,13,.9,720,2.8,{pierce:5,r:7,life:1.7});break;
      }
      case 5: { // Boride Drill Spike
        fire(p,p.angle||0,900,5.2,{pierce:999,r:10,life:1.8,kb:1.2});lineHit(p,760,12,1.2,null);break;
      }
      case 6: { // Diamond Edge Cleave
        var e6=alive();for(var i6=0;i6<e6.length;i6++){var q6=e6[i6],dx6=q6.x-p.x,dy6=q6.y-p.y,a6=Math.atan2(dy6,dx6),da6=Math.atan2(Math.sin(a6-(p.angle||0)),Math.cos(a6-(p.angle||0)));if(Math.abs(da6)<.65&&dx6*dx6+dy6*dy6<260*260){hit(q6,p,5.8);q6.v30DiamondCritT=4;}}
        ring(p.x,p.y,h,190);break;
      }
      case 7: { // Atmospheric Blast
        pointAOE(p,p.x,p.y,360,2.6,'shock');clearHostileShots(p.x,p.y,390);alive().forEach(function(e){if(d2(e.x,e.y,p.x,p.y)<390*390)enemyKnock(e,p.x,p.y,90);});break;
      }
      case 8: { // Hyperoxic Overdrive
        playerBuff(p,'rate',2.05,5);playerBuff(p,'crit',1,5);playerBuff(p,'damage',Math.max(p.puDamage||1,1.12),5);p.v30GuaranteedCritT=5;ring(p.x,p.y,h,130);break;
      }
      case 9: { // Teflon Nonstick Barrier
        playerShield(p,55,5);p.v30StatusImmuneT=5;p.v30DamageImmuneT=1.2;p.iframes=Math.max(p.iframes||0,1.2);break;
      }
      case 10: { // Noble Neon Beam
        r.isoT3.beams.push({x:p.x,y:p.y,angle:p.angle||0,len:1000,w:18,t:4.8,dmg:dmg(p,.75),status:'burn',h:h,owner:p.id});break;
      }
      case 11: { // Vapor Flame Nova
        pointAOE(p,p.x,p.y,300,2.2,'stun');alive().forEach(function(e){if(d2(e.x,e.y,p.x,p.y)<300*300){status(e,'stun',2);e.v30BlindT=2;enemyKnock(e,p.x,p.y,75);}});break;
      }
      case 12: { // Magnesia Shield Wall
        playerShield(p,48,1);r.isoT3.walls.push({x:p.x+Math.cos(p.angle)*115,y:p.y+Math.sin(p.angle)*115,angle:(p.angle||0)+Math.PI/2,len:320,t:7,h:h,shield:80});addZone(p,{type:'heat',x:p.x,y:p.y,r:190,t:5,dps:dmg(p,.12),status:'burn'});break;
      }
      case 13: { // Alumino-Thermic Blast
        pointAOE(p,t.x,t.y,250,4.2,'burn');alive().forEach(function(e){if(d2(e.x,e.y,t.x,t.y)<250*250){status(e,'rust',7);e.v30ArmorShredT=7;e.v30ArmorShred=.65;}});break;
      }
      case 14: { // Silicate Mirror Array
        playerShield(p,35,0);p.v30MirrorT=7;p.v30MirrorAmp=1.45;clearHostileShots(p.x,p.y,170);ring(p.x,p.y,h,160);break;
      }
      case 15: { // Pyrotechnic Volley
        for(var i15=0;i15<7;i15++){(function(k){delay(p,k*150,function(){var a=(p.angle||0)+(k-3)*.14;var b=fire(p,a,560,1.65,{burn:true,expl:true,r:7,life:1.4});if(b)ring(b.x,b.y,h,28);});})(i15);}break;
      }
      case 16: { // Vulcanized Carapace
        playerShield(p,42,0);p.v30StatusImmuneT=6;p.v30KnockImmuneT=6;p.puTimer=Math.max(p.puTimer||0,6);p.puArmor=Math.max(p.puArmor||0,.7);break;
      }
      case 17: { // Chloric Shock Dart
        fan(p,5,.35,900,2.2,{pierce:2,life:1.4,poison:true,shock:true});addZone(p,{type:'toxicgas',x:t.x,y:t.y,r:110,t:5,dps:dmg(p,.25),status:'poison'});break;
      }
      case 18: { // Absolute Inertia Field
        addZone(p,{type:'stasis',x:p.x,y:p.y,r:360,t:3,dps:dmg(p,.3),status:'freeze',freezeShots:true});break;
      }
      case 19: { // Violet Combustion Nova
        pointAOE(p,p.x,p.y,315,3.8,'burn');for(var i19=0;i19<4;i19++){(function(k){delay(p,180+k*170,function(){pointAOE(p,p.x+Math.cos((p.angle||0)+k*TAU/4)*120,p.y+Math.sin((p.angle||0)+k*TAU/4)*120,120,1.1,'shock');});})(i19);}break;
      }
      case 20: { // Calcite Spike Wave
        for(var i20=0;i20<10;i20++){(function(k){delay(p,k*75,function(){var x20=p.x+Math.cos(p.angle)*((k+1)*60),y20=p.y+Math.sin(p.angle)*((k+1)*60);pointAOE(p,x20,y20,34,1.9,'brittle');alive().forEach(function(e){if(d2(e.x,e.y,x20,y20)<34*34)enemyKnock(e,x20,y20,70);});});})(i20);}break;
      }
      case 21: { // Structural Fortification
        playerShield(p,30,6);p.v30DamageImmuneT=0.35;p.v30DeflectT=6;p.puArmor=Math.max(p.puArmor||0,.78);break;
      }
      case 22: { // Titanium Dreadnought Charge
        var ox22=p.x,oy22=p.y;p.x=clamp(p.x+Math.cos(p.angle)*360,28,(window.W||1200)-28);p.y=clamp(p.y+Math.sin(p.angle)*360,28,(window.H||800)-28);lineHit({x:ox22,y:oy22,angle:p.angle},360,42,3.2,'shock');clearHostileShots(p.x,p.y,120);p.iframes=Math.max(p.iframes||0,1.4);break;
      }
      case 23: { // Vanadium Steel Cleave
        lineHit(p,330,65,5.5,'burn');playerBuff(p,'crit',1,3);p.v30CritDamageT=1.7;break;
      }
      case 24: { // Stainless Chrome Aegis
        playerShield(p,95,1.4);p.v30ConvertDamageT=6;p.v30AttackFromShield=0;break;
      }
      case 25: { // Catalytic Hyper-Nova
        var e25=alive();for(var i25=0;i25<e25.length;i25++){var q25=e25[i25],had=!!(q25.burn||q25.poison||q25.corrode||q25.rust||q25.freeze||q25.stun||q25.mark);if(had){hit(q25,p,3.2);pointAOE(p,q25.x,q25.y,105,1.7,'shock');}}break;
      }
      case 26: { // Magnetic Singularity Core
        addZone(p,{type:'magnet',x:t.x,y:t.y,r:180,t:3.4,pull:210,dps:dmg(p,.22),status:'rust'});r.isoT3.fuses.push({x:t.x,y:t.y,t:3.4,life:3.4,r:165,dmg:dmg(p,3.8),status:'shock',h:h});break;
      }
      case 27: { // Magnetic Super-Alloy Field
        addZone(p,{type:'reverse',x:p.x,y:p.y,r:270,t:4,dps:0,reverseShots:true});break;
      }
      case 28: { // Electromagnetic Repulsor
        pointAOE(p,p.x,p.y,330,1.9,'shock');alive().forEach(function(e){if(d2(e.x,e.y,p.x,p.y)<330*330)enemyKnock(e,p.x,p.y,220);});break;
      }
      case 29: { // Conductive Grid Overload
        var e29=alive();for(var i29=0;i29<e29.length;i29++){hit(e29[i29],p,2.1);if(typeof arcChain==='function')arcChain(e29[i29],dmg(p,.55),Math.min(7,3+(e29.length>6?3:0)),h);status(e29[i29],'shock',2);}
        addZone(p,{type:'electricfloor',x:p.x,y:p.y,r:Math.max(window.W||1200,window.H||800),t:4,dps:dmg(p,.08),status:'shock'});break;
      }
      case 30: { // Zinc Oxide Regeneration
        (r.players||[]).forEach(function(pl){if(!pl.downed){pl.hp=Math.min(S().hp||120,pl.hp+(S().hp||120)*.2);pl.sh=Math.min((S().shieldMax||90)+20,(pl.sh||0)+20);}});
        if(Array.isArray(r.allies))r.allies.forEach(function(a){a.hp=Math.min(a.maxHp||a.hp||100,(a.hp||0)+(a.maxHp||a.hp||100)*.15);a.v30RegenT=6;});ring(p.x,p.y,h,200);break;
      }
      case 31: { // Gallium Alloy Embrittlement
        var e31=alive();for(var i31=0;i31<e31.length;i31++){var q31=e31[i31];status(q31,'brittle',7);q31.v30TakenAmp=1.6;q31.v30TakenAmpT=7;q31.v30ArmorShredT=7;q31.v30ArmorShred=.60;hit(q31,p,2.0);}break;
      }
      case 32: { // Semiconductor Gate Array
        addZone(p,{type:'gate',x:p.x,y:p.y,r:260,t:5,dps:0,redirectShots:true});break;
      }
      case 33: { // Lethal Toxicity Cascade
        var e33=alive();for(var i33=0;i33<e33.length;i33++){var q33=e33[i33];if(q33.poison){hit(q33,p,6.5);pointAOE(p,q33.x,q33.y,95,2.1,'poison');}}
        break;
      }
      case 34: { // Solar Amplification Nova
        pointAOE(p,p.x,p.y,420,2.0,'stun');globalStatus('stun',2.2,p,.15);playerBuff(p,'crit',1,6);p.v30CritAllT=6;break;
      }
      case 35: { // Fuming Bromine Suffocation
        addZone(p,{type:'bromine',x:t.x,y:t.y,r:360,t:6,dps:dmg(p,.14),status:'confuse',miss:.72});break;
      }
      case 36: { // White Flash Supernova
        var e36=alive();for(var i36=0;i36<e36.length;i36++){var q36=e36[i36];q36.v30BlindT=5;if(!q36.boss&&(q36.tier==='common'||q36.tier==='uncommon'||q36.elite===false))q36.v30PermanentStun=true;status(q36,'stun',q36.boss?2.5:99);}
        clearHostileShots(p.x,p.y,Math.max(window.W||1200,window.H||800));ring(p.x,p.y,h,520);break;
      }
      case 37: { // Alkali Super-Detonation
        pointAOE(p,p.x,p.y,Math.max(window.W||1200,window.H||800),8.5,'burn');clearHostileShots(p.x,p.y,Math.max(window.W||1200,window.H||800));break;
      }
      case 38: { // Strontium Beacon Flare
        r.isoT3.orbits.push({type:'beacon',x:t.x,y:t.y,t:8,r:120,shoot:true,dps:dmg(p,.45),h:h,owner:p.id});alive().forEach(function(e){e.v30AggroPoint={x:t.x,y:t.y};e.v30AggroT=8;});break;
      }
      case 39: { // Superconducting Magnetic Lift
        p.v30FlightT=7;p.v30HazardImmuneT=7;p.v30Airborne=true;playerBuff(p,'speed',1.7,7);playerShield(p,24,0);break;
      }
      case 40: { // Nuclear Cladding Shell
        playerShield(p,50,0);p.v30CladdingT=6;p.v30Retaliation=dmg(p,2.4);break;
      }
      case 41: { // Zero-Resistance Railgun
        fire(p,p.angle||0,1300,7.5,{pierce:999,r:9,life:1.3,kb:3});lineHit(p,1000,15,1.5,'shock');break;
      }
      case 42: { // Moly-Disulfide Slick
        addZone(p,{type:'slick',x:p.x,y:p.y,r:360,t:8,dps:dmg(p,.08),slick:true});break;
      }
      case 43: { // Synthetic Decay Storm
        for(var i43=0;i43<14;i43++){(function(k){delay(p,k*110,function(){var x43=30+Math.random()*((window.W||1200)-60),y43=30+Math.random()*((window.H||800)-60);r.isoT3.fuses.push({x:x43,y:y43,t:.45,life:.45,r:82,dmg:dmg(p,1.7),status:'radiation',h:h});});})(i43);}break;
      }
      case 44: { // Multi-Valence Explosion
        var vals=['burn','shock','corrode','rust','poison','freeze'];for(var i44=0;i44<vals.length;i44++){(function(k){delay(p,k*120,function(){pointAOE(p,t.x+Math.cos(k)*35,t.y+Math.sin(k)*35,110,1.65,vals[k]);});})(i44);}break;
      }
      case 45: { // Rhodium Plating Nova
        ring(p.x,p.y,h,400);burst(p.x,p.y,h,34);clearHostileShots(p.x,p.y,Math.max(window.W||1200,window.H||800));globalStatus('stun',2,p,.1);break;
      }
      case 46: { // Hydrogen Fusion Eruption
        pointAOE(p,p.x,p.y,420,7.8,'burn');clearHostileShots(p.x,p.y,420);break;
      }
      case 47: { // Sterling Silver Tempest
        for(var i47=0;i47<28;i47++){var ang47=i47/28*TAU;fire(p,ang47,1150,2.1,{pierce:999,r:3,life:1.45,kb:.7});}break;
      }
      case 48: { // Heavy Metal Bio-Accumulation
        alive().forEach(function(e){var mh=Number(e.maxHp||e.hp||100);e.maxHp=Math.max(1,mh*.78);e.hp=Math.min(e.hp,e.maxHp);status(e,'weaken',9);});break;
      }
      case 49: { // Cryogenic Solder Bind
        addZone(p,{type:'weld',x:t.x,y:t.y,r:150,t:7,dps:dmg(p,.15),status:'freeze',root:7});alive().forEach(function(e){if(d2(e.x,e.y,t.x,t.y)<150*150){e.v30RootT=7;e.v30WeldT=7;}});break;
      }
      case 50: { // Bronze Alloy Vanguard
        if(Array.isArray(r.allies)){r.allies.forEach(function(a){if(a.summonType==='tin'||a.type==='tin'||a.befriendSource==='tin'){a.v30Bronze=true;a.dmg=(a.dmg||10)*1.8;a.maxHp=(a.maxHp||a.hp||50)*1.7;a.hp=Math.min(a.maxHp,a.hp+20);}});}ring(p.x,p.y,h,160);break;
      }
      case 51: { // Flame-Retardant Barrier
        playerShield(p,44,1.2);p.v30FireproofT=7;p.v30ExplosionImmuneT=7;clearHostileShots(p.x,p.y,240);break;
      }
      case 52: { // Toxic Garlic Miasma
        addZone(p,{type:'miasma',x:p.x,y:p.y,r:330,t:7,dps:dmg(p,.3),status:'confuse'});break;
      }
      case 53: { // Thyroid Energy Overload
        p.v30SpeedMult=2;p.v30SpeedT=6;p.dashCd=0;p.v30DashRecoveryT=6;p.puTimer=Math.max(p.puTimer||0,6);ring(p.x,p.y,h,135);break;
      }
      case 54: { // Noble Stasis Field
        addZone(p,{type:'stasis',x:t.x,y:t.y,r:300,t:3,dps:0,status:'freeze',freezeShots:true});break;
      }
      case 55: { // Hyper-Alkali Water Eruption
        addZone(p,{type:'water',x:t.x,y:t.y,r:120,t:4,dps:0,status:'drenched'});delay(p,900,function(){pointAOE(p,t.x,t.y,200,4.4,'shock');alive().forEach(function(e){if(d2(e.x,e.y,t.x,t.y)<200*200)enemyKnock(e,t.x,t.y,120);});});break;
      }
      case 56: { // Baryte Shield Fortress
        r.isoT3.walls.push({x:t.x,y:t.y,angle:(p.angle||0)+Math.PI/2,len:360,t:9,h:h,shield:130});playerShield(p,36,0);break;
      }
      case 57: { // Lanthanide Optical Flare
        lineHit(p,840,18,6.0,'burn');break;
      }
      case 58: { // Pyrophoric Firestorm
        addZone(p,{type:'firestorm',x:p.x,y:p.y,r:320,t:6,dps:dmg(p,.55),status:'burn'});break;
      }
      case 59: { // Green Spectrum Overdrive
        fan(p,11,.95,900,1.35,{pierce:5,life:1.6});p.v30ProjectileSpeedMult=1.8;p.v30ProjectileSpeedT=6;playerBuff(p,'damage',Math.max(p.puDamage||1,1.12),6);break;
      }
      case 60: { // Magnetic Crush Nova
        var e60=alive();var cx60=p.x,cy60=p.y;for(var i60=0;i60<e60.length;i60++){var q60=e60[i60],a60=Math.atan2(cy60-q60.y,cx60-q60.x);q60.x+=Math.cos(a60)*140;q60.y+=Math.sin(a60)*140;}delay(p,700,function(){pointAOE(p,cx60,cy60,260,5.2,'shock');});break;
      }
      case 61: { // Nuclear Micro-Battery Pulse
        p.activeCd=0;p.dashCd=0;p.v30CooldownRefreshFlashT=1.2;ring(p.x,p.y,h,170);break;
      }
      case 62: { // Neutron Absorbing Mesh
        playerShield(p,60,0);p.v30ShieldFromDamageT=6;p.v30AbsorbDamageT=6;break;
      }
      case 63: { // Phosphor Resonance Cascade
        alive().forEach(function(e){if(e.mark||e.v30PhosphorMark){e.mark=0;pointAOE(p,e.x,e.y,105,2.4,'burn');e.v30PhosphorMark=0;}});break;
      }
      case 64: { // MRI Contrast Scan
        alive().forEach(function(e){e.v30WeakPointT=8;e.v30CritTaken=3;e.mark=Math.max(e.mark||0,8);e.flash=.35;});p.v30CritDamageBoost=3;ring(p.x,p.y,h,520);break;
      }
      case 65: { // Terfenol-D Impact Stomp
        pointAOE(p,p.x,p.y,360,2.6,'shock');alive().forEach(function(e){if(d2(e.x,e.y,p.x,p.y)<360*360){e.v30AirborneT=1.4;enemyKnock(e,p.x,p.y,170);}});break;
      }
      case 66: { // Magnetic Hardness Lock
        p.v30StatusImmuneT=7;p.iframes=Math.max(p.iframes||0,.8);playerShield(p,28,.8);break;
      }
      case 67: { // Flux Concentrator Vortex
        addZone(p,{type:'gravity',x:t.x,y:t.y,r:230,t:4,pull:190,dps:dmg(p,.38),status:'brittle'});break;
      }
      case 68: { // Pink Erbium Shimmer
        playerShield(p,70,0);p.v30LaserImmuneT=6;p.v30ProjectileDeflectT=6;ring(p.x,p.y,h,150);break;
      }
      case 69: { // Thulium Fiber Cannon
        lineHit(p,1100,16,8.5,null);alive().forEach(function(e){if(!e.boss&&d2(e.x,e.y,p.x,p.y)<1150*1150)hit(e,p,12);});ring(p.x,p.y,h,280);break;
      }
      case 70: { // Fiber Laser Melter
        lineHit(p,950,22,4.0,'burn');alive().forEach(function(e){if(e.boss&&d2(e.x,e.y,p.x,p.y)<1000*1000){e.v30BossArmorT=5;e.v30BossArmor=.55;hit(e,p,5.5);}});break;
      }
      case 71: { // Apex Lanthanide Lance
        fire(p,p.angle||0,1450,7.2,{pierce:999,r:9,life:1.6,kb:2.2});break;
      }
      case 72: { // Hafnium Carbide Plasma
        lineHit(p,750,34,5.0,'burn');addZone(p,{type:'plasma',x:t.x,y:t.y,r:120,t:4,dps:dmg(p,.3),status:'burn'});break;
      }
      case 73: { // Corrosion-Proof Bulwark
        playerShield(p,50,0);p.v30AcidImmuneT=8;p.v30StatusImmuneT=8;if(Array.isArray(r.allies))r.allies.forEach(function(a){a.v30AcidImmuneT=8;a.v30Shield=(a.v30Shield||0)+30;});r.isoT3.walls.push({x:p.x+Math.cos(p.angle)*100,y:p.y+Math.sin(p.angle)*100,angle:(p.angle||0)+Math.PI/2,len:300,t:8,h:h,shield:90});break;
      }
      case 74: { // Incandescent Filament Nova
        ring(p.x,p.y,h,400);clearHostileShots(p.x,p.y,400);alive().forEach(function(e){if(d2(e.x,e.y,p.x,p.y)<400*400){status(e,'stun',2);status(e,'burn',4);}});break;
      }
      case 75: { // Refractory Thermal Jet
        p.x=clamp(p.x+Math.cos(p.angle)*260,28,(window.W||1200)-28);p.y=clamp(p.y+Math.sin(p.angle)*260,28,(window.H||800)-28);lineHit({x:p.x-Math.cos(p.angle)*260,y:p.y-Math.sin(p.angle)*260,angle:p.angle},280,36,2.6,'burn');break;
      }
      case 76: { // Colossal Mass Collapse
        pointAOE(p,p.x,p.y,420,6.2,'shock');alive().forEach(function(e){if(d2(e.x,e.y,p.x,p.y)<420*420)enemyKnock(e,p.x,p.y,240);});break;
      }
      case 77: { // Corrosion-Immune Hull
        p.v30StatusImmuneT=8;p.v30AcidImmuneT=8;playerShield(p,40,.5);break;
      }
      case 78: { // Catalytic Exhaust Nova
        var got78=clearHostileShots(p.x,p.y,Math.max(window.W||1200,window.H||800));playerShield(p,Math.max(25,got78*2.2),.4);ring(p.x,p.y,h,360);break;
      }
      case 79: { // Golden Touch Petrification
        var e79=alive().sort(function(a,b){return d2(a.x,a.y,p.x,p.y)-d2(b.x,b.y,p.x,p.y);})[0];if(e79){e79.v30GoldT=8;e79.v30Petrified=true;status(e79,'freeze',8);e79.v30CoinValue=25;if(!e79.boss)r.coins=(r.coins||0)+25;ring(e79.x,e79.y,48,65);}break;
      }
      case 80: { // Quicksilver Surge
        var ox80=p.x,oy80=p.y;p.x=clamp(p.x+Math.cos(p.angle)*330,28,(window.W||1200)-28);p.y=clamp(p.y+Math.sin(p.angle)*330,28,(window.H||800)-28);lineHit({x:ox80,y:oy80,angle:p.angle},330,58,3.7,'slow');alive().forEach(function(e){if(d2(e.x,e.y,p.x,p.y)<160*160)enemyKnock(e,p.x,p.y,130);});break;
      }
      case 81: { // Execution Poison Burst
        alive().forEach(function(e){if(e.poison){hit(e,p,7.2);pointAOE(p,e.x,e.y,120,1.8,'poison');}});break;
      }
      case 82: { // Bunker Down
        playerShield(p,70,0);p.puArmor=Math.max(p.puArmor||0,.8);p.v30BunkerT=5;p.puTimer=Math.max(p.puTimer||0,5);break;
      }
      case 83: { // Iridescent Crystal Maze
        var pts=[];for(var i83=0;i83<9;i83++){var ang83=i83/9*TAU;pts.push({x:t.x+Math.cos(ang83)*130,y:t.y+Math.sin(ang83)*130});}
        for(var j83=0;j83<pts.length;j83++){addZone(p,{type:'crystal',x:pts[j83].x,y:pts[j83].y,r:70,t:8,dps:dmg(p,.32),status:'brittle'});ring(pts[j83].x,pts[j83].y,(h+j83*38)%360,70);}break;
      }
      case 84: { // Lethal Heat Source
        addZone(p,{type:'radioheat',x:p.x,y:p.y,r:380,t:5,dps:dmg(p,.8),status:'burn'});break;
      }
      case 85: { // Ephemeral Decay Blast
        r.isoT3.fuses.push({x:p.x,y:p.y,t:1.2,life:1.2,r:520,dmg:dmg(p,10),status:'burn',h:h});break;
      }
      case 86: { // Heavy Gas Suffocation
        addZone(p,{type:'radon',x:p.x,y:p.y,r:Math.max(window.W||1200,window.H||800)*.65,t:6,dps:dmg(p,.25),status:'silence'});break;
      }
      case 87: { // Francium Cataclysm
        pointAOE(p,p.x,p.y,Math.max(window.W||1200,window.H||800),9.5,'shock');for(var i87=0;i87<8;i87++){(function(k){delay(p,120+k*80,function(){var a87=k/8*TAU;pointAOE(p,p.x+Math.cos(a87)*160,p.y+Math.sin(a87)*160,120,2.1,'burn');});})(i87);}break;
      }
      case 88: { // Radium Burn Nova
        pointAOE(p,p.x,p.y,420,3.6,'burn');alive().forEach(function(e){if(d2(e.x,e.y,p.x,p.y)<420*420)status(e,'burn',99,dmg(p,.5));});break;
      }
      case 89: { // Nuclear Core Meltdown
        addZone(p,{type:'radwave',x:p.x,y:p.y,r:450,t:5,dps:dmg(p,.72),status:'poison'});ring(p.x,p.y,h,280);break;
      }
      case 90: { // Fertile Breeder Blast
        fire(p,p.angle||0,700,3.2,{pierce:3,r:10,life:1.2,expl:true});delay(p,500,function(){pointAOE(p,t.x,t.y,230,4.5,'burn');for(var k90=0;k90<5;k90++){var a90=k90/5*TAU;r.isoT3.fuses.push({x:t.x+Math.cos(a90)*120,y:t.y+Math.sin(a90)*120,t:.35,life:.35,r:85,dmg:dmg(p,1.7),status:'shock',h:h});}});break;
      }
      case 91: { // Superheavy Chain Detonation
        alive().forEach(function(e){if(e.v30DecayChain||e.compMarks||e.decayChain){pointAOE(p,e.x,e.y,115,3.8,'shock');e.v30DecayChain=0;e.decayChain=0;}});break;
      }
      case 92: { // Supercritical Fission Burst
        addZone(p,{type:'fission',x:t.x,y:t.y,r:90,t:5,dps:dmg(p,.42),status:'burn',expand:true});r.isoT3.fuses.push({x:t.x,y:t.y,t:5,life:5,r:280,dmg:dmg(p,5.8),status:'shock',h:h});break;
      }
      case 93: { // Neptunium Pulse Nova
        pointAOE(p,p.x,p.y,Math.max(window.W||1200,window.H||800),2.7,'poison');alive().forEach(function(e){if(e.type==='ghost')e.invuln=false;});break;
      }
      case 94: { // Thermonuclear Overdrive
        alive().forEach(function(e){standardKill(e,p,20);});clearHostileShots(p.x,p.y,Math.max(window.W||1200,window.H||800));ring(p.x,p.y,h,720);break;
      }
      case 95: { // Alpha Beam Sweep
        lineHit(p,900,90,5.4,'burn');break;
      }
      case 96: { // Thermoelectric Power Surge
        p.v30HeatPowerT=8;playerBuff(p,'damage',Math.max(p.puDamage||1,1.45),8);playerBuff(p,'speed',1,8);p.puTimer=Math.max(p.puTimer||0,8);ring(p.x,p.y,h,145);break;
      }
      case 97: { // Targeted Radio-Burst
        for(var i97=0;i97<6;i97++){(function(k){delay(p,k*110,function(){var es=alive();if(!es.length)return;var e97=es[k%es.length];r.isoT3.fuses.push({x:e97.x,y:e97.y,t:.22,life:.22,r:100,dmg:dmg(p,3.2),status:'poison',h:h});});})(i97);}break;
      }
      case 98: { // Dense Neutron Beam
        lineHit(p,1100,24,6.8,null);break;
      }
      case 99: { // Quantum Confusion Nova
        globalStatus('confuse',5,p,.15);pointAOE(p,p.x,p.y,Math.max(window.W||1200,window.H||800),1.9,'confuse');break;
      }
      case 100: { // Thermonuclear Ivy Nova
        alive().forEach(function(e){if(!e.boss)standardKill(e,p,16);else hit(e,p,8);});clearHostileShots(p.x,p.y,Math.max(window.W||1200,window.H||800));ring(p.x,p.y,h,700);break;
      }
      case 101: { // Mendeleev Resonance Burst
        var cycle=[1,8,14,17,26,29,53,79,92,118];for(var i101=0;i101<cycle.length;i101++){var hh=hue(cycle[i101]);pointAOE(p,p.x+Math.cos(i101/10*TAU)*120,p.y+Math.sin(i101/10*TAU)*120,110,1.45,i101%3===0?'burn':i101%3===1?'shock':'corrode');ring(p.x+Math.cos(i101/10*TAU)*120,p.y+Math.sin(i101/10*TAU)*120,hh,72);}break;
      }
      case 102: { // Peace Sanctuary Field
        addZone(p,{type:'sanctuary',x:p.x,y:p.y,r:390,t:7,dps:0,status:'silence',silence:true});break;
      }
      case 103: { // Heavy Ion Cannon
        fire(p,p.angle||0,1200,8.2,{pierce:999,r:11,life:1.7,kb:4});lineHit(p,1050,18,2.3,'rust');alive().forEach(function(e){if(e.boss&&d2(e.x,e.y,p.x,p.y)<1100*1100){e.v30ArmorCrushT=6;e.v30ArmorCrush=.72;}});break;
      }
      case 104: { // Nuclear Model Overdrive
        p.v30KnockbackMult=5;p.v30KineticT=7;fan(p,7,.55,760,1.8,{pierce:4,kb:5,life:1.5});break;
      }
      case 105: { // Cluster Fission Storm
        for(var i105=0;i105<12;i105++){(function(k){delay(p,k*70,function(){var a105=Math.random()*TAU;fire(p,a105,850,1.65,{pierce:4,expl:true,life:1.5,r:6});});})(i105);}break;
      }
      case 106: { // Superheavy Meltdown
        addZone(p,{type:'reactor',x:p.x,y:p.y,r:300,t:4.5,dps:dmg(p,.9),status:'burn'});r.isoT3.fuses.push({x:p.x,y:p.y,t:4.5,life:4.5,r:460,dmg:dmg(p,8.8),status:'shock',h:h});break;
      }
      case 107: { // Bohr Model Wave
        var speed107=Math.hypot(p.vx||0,p.vy||0);var mult107=1+clamp(speed107/600,0,2.5);lineHit(p,900,55,2.2*mult107,'shock');p.v30MomentumPower=mult107;break;
      }
      case 108: { // Gravitational Collapse
        addZone(p,{type:'blackhole',x:t.x,y:t.y,r:175,t:4,pull:250,dps:dmg(p,.55),status:'brittle'});delay(p,4000,function(){pointAOE(p,t.x,t.y,260,7.4,'shock');});break;
      }
      case 109: { // Chaos Matrix Pulse
        var pool=['burn','poison','corrode','rust','freeze','shock','brittle','confuse'];alive().forEach(function(e){for(var z109=0;z109<3;z109++){status(e,pool[((e._chaosIdx||0)+z109+109)%pool.length],4,dmg(p,.2));}e._chaosIdx=((e._chaosIdx||0)+1)%pool.length;});pointAOE(p,p.x,p.y,340,2.4,null);break;
      }
      case 110: { // Darmstadt Impact Sabot
        fire(p,p.angle||0,1350,10.5,{pierce:999,r:10,life:1.5,kb:2.8});alive().forEach(function(e){if(!e.boss&&d2(e.x,e.y,p.x,p.y)<1100*1100)e.v30Sabot=true;});break;
      }
      case 111: { // High-Dose X-Ray Flash
        ring(p.x,p.y,h,560);alive().forEach(function(e){e.v30BlindT=5;e.v30WeakPointT=5;e.v30RadiatedT=5;e.mark=Math.max(e.mark||0,5);status(e,'poison',5,dmg(p,.35));});clearHostileShots(p.x,p.y,Math.max(window.W||1200,window.H||800));break;
      }
      case 112: { // Volatile Liquid Metal Wave
        var ox112=p.x,oy112=p.y;p.x=clamp(p.x+Math.cos(p.angle)*300,28,(window.W||1200)-28);p.y=clamp(p.y+Math.sin(p.angle)*300,28,(window.H||800)-28);lineHit({x:ox112,y:oy112,angle:p.angle},300,70,3.3,'rust');alive().forEach(function(e){if(d2(e.x,e.y,p.x,p.y)<200*200)enemyKnock(e,p.x,p.y,150);});break;
      }
      case 113: { // Nihonium Super-Detonation
        alive().forEach(function(e){if(e.mark||e.v30NihoniumMark){e.mark=0;e.v30NihoniumMark=0;pointAOE(p,e.x,e.y,130,5.6,'burn');}});break;
      }
      case 114: { // Flerovium Kinetic Cannon
        fire(p,p.angle||0,1050,11.5,{pierce:999,r:16,life:2.0,kb:6,main:true});ring(p.x,p.y,h,70);break;
      }
      case 115: { // Element 115 Plasma Overdrive
        p.v30AntiGravityT=6;playerBuff(p,'rate',2.0,6);p.v30ProjectileSpeedMult=2;p.v30ProjectileSpeedT=6;playerBuff(p,'damage',Math.max(p.puDamage||1,1.2),6);break;
      }
      case 116: { // Decay Sludge Eruption
        var e116=alive();for(var i116=0;i116<e116.length;i116++){var q116=e116[i116];if(q116.v30SludgePods&&q116.v30SludgePods>0){var pods=q116.v30SludgePods;q116.v30SludgePods=0;pointAOE(p,q116.x,q116.y,90+pods*10,2.4+pods*.5,'poison');}}
        break;
      }
      case 117: { // Tennessine Halide Nova
        alive().forEach(function(e){if(e.poison){pointAOE(p,e.x,e.y,125,5.0,'burn');e.poison=null;}});break;
      }
      case 118: { // Oganesson Cosmological Collapse
        var sx118=t.x,sy118=t.y;addZone(p,{type:'cosmic',x:sx118,y:sy118,r:220,t:3.8,pull:310,dps:dmg(p,.65),status:'brittle'});r.isoT3.fuses.push({x:sx118,y:sy118,t:3.8,life:3.8,r:360,dmg:dmg(p,12),status:'shock',h:h});r.shake=Math.max(r.shake||0,15);break;
      }
      default: {
        /* No default should be reached after the 118-item installation audit. */
        console.error('ISO V30 missing Ability 3 executor for element',n);
      }
    }
    p.__isoT3Last=n;
  }

  function updateT3(dt){
    var r=R();if(!r||!r.isoT3)return;
    var now=r.t||0;
    r.isoT3.zones=(r.isoT3.zones||[]).filter(function(z){
      z.t-=dt;z.__tick=(z.__tick||0)-dt;
      if(z.__tick<=0){
        z.__tick=.16;
        var es=alive();
        var gateShots=r.ebullets&&Array.isArray(r.ebullets)?r.ebullets:[];
        if(z.nullify||z.freezeShots||z.reverseShots||z.redirectShots){
          for(var gi=gateShots.length-1;gi>=0;gi--){
            var gb=gateShots[gi];
            if(!gb||d2(gb.x,gb.y,z.x,z.y)>=z.r*z.r)continue;
            if(z.nullify){gateShots.splice(gi,1);continue;}
            if(z.reverseShots&&!gb.v30Reversed){
              gb.v30Reversed=true;
              var rs=RUN.players.find(function(q){return q.id===z.owner;})||RUN.players[0];
              r.bullets.push({x:gb.x,y:gb.y,vx:-gb.vx,vy:-gb.vy,dmg:(gb.dmg||10)*1.15,r:5,pierce:2,hit:[],life:1.25,owner:rs?rs.id:0,crit:true});
              gateShots.splice(gi,1);continue;
            }
            if(z.redirectShots){
              var rp=RUN.players.find(function(q){return q.id===z.owner;})||RUN.players[0];
              if(rp){var ra=Math.atan2(gb.y-rp.y,gb.x-rp.x),rspeed=Math.max(220,Math.hypot(gb.vx,gb.vy));gb.vx=Math.cos(ra)*rspeed;gb.vy=Math.sin(ra)*rspeed;}
            }
            if(z.freezeShots){gb.vx*=.05;gb.vy*=.05;gb.v30Frozen=true;}
          }
        }
        for(var i=0;i<es.length;i++){
          var e=es[i],inside=d2(e.x,e.y,z.x,z.y)<Math.pow((z.r||100)+e.r,2);
          if(!inside)continue;
          if(z.dps)hit(e,(r.players||[]).find(function(q){return q.id===z.owner;})||r.players[0]||{puDamage:1},z.dps/(Number(S().dmg)||14));
          if(z.status)status(e,z.status,z.status==='freeze'?1.0:.8,dmg(r.players&&r.players[0]||{puDamage:1},.18));
          if(z.root)e.v30RootT=Math.max(e.v30RootT||0,z.root);
          if(z.pull){var aa=Math.atan2(z.y-e.y,z.x-e.x),step=Math.min(z.pull*dt,22);e.x+=Math.cos(aa)*step;e.y+=Math.sin(aa)*step;}
          if(z.type==='slick'){e.v30SlickT=z.t;e.v30Slick=true;}
          if(z.type==='bromine')e.v30MissMul=z.miss||.72;
          if(z.type==='reverse')e.v30MagnetFrozenT=z.t;
          if(z.type==='sanctuary'||z.silence)status(e,'silence',.5);
          if(z.type==='cryo'||z.type==='stasis'||z.type==='weld'||z.type==='radon'){
            if(z.freezeShots&&Array.isArray(r.ebullets))r.ebullets.forEach(function(b){if(d2(b.x,b.y,z.x,z.y)<z.r*z.r){b.v30Frozen=true;b.vx*=.02;b.vy*=.02;}});
          }
          if(z.type==='water')status(e,'drenched',2);
          if(z.type==='fission'||z.type==='reactor')e.v30DecayChain=1;
          if(z.type==='electricfloor'&&typeof arcChain==='function')arcChain(e,dmg(r.players&&r.players[0]||{puDamage:1},.25),3,z.h);
        }
      }
      return z.t>0;
    });
    r.isoT3.fuses=(r.isoT3.fuses||[]).filter(function(f){
      f.t-=dt;
      if(f.t<=0){var es=alive(),owner=(r.players||[]).find(function(q){return q.id===f.owner;})||r.players[0]||{puDamage:1};for(var i=0;i<es.length;i++){if(d2(es[i].x,es[i].y,f.x,f.y)<(f.r+es[i].r)*(f.r+es[i].r)){hit(es[i],owner,f.dmg/(Number(S().dmg)||14));if(f.status)status(es[i],f.status,4);}}ring(f.x,f.y,f.h,f.r);burst(f.x,f.y,f.h,30);return false;}return true;
    });
    r.isoT3.beams=(r.isoT3.beams||[]).filter(function(b){
      b.t-=dt;var owner=(r.players||[]).find(function(q){return q.id===b.owner;})||r.players[0];if(!owner)return false;
      b.x=owner.x;b.y=owner.y;
      var a=b.angle,co=Math.cos(a),si=Math.sin(a),es=alive();
      for(var i=0;i<es.length;i++){var e=es[i],dx=e.x-b.x,dy=e.y-b.y,tt=dx*co+dy*si;if(tt>=0&&tt<=b.len){var px=b.x+co*tt,py=b.y+si*tt;if(d2(e.x,e.y,px,py)<(b.w+e.r)*(b.w+e.r)){hit(e,owner,b.dmg/(Number(S().dmg)||14)*dt*5);if(b.status)status(e,b.status,.45);}}}
      return b.t>0;
    });
    r.isoT3.orbits=(r.isoT3.orbits||[]).filter(function(o){
      o.t-=dt;if(o.t<=0)return false;
      if(o.type==='beacon'){var es=alive();for(var i=0;i<es.length;i++){if(d2(es[i].x,es[i].y,o.x,o.y)<o.r*o.r){es[i].v30AggroPoint={x:o.x,y:o.y};hit(es[i],(r.players||[]).find(function(q){return q.id===o.owner;})||r.players[0],.18);status(es[i],'burn',1.2);}}}
      return true;
    });
    r.isoT3.walls=(r.isoT3.walls||[]).filter(function(w){w.t-=dt;return w.t>0;});

    /* Temporary player-side buffs/flags. */
    (r.players||[]).forEach(function(p){
      ['v30StatusImmuneT','v30DamageImmuneT','v30KnockImmuneT','v30DeflectT','v30MirrorT','v30ConvertDamageT','v30FlightT','v30HazardImmuneT','v30CladdingT','v30SpeedT','v30DashRecoveryT','v30CritAllT','v30LaserImmuneT','v30ProjectileDeflectT','v30AntiGravityT','v30ProjectileSpeedT','v30BunkerT','v30CooldownRefreshFlashT','v30HeatPowerT','v30ShieldFromDamageT','v30AbsorbDamageT','v30KineticT'].forEach(function(k){if(typeof p[k]==='number'&&p[k]>0)p[k]=Math.max(0,p[k]-dt);});
      if(p.v30GuaranteedCritT>0){p.v30GuaranteedCritT=Math.max(0,p.v30GuaranteedCritT);p.puCrit=1;}
      if(p.v30CritAllT<=0&&p.v30GuaranteedCritT<=0&&p.puTimer<=0)p.puCrit=0;
    });

    alive().forEach(function(e){
      ['v30WeakenT','v30ArmorShredT','v30TakenAmpT','v30BossArmorT','v30ArmorCrushT','v30RootT','v30WeldT','v30BlindT','v30RadiatedT','v30WeakPointT','v30AggroT','v30SlickT','v30MissT','v30PhosphorMarkT','v30DecayChainT'].forEach(function(k){if(typeof e[k]==='number'&&e[k]>0)e[k]=Math.max(0,e[k]-dt);});
      if(e.v30TakenAmpT<=0)e.v30TakenAmp=0;
      if(e.v30ArmorShredT<=0)e.v30ArmorShred=0;
      if(e.v30BossArmorT<=0)e.v30BossArmor=0;
      if(e.v30ArmorCrushT<=0)e.v30ArmorCrush=0;
    });

    /* Nicotine/ally-safe flags: allies are never part of hostile effect loops. */
    if(Array.isArray(r.allies))r.allies.forEach(function(a){a.v30TeamSafe=true;});
  }
  function renderT3(){
    var r=R();if(!r||typeof cx==='undefined'||!r.isoT3)return;
    var arr=r.isoT3.zones||[];
    for(var i=0;i<arr.length;i++){var z=arr[i];cx.save();cx.globalCompositeOperation='lighter';cx.strokeStyle='hsla('+(z.h||190)+',95%,70%,.32)';cx.lineWidth=2;cx.beginPath();cx.arc(z.x,z.y,z.r||90,0,TAU);cx.stroke();if(z.type==='crystal'||z.type==='cosmic'){cx.fillStyle='hsla('+(z.h||190)+',95%,65%,.05)';cx.fill();}cx.restore();}
    (r.isoT3.beams||[]).forEach(function(b){cx.save();cx.globalCompositeOperation='lighter';cx.strokeStyle='hsla('+(b.h||190)+',100%,75%,.15)';cx.lineWidth=b.w*3;cx.beginPath();cx.moveTo(b.x,b.y);cx.lineTo(b.x+Math.cos(b.angle)*b.len,b.y+Math.sin(b.angle)*b.len);cx.stroke();cx.strokeStyle='hsla('+(b.h||190)+',100%,92%,.95)';cx.lineWidth=Math.max(2,b.w);cx.beginPath();cx.moveTo(b.x,b.y);cx.lineTo(b.x+Math.cos(b.angle)*b.len,b.y+Math.sin(b.angle)*b.len);cx.stroke();cx.restore();});
    (r.isoT3.fuses||[]).forEach(function(f){var prog=1-Math.max(0,f.t)/Math.max(.001,f.life),rate=3+18*Math.pow(prog,2.2);cx.save();cx.strokeStyle='hsla('+(f.h||190)+',100%,75%,'+(.45+.45*Math.abs(Math.sin((r.t||0)*rate)))+')';cx.lineWidth=2.5;cx.beginPath();cx.arc(f.x,f.y,f.r*(.35+.65*prog),0,TAU);cx.stroke();cx.restore();});
    (r.isoT3.walls||[]).forEach(function(w){var co=Math.cos(w.angle),si=Math.sin(w.angle),hx=w.h||190;cx.save();cx.globalCompositeOperation='lighter';cx.strokeStyle='hsla('+hx+',95%,76%,.75)';cx.lineWidth=10;cx.beginPath();cx.moveTo(w.x-co*w.len/2,w.y-si*w.len/2);cx.lineTo(w.x+co*w.len/2,w.y+si*w.len/2);cx.stroke();cx.strokeStyle='hsla('+hx+',100%,95%,.9)';cx.lineWidth=2;cx.stroke();cx.restore();});
  }

  function install(){
    if(!window.DATA||!DATA.ELEMS)return;
    var count=0,missing=[];
    Object.values(DATA.ELEMS).forEach(function(el){
      var n=Number(el.n);if(n<1||n>118)return;
      var list=el.choices||el.signatures||[];
      if(!list[2]){missing.push(n);return;}
      var choice=list[2],name=choice.name,desc=choice.desc;
      choice.exec=function(p){executeThird(n,p);};
      choice.slot=2;choice.main=false;choice.implemented=true;choice.v30TertiaryContract=true;choice.v30TertiaryElement=n;
      /* Preserve the player's displayed ability exactly. */
      choice.name=name;choice.desc=desc;
      list[2]=choice;el.choices=list;el.signatures=list;
      count++;
    });
    DATA.ISO_ELEMENT_THIRD_V30_AUDIT=function(){
      var out=[];Object.values(DATA.ELEMS).forEach(function(el){var c=el.choices&&el.choices[2];out.push({n:Number(el.n),name:el.name,ability:c&&c.name,description:c&&c.desc,implemented:!!(c&&c.v30TertiaryContract&&typeof c.exec==='function')});});return out;
    };
    DATA.ISO_ELEMENT_THIRD_V30_RUN=function(n,p){return executeThird(Number(n),p);};
    console.log('ISO_ELEMENT_THIRD_V30 active:',count,'/118 Ability 3 executors installed. Missing:',missing);
    if(missing.length)console.error('ISO_ELEMENT_THIRD_V30 missing ability 3 entries',missing);
  }

  install();

  var oldUpdate=window.update;
  if(typeof oldUpdate==='function'&&!window.__ISO_T3_V30_UPDATE__){
    window.__ISO_T3_V30_UPDATE__=true;
    window.update=function(dt){oldUpdate(dt);updateT3(dt);};
  }
  var oldRender=window.render;
  if(typeof oldRender==='function'&&!window.__ISO_T3_V30_RENDER__){
    window.__ISO_T3_V30_RENDER__=true;
    window.render=function(){oldRender();renderT3();};
  }

  /* Give delayed abilities an isolated run token. A run cleanup/new run gets a
     new token so scheduled third-ability effects can never leak into another
     round. */
  var oldStart=window.start;
  if(typeof oldStart==='function'&&!window.__ISO_T3_V30_START__){
    window.__ISO_T3_V30_START__=true;
    window.start=function(){var out=oldStart.apply(this,arguments);if(window.RUN){RUN.__isoT3Token=String(Date.now())+'_'+String(Math.random());RUN.isoT3=RUN.isoT3||{zones:[],beams:[],fuses:[],orbits:[],walls:[]};}return out;};
  }
  console.log('ISO_ELEMENT_THIRD_V30 loaded: all 118 base-element Ability 3 slots now execute through dedicated description-matched contracts.');
})();
