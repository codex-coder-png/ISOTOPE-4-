/* ISOTOPE V92 — Chromebook Periodic Vault interaction repair
   - Keeps locked element tiles selectable so the normal purchase panel can open.
   - Forces the periodic-table hover grow/shrink effect to remain available after
     the later Vault/QoL layers inject their own styles.
   - Uses touch/pointer-friendly properties without changing game mechanics.
*/
'use strict';
(function(){
  if(window.__ISO_V92_CHROMEBOOK_VAULT__) return;
  window.__ISO_V92_CHROMEBOOK_VAULT__=true;

  var style=document.createElement('style');
  style.id='iso-v92-chromebook-vault-style';
  style.textContent=`
    #scr-vault #ptable .pt[data-id]{
      pointer-events:auto!important;
      cursor:pointer!important;
      touch-action:manipulation!important;
      -webkit-tap-highlight-color:transparent;
      will-change:transform;
    }
    #scr-vault #ptable .pt[data-id]:hover{
      transform:scale(1.18)!important;
      z-index:25!important;
      box-shadow:0 6px 18px rgba(0,0,0,.6)!important;
    }
    #scr-vault #ptable .pt[data-id].affordable:hover{
      transform:translateY(-1px) scale(1.18)!important;
    }
  `;
  document.head.appendChild(style);

  function repair(){
    var scr=document.getElementById('scr-vault');
    if(!scr || scr.classList.contains('hidden')) return;
    document.querySelectorAll('#scr-vault #ptable .pt[data-id]').forEach(function(tile){
      tile.style.pointerEvents='auto';
      tile.style.cursor='pointer';
      tile.style.touchAction='manipulation';
      tile.removeAttribute('aria-disabled');
    });
  }

  if(window.UI&&typeof UI.show==='function'&&!UI.__v92ChromebookVault){
    var base=UI.show;
    UI.show=function(id){
      var out=base.apply(this,arguments);
      if(id==='scr-vault'){
        requestAnimationFrame(repair);
        setTimeout(repair,60);
      }
      return out;
    };
    UI.__v92ChromebookVault=true;
  }

  document.addEventListener('click',function(ev){
    var b=ev.target&&ev.target.closest?ev.target.closest('[data-go="scr-vault"]'):null;
    if(b){setTimeout(repair,20);setTimeout(repair,120);}
  },true);

  repair();
  console.log('ISOTOPE V92 Chromebook Vault interaction repair active.');
})();
