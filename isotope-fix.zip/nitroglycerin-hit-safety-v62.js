/* ISOTOPE V62 — NITROGLYCERIN HIT SAFETY
   Ensures Nitroglycerin projectiles always carry collision state and guards the
   shared updater against malformed legacy/custom bullets. */
(function(){
  'use strict';
  var KEY='__ISO_NITRO_HIT_SAFETY_V62__';
  if(window[KEY]) return;
  window[KEY]=true;

  function ensureBullet(b){
    if(!b || typeof b!=='object') return false;
    if(!Array.isArray(b.hit)) b.hit=[];
    if(!Number.isFinite(b.x)) b.x=0;
    if(!Number.isFinite(b.y)) b.y=0;
    if(!Number.isFinite(b.vx)) b.vx=0;
    if(!Number.isFinite(b.vy)) b.vy=0;
    if(!Number.isFinite(b.r)) b.r=4;
    if(!Number.isFinite(b.life)) b.life=0;
    if(!Number.isFinite(b.dmg)) b.dmg=(window.ST&&Number(ST.dmg))||1;
    return true;
  }

  function patchArray(){
    try{
      if(!window.RUN || !Array.isArray(RUN.bullets)) return;
      for(var i=0;i<RUN.bullets.length;i++) ensureBullet(RUN.bullets[i]);
    }catch(e){ console.warn('V62 bullet normalization',e); }
  }

  if(window.RUN && Array.isArray(RUN.bullets)) patchArray();
  window.ISOTOPE_NITRO_HIT_SAFETY={ensureBullet:ensureBullet,patchArray:patchArray};
  console.log('ISOTOPE V62 NITRO HIT SAFETY active — projectile collision arrays normalized.');
})();
